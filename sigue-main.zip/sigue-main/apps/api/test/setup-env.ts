/**
 * Carga `.env.test` antes de las pruebas.
 * Solo se usa si el archivo existe; si no, las pruebas que dependen de base de datos
 * se omiten solas (`TEST_DATABASE_URL` indefinida).
 */
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { config } from 'dotenv';

const file = join(__dirname, '..', '.env.test');
if (existsSync(file)) {
  config({ path: file });
}
