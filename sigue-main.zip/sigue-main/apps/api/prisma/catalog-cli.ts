/**
 * Carga del catálogo normativo en un entorno sin datos de demostración.
 *
 * En producción **no** se puede ejecutar `prisma db seed`: ese script crea
 * usuarios con la contraseña pública `demo-password`. Este comando carga solo
 * lo que todo entorno necesita (normas, cláusulas, proveedores de IA y, si ya
 * existe alguna organización, sus plantillas propietarias).
 *
 * Uso:
 *
 *     npm run db:catalog --workspace @sigue/api
 *
 * Conecta con `DIRECT_URL` (rol dueño) porque el catálogo es global y el rol de
 * aplicación solo tiene lectura sobre él. Es idempotente.
 */
import { PrismaClient } from '@prisma/client';
import { config } from 'dotenv';
import { seedCatalog } from './catalog';

config();

const url = process.env.DIRECT_URL ?? process.env.DATABASE_URL;
if (!url) {
  console.error('Falta DIRECT_URL (o DATABASE_URL) para conectar a la base.');
  process.exit(1);
}

const prisma = new PrismaClient({ datasourceUrl: url });

async function main() {
  console.log('→ Cargando catálogo normativo...');
  const ids = await seedCatalog(prisma, console.log);
  console.log(`✓ Catálogo listo: ${Object.keys(ids).length} normas.`);
}

main()
  .catch((error) => {
    console.error('✖ Error cargando el catálogo:', error);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
