/**
 * Catálogo normativo compartido por el seed de demo y el aprovisionamiento de
 * producción.
 *
 * `prisma db seed` crea usuarios con contraseña conocida: no puede ejecutarse en
 * producción. Pero el catálogo (normas, cláusulas y proveedores de IA) sí es
 * necesario en cualquier entorno, y las plantillas propietarias también para
 * cada organización existente. Este módulo aísla esa parte, de modo que
 * `npm run db:catalog` la cargue sin tocar datos de demostración.
 *
 * Todo es idempotente: se apoya en upserts por clave natural (código de norma,
 * código de cláusula, nombre de proveedor).
 */
import type { PrismaClient } from '@prisma/client';
import { ISO9001_CLAUSES, type ClauseSeed } from './iso9001-data';
import { ISO20000_CLAUSES } from './iso20000-data';
import { ISO22301_CLAUSES } from './iso22301-data';
import { ISO27001_CLAUSES } from './iso27001-data';
import { ISO37001_CLAUSES } from './iso37001-data';
import { ISO42001_CLAUSES } from './iso42001-data';
import { SIGUE_TEMPLATES } from '../src/common/templates/templates-data';
// Las plantillas se siembran igual desde el CLI y desde el panel de plataforma.
import { seedTemplates } from '../src/common/templates/seed-templates';

export { seedTemplates };

export interface CatalogStandard {
  code: string;
  title: string;
  edition: string;
  year: number;
  clauses: ClauseSeed[];
  /** Origen del contenido, para el resumen del comando. */
  note?: string;
}

export const CATALOG_STANDARDS: CatalogStandard[] = [
  {
    code: 'ISO9001',
    title: 'Sistemas de gestión de la calidad',
    edition: '2015',
    year: 2015,
    clauses: ISO9001_CLAUSES,
  },
  {
    code: 'ISO27001',
    title: 'Seguridad de la información',
    edition: '2022',
    year: 2022,
    clauses: ISO27001_CLAUSES,
    note: 'incluye los 93 controles del Anexo A',
  },
  {
    code: 'ISO22301',
    title: 'Continuidad del negocio',
    edition: '2019',
    year: 2019,
    clauses: ISO22301_CLAUSES,
  },
  {
    code: 'ISO42001',
    title: 'Sistemas de gestión de la inteligencia artificial',
    edition: '2023',
    year: 2023,
    clauses: ISO42001_CLAUSES,
  },
  {
    code: 'ISO20000',
    title: 'Gestión de servicios de TI',
    edition: '2018',
    year: 2018,
    clauses: ISO20000_CLAUSES,
    note: 'SGS con los procesos de la cláusula 8',
  },
  {
    code: 'ISO37001',
    title: 'Sistemas de gestión antisoborno',
    edition: '2025',
    year: 2025,
    clauses: ISO37001_CLAUSES,
    note: 'controles operativos de la cláusula 8',
  },
];

/** Carga (o actualiza) el árbol de cláusulas de una norma. */
async function seedClauses(prisma: PrismaClient, standardId: string, clauses: ClauseSeed[]) {
  for (const c of clauses) {
    await prisma.standardClause.upsert({
      where: { standardId_code: { standardId, code: c.code } },
      update: {
        title: c.title,
        kind: c.kind,
        requirementText: c.requirementText,
        weight: c.weight,
        sortOrder: c.sortOrder,
      },
      create: {
        standardId,
        code: c.code,
        title: c.title,
        kind: c.kind,
        requirementText: c.requirementText,
        weight: c.weight,
        sortOrder: c.sortOrder,
      },
    });
  }
}

/** Proveedores y modelos de IA registrados (el mock es el único activo sin claves). */
async function seedAiProviders(prisma: PrismaClient) {
  const mock = await prisma.aiProvider.upsert({
    where: { name: 'mock' },
    update: {},
    create: { name: 'mock', displayName: 'Proveedor simulado (desarrollo)', status: 'ACTIVE' },
  });
  await prisma.aiModel.upsert({
    where: { providerId_name: { providerId: mock.id, name: 'sigue-sim-1' } },
    update: {},
    create: {
      providerId: mock.id,
      name: 'sigue-sim-1',
      version: '1.0',
      capabilities: { text: true, structured: true, vision: false },
      costPer1k: { input: 0.001, output: 0.002 },
      status: 'ACTIVE',
    },
  });

  // Los proveedores externos quedan registrados pero inactivos: sin credenciales
  // no deben recibir tráfico.
  const azureOpenAi = await prisma.aiProvider.upsert({
    where: { name: 'azure-openai' },
    update: {},
    create: { name: 'azure-openai', displayName: 'Azure OpenAI', status: 'INACTIVE' },
  });
  await prisma.aiModel.upsert({
    where: { providerId_name: { providerId: azureOpenAi.id, name: 'gpt-4o-mini' } },
    update: {},
    create: {
      providerId: azureOpenAi.id,
      name: 'gpt-4o-mini',
      version: '2024-11-20',
      capabilities: { text: true, vision: true },
      costPer1k: { input: 0.00015, output: 0.0006 },
    },
  });
}

/**
 * Siembra el catálogo global y las plantillas de las organizaciones existentes.
 * Devuelve el id de cada norma por código (`ISO9001`, `ISO27001`, …).
 */
export async function seedCatalog(
  prisma: PrismaClient,
  logger: (message: string) => void = () => {},
): Promise<Record<string, string>> {
  const ids: Record<string, string> = {};

  for (const std of CATALOG_STANDARDS) {
    const row = await prisma.standard.upsert({
      where: { code: std.code },
      update: { title: std.title, edition: std.edition, year: std.year },
      create: { code: std.code, title: std.title, edition: std.edition, year: std.year },
    });
    await seedClauses(prisma, row.id, std.clauses);
    ids[std.code] = row.id;
    logger(
      `  ✔ ${std.code}:${std.edition} con ${std.clauses.length} cláusulas/requisitos` +
        (std.note ? ` (${std.note})` : ''),
    );
  }

  await seedAiProviders(prisma);
  logger('  ✔ Proveedores de IA registrados (mock activo, Azure OpenAI inactivo)');

  // Las plantillas cuelgan de una organización. En un entorno recién creado aún
  // no hay ninguna; volver a ejecutar el comando tras crear la organización
  // las carga sin duplicar nada.
  const orgs = await prisma.organization.findMany({ select: { id: true } });
  for (const org of orgs) {
    await seedTemplates(prisma, org.id);
  }
  logger(
    orgs.length > 0
      ? `  ✔ ${SIGUE_TEMPLATES.length} plantillas propietarias en ${orgs.length} organización(es)`
      : '  ℹ Sin organizaciones todavía: las plantillas se cargarán al volver a ejecutar el comando',
  );

  return ids;
}
