// Datos de la norma ISO/IEC 42001:2023 (redacción propia — sin copiar texto de la norma).
// Cláusulas 4..10 + controles del Anexo A.

import type { ClauseSeed } from './iso9001-data';

let order = 0;
const clause = (code: string, title: string): ClauseSeed => ({
  code,
  title,
  kind: 'clause',
  weight: 1,
  sortOrder: ++order,
});
const requirement = (code: string, title: string, requirementText: string, weight = 2): ClauseSeed => ({
  code,
  title,
  requirementText,
  kind: 'requirement',
  weight,
  sortOrder: ++order,
});

export const ISO42001_CLAUSES: ClauseSeed[] = [
  // --- Cláusula 4: Contexto de la organización ---
  clause('4', 'Contexto de la organización'),
  requirement('4.1', 'Comprensión de la organización y su contexto', 'Determinar las cuestiones internas y externas pertinentes al uso y desarrollo de la IA.'),
  requirement('4.2', 'Partes interesadas y expectativas', 'Identificar las partes interesadas pertinentes a los sistemas de IA y sus expectativas.'),

  // --- Cláusula 5: Liderazgo ---
  clause('5', 'Liderazgo'),
  requirement('5.1', 'Liderazgo y compromiso', 'La alta dirección debe demostrar liderazgo y compromiso con el sistema de gestión de IA.'),
  requirement('5.2', 'Política de IA', 'Establecer una política de IA alineada con los valores, propósito y contexto de la organización.', 3),

  // --- Cláusula 6: Planificación ---
  clause('6', 'Planificación'),
  requirement(
    '6.1',
    'Acciones para abordar riesgos y oportunidades de la IA',
    'Determinar los riesgos y oportunidades asociados a los sistemas de IA y planificar acciones.',
    3,
  ),
  requirement('6.2', 'Evaluación de impacto de la IA', 'Evaluar el impacto de los sistemas de IA en individuos, grupos y la organización.', 3),

  // --- Cláusula 7: Soporte ---
  clause('7', 'Soporte'),
  requirement('7.5', 'Información documentada', 'Controlar la información documentada del sistema de gestión de IA.'),

  // --- Cláusula 8: Operación ---
  clause('8', 'Operación'),
  requirement(
    '8.2',
    'Procesos del ciclo de vida de los sistemas de IA',
    'Planificar y controlar los procesos del ciclo de vida de los sistemas de IA (diseño, desarrollo, despliegue, monitoreo, retiro).',
    3,
  ),

  // --- Cláusula 9: Evaluación del desempeño ---
  clause('9', 'Evaluación del desempeño'),
  requirement('9.2', 'Auditoría interna', 'Realizar auditorías internas del sistema de gestión de IA.'),

  // --- Cláusula 10: Mejora ---
  clause('10', 'Mejora'),
  requirement('10.2', 'No conformidad y acción correctiva', 'Gestionar las no conformidades del sistema de IA y verificar la eficacia de las acciones.', 3),

  // --- Anexo A: controles ---
  clause('A', 'Controles del Anexo A'),
  requirement('A.2', 'Políticas internas de IA', 'Definir políticas internas que guíen el desarrollo y uso de los sistemas de IA.'),
  requirement('A.3', 'Sistema de gestión interno', 'Establecer un sistema de gestión interno para la responsabilidad de la IA.'),
  requirement('A.4', 'Proceso de ciclo de vida', 'Gestionar el ciclo de vida completo de los sistemas de IA con controles.', 3),
  requirement('A.5', 'Datos para el desarrollo de sistemas de IA', 'Asegurar la calidad, legalidad y minimización de los datos usados en el desarrollo.', 3),
  requirement('A.9', 'Privacidad', 'Proteger la privacidad en el diseño y operación de los sistemas de IA.', 3),
  requirement('A.10', 'Transparencia', 'Comunicar de forma transparente el uso de IA y sus limitaciones.'),
  requirement('A.11', 'Responsabilidad', 'Asignar responsabilidades claras para cada sistema de IA.'),
  requirement('A.12', 'Medición del impacto', 'Medir y evaluar el impacto de los sistemas de IA.'),
  requirement('A.13', 'Impactos adversos', 'Identificar y gestionar los impactos adversos de los sistemas de IA.', 3),
  requirement('A.14', 'Evaluación', 'Evaluar el desempeño y los riesgos de los sistemas de IA.'),
];
