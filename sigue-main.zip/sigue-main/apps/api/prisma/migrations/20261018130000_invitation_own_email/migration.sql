-- Fin del acceso concedido (independiente de la caducidad del enlace).
-- La invitación caduca en 7 días; el acceso del consultor puede durar meses.
ALTER TABLE "Invitation" ADD COLUMN "accessEnd" TIMESTAMP(3);

-- Un usuario autenticado puede ver las invitaciones dirigidas a su propio correo
-- aunque todavía no pertenezca a la organización (necesario para aceptarlas).
-- Las políticas permisivas se combinan con OR: no amplía el acceso a otras
-- invitaciones ni a datos de la organización.
CREATE POLICY "invitation_for_own_email" ON "Invitation"
FOR SELECT
USING (
  lower("email") = (
    SELECT lower(u."email") FROM "User" u
    WHERE u."id" = current_setting('app.user_id', true)
  )
);
