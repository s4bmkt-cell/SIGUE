-- Ciclo de vida de las invitaciones: quién invita, quién acepta y cuándo.

ALTER TABLE "Invitation" ADD COLUMN "invitedById" TEXT;
ALTER TABLE "Invitation" ADD COLUMN "acceptedById" TEXT;
ALTER TABLE "Invitation" ADD COLUMN "acceptedAt" TIMESTAMP(3);
ALTER TABLE "Invitation" ADD COLUMN "revokedAt" TIMESTAMP(3);
ALTER TABLE "Invitation" ADD COLUMN "lastSentAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- Un correo no puede tener dos invitaciones pendientes en la misma organización.
CREATE UNIQUE INDEX "Invitation_orgId_email_pending_key"
  ON "Invitation"("orgId", "email")
  WHERE "status" = 'PENDING';

CREATE INDEX "Invitation_email_status_idx" ON "Invitation"("email", "status");
