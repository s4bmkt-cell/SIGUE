-- Eventos de auditoría sin actor identificado (p. ej. intento de login con un
-- correo inexistente). Se pueden **escribir**, pero no leer por la API: la
-- política de lectura exige organización o actor propio.
DROP POLICY IF EXISTS "tenant_isolation_AuditLog_insert_anonymous" ON "AuditLog";
CREATE POLICY "tenant_isolation_AuditLog_insert_anonymous" ON "AuditLog"
FOR INSERT
WITH CHECK ("orgId" IS NULL AND "actorId" IS NULL);
