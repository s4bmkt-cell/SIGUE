-- La Declaración de Aplicabilidad deja de ser exclusiva de ISO/IEC 27001.
--
-- ISO/IEC 42001 también tiene un Anexo A normativo y exige declarar la
-- aplicabilidad de sus controles, así que cada fila queda ligada a su norma.
-- Los datos existentes (el seed solo creaba controles A.x de 27001) se asignan
-- a esa norma antes de hacer la columna obligatoria.

ALTER TABLE "StatementOfApplicability" ADD COLUMN "standardId" TEXT;

-- Backfill: toda SOA previa pertenece a ISO/IEC 27001. Si la norma aún no está
-- en el catálogo, la fila queda con NULL y la migración falla al final, que es
-- el comportamiento deseado: no se adivina a qué norma pertenece un control.
UPDATE "StatementOfApplicability" soa
SET "standardId" = s."id"
FROM "Standard" s
WHERE s."code" = 'ISO27001'
  AND soa."standardId" IS NULL;

-- La clave única anterior era (orgId, controlCode); con dos normas puede haber
-- el mismo código en ambas, así que se amplía con la norma.
DROP INDEX IF EXISTS "StatementOfApplicability_orgId_controlCode_key";
CREATE UNIQUE INDEX "StatementOfApplicability_orgId_standardId_controlCode_key"
  ON "StatementOfApplicability"("orgId", "standardId", "controlCode");
CREATE INDEX "StatementOfApplicability_standardId_idx"
  ON "StatementOfApplicability"("standardId");

ALTER TABLE "StatementOfApplicability" ALTER COLUMN "standardId" SET NOT NULL;

ALTER TABLE "StatementOfApplicability"
  ADD CONSTRAINT "StatementOfApplicability_standardId_fkey"
  FOREIGN KEY ("standardId") REFERENCES "Standard"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- RLS: la política por `app.org_id` ya existía y sigue vigente; solo se
-- confirma que el rol de aplicación conserva el DML sobre la tabla.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sigue_app') THEN
    EXECUTE 'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE "StatementOfApplicability" TO "sigue_app"';
  END IF;
END $$;
