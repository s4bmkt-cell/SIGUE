-- Varios FODA y varios PESTEL por organización.
--
-- Antes cada elemento era una fila suelta del tenant (`ContextSwot` /
-- `ContextPestel`) y solo cabía un análisis implícito. Ahora cada elemento
-- pertenece a un análisis con nombre, descripción y periodo, de modo que la
-- organización puede mantener uno por año, sede o línea de negocio.
--
-- El orden importa: se crean primero los contenedores, luego se añade la
-- columna como NULL, se agrupa lo existente en un análisis «general» por
-- organización y solo entonces se vuelve obligatoria.

-- CreateTable
CREATE TABLE "ContextSwotAnalysis" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "period" TEXT,
    "ownerId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ContextSwotAnalysis_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ContextPestelAnalysis" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "period" TEXT,
    "ownerId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ContextPestelAnalysis_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ContextSwotAnalysis_orgId_idx" ON "ContextSwotAnalysis"("orgId");

-- CreateIndex
CREATE INDEX "ContextPestelAnalysis_orgId_idx" ON "ContextPestelAnalysis"("orgId");

-- AddForeignKey
ALTER TABLE "ContextSwotAnalysis" ADD CONSTRAINT "ContextSwotAnalysis_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ContextPestelAnalysis" ADD CONSTRAINT "ContextPestelAnalysis_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- La columna entra opcional para poder rellenarla con los datos existentes.
ALTER TABLE "ContextSwot" ADD COLUMN "analysisId" TEXT;
ALTER TABLE "ContextPestel" ADD COLUMN "analysisId" TEXT;

-- Backfill: un análisis «general» por organización con elementos. El id se
-- deriva de la organización para que la migración sea reproducible y no
-- dependa de `gen_random_uuid()` (que exigiría pgcrypto).
INSERT INTO "ContextSwotAnalysis" ("id", "orgId", "name", "description", "updatedAt")
SELECT DISTINCT
  'swot-' || s."orgId",
  s."orgId",
  'FODA general',
  'Análisis creado al habilitar varios FODA por organización. Renómbralo o crea uno nuevo.',
  CURRENT_TIMESTAMP
FROM "ContextSwot" s
WHERE NOT EXISTS (
  SELECT 1 FROM "ContextSwotAnalysis" a WHERE a."id" = 'swot-' || s."orgId"
);

UPDATE "ContextSwot"
SET "analysisId" = 'swot-' || "orgId"
WHERE "analysisId" IS NULL;

INSERT INTO "ContextPestelAnalysis" ("id", "orgId", "name", "description", "updatedAt")
SELECT DISTINCT
  'pestel-' || p."orgId",
  p."orgId",
  'PESTEL general',
  'Análisis creado al habilitar varios PESTEL por organización. Renómbralo o crea uno nuevo.',
  CURRENT_TIMESTAMP
FROM "ContextPestel" p
WHERE NOT EXISTS (
  SELECT 1 FROM "ContextPestelAnalysis" a WHERE a."id" = 'pestel-' || p."orgId"
);

UPDATE "ContextPestel"
SET "analysisId" = 'pestel-' || "orgId"
WHERE "analysisId" IS NULL;

-- Con el backfill hecho, la pertenencia a un análisis pasa a ser obligatoria.
ALTER TABLE "ContextSwot" ALTER COLUMN "analysisId" SET NOT NULL;
ALTER TABLE "ContextPestel" ALTER COLUMN "analysisId" SET NOT NULL;

-- CreateIndex
CREATE INDEX "ContextSwot_analysisId_idx" ON "ContextSwot"("analysisId");

-- CreateIndex
CREATE INDEX "ContextPestel_analysisId_idx" ON "ContextPestel"("analysisId");

-- AddForeignKey
ALTER TABLE "ContextSwot" ADD CONSTRAINT "ContextSwot_analysisId_fkey" FOREIGN KEY ("analysisId") REFERENCES "ContextSwotAnalysis"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ContextPestel" ADD CONSTRAINT "ContextPestel_analysisId_fkey" FOREIGN KEY ("analysisId") REFERENCES "ContextPestelAnalysis"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- ===== Row-Level Security =====
-- Mismo aislamiento por `app.org_id` que el resto de tablas del tenant, forzado
-- también para el dueño de la tabla.
ALTER TABLE "ContextSwotAnalysis" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ContextSwotAnalysis" FORCE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_ContextSwotAnalysis" ON "ContextSwotAnalysis"
  USING ("orgId" = current_setting('app.org_id', true))
  WITH CHECK ("orgId" = current_setting('app.org_id', true));

ALTER TABLE "ContextPestelAnalysis" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ContextPestelAnalysis" FORCE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_ContextPestelAnalysis" ON "ContextPestelAnalysis"
  USING ("orgId" = current_setting('app.org_id', true))
  WITH CHECK ("orgId" = current_setting('app.org_id', true));

-- Privilegios mínimos del rol de aplicación. En una base recién creada el rol
-- aún no existe (lo aprovisiona `db:setup-role`), de ahí la comprobación.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sigue_app') THEN
    EXECUTE 'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE "ContextSwotAnalysis" TO "sigue_app"';
    EXECUTE 'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE "ContextPestelAnalysis" TO "sigue_app"';
  END IF;
END $$;
