-- Administrador de plataforma.
--
-- `admin_global` llevaba tiempo declarado en los `@RequireRoles` de varias rutas
-- (billing, audit, export, users, consultant) y leído por la web, pero **no había
-- forma de asignarlo**: no está en el catálogo `ORG_ROLES`, los DTOs lo rechazan
-- con `@IsIn` y `resolveRoles` solo lee `OrgMember.roles`. Era un rol inerte.
--
-- Se resuelve con un atributo del usuario y no con una membresía porque el
-- administrador de la plataforma no pertenece a las organizaciones que
-- administra: darle una membresía lo haría además miembro del inquilino, con
-- acceso al contenido del SGI de ese cliente.

ALTER TABLE "User" ADD COLUMN "isPlatformAdmin" BOOLEAN NOT NULL DEFAULT false;

-- ===== RLS para el panel =====
--
-- `Organization` ya tiene RLS (y `sigue_app` sin `DELETE`). Para que el panel
-- pueda listar **todas** las empresas hace falta abrir una rendija explícita,
-- no desactivar el aislamiento: se usa el GUC `app.platform`, que solo fija
-- `withTenant({ platform: true })` desde el módulo de plataforma.
--
-- Las políticas se **suman** a las existentes (en PostgreSQL las permisivas se
-- combinan con OR), así que ninguna ruta normal cambia de comportamiento: sin
-- el GUC, `current_setting('app.platform', true)` es NULL y la comparación no
-- es verdadera. Es una condición más restrictiva que "sin RLS": el aislamiento
-- por inquilino sigue intacto para todo lo demás.
CREATE POLICY "platform_read_Organization" ON "Organization"
  FOR SELECT
  USING (current_setting('app.platform', true) = 'true');

CREATE POLICY "platform_insert_Organization" ON "Organization"
  FOR INSERT
  WITH CHECK (current_setting('app.platform', true) = 'true');

CREATE POLICY "platform_update_Organization" ON "Organization"
  FOR UPDATE
  USING (current_setting('app.platform', true) = 'true')
  WITH CHECK (current_setting('app.platform', true) = 'true');

-- Las métricas del panel (usuarios, normas, almacenamiento, consumo) viven en
-- tablas de inquilino. Solo lectura: el panel nunca escribe datos de negocio de
-- una organización, y mucho menos su contenido.
CREATE POLICY "platform_read_OrgMember" ON "OrgMember"
  FOR SELECT USING (current_setting('app.platform', true) = 'true');

CREATE POLICY "platform_read_Subscription" ON "Subscription"
  FOR SELECT USING (current_setting('app.platform', true) = 'true');

CREATE POLICY "platform_read_OrgStandard" ON "OrgStandard"
  FOR SELECT USING (current_setting('app.platform', true) = 'true');

CREATE POLICY "platform_read_EvidenceFile" ON "EvidenceFile"
  FOR SELECT USING (current_setting('app.platform', true) = 'true');

CREATE POLICY "platform_read_OrgUsage" ON "OrgUsage"
  FOR SELECT USING (current_setting('app.platform', true) = 'true');

-- El alta de una organización se hace desde la API, con el rol de aplicación:
-- se le concede `INSERT`. El `DELETE` sigue revocado a propósito —dar de baja
-- es suspender, no borrar— y el `UPDATE` ya lo tenía.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sigue_app') THEN
    EXECUTE 'GRANT INSERT ON TABLE "Organization" TO "sigue_app"';
  END IF;
END $$;
