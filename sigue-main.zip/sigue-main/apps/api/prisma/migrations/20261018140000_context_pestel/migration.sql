-- Análisis PESTEL del contexto de la organización (ISO 4.1).
-- Mismo patrón que ContextSwot: una fila por factor, con su dimensión e impacto.
CREATE TABLE "ContextPestel" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "impact" TEXT NOT NULL DEFAULT 'NEUTRO',
    "text" TEXT NOT NULL,
    "ownerId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ContextPestel_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ContextPestel_orgId_idx" ON "ContextPestel"("orgId");

-- AddForeignKey
ALTER TABLE "ContextPestel" ADD CONSTRAINT "ContextPestel_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- ===== Row-Level Security =====
-- Aislamiento por `app.org_id`, forzado también para el dueño de la tabla.
ALTER TABLE "ContextPestel" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ContextPestel" FORCE ROW LEVEL SECURITY;
CREATE POLICY "tenant_isolation_ContextPestel" ON "ContextPestel"
  USING ("orgId" = current_setting('app.org_id', true))
  WITH CHECK ("orgId" = current_setting('app.org_id', true));

-- Privilegios mínimos del rol de aplicación. En una base recién creada el rol
-- aún no existe (lo aprovisiona `db:setup-role`), de ahí la comprobación.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sigue_app') THEN
    EXECUTE 'GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE "ContextPestel" TO "sigue_app"';
  END IF;
END $$;
