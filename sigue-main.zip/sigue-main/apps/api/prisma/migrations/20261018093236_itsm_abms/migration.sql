-- CreateTable
CREATE TABLE "ServiceCatalog" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "category" TEXT NOT NULL DEFAULT 'SOPORTE',
    "criticality" TEXT NOT NULL DEFAULT 'MEDIA',
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "ownerId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ServiceCatalog_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ServiceLevelAgreement" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "serviceCode" TEXT NOT NULL,
    "customer" TEXT NOT NULL,
    "responseHours" INTEGER NOT NULL DEFAULT 4,
    "resolutionHours" INTEGER NOT NULL DEFAULT 24,
    "availabilityPct" DECIMAL(5,2) NOT NULL DEFAULT 99.5,
    "status" TEXT NOT NULL DEFAULT 'ACTIVE',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ServiceLevelAgreement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ServiceRequest" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "folio" TEXT NOT NULL,
    "serviceCode" TEXT,
    "type" TEXT NOT NULL DEFAULT 'INCIDENT',
    "title" TEXT NOT NULL,
    "description" TEXT,
    "priority" TEXT NOT NULL DEFAULT 'MEDIA',
    "status" TEXT NOT NULL DEFAULT 'OPEN',
    "reportedById" TEXT,
    "assigneeId" TEXT,
    "resolvedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ServiceRequest_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BriberyRiskAssessment" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "area" TEXT NOT NULL,
    "activity" TEXT NOT NULL,
    "likelihood" INTEGER NOT NULL DEFAULT 1,
    "impact" INTEGER NOT NULL DEFAULT 1,
    "score" INTEGER NOT NULL DEFAULT 1,
    "mitigation" TEXT,
    "status" TEXT NOT NULL DEFAULT 'ASSESSED',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BriberyRiskAssessment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BriberyControl" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "code" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "status" TEXT NOT NULL DEFAULT 'PLANNED',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BriberyControl_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BriberyIncident" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "severity" TEXT NOT NULL DEFAULT 'MEDIA',
    "status" TEXT NOT NULL DEFAULT 'OPEN',
    "resolution" TEXT,
    "reportedById" TEXT,
    "detectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BriberyIncident_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ServiceCatalog_orgId_idx" ON "ServiceCatalog"("orgId");

-- CreateIndex
CREATE UNIQUE INDEX "ServiceCatalog_orgId_code_key" ON "ServiceCatalog"("orgId", "code");

-- CreateIndex
CREATE INDEX "ServiceLevelAgreement_orgId_idx" ON "ServiceLevelAgreement"("orgId");

-- CreateIndex
CREATE INDEX "ServiceRequest_orgId_idx" ON "ServiceRequest"("orgId");

-- CreateIndex
CREATE UNIQUE INDEX "ServiceRequest_orgId_folio_key" ON "ServiceRequest"("orgId", "folio");

-- CreateIndex
CREATE INDEX "BriberyRiskAssessment_orgId_idx" ON "BriberyRiskAssessment"("orgId");

-- CreateIndex
CREATE INDEX "BriberyControl_orgId_idx" ON "BriberyControl"("orgId");

-- CreateIndex
CREATE UNIQUE INDEX "BriberyControl_orgId_code_key" ON "BriberyControl"("orgId", "code");

-- CreateIndex
CREATE INDEX "BriberyIncident_orgId_idx" ON "BriberyIncident"("orgId");

-- AddForeignKey
ALTER TABLE "ServiceCatalog" ADD CONSTRAINT "ServiceCatalog_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ServiceLevelAgreement" ADD CONSTRAINT "ServiceLevelAgreement_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ServiceRequest" ADD CONSTRAINT "ServiceRequest_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BriberyRiskAssessment" ADD CONSTRAINT "BriberyRiskAssessment_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BriberyControl" ADD CONSTRAINT "BriberyControl_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BriberyIncident" ADD CONSTRAINT "BriberyIncident_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- ===== Row-Level Security para las tablas nuevas =====
-- Cada tabla de inquilino queda aislada por `app.org_id`; `FORCE` hace que
-- también aplique al dueño de la tabla (defensa en profundidad).
DO $$
DECLARE t TEXT;
BEGIN
  FOREACH t IN ARRAY ARRAY['ServiceCatalog','ServiceLevelAgreement','ServiceRequest','BriberyRiskAssessment','BriberyControl','BriberyIncident']
  LOOP
    EXECUTE format('ALTER TABLE "%s" ENABLE ROW LEVEL SECURITY', t);
    EXECUTE format('ALTER TABLE "%s" FORCE ROW LEVEL SECURITY', t);
    EXECUTE format('CREATE POLICY "tenant_isolation_%s" ON "%s" USING ("orgId" = current_setting(''app.org_id'', true)) WITH CHECK ("orgId" = current_setting(''app.org_id'', true))', t, t);
  END LOOP;
END $$;
