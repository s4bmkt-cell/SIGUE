-- Row-Level Security en "Organization".
--
-- Era la única tabla con datos de inquilino que quedaba **sin** RLS: el rol de
-- aplicación podía leer todas las organizaciones, insertar nuevas y modificar
-- cualquier fila sin fijar `app.org_id`. El código validaba la membresía en cada
-- endpoint, así que no había una fuga explotable por HTTP, pero cualquier ruta
-- futura que olvidara esa comprobación habría quedado expuesta, y la base no
-- aportaba ninguna red de seguridad.
--
-- La política no puede usar el patrón genérico `"orgId" = app.org_id` porque la
-- clave aquí se llama `id`. Además necesita tres casos legítimos:
--   1. Operar sobre la organización activa (`app.org_id`).
--   2. Leer la organización de la que ya se es miembro (la app arranca con
--      `app.user_id` y sin `app.org_id`, p. ej. listar las organizaciones).
--   3. Leer la organización de una invitación pendiente dirigida a mi correo:
--      quien acepta una invitación todavía no es miembro y necesita ver el
--      nombre de la organización en la pantalla de aceptación.
--
-- Las escrituras quedan restringidas a la organización activa (`WITH CHECK`).

-- Los subconsultas a `OrgMember` e `Invitation` quedan sujetas a *sus* políticas,
-- que ya limitan por membresía propia y por correo propio respectivamente: no
-- amplían el acceso de esta política, lo reutilizan.
DROP POLICY IF EXISTS "organization_access" ON "Organization";
CREATE POLICY "organization_access" ON "Organization"
  USING (
    "id" = current_setting('app.org_id', true)
    OR EXISTS (
      SELECT 1 FROM "OrgMember" m
      WHERE m."orgId" = "Organization"."id"
        AND m."userId" = current_setting('app.user_id', true)
        AND m."status" = 'ACTIVE'
    )
    OR EXISTS (
      SELECT 1 FROM "Invitation" i
      WHERE i."orgId" = "Organization"."id"
        AND lower(i."email") = (
          SELECT lower(u."email") FROM "User" u
          WHERE u."id" = current_setting('app.user_id', true)
        )
    )
  )
  WITH CHECK ("id" = current_setting('app.org_id', true));

-- Se habilita aquí y el `FORCE` lo decide `db:setup-role`, igual que en las demás
-- tablas de inquilino: depende de si el dueño tiene `BYPASSRLS`, y en una base
-- gestionada sin ese atributo forzarlo dejaría al seed escribiendo a ciegas.
ALTER TABLE "Organization" ENABLE ROW LEVEL SECURITY;

-- El rol de aplicación nunca crea ni borra organizaciones (`db:provision` y el
-- seed lo hacen con el rol dueño), así que esos dos privilegios se retiran. El
-- UPDATE se conserva porque la app edita el perfil y aplica cambios de plan.
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname = 'sigue_app') THEN
    EXECUTE 'REVOKE INSERT, DELETE ON TABLE "Organization" FROM "sigue_app"';
    EXECUTE 'GRANT SELECT, UPDATE ON TABLE "Organization" TO "sigue_app"';
  END IF;
END $$;
