-- Archivo adjunto del documento y sedes a las que aplica.
--
-- 1) `DocumentFile`: hasta ahora el documento solo tenía texto. La organización
--    suele tener el original (PDF/Word) y necesita cargarlo al darlo de alta;
--    el archivo se guarda en el mismo almacenamiento que las evidencias.
-- 2) `Document.branchIds`: un documento puede aplicar a una sede concreta o a
--    varias. Se guarda como arreglo de ids porque la vista solo lo muestra y lo
--    filtra; una tabla puente añadiría una unión sin aportar nada.

CREATE TABLE "DocumentFile" (
    "id" TEXT NOT NULL,
    "orgId" TEXT NOT NULL,
    "documentId" TEXT NOT NULL,
    "filename" TEXT NOT NULL,
    "blobName" TEXT NOT NULL,
    "size" INTEGER NOT NULL,
    "sha256" TEXT,
    "mime" TEXT,
    "uploadedBy" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "DocumentFile_pkey" PRIMARY KEY ("id")
);

ALTER TABLE "Document" ADD COLUMN "branchIds" TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[];

CREATE INDEX "DocumentFile_orgId_idx" ON "DocumentFile"("orgId");
CREATE INDEX "DocumentFile_documentId_idx" ON "DocumentFile"("documentId");

ALTER TABLE "DocumentFile" ADD CONSTRAINT "DocumentFile_orgId_fkey" FOREIGN KEY ("orgId") REFERENCES "Organization"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "DocumentFile" ADD CONSTRAINT "DocumentFile_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES "Document"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- ===== Row-Level Security para la tabla nueva =====
DO $$
BEGIN
  EXECUTE format('ALTER TABLE "DocumentFile" ENABLE ROW LEVEL SECURITY');
  EXECUTE format('ALTER TABLE "DocumentFile" FORCE ROW LEVEL SECURITY');
  EXECUTE format('CREATE POLICY "tenant_isolation_DocumentFile" ON "DocumentFile" USING ("orgId" = current_setting(''app.org_id'', true)) WITH CHECK ("orgId" = current_setting(''app.org_id'', true))');
END $$;
