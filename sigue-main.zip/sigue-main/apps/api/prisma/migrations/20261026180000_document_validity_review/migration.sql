-- Vigencia, revisión periódica y procedencia externa del documento.
--
-- ISO 27001 7.5.3 e ISO 9001 7.5.2 exigen que la información documentada se
-- revise y vuelva a aprobar cuando se planifica; hasta ahora el sistema no
-- guardaba cuándo caduca ni cuándo toca revisarla, así que el inventario no
-- podía avisar de nada. `Evidence` ya tenía estos campos; el documento no.
--
-- `validityUntil`, `reviewDate`, `sourceProvider` y `sourceRef` entran como
-- NULL: son datos que el control documental puede no haber registrado todavía
-- y forzar un valor inventado falsearía el registro.

ALTER TABLE "Document" ADD COLUMN "validityUntil" TIMESTAMP(3);
ALTER TABLE "Document" ADD COLUMN "reviewDate" TIMESTAMP(3);
ALTER TABLE "Document" ADD COLUMN "sourceProvider" TEXT;
ALTER TABLE "Document" ADD COLUMN "sourceRef" TEXT;

-- Índice compuesto: la consulta habitual de alertas filtra por organización y
-- ordena por fecha de revisión. Separados no sirven para este caso.
CREATE INDEX "Document_orgId_reviewDate_idx" ON "Document"("orgId", "reviewDate");
