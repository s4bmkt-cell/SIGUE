-- Auditoría persistida: cadena de hashes por organización.

-- ===== Encadenamiento =====
-- Se añaden como nulables, se rellenan y luego se vuelven obligatorias, para
-- poder migrar sobre una tabla que ya tenga eventos.
ALTER TABLE "AuditLog" ADD COLUMN "chainKey" TEXT;
ALTER TABLE "AuditLog" ADD COLUMN "seq" INTEGER;

UPDATE "AuditLog"
SET "chainKey" = COALESCE('org:' || "orgId", 'anonymous'),
    "seq" = sub."rn"
FROM (
  SELECT "id", row_number() OVER (
    PARTITION BY COALESCE('org:' || "orgId", 'anonymous')
    ORDER BY "createdAt" ASC, "id" ASC
  ) AS "rn"
  FROM "AuditLog"
) AS sub
WHERE "AuditLog"."id" = sub."id";

ALTER TABLE "AuditLog" ALTER COLUMN "chainKey" SET NOT NULL;
ALTER TABLE "AuditLog" ALTER COLUMN "seq" SET NOT NULL;

-- ===== Cabeza de cada cadena =====
CREATE TABLE "AuditChain" (
    "chainKey" TEXT NOT NULL,
    "lastHash" TEXT NOT NULL,
    "lastSeq" INTEGER NOT NULL DEFAULT 0,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "AuditChain_pkey" PRIMARY KEY ("chainKey")
);

INSERT INTO "AuditChain" ("chainKey", "lastHash", "lastSeq", "updatedAt")
SELECT DISTINCT ON ("chainKey") "chainKey", "hash", "seq", "createdAt"
FROM "AuditLog"
ORDER BY "chainKey", "seq" DESC;

CREATE UNIQUE INDEX "AuditLog_chainKey_seq_key" ON "AuditLog"("chainKey", "seq");
CREATE INDEX "AuditLog_chainKey_seq_idx" ON "AuditLog"("chainKey", "seq");
CREATE INDEX "AuditLog_actorId_idx" ON "AuditLog"("actorId");

-- ===== Inmutabilidad =====
-- La bitácora solo crece. Si alguien con permisos de escritura intenta corregir
-- un evento in situ, el trigger lo impide; si lo consigue por otra vía (p. ej.
-- acceso al disco), la verificación de la cadena lo delata.
CREATE OR REPLACE FUNCTION "audit_log_append_only"() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'AuditLog es append-only: no se permite % sobre eventos ya escritos', TG_OP;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER "AuditLog_append_only"
BEFORE UPDATE OR DELETE ON "AuditLog"
FOR EACH ROW EXECUTE FUNCTION "audit_log_append_only"();

CREATE TRIGGER "AuditChain_append_only"
BEFORE DELETE ON "AuditChain"
FOR EACH ROW EXECUTE FUNCTION "audit_log_append_only"();

-- ===== Aislamiento =====
-- AuditLog admite eventos sin organización (login, recuperación de contraseña):
-- se ven los de la organización activa y los propios del usuario.
ALTER TABLE "AuditLog" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "AuditLog" FORCE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "tenant_isolation_AuditLog" ON "AuditLog";
CREATE POLICY "tenant_isolation_AuditLog" ON "AuditLog"
USING (
  "orgId" = current_setting('app.org_id', true)
  OR ("orgId" IS NULL AND "actorId" = current_setting('app.user_id', true))
)
WITH CHECK (
  "orgId" = current_setting('app.org_id', true)
  OR ("orgId" IS NULL AND "actorId" = current_setting('app.user_id', true))
);

-- `AuditChain` solo guarda hashes y contadores, sin datos de negocio, y no se
-- expone por API: no lleva RLS. Los privilegios del rol de aplicación se
-- conceden en `prisma/setup-app-role.mjs`.

