/**
 * Reparación puntual de la cadena de auditoría.
 *
 * Contexto: antes de corregir `sanitize()`, los valores `Decimal` de Prisma se
 * serializaban por reflexión y arrastraban el código de su `constructor` al
 * cálculo del hash. El evento quedaba guardado con un hash que ya no podía
 * recalcularse al leerlo desde la base (el `constructor` no vuelve a existir
 * como propiedad), así que la verificación lo marcaba como manipulado.
 *
 * Este script **no** corrige contenido: solo reescribe los hashes de los
 * eventos cuyo hash almacenado coincide exactamente con la reconstrucción
 * heredada (con el `constructor` del `Decimal`). Si un evento no coincide ni
 * con la forma heredada, se aborta sin tocar nada: eso sí sería manipulación.
 *
 * Uso (rol dueño de las tablas, el único que puede desactivar el trigger):
 *
 *     node --env-file=.env prisma/audit-repair.mjs [--dry-run]
 */
import { Prisma, PrismaClient } from '@prisma/client';
import { createHash } from 'crypto';
import { canonicalJson, eventPayload } from '../dist/modules/audit/audit-hash.js';

const prisma = new PrismaClient({ datasourceUrl: process.env.DIRECT_URL });
const dryRun = process.argv.includes('--dry-run');

const hashOf = (row) =>
  createHash('sha256')
    .update(
      row.prevHash +
        canonicalJson(
          eventPayload({
            id: row.id,
            chainKey: row.chainKey,
            seq: row.seq,
            orgId: row.orgId,
            actorId: row.actorId,
            action: row.action,
            entity: row.entity,
            entityId: row.entityId,
            before: row.before,
            after: row.after,
            ip: row.ip,
            userAgent: row.userAgent,
            at: row.createdAt.toISOString(),
          }),
        ),
    )
    .digest('hex');

/** Ruta donde se encuentra un `Decimal` serializado como `{s,e,d}`. */
function decimalPaths(value, prefix = []) {
  if (!value || typeof value !== 'object' || prefix.length > 8) return [];
  if (Array.isArray(value)) {
    return value.flatMap((v, i) => decimalPaths(v, [...prefix, i]));
  }
  const keys = Object.keys(value).sort().join(',');
  if (keys === 'd,e,s') return [prefix];
  return Object.entries(value).flatMap(([k, v]) => decimalPaths(v, [...prefix, k]));
}

/** Reconstruye el objeto tal como lo serializaba el código anterior. */
function withLegacyDecimals(value, paths, prefix = []) {
  const here = paths.find((p) => p.length === prefix.length && p.every((x, i) => x === prefix[i]));
  if (here) {
    return {
      constructor: Prisma.Decimal.prototype.constructor,
      s: value.s,
      e: value.e,
      d: value.d,
    };
  }
  if (!value || typeof value !== 'object') return value;
  if (Array.isArray(value)) {
    return value.map((v, i) => withLegacyDecimals(v, paths, [...prefix, i]));
  }
  return Object.fromEntries(
    Object.entries(value).map(([k, v]) => [k, withLegacyDecimals(v, paths, [...prefix, k])]),
  );
}

function legacyHashOf(row) {
  const beforePaths = decimalPaths(row.before);
  const afterPaths = decimalPaths(row.after);
  if (!beforePaths.length && !afterPaths.length) return null;
  const legacy = {
    ...row,
    before: beforePaths.length ? withLegacyDecimals(row.before, beforePaths) : row.before,
    after: afterPaths.length ? withLegacyDecimals(row.after, afterPaths) : row.after,
  };
  return hashOf(legacy);
}

async function main() {
  const rows = await prisma.auditLog.findMany({
    orderBy: [{ chainKey: 'asc' }, { seq: 'asc' }],
  });

  const chains = new Map();
  for (const row of rows) {
    if (!chains.has(row.chainKey)) chains.set(row.chainKey, []);
    chains.get(row.chainKey).push(row);
  }

  const repairs = [];

  for (const [chainKey, events] of chains) {
    let prevHash = events[0]?.prevHash ?? 'GENESIS';
    let needsRechain = false;

    for (const row of events) {
      if (row.prevHash !== prevHash) needsRechain = true;

      const recomputed = hashOf(row);
      if (recomputed !== row.hash) {
        const legacy = legacyHashOf(row);
        if (legacy !== row.hash) {
          console.error(
            `✖ ${chainKey} seq ${row.seq} (${row.action}): hash no coincide ni con la forma heredada. ` +
              'Posible manipulación: no se repara nada.',
          );
          process.exitCode = 1;
          return;
        }
        needsRechain = true;
      }

      if (needsRechain) {
        repairs.push({ chainKey, seq: row.seq, action: row.action, before: row.prevHash, sha: row.hash });
        row.prevHash = prevHash;
        row.hash = hashOf(row);
        // Tras reescribir este evento, los siguientes también cambian.
      }
      prevHash = row.hash;
    }

    if (needsRechain) {
      const head = events[events.length - 1];
      if (head) {
        console.log(`→ ${chainKey}: se reencadena desde el último evento corregido (head seq ${head.seq})`);
      }
    }
  }

  if (!repairs.length) {
    console.log('✔ Todas las cadenas son válidas: nada que reparar.');
    return;
  }

  console.log(`Eventos a reescribir: ${repairs.length}`);
  for (const r of repairs.slice(0, 20)) {
    console.log(`  · ${r.chainKey} seq ${r.seq} ${r.action}`);
  }
  if (dryRun) {
    console.log('(--dry-run: no se escribió nada)');
    return;
  }

  for (const [chainKey, events] of chains) {
    const touched = repairs.some((r) => r.chainKey === chainKey);
    if (!touched) continue;

    await prisma.$transaction(async (tx) => {
      await tx.$executeRawUnsafe('ALTER TABLE "AuditLog" DISABLE TRIGGER "AuditLog_append_only"');
      for (const row of events) {
        await tx.$executeRaw`
          UPDATE "AuditLog"
          SET "prevHash" = ${row.prevHash}, "hash" = ${row.hash}
          WHERE "id" = ${row.id}
        `;
      }
      await tx.$executeRawUnsafe('ALTER TABLE "AuditLog" ENABLE TRIGGER "AuditLog_append_only"');
      await tx.auditChain.update({
        where: { chainKey },
        data: { lastHash: events[events.length - 1].hash, lastSeq: events.length },
      });
    });

    console.log(`✔ ${chainKey} reparada (${events.length} eventos reencadenados)`);
  }
}

main()
  .catch((error) => {
    console.error(error);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
