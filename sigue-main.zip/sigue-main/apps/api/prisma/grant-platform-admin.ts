/**
 * Concede (o retira) el rol de administrador de plataforma a una cuenta.
 *
 * Es el **único** camino para obtener el rol: no hay endpoint que lo asigne, ni
 * `POST /auth/register` ni `POST /orgs/users` ni el panel lo tocan. Sin esta
 * puerta cerrada, cualquiera con acceso a la API podría ascender su cuenta y ver
 * el catálogo de todas las empresas.
 *
 * Uso:
 *
 *     npm run db:platform-admin --workspace @sigue/api -- --email admin@sign.mx
 *     npm run db:platform-admin --workspace @sigue/api -- --email admin@sign.mx --revoke
 *     npm run db:platform-admin --workspace @sigue/api -- --list
 *
 * Conecta con `DIRECT_URL` (rol dueño): `User` no lleva RLS, pero la aplicación
 * no debe poder escribir esta columna, y usar el rol dueño deja explícito que es
 * una operación de operador. Es idempotente.
 */
import { PrismaClient } from '@prisma/client';
import { config } from 'dotenv';

config();

const url = process.env.DIRECT_URL ?? process.env.DATABASE_URL;
if (!url) {
  console.error('Falta DIRECT_URL (o DATABASE_URL) para conectar a la base.');
  process.exit(1);
}

const prisma = new PrismaClient({ datasourceUrl: url });

interface Options {
  email?: string;
  revoke: boolean;
  list: boolean;
}

function parseArgs(argv: string[]): Options {
  const flags = new Set(argv.filter((a) => a.startsWith('--')).map((a) => a.slice(2)));
  const emailIndex = argv.indexOf('--email');
  const email = emailIndex >= 0 ? argv[emailIndex + 1] : undefined;
  return {
    email: email?.trim().toLowerCase(),
    revoke: flags.has('revoke'),
    list: flags.has('list'),
  };
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));

  if (opts.list) {
    const admins = await prisma.user.findMany({
      where: { isPlatformAdmin: true },
      select: { id: true, email: true, name: true, status: true, lastLoginAt: true },
      orderBy: { email: 'asc' },
    });
    if (!admins.length) {
      console.log('No hay administradores de plataforma.');
      return;
    }
    console.log(`Administradores de plataforma (${admins.length}):`);
    for (const a of admins) {
      const last = a.lastLoginAt ? a.lastLoginAt.toISOString().slice(0, 10) : 'nunca';
      console.log(`  · ${a.email} — ${a.name} [${a.status}] último acceso: ${last}`);
    }
    return;
  }

  if (!opts.email) {
    throw new Error('Falta --email. Usa --list para ver los administradores actuales.');
  }

  const user = await prisma.user.findUnique({
    where: { email: opts.email },
    select: { id: true, email: true, name: true, status: true, isPlatformAdmin: true },
  });
  if (!user) {
    throw new Error(
      `No existe ninguna cuenta con ${opts.email}. Regístrala primero en la web y repite.`,
    );
  }

  const next = !opts.revoke;
  if (user.isPlatformAdmin === next) {
    console.log(
      `↔ ${user.email} ya ${next ? 'es' : 'no es'} administrador de plataforma. Sin cambios.`,
    );
    return;
  }

  await prisma.user.update({ where: { id: user.id }, data: { isPlatformAdmin: next } });
  console.log(
    next
      ? `✔ ${user.email} es ahora administrador de plataforma. Vuelve a iniciar sesión para que el token lo incluya.`
      : `✔ Se retiró el rol de plataforma a ${user.email}.`,
  );
  if (next && user.status !== 'ACTIVE') {
    console.warn(`  ⚠ La cuenta está en estado ${user.status}; no podrá entrar hasta activarla.`);
  }
}

main()
  .catch((error) => {
    console.error('✖ Error gestionando el administrador de plataforma:', error.message);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
