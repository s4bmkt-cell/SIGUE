// Datos de la norma ISO/IEC 20000-1:2018 (redacción propia — sin copiar texto de la norma).
// Estructura: cláusulas 4..10; la cláusula 8 concentra los procesos del sistema
// de gestión de servicios (portafolio, acuerdos, suministro y demanda, diseño y
// transición, resolución y aseguramiento).

import type { ClauseSeed } from './iso9001-data';

let order = 0;
const clause = (code: string, title: string): ClauseSeed => ({
  code,
  title,
  kind: 'clause',
  weight: 1,
  sortOrder: ++order,
});
const requirement = (code: string, title: string, requirementText: string, weight = 2): ClauseSeed => ({
  code,
  title,
  requirementText,
  kind: 'requirement',
  weight,
  sortOrder: ++order,
});

export const ISO20000_CLAUSES: ClauseSeed[] = [
  // --- Cláusula 4: Contexto de la organización ---
  clause('4', 'Contexto de la organización'),
  requirement(
    '4.1',
    'Comprensión de la organización y de su contexto',
    'Determinar las cuestiones internas y externas que afectan la capacidad del sistema de gestión de servicios para lograr sus resultados.',
  ),
  requirement(
    '4.2',
    'Comprensión de las necesidades y expectativas de las partes interesadas',
    'Identificar los clientes, usuarios, proveedores y reguladores pertinentes, y los requisitos que aplican al servicio.',
  ),
  requirement(
    '4.3',
    'Determinación del alcance del sistema de gestión de servicios',
    'Definir el alcance identificando los servicios incluidos, las unidades organizativas y los límites geográficos.',
    3,
  ),
  requirement(
    '4.4',
    'Sistema de gestión de servicios',
    'Establecer, implementar, mantener y mejorar de forma continua el SGS y los procesos que lo componen.',
    3,
  ),

  // --- Cláusula 5: Liderazgo ---
  clause('5', 'Liderazgo'),
  requirement(
    '5.1',
    'Liderazgo y compromiso',
    'La alta dirección demuestra liderazgo asegurando la disponibilidad de recursos y la integración del SGS con los procesos de negocio.',
    3,
  ),
  requirement('5.2', 'Política del sistema de gestión de servicios', 'Establecer, comunicar y mantener una política de gestión de servicios adecuada al propósito de la organización.'),
  requirement('5.3', 'Roles, responsabilidades y autoridades', 'Asignar y comunicar las responsabilidades y autoridades del SGS dentro de la organización.'),

  // --- Cláusula 6: Planificación ---
  clause('6', 'Planificación'),
  requirement(
    '6.1',
    'Acciones para abordar riesgos y oportunidades',
    'Determinar los riesgos y oportunidades del SGS y planificar las acciones para tratarlos e integrarlas en sus procesos.',
    3,
  ),
  requirement('6.2', 'Objetivos del sistema de gestión de servicios', 'Establecer objetivos medibles y coherentes con la política, y planificar cómo alcanzarlos.'),
  requirement('6.3', 'Planificación de los cambios', 'Planificar los cambios del SGS de forma controlada, considerando su propósito y sus consecuencias.'),

  // --- Cláusula 7: Apoyo ---
  clause('7', 'Apoyo del sistema de gestión de servicios'),
  requirement('7.1', 'Recursos', 'Determinar y proporcionar los recursos necesarios para el SGS y los servicios.'),
  requirement('7.2', 'Competencia', 'Asegurar que el personal que afecta al desempeño del servicio es competente y mantener evidencia de ello.'),
  requirement('7.3', 'Toma de conciencia', 'Asegurar que el personal conoce la política, sus objetivos y su contribución al SGS.'),
  requirement('7.4', 'Comunicación', 'Determinar qué, cuándo, con quién y cómo se comunica lo relativo al SGS.'),
  requirement('7.5', 'Información documentada', 'Controlar la creación, actualización, distribución y conservación de la información documentada del SGS.'),

  // --- Cláusula 8: Operación del sistema de gestión de servicios ---
  clause('8', 'Operación del sistema de gestión de servicios'),

  requirement('8.1', 'Planificación y control operacional', 'Planificar, implementar y controlar los procesos necesarios para cumplir los requisitos del servicio.', 3),

  clause('8.2', 'Portafolio de servicios'),
  requirement('8.2.1', 'Prestación de servicios', 'Prestar los servicios acordados cumpliendo los requisitos y los niveles de servicio comprometidos.', 3),
  requirement('8.2.2', 'Planificación de los servicios', 'Planificar los servicios considerando su ciclo de vida, los recursos y las dependencias.'),
  requirement('8.2.3', 'Control de las partes involucradas en el ciclo de vida del servicio', 'Coordinar a las partes internas y externas que intervienen en el ciclo de vida del servicio.'),
  requirement('8.2.4', 'Gestión del catálogo de servicios', 'Mantener un catálogo de servicios actualizado con la información necesaria para clientes y usuarios.', 3),
  requirement('8.2.5', 'Gestión de activos', 'Identificar y controlar los activos que soportan la prestación de los servicios.'),
  requirement('8.2.6', 'Gestión de la configuración', 'Definir y mantener la información de configuración de los elementos que soportan los servicios.'),

  clause('8.3', 'Relación y acuerdo'),
  requirement('8.3.1', 'Generalidades', 'Gestionar la relación con clientes y proveedores, y los acuerdos que de ella se derivan.'),
  requirement('8.3.2', 'Gestión de la relación con el negocio', 'Comprender las necesidades del negocio y alinear los servicios con ellas.'),
  requirement('8.3.3', 'Gestión de los niveles de servicio', 'Definir, acordar, medir y revisar los niveles de servicio con los clientes.', 3),
  requirement('8.3.4', 'Gestión de proveedores', 'Gestionar el desempeño de los proveedores y el cumplimiento de los acuerdos.'),

  clause('8.4', 'Suministro y demanda'),
  requirement('8.4.1', 'Presupuesto y contabilidad de los servicios', 'Presupuestar y contabilizar los costos de los servicios prestados.'),
  requirement('8.4.2', 'Gestión de la demanda', 'Analizar y gestionar la demanda de servicios y su impacto en la capacidad.'),
  requirement('8.4.3', 'Gestión de la capacidad', 'Asegurar la capacidad suficiente para cumplir los niveles de servicio acordados.'),

  clause('8.5', 'Diseño, construcción y transición del servicio'),
  requirement('8.5.1', 'Gestión de cambios', 'Registrar, evaluar, autorizar, implementar y revisar los cambios en los servicios y sus componentes.', 3),
  requirement('8.5.2', 'Diseño y transición del servicio', 'Diseñar y transicionar servicios nuevos o modificados considerando su impacto y sus riesgos.'),
  requirement('8.5.3', 'Gestión de versiones y despliegues', 'Planificar y controlar la liberación y el despliegue de versiones en producción.'),

  clause('8.6', 'Resolución y cumplimiento'),
  requirement('8.6.1', 'Gestión de incidentes', 'Registrar, clasificar, resolver y comunicar los incidentes conforme a los acuerdos de servicio.', 3),
  requirement('8.6.2', 'Gestión de peticiones de servicio', 'Atender las peticiones de servicio dentro de los tiempos acordados.'),
  requirement('8.6.3', 'Gestión de problemas', 'Identificar las causas raíz de los incidentes recurrentes y definir acciones correctivas.'),

  clause('8.7', 'Aseguramiento del servicio'),
  requirement('8.7.1', 'Gestión de la disponibilidad del servicio', 'Medir y mantener la disponibilidad acordada de los servicios.'),
  requirement('8.7.2', 'Gestión de la continuidad del servicio', 'Establecer planes para mantener los servicios ante interrupciones significativas.'),
  requirement('8.7.3', 'Gestión de la seguridad de la información', 'Proteger la información y los datos de los servicios conforme a las políticas aplicables.'),

  // --- Cláusula 9: Evaluación del desempeño ---
  clause('9', 'Evaluación del desempeño'),
  requirement('9.1', 'Seguimiento, medición, análisis y evaluación', 'Determinar qué medir, cómo medirlo y con qué frecuencia, y evaluar los resultados.', 2),
  requirement('9.2', 'Auditoría interna', 'Planificar y realizar auditorías internas del SGS a intervalos planificados.'),
  requirement('9.3', 'Revisión por la dirección', 'Revisar el SGS a intervalos planificados con las entradas y salidas requeridas.'),
  requirement('9.4', 'Informes de servicio', 'Producir informes de desempeño del servicio para clientes y partes interesadas.'),

  // --- Cláusula 10: Mejora ---
  clause('10', 'Mejora'),
  requirement('10.1', 'No conformidad y acción correctiva', 'Gestionar las no conformidades del servicio o del SGS y verificar la eficacia de las acciones.', 3),
  requirement('10.2', 'Mejora continua', 'Mejorar de forma continua la idoneidad, adecuación y eficacia del SGS y de los servicios.'),
];

/** Etiquetas cortas para agrupar los procesos de la cláusula 8 en la vista. */
export const ISO20000_PROCESS_GROUPS = [
  { code: '8.2', label: 'Portafolio de servicios' },
  { code: '8.3', label: 'Relación y acuerdo' },
  { code: '8.4', label: 'Suministro y demanda' },
  { code: '8.5', label: 'Diseño y transición' },
  { code: '8.6', label: 'Resolución y cumplimiento' },
  { code: '8.7', label: 'Aseguramiento del servicio' },
];
