/**
 * Aprovisiona la primera organización con su administrador.
 *
 * En producción **no** se puede usar `db:seed` (crea usuarios con la contraseña
 * pública `demo-password`) y **no existe** endpoint ni comando para crear la
 * primera organización: `POST /auth/register` deja la cuenta sin organización y
 * las pantallas de acceso no tienen alta salvo por invitación. Sin una
 * organización, el usuario entra y no ve nada (`orgId` nulo en el token).
 *
 * Este script cubre ese hueco con el rol dueño de las tablas, desde una máquina
 * con acceso a la base. Es idempotente: repetirlo actualiza en lugar de duplicar.
 *
 * Uso:
 *
 *     ADMIN_PASSWORD='<clave-fuerte>' npm run db:provision --workspace @sigue/api -- \
 *       --org-name "Acme, S.A. de C.V." \
 *       --admin-email admin@acme.mx \
 *       --admin-name "Ana Ruiz" \
 *       --plan BUSINESS \
 *       --standards ISO9001
 *
 * La contraseña va por variable de entorno y no por argumento para que no quede
 * en el historial del shell ni en la lista de procesos.
 *
 * Qué crea, en orden:
 *   1. La organización (con `planCode`).
 *   2. La fila de `Subscription`, que es obligatoria: sin ella, la pantalla de
 *      facturación responde 404 aunque la organización exista.
 *   3. El usuario administrador, o reutiliza uno existente sin tocarle la clave.
 *   4. La membresía con rol `admin_org` (y los que se pidan) en estado ACTIVE.
 *   5. Las normas activadas, con su Declaración de Aplicabilidad si tienen
 *      Anexo A. Los niveles de cumplimiento no se siembran: la API devuelve
 *      `NOT_IMPLEMENTED` para toda cláusula sin fila, que es el estado correcto
 *      de una organización recién creada.
 *   6. El catálogo normativo y las plantillas propietarias (reutiliza
 *      `seedCatalog`, así que es la misma carga que `db:catalog`).
 *
 * El alta en sí vive en `src/modules/platform/org-provisioning.ts`, que es el
 * mismo código que usa el panel de plataforma: así el CLI y la interfaz no se
 * desincronizan. Este archivo solo se queda con lo propio de la línea de
 * comandos (argumentos, catálogo, simulación).
 */
import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import { config } from 'dotenv';
import { CATALOG_STANDARDS, seedCatalog } from './catalog';
import { ORG_ROLES, isOrgRole } from '../src/common/roles';
import { PLAN_LIMITS } from '../src/modules/billing/plan-limits';
import { provisionOrganization } from '../src/modules/platform/org-provisioning';

config();

/** Marcador para deshacer la transacción cuando se pide `--dry-run`. */
class DryRun extends Error {}

interface Options {
  orgName: string;
  orgId?: string;
  legalName?: string;
  plan: string;
  adminEmail: string;
  adminName: string;
  adminPassword?: string;
  resetPassword: boolean;
  roles: string[];
  standards: string[];
  catalog: boolean;
  dryRun: boolean;
}

function parseArgs(argv: string[]): Options {
  const flags = new Map<string, string | true>();
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (!arg.startsWith('--')) continue;
    const key = arg.slice(2);
    const next = argv[i + 1];
    // Los indicadores booleanos no consumen el siguiente argumento.
    if (next && !next.startsWith('--')) {
      flags.set(key, next);
      i += 1;
    } else {
      flags.set(key, true);
    }
  }

  const str = (key: string) => {
    const value = flags.get(key);
    return typeof value === 'string' ? value : undefined;
  };
  const list = (key: string) =>
    (str(key) ?? '')
      .split(',')
      .map((v) => v.trim())
      .filter(Boolean);

  const orgName = str('org-name');
  const adminEmail = str('admin-email');
  const adminName = str('admin-name');
  const missing = [
    !orgName && '--org-name',
    !adminEmail && '--admin-email',
    !adminName && '--admin-name',
  ].filter(Boolean);
  if (missing.length) {
    throw new Error(`Faltan argumentos obligatorios: ${missing.join(', ')}`);
  }

  return {
    orgName: orgName!,
    orgId: str('org-id'),
    legalName: str('legal-name'),
    plan: (str('plan') ?? 'ESSENTIAL').toUpperCase(),
    adminEmail: adminEmail!.trim().toLowerCase(),
    adminName: adminName!,
    adminPassword: process.env.ADMIN_PASSWORD,
    resetPassword: flags.has('reset-password'),
    roles: list('roles').length ? list('roles') : ['admin_org'],
    standards: list('standards').map((s) => s.toUpperCase()),
    catalog: !flags.has('no-catalog'),
    dryRun: flags.has('dry-run'),
  };
}

function validate(opts: Options): void {
  // Un argumento con acentos que atraviesa una consola mal configurada (Git Bash
  // en Windows, por ejemplo) llega con U+FFFD en lugar de la letra. Esto guardó
  // una vez «Organizaci\uFFFDn» de verdad: conviene fallar antes que dejar el
  // nombre roto, porque luego la idempotencia por nombre ya no lo encuentra.
  const corruptos = [
    ['--org-name', opts.orgName],
    ['--admin-name', opts.adminName],
    ['--legal-name', opts.legalName],
  ].filter(([, valor]) => typeof valor === 'string' && valor.includes('\uFFFD'));

  if (corruptos.length) {
    throw new Error(
      `Argumento con caracteres corruptos (U+FFFD): ${corruptos.map(([k]) => k).join(', ')}. ` +
        'La terminal no envió el texto en UTF-8: revisa el code page (chcp 65001 en Windows) ' +
        'o pasa el valor desde un archivo.',
    );
  }
  if (!opts.orgName.trim()) {
    throw new Error('--org-name no puede estar vacío.');
  }
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(opts.adminEmail)) {
    throw new Error(`Correo inválido: ${opts.adminEmail}`);
  }
  if (!PLAN_LIMITS[opts.plan]) {
    throw new Error(
      `Plan inválido: ${opts.plan}. Válidos: ${Object.keys(PLAN_LIMITS).join(', ')}`,
    );
  }
  for (const role of opts.roles) {
    if (!isOrgRole(role)) {
      throw new Error(
        `Rol inválido: ${role}. Válidos: ${ORG_ROLES.map((r) => r.code).join(', ')}`,
      );
    }
  }
  // Un administrador de la organización es requisito práctico: sin él nadie
  // puede invitar al resto ni cambiar el plan.
  if (!opts.roles.includes('admin_org')) {
    throw new Error('`--roles` debe incluir admin_org: es el único que gestiona miembros y plan.');
  }
  const known = new Set(CATALOG_STANDARDS.map((s) => s.code));
  for (const code of opts.standards) {
    if (!known.has(code)) {
      throw new Error(
        `Norma desconocida: ${code}. En el catálogo: ${[...known].join(', ')}`,
      );
    }
  }
  if (opts.standards.length > PLAN_LIMITS[opts.plan].standards) {
    // Se avisa, no se bloquea: el límite lo aplica la API al activar normas por
    // interfaz, y aquí se escribe con el rol dueño. Saltárselo en silencio
    // dejaría la organización por encima de su plan.
    console.warn(
      `⚠ El plan ${opts.plan} admite ${PLAN_LIMITS[opts.plan].standards} norma(s) y se piden ` +
        `${opts.standards.length}. La organización quedará por encima de su cuota.`,
    );
  }
  if (opts.adminPassword !== undefined && opts.adminPassword.length < 8) {
    throw new Error('ADMIN_PASSWORD debe tener al menos 8 caracteres (regla de la API).');
  }
}

async function main() {
  const opts = parseArgs(process.argv.slice(2));
  validate(opts);

  const url = process.env.DIRECT_URL ?? process.env.DATABASE_URL;
  if (!url) {
    throw new Error('Falta DIRECT_URL (rol dueño): es el único que puede escribir en varias organizaciones.');
  }

  const prisma = new PrismaClient({ datasourceUrl: url });
  console.log(`→ Aprovisionando "${opts.orgName}" (plan ${opts.plan})${opts.dryRun ? ' [simulación]' : ''}`);

  // El catálogo va **antes**: activar una norma exige que la norma exista, y en
  // una base recién migrada no hay ninguna. Es idempotente y global, así que se
  // carga fuera de la transacción de aprovisionamiento. En simulación se omite:
  // `--dry-run` no debe escribir nada, y el catálogo sí escribe.
  if (opts.catalog && !opts.dryRun) {
    console.log('→ Cargando catálogo normativo...');
    await seedCatalog(prisma, console.log);
  } else if (!opts.dryRun && opts.standards.length) {
    throw new Error('--no-catalog no puede combinarse con --standards: las normas aún no existirían.');
  }
  if (opts.dryRun && opts.standards.length) {
    console.log('  ℹ Simulación: se omite la carga del catálogo y solo se valida el resto.');
  }

  try {
    await prisma.$transaction(async (tx) => {
      // El alta completa (organización, suscripción, usuario, membresía, normas y
      // plantillas) es la misma función que usa el panel de plataforma.
      const result = await provisionOrganization(tx, {
        orgName: opts.orgName,
        orgId: opts.orgId,
        legalName: opts.legalName,
        plan: opts.plan,
        adminEmail: opts.adminEmail,
        adminName: opts.adminName,
        adminPassword: opts.adminPassword,
        roles: opts.roles,
        standards: opts.standards,
      });

      console.log(`  ✔ Organización ${result.orgId}`);
      console.log(`  ✔ Suscripción ${opts.plan} (ACTIVE)`);
      console.log(
        result.userCreated
          ? `  ✔ Usuario ${opts.adminEmail}`
          : `  ↔ Usuario ${opts.adminEmail} ya existía (contraseña intacta)`,
      );
      console.log(`  ✔ Membresía con roles ${opts.roles.join(', ')}`);
      for (const code of opts.standards) {
        console.log(`  ✔ ${code} activa`);
      }
      if (!opts.standards.length) {
        console.log('  ℹ Sin normas activas: actívalas desde la interfaz o repite con --standards');
      }
      console.log(`  ✔ ${result.templates} plantillas propietarias`);

      // `--reset-password` es propio del CLI: el panel nunca cambia la clave de
      // una cuenta existente. Se aplica después del alta, y solo si se pidió.
      if (opts.resetPassword && !result.userCreated) {
        if (!opts.adminPassword) throw new Error('--reset-password requiere ADMIN_PASSWORD.');
        await tx.user.update({
          where: { id: result.userId },
          data: { passwordHash: await bcrypt.hash(opts.adminPassword, 10) },
        });
        console.log(`  ✔ Contraseña restablecida para ${opts.adminEmail}`);
      }
      if (opts.resetPassword && result.userCreated) {
        console.log('  ℹ El usuario se creó en esta ejecución: no hace falta restablecer la clave.');
      }

      if (opts.dryRun) throw new DryRun();
      return result;
    });
  } catch (error) {
    // La simulación usa la excepción para deshacer la transacción: no es un fallo.
    if (!(error instanceof DryRun)) throw error;
    console.log('✓ Simulación completada; no se escribió nada.');
    return;
  }

  console.log('✓ Aprovisionamiento completado.');
  console.log(`  Entra a la web con ${opts.adminEmail}.`);

  await prisma.$disconnect();
}

main().catch(async (error) => {
  console.error('✖ Error aprovisionando la organización:', error.message);
  process.exitCode = 1;
});
