// Datos de la norma ISO/IEC 27001:2022 (redacción propia — sin copiar texto de la norma).
// Estructura: cláusulas 4..10 con sus requisitos, más los 93 controles del Anexo A
// (temas A.5 organizacional, A.6 personas, A.7 físico y A.8 tecnológico).

import type { ClauseSeed } from './iso9001-data';

let order = 0;
const clause = (code: string, title: string): ClauseSeed => ({
  code,
  title,
  kind: 'clause',
  weight: 1,
  sortOrder: ++order,
});
const requirement = (code: string, title: string, requirementText: string, weight = 2): ClauseSeed => ({
  code,
  title,
  requirementText,
  kind: 'requirement',
  weight,
  sortOrder: ++order,
});

export const ISO27001_CLAUSES: ClauseSeed[] = [
  // --- Cláusula 4: Contexto de la organización ---
  clause('4', 'Contexto de la organización'),
  requirement(
    '4.1',
    'Comprensión de la organización y su contexto',
    'Determinar las cuestiones internas y externas pertinentes al propósito del SGSI y mantenerlas actualizadas.',
  ),
  requirement(
    '4.2',
    'Comprensión de las necesidades y expectativas de las partes interesadas',
    'Identificar las partes interesadas pertinentes al SGSI y los requisitos que de ellas se derivan.',
  ),
  requirement(
    '4.3',
    'Determinación del alcance del SGSI',
    'Definir y documentar los límites y la aplicabilidad del SGSI, incluidas las interfaces y dependencias externas.',
    3,
  ),
  requirement(
    '4.4',
    'Sistema de gestión de la seguridad de la información',
    'Establecer, implementar, mantener y mejorar de forma continua el SGSI y sus procesos.',
    3,
  ),

  // --- Cláusula 5: Liderazgo ---
  clause('5', 'Liderazgo'),
  requirement(
    '5.1',
    'Liderazgo y compromiso',
    'La alta dirección debe demostrar liderazgo y compromiso con el SGSI, asegurando recursos y la integración con los procesos del negocio.',
    3,
  ),
  requirement(
    '5.2',
    'Política de seguridad de la información',
    'Establecer, aprobar, comunicar y revisar una política de seguridad de la información alineada con el contexto de la organización.',
    3,
  ),
  requirement(
    '5.3',
    'Roles, responsabilidades y autoridades en la organización',
    'Asignar y comunicar las responsabilidades y autoridades de seguridad de la información pertinentes.',
  ),

  // --- Cláusula 6: Planificación ---
  clause('6', 'Planificación'),
  requirement(
    '6.1.1',
    'Generalidades de las acciones para abordar riesgos y oportunidades',
    'Al planificar el SGSI, considerar el contexto y los requisitos de las partes interesadas para determinar los riesgos y oportunidades que deben tratarse.',
  ),
  requirement(
    '6.1.2',
    'Valoración de riesgos de seguridad de la información',
    'Definir y aplicar un proceso de valoración de riesgos con criterios de aceptación y resultados documentados y coherentes.',
    3,
  ),
  requirement(
    '6.1.3',
    'Tratamiento de riesgos de seguridad de la información',
    'Seleccionar las opciones de tratamiento adecuadas y producir una declaración de aplicabilidad con las justificaciones correspondientes.',
    3,
  ),
  requirement(
    '6.2',
    'Objetivos de seguridad de la información y planificación para lograrlos',
    'Establecer objetivos medibles, coherentes con la política, con responsables, plazos y evaluación de resultados.',
  ),
  requirement(
    '6.3',
    'Planificación de los cambios',
    'Planificar los cambios del SGSI de forma controlada.',
  ),

  // --- Cláusula 7: Soporte ---
  clause('7', 'Soporte'),
  requirement(
    '7.1',
    'Recursos',
    'Determinar y proporcionar los recursos necesarios para el SGSI.',
  ),
  requirement(
    '7.2',
    'Competencia',
    'Asegurar que el personal que afecta al desempeño del SGSI sea competente y conservar evidencia de ello.',
  ),
  requirement(
    '7.3',
    'Toma de conciencia',
    'Asegurar que el personal conozca la política, su contribución al SGSI y las implicaciones de no cumplir.',
  ),
  requirement(
    '7.4',
    'Comunicación',
    'Determinar qué, cuándo, a quién y cómo comunicar en materia de seguridad de la información.',
  ),
  requirement(
    '7.5',
    'Información documentada',
    'Incluir la información documentada requerida y controlar su creación, actualización, distribución y retención.',
  ),

  // --- Cláusula 8: Operación ---
  clause('8', 'Operación'),
  requirement(
    '8.1',
    'Planificación y control operacional',
    'Planificar, implementar y controlar los procesos necesarios para satisfacer los requisitos del SGSI.',
    3,
  ),
  requirement(
    '8.2',
    'Valoración de riesgos de seguridad de la información',
    'Realizar valoraciones de riesgos a intervalos planificados o ante cambios significativos, conservando los resultados.',
    3,
  ),
  requirement(
    '8.3',
    'Tratamiento de riesgos de seguridad de la información',
    'Implementar el plan de tratamiento y conservar información documentada sobre los resultados.',
    3,
  ),

  // --- Cláusula 9: Evaluación del desempeño ---
  clause('9', 'Evaluación del desempeño'),
  requirement(
    '9.1',
    'Seguimiento, medición, análisis y evaluación',
    'Determinar los métodos de seguimiento y medir la eficacia del SGSI, incluida la eficacia de los controles.',
  ),
  requirement(
    '9.2',
    'Auditoría interna',
    'Planificar y realizar auditorías internas del SGSI conforme a un programa establecido.',
  ),
  requirement(
    '9.3',
    'Revisión por la dirección',
    'Revisar el SGSI a intervalos planificados con las entradas y salidas que exige la norma.',
  ),

  // --- Cláusula 10: Mejora ---
  clause('10', 'Mejora'),
  requirement(
    '10.1',
    'Mejora continua',
    'Mejorar de forma continua la idoneidad, adecuación y eficacia del SGSI.',
  ),
  requirement(
    '10.2',
    'No conformidad y acción correctiva',
    'Reaccionar ante las no conformidades, evaluar la necesidad de acciones correctivas y conservar evidencia.',
    3,
  ),

  // ===== Anexo A — Controles organizacionales (A.5) =====
  clause('A.5', 'Controles organizacionales'),
  requirement('A.5.1', 'Políticas para la seguridad de la información', 'Definir, aprobar, publicar y revisar políticas de seguridad de la información y políticas específicas por tema.'),
  requirement('A.5.2', 'Asignación de roles y responsabilidades de seguridad de la información', 'Asignar y comunicar roles y responsabilidades de seguridad de la información según las necesidades de la organización.'),
  requirement('A.5.3', 'Segregación de funciones', 'Separar funciones y áreas de responsabilidad conflictivas para reducir el riesgo de uso no autorizado o no detectado.'),
  requirement('A.5.4', 'Responsabilidades de la dirección', 'Exigir a todo el personal la aplicación de la seguridad de la información conforme a las políticas establecidas.'),
  requirement('A.5.5', 'Contacto con autoridades', 'Mantener contacto con las autoridades competentes y conocer los canales para reportar incidentes.'),
  requirement('A.5.6', 'Contacto con grupos de interés especial', 'Mantener contacto con grupos profesionales, foros o asociaciones especializadas en seguridad de la información.'),
  requirement('A.5.7', 'Inteligencia de amenazas', 'Recopilar y analizar información sobre amenazas para informar las decisiones de seguridad.'),
  requirement('A.5.8', 'Seguridad de la información en la gestión de proyectos', 'Integrar la seguridad de la información en los procesos de gestión de proyectos.'),
  requirement('A.5.9', 'Inventario de información y otros activos asociados', 'Elaborar y mantener un inventario de la información y los activos asociados, con sus propietarios.'),
  requirement('A.5.10', 'Uso aceptable de la información y otros activos asociados', 'Definir y comunicar reglas de uso aceptable y manejo de la información y los activos.'),
  requirement('A.5.11', 'Devolución de activos', 'Recuperar los activos al término del empleo, contrato o acuerdo.'),
  requirement('A.5.12', 'Clasificación de la información', 'Clasificar la información según sus requisitos de confidencialidad, integridad y disponibilidad.'),
  requirement('A.5.13', 'Etiquetado de la información', 'Definir y aplicar procedimientos de etiquetado coherentes con el esquema de clasificación.'),
  requirement('A.5.14', 'Transferencia de información', 'Establecer reglas y acuerdos para la transferencia de información por cualquier medio.'),
  requirement('A.5.15', 'Control de acceso', 'Establecer reglas de control de acceso físico y lógico basadas en los requisitos de seguridad y del negocio.'),
  requirement('A.5.16', 'Gestión de identidades', 'Gestionar el ciclo de vida completo de las identidades.'),
  requirement('A.5.17', 'Información de autenticación', 'Controlar la asignación y el uso de la información de autenticación.'),
  requirement('A.5.18', 'Derechos de acceso', 'Asignar, revisar y retirar los derechos de acceso conforme a las reglas de control de acceso.'),
  requirement('A.5.19', 'Seguridad de la información en las relaciones con proveedores', 'Definir y aplicar procesos para gestionar los riesgos de seguridad asociados a proveedores.'),
  requirement('A.5.20', 'Abordar la seguridad de la información en acuerdos con proveedores', 'Establecer y acordar los requisitos de seguridad de la información con cada proveedor.'),
  requirement('A.5.21', 'Gestión de la seguridad de la información en la cadena de suministro de TIC', 'Gestionar los riesgos asociados a la cadena de suministro de productos y servicios de TIC.'),
  requirement('A.5.22', 'Seguimiento, revisión y gestión de cambios de servicios de proveedores', 'Supervisar y revisar periódicamente los servicios prestados por proveedores y gestionar sus cambios.'),
  requirement('A.5.23', 'Seguridad de la información para el uso de servicios en la nube', 'Definir procesos y responsabilidades para el uso seguro de servicios en la nube.'),
  requirement('A.5.24', 'Planificación y preparación de la gestión de incidentes', 'Planificar la gestión de incidentes con procesos, roles y comunicaciones definidos.'),
  requirement('A.5.25', 'Evaluación y decisión sobre eventos de seguridad de la información', 'Evaluar los eventos y decidir si constituyen incidentes de seguridad.'),
  requirement('A.5.26', 'Respuesta a incidentes', 'Responder a los incidentes conforme a procedimientos documentados.'),
  requirement('A.5.27', 'Aprendizaje de incidentes', 'Usar el conocimiento de los incidentes para fortalecer los controles y reducir la probabilidad o el impacto.'),
  requirement('A.5.28', 'Recopilación de evidencia', 'Establecer procedimientos para la identificación, recolección y preservación de evidencia.'),
  requirement('A.5.29', 'Seguridad de la información durante la interrupción', 'Planificar cómo mantener la seguridad de la información durante las interrupciones.'),
  requirement('A.5.30', 'Preparación de TIC para la continuidad del negocio', 'Planificar la continuidad de las TIC con base en los objetivos de continuidad del negocio.'),
  requirement('A.5.31', 'Requisitos legales, reglamentarios y contractuales', 'Identificar, documentar y mantener actualizados los requisitos aplicables y el enfoque para cumplirlos.'),
  requirement('A.5.32', 'Derechos de propiedad intelectual', 'Proteger la propiedad intelectual y aplicar procedimientos para el uso de productos protegidos.'),
  requirement('A.5.33', 'Protección de registros', 'Proteger los registros contra pérdida, destrucción, falsificación y acceso no autorizado.'),
  requirement('A.5.34', 'Privacidad y protección de información de identificación personal', 'Cumplir los requisitos de privacidad y protección de datos personales.'),
  requirement('A.5.35', 'Revisión independiente de la seguridad de la información', 'Revisar de forma independiente el enfoque de gestión de seguridad a intervalos planificados.'),
  requirement('A.5.36', 'Cumplimiento de políticas, reglas y normas de seguridad', 'Revisar periódicamente el cumplimiento de las políticas y normas de seguridad.'),
  requirement('A.5.37', 'Procedimientos de operación documentados', 'Documentar y mantener los procedimientos operativos necesarios para las instalaciones de procesamiento.'),

  // ===== Anexo A — Controles de las personas (A.6) =====
  clause('A.6', 'Controles de las personas'),
  requirement('A.6.1', 'Verificación de antecedentes', 'Verificar los antecedentes de los candidatos antes del empleo y de forma periódica según la ley y el riesgo.'),
  requirement('A.6.2', 'Términos y condiciones del empleo', 'Comunicar en los contratos las responsabilidades de seguridad de la información.'),
  requirement('A.6.3', 'Concientización, educación y formación en seguridad de la información', 'Proporcionar concienciación y formación periódica adecuada al rol del personal.'),
  requirement('A.6.4', 'Proceso disciplinario', 'Aplicar un proceso disciplinario formal y comunicado ante incumplimientos de seguridad.'),
  requirement('A.6.5', 'Responsabilidades después de la terminación o cambio de empleo', 'Definir y exigir las responsabilidades de seguridad que persisten tras el cese o cambio de puesto.'),
  requirement('A.6.6', 'Acuerdos de confidencialidad', 'Identificar, revisar y firmar acuerdos de confidencialidad pertinentes.'),
  requirement('A.6.7', 'Trabajo remoto', 'Definir y aplicar medidas de seguridad para el trabajo remoto.'),
  requirement('A.6.8', 'Reporte de eventos de seguridad de la información', 'Establecer un canal ágil y conocido para reportar eventos de seguridad.'),

  // ===== Anexo A — Controles físicos (A.7) =====
  clause('A.7', 'Controles físicos'),
  requirement('A.7.1', 'Perímetros de seguridad física', 'Definir y usar perímetros de seguridad para proteger las áreas con información y activos.'),
  requirement('A.7.2', 'Entrada física', 'Proteger las áreas seguras con controles de entrada y registros de acceso.'),
  requirement('A.7.3', 'Seguridad de oficinas, salas e instalaciones', 'Diseñar y aplicar protecciones físicas para oficinas, salas e instalaciones.'),
  requirement('A.7.4', 'Monitoreo de seguridad física', 'Monitorizar continuamente las instalaciones para detectar accesos no autorizados.'),
  requirement('A.7.5', 'Protección contra amenazas físicas y ambientales', 'Implementar protecciones frente a amenazas físicas y ambientales como incendio, inundación o sismo.'),
  requirement('A.7.6', 'Trabajo en áreas seguras', 'Definir y aplicar medidas para el trabajo dentro de áreas seguras.'),
  requirement('A.7.7', 'Escritorio limpio y pantalla limpia', 'Establecer reglas de escritorio y pantalla limpios para proteger la información.'),
  requirement('A.7.8', 'Ubicación y protección de equipos', 'Ubicar y proteger los equipos para reducir riesgos de acceso no autorizado y daño.'),
  requirement('A.7.9', 'Seguridad de activos fuera de las instalaciones', 'Proteger los activos que se encuentran fuera de las instalaciones.'),
  requirement('A.7.10', 'Medios de almacenamiento', 'Gestionar los medios de almacenamiento a lo largo de su ciclo de vida.'),
  requirement('A.7.11', 'Servicios de suministro', 'Proteger los equipos frente a fallas en los servicios de suministro.'),
  requirement('A.7.12', 'Seguridad del cableado', 'Proteger el cableado de energía y telecomunicaciones de interceptación y daño.'),
  requirement('A.7.13', 'Mantenimiento de equipos', 'Realizar el mantenimiento correcto y oportuno de los equipos.'),
  requirement('A.7.14', 'Eliminación o reutilización segura de equipos', 'Verificar la eliminación segura de datos antes de retirar o reutilizar equipos.'),

  // ===== Anexo A — Controles tecnológicos (A.8) =====
  clause('A.8', 'Controles tecnológicos'),
  requirement('A.8.1', 'Dispositivos de usuario final', 'Proteger la información almacenada, procesada o accesible desde dispositivos de usuario final.'),
  requirement('A.8.2', 'Privilegios de acceso', 'Restringir y gestionar los privilegios de acceso.'),
  requirement('A.8.3', 'Restricción de acceso a la información', 'Restringir el acceso a la información y a las funciones de las aplicaciones según la política de control de acceso.'),
  requirement('A.8.4', 'Acceso al código fuente', 'Gestionar adecuadamente el acceso al código fuente, herramientas y bibliotecas.'),
  requirement('A.8.5', 'Autenticación segura', 'Implementar tecnologías y procedimientos de autenticación seguros.'),
  requirement('A.8.6', 'Gestión de capacidad', 'Supervisar y ajustar el uso de recursos según las necesidades de capacidad.'),
  requirement('A.8.7', 'Protección contra malware', 'Implementar protecciones contra malware con actualizaciones y detección actualizadas.'),
  requirement('A.8.8', 'Gestión de vulnerabilidades técnicas', 'Obtener información oportuna sobre vulnerabilidades y evaluar la exposición.'),
  requirement('A.8.9', 'Gestión de configuración', 'Establecer y mantener configuraciones seguras de hardware, software y servicios.'),
  requirement('A.8.10', 'Eliminación de información', 'Eliminar la información de sistemas, dispositivos y medios cuando ya no sea necesaria.'),
  requirement('A.8.11', 'Enmascaramiento de datos', 'Aplicar enmascaramiento o seudonimización conforme a la política y los requisitos legales.'),
  requirement('A.8.12', 'Prevención de fuga de datos', 'Aplicar medidas para prevenir la fuga de información en sistemas, redes y dispositivos.'),
  requirement('A.8.13', 'Copias de seguridad de la información', 'Realizar y probar copias de seguridad según una política acordada.'),
  requirement('A.8.14', 'Redundancia de instalaciones de procesamiento', 'Implementar redundancia suficiente para cumplir los requisitos de disponibilidad.'),
  requirement('A.8.15', 'Registro de eventos', 'Generar, almacenar, proteger y analizar registros de eventos.'),
  requirement('A.8.16', 'Actividades de monitoreo', 'Monitorizar redes, sistemas y aplicaciones y evaluar anomalías.'),
  requirement('A.8.17', 'Sincronización de relojes', 'Sincronizar los relojes de los sistemas con fuentes de tiempo aprobadas.'),
  requirement('A.8.18', 'Uso de programas utilitarios privilegiados', 'Restringir y controlar el uso de utilidades que puedan eludir controles.'),
  requirement('A.8.19', 'Instalación de software en sistemas operativos', 'Establecer y aplicar procedimientos para la instalación segura de software.'),
  requirement('A.8.20', 'Redes', 'Proteger, gestionar y controlar las redes y sus dispositivos.'),
  requirement('A.8.21', 'Seguridad de los servicios de red', 'Identificar, implementar y supervisar los mecanismos de seguridad de los servicios de red.'),
  requirement('A.8.22', 'Segregación de redes', 'Separar grupos de servicios, usuarios y sistemas de información en redes.'),
  requirement('A.8.23', 'Filtrado web', 'Gestionar el acceso a sitios web externos para reducir la exposición a contenido malicioso.'),
  requirement('A.8.24', 'Uso de criptografía', 'Definir y aplicar reglas para el uso eficaz de la criptografía y la gestión de claves.'),
  requirement('A.8.25', 'Ciclo de vida de desarrollo seguro', 'Establecer reglas para el desarrollo seguro de software y sistemas.'),
  requirement('A.8.26', 'Requisitos de seguridad de las aplicaciones', 'Identificar y especificar los requisitos de seguridad al desarrollar o adquirir aplicaciones.'),
  requirement('A.8.27', 'Principios de arquitectura e ingeniería seguras', 'Establecer e implementar principios de ingeniería segura de sistemas.'),
  requirement('A.8.28', 'Codificación segura', 'Aplicar principios de codificación segura en el desarrollo de software.'),
  requirement('A.8.29', 'Pruebas de seguridad en desarrollo y aceptación', 'Definir y aplicar procesos de pruebas de seguridad en el ciclo de desarrollo.'),
  requirement('A.8.30', 'Desarrollo subcontratado', 'Dirigir, supervisar y revisar la actividad de desarrollo subcontratada.'),
  requirement('A.8.31', 'Separación de entornos de desarrollo, prueba y producción', 'Separar y proteger los entornos de desarrollo, prueba y producción.'),
  requirement('A.8.32', 'Gestión de cambios', 'Someter los cambios en la información, los sistemas y las instalaciones a procedimientos de gestión de cambios.'),
  requirement('A.8.33', 'Información de prueba', 'Seleccionar, proteger y gestionar adecuadamente la información usada en pruebas.'),
  requirement('A.8.34', 'Protección de sistemas de información durante pruebas de auditoría', 'Planificar y acordar las pruebas de auditoría que afecten a sistemas en producción.'),
];

/** Códigos de los controles del Anexo A (A.5…A.8), en orden. */
export const ISO27001_CONTROL_CODES = ISO27001_CLAUSES.filter((c) =>
  c.code.startsWith('A.'),
).map((c) => c.code);
