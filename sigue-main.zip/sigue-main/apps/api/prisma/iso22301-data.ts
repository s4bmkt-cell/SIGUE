// Datos de la norma ISO 22301:2019 (redacción propia — sin copiar texto de la norma).
// Estructura: cláusulas 4..10 con los requisitos clave de continuidad del negocio.

import type { ClauseSeed } from './iso9001-data';

let order = 0;
const clause = (code: string, title: string): ClauseSeed => ({
  code,
  title,
  kind: 'clause',
  weight: 1,
  sortOrder: ++order,
});
const requirement = (code: string, title: string, requirementText: string, weight = 2): ClauseSeed => ({
  code,
  title,
  requirementText,
  kind: 'requirement',
  weight,
  sortOrder: ++order,
});

export const ISO22301_CLAUSES: ClauseSeed[] = [
  // --- Cláusula 4: Contexto de la organización ---
  clause('4', 'Contexto de la organización'),
  requirement(
    '4.1',
    'Comprensión de la organización y su contexto',
    'Analizar las cuestiones internas y externas que afectan la capacidad de mantener la continuidad del negocio.',
  ),
  requirement(
    '4.2',
    'Comprensión de las necesidades y expectativas de las partes interesadas',
    'Identificar las partes interesadas pertinentes al SGCN y sus requisitos, incluidos los legales y regulatorios.',
  ),
  requirement(
    '4.3',
    'Determinación del alcance del sistema de gestión de continuidad del negocio',
    'Definir y documentar el alcance del SGCN considerando los productos y servicios, las dependencias y las interfaces externas.',
    3,
  ),
  requirement(
    '4.4',
    'Sistema de gestión de continuidad del negocio',
    'Establecer, implementar, mantener y mejorar de forma continua el SGCN y sus procesos.',
    3,
  ),

  // --- Cláusula 5: Liderazgo ---
  clause('5', 'Liderazgo'),
  requirement(
    '5.1',
    'Liderazgo y compromiso',
    'La alta dirección debe demostrar liderazgo y compromiso con el SGCN, integrándolo con la estrategia y los procesos del negocio.',
    3,
  ),
  requirement(
    '5.2',
    'Política de continuidad del negocio',
    'Establecer una política de continuidad del negocio, aprobada, comunicada y disponible para las partes interesadas.',
    3,
  ),
  requirement(
    '5.3',
    'Roles, responsabilidades y autoridades',
    'Asignar y comunicar roles, responsabilidades y autoridades para el SGCN, incluidos los equipos de respuesta.',
  ),

  // --- Cláusula 6: Planificación ---
  clause('6', 'Planificación'),
  requirement(
    '6.1',
    'Acciones para abordar riesgos y oportunidades',
    'Determinar los riesgos y oportunidades que deben abordarse para asegurar que el SGCN logre sus resultados previstos.',
  ),
  requirement(
    '6.2',
    'Objetivos de continuidad del negocio y planificación para lograrlos',
    'Establecer objetivos de continuidad medibles, coherentes con la política, con responsables, plazos y métodos de evaluación.',
  ),
  requirement(
    '6.3',
    'Planificación de cambios',
    'Planificar los cambios del SGCN de forma controlada y considerando sus consecuencias.',
  ),

  // --- Cláusula 7: Soporte ---
  clause('7', 'Soporte'),
  requirement(
    '7.1',
    'Recursos',
    'Determinar y proporcionar los recursos necesarios para el SGCN.',
  ),
  requirement(
    '7.2',
    'Competencia',
    'Asegurar que el personal que ejecuta funciones de continuidad sea competente y conservar evidencia.',
  ),
  requirement(
    '7.3',
    'Toma de conciencia',
    'Asegurar que el personal comprenda la política de continuidad y su papel en la respuesta a interrupciones.',
  ),
  requirement(
    '7.4',
    'Comunicación',
    'Determinar qué, cuándo, con quién y cómo comunicar durante la operación normal y las interrupciones, incluida la comunicación con autoridades y medios.',
    3,
  ),
  requirement(
    '7.5',
    'Información documentada',
    'Mantener y controlar la información documentada requerida por el SGCN.',
  ),

  // --- Cláusula 8: Operación ---
  clause('8', 'Operación'),
  requirement(
    '8.1',
    'Planificación y control operacional',
    'Planificar, implementar y controlar los procesos necesarios para cumplir los requisitos del SGCN.',
  ),
  requirement(
    '8.2',
    'Análisis de impacto en el negocio y valoración de riesgos',
    'Realizar y mantener actualizado el análisis de impacto en el negocio y la valoración de riesgos de interrupción.',
    3,
  ),
  requirement(
    '8.3',
    'Estrategias y soluciones de continuidad del negocio',
    'Identificar y seleccionar estrategias y soluciones para continuar y recuperar las actividades prioritarias.',
    3,
  ),
  requirement(
    '8.4',
    'Planes y procedimientos de continuidad del negocio',
    'Desarrollar e implementar planes y procedimientos de continuidad con roles, estructura de respuesta y comunicaciones.',
    3,
  ),
  requirement(
    '8.5',
    'Ejercicios y pruebas',
    'Planificar y ejecutar ejercicios y pruebas del SGCN a intervalos planificados y revisar sus resultados.',
    3,
  ),
  requirement(
    '8.6',
    'Evaluación del desempeño del SGCN',
    'Evaluar el desempeño y la eficacia del SGCN para demostrar su adecuación.',
  ),

  // --- Cláusula 9: Evaluación del desempeño ---
  clause('9', 'Evaluación del desempeño'),
  requirement(
    '9.1',
    'Seguimiento, medición, análisis y evaluación',
    'Determinar qué medir, los métodos, cuándo y quién, y analizar los resultados del SGCN.',
  ),
  requirement(
    '9.2',
    'Auditoría interna',
    'Planificar y realizar auditorías internas del SGCN conforme a un programa establecido.',
  ),
  requirement(
    '9.3',
    'Revisión por la dirección',
    'Revisar el SGCN a intervalos planificados con las entradas y salidas que exige la norma.',
  ),

  // --- Cláusula 10: Mejora ---
  clause('10', 'Mejora'),
  requirement(
    '10.1',
    'Mejora continua',
    'Mejorar de forma continua la idoneidad, adecuación y eficacia del SGCN.',
  ),
  requirement(
    '10.2',
    'No conformidad y acción correctiva',
    'Gestionar las no conformidades del SGCN y verificar la eficacia de las acciones correctivas.',
    3,
  ),
];
