// Datos de la norma ISO 9001:2015 (redacción propia — sin copiar texto de la norma).
// Estructura: cláusulas de nivel 1 (4..10) y requisitos clave por cláusula.

export interface ClauseSeed {
  code: string;
  title: string;
  kind: 'clause' | 'requirement';
  requirementText?: string;
  weight: number;
  sortOrder: number;
}

export const ISO9001_CLAUSES: ClauseSeed[] = [
  // --- Cláusula 4: Contexto de la organización ---
  { code: '4', title: 'Contexto de la organización', kind: 'clause', weight: 1, sortOrder: 1 },
  { code: '4.1', title: 'Comprensión de la organización y su contexto', kind: 'requirement',
    requirementText: 'Determinar las cuestiones externas e internas pertinentes al propósito y dirección estratégica de la organización, y hacer seguimiento de ellas.',
    weight: 2, sortOrder: 2 },
  { code: '4.2', title: 'Comprensión de las necesidades y expectativas de las partes interesadas', kind: 'requirement',
    requirementText: 'Identificar las partes interesadas pertinentes al sistema de gestión y sus requisitos, con seguimiento de la información.',
    weight: 2, sortOrder: 3 },
  { code: '4.3', title: 'Determinación del alcance del sistema de gestión', kind: 'requirement',
    requirementText: 'Definir el alcance del sistema de gestión considerando cuestiones internas/externas, partes interesadas y productos y servicios.',
    weight: 2, sortOrder: 4 },
  { code: '4.4', title: 'Sistema de gestión y sus procesos', kind: 'requirement',
    requirementText: 'Establecer, implementar, mantener y mejorar continuamente el sistema de gestión, incluyendo los procesos necesarios y sus interacciones.',
    weight: 3, sortOrder: 5 },

  // --- Cláusula 5: Liderazgo ---
  { code: '5', title: 'Liderazgo', kind: 'clause', weight: 1, sortOrder: 6 },
  { code: '5.1', title: 'Liderazgo y compromiso', kind: 'requirement',
    requirementText: 'La alta dirección debe demostrar liderazgo y compromiso con el sistema de gestión, asumiendo la responsabilidad de su eficacia.',
    weight: 2, sortOrder: 7 },
  { code: '5.2', title: 'Política', kind: 'requirement',
    requirementText: 'Establecer, implementar y mantener una política de calidad adecuada al propósito y contexto de la organización.',
    weight: 2, sortOrder: 8 },
  { code: '5.3', title: 'Roles, responsabilidades y autoridades', kind: 'requirement',
    requirementText: 'Asignar y comunicar los roles, responsabilidades y autoridades relevantes dentro de la organización.',
    weight: 2, sortOrder: 9 },

  // --- Cláusula 6: Planificación ---
  { code: '6', title: 'Planificación', kind: 'clause', weight: 1, sortOrder: 10 },
  { code: '6.1', title: 'Acciones para abordar riesgos y oportunidades', kind: 'requirement',
    requirementText: 'Determinar los riesgos y oportunidades que afectan a la conformidad de los productos y servicios, y planificar acciones para abordarlos.',
    weight: 3, sortOrder: 11 },
  { code: '6.2', title: 'Objetivos de la calidad y planificación para lograrlos', kind: 'requirement',
    requirementText: 'Establecer objetivos de calidad coherentes con la política, con seguimiento, responsables y plazos.',
    weight: 3, sortOrder: 12 },
  { code: '6.3', title: 'Planificación de los cambios', kind: 'requirement',
    requirementText: 'Planificar los cambios del sistema de gestión de manera que se mantenga su integridad.',
    weight: 2, sortOrder: 13 },

  // --- Cláusula 7: Soporte ---
  { code: '7', title: 'Soporte', kind: 'clause', weight: 1, sortOrder: 14 },
  { code: '7.1', title: 'Recursos', kind: 'requirement',
    requirementText: 'Determinar y proporcionar los recursos necesarios (personas, infraestructura, ambiente) para la operación del sistema.',
    weight: 2, sortOrder: 15 },
  { code: '7.1.5', title: 'Recursos de seguimiento y medición', kind: 'requirement',
    requirementText: 'Mantener la trazabilidad de las mediciones mediante equipos calibrados o verificados.',
    weight: 2, sortOrder: 16 },
  { code: '7.2', title: 'Competencia', kind: 'requirement',
    requirementText: 'Asegurar que las personas que realizan trabajos que afectan a la calidad son competentes, y tomar acciones cuando no lo sean.',
    weight: 3, sortOrder: 17 },
  { code: '7.3', title: 'Toma de conciencia', kind: 'requirement',
    requirementText: 'Asegurar que las personas toman conciencia de la política, los objetivos y su contribución a la eficacia del sistema.',
    weight: 2, sortOrder: 18 },
  { code: '7.4', title: 'Comunicación', kind: 'requirement',
    requirementText: 'Determinar las comunicaciones internas y externas pertinentes al sistema de gestión.',
    weight: 2, sortOrder: 19 },
  { code: '7.5', title: 'Información documentada', kind: 'requirement',
    requirementText: 'Controlar la información documentada requerida por el sistema y por la norma, con creación, actualización y control adecuados.',
    weight: 3, sortOrder: 20 },

  // --- Cláusula 8: Operación ---
  { code: '8', title: 'Operación', kind: 'clause', weight: 1, sortOrder: 21 },
  { code: '8.1', title: 'Planificación y control operacional', kind: 'requirement',
    requirementText: 'Planificar, implementar y controlar los procesos necesarios para cumplir los requisitos de los productos y servicios.',
    weight: 3, sortOrder: 22 },
  { code: '8.2', title: 'Requisitos para los productos y servicios', kind: 'requirement',
    requirementText: 'Determinar, revisar y comunicar los requisitos de los productos y servicios, incluyendo la comunicación con el cliente.',
    weight: 3, sortOrder: 23 },
  { code: '8.3', title: 'Diseño y desarrollo', kind: 'requirement',
    requirementText: 'Planificar y controlar el diseño y desarrollo de productos y servicios cuando aplique.',
    weight: 2, sortOrder: 24 },
  { code: '8.4', title: 'Control de los procesos, productos y servicios suministrados externamente', kind: 'requirement',
    requirementText: 'Controlar los proveedores externos y los procesos, productos y servicios que suministran.',
    weight: 3, sortOrder: 25 },
  { code: '8.5', title: 'Producción y prestación del servicio', kind: 'requirement',
    requirementText: 'Implementar la producción y prestación del servicio bajo condiciones controladas.',
    weight: 3, sortOrder: 26 },
  { code: '8.5.1', title: 'Control de la producción', kind: 'requirement',
    requirementText: 'Disponer de información documentada, seguimiento y medición, y actividades de liberación y entrega bajo condiciones controladas.',
    weight: 2, sortOrder: 27 },
  { code: '8.5.2', title: 'Identificación y trazabilidad', kind: 'requirement',
    requirementText: 'Identificar las salidas para asegurar la trazabilidad cuando sea requerida.',
    weight: 2, sortOrder: 28 },
  { code: '8.6', title: 'Liberación de los productos y servicios', kind: 'requirement',
    requirementText: 'Liberar los productos y servicios únicamente cuando se hayan cumplido los criterios de aceptación.',
    weight: 2, sortOrder: 29 },
  { code: '8.7', title: 'Control de las salidas no conformes', kind: 'requirement',
    requirementText: 'Identificar y controlar las salidas no conformes para prevenir su uso o entrega no intencionada.',
    weight: 3, sortOrder: 30 },

  // --- Cláusula 9: Evaluación del desempeño ---
  { code: '9', title: 'Evaluación del desempeño', kind: 'clause', weight: 1, sortOrder: 31 },
  { code: '9.1', title: 'Seguimiento, medición, análisis y evaluación', kind: 'requirement',
    requirementText: 'Determinar qué se necesita seguir y medir, y evaluar el desempeño y la eficacia del sistema.',
    weight: 3, sortOrder: 32 },
  { code: '9.1.2', title: 'Satisfacción del cliente', kind: 'requirement',
    requirementText: 'Hacer seguimiento de la percepción del cliente sobre el grado en que se cumplen sus necesidades y expectativas.',
    weight: 3, sortOrder: 33 },
  { code: '9.2', title: 'Auditoría interna', kind: 'requirement',
    requirementText: 'Realizar auditorías internas a intervalos planificados para verificar la conformidad y eficacia del sistema.',
    weight: 3, sortOrder: 34 },
  { code: '9.3', title: 'Revisión por la dirección', kind: 'requirement',
    requirementText: 'Revisar periódicamente el sistema de gestión por la dirección, considerando las entradas requeridas y emitiendo acuerdos.',
    weight: 3, sortOrder: 35 },

  // --- Cláusula 10: Mejora ---
  { code: '10', title: 'Mejora', kind: 'clause', weight: 1, sortOrder: 36 },
  { code: '10.1', title: 'Generalidades', kind: 'requirement',
    requirementText: 'Determinar y seleccionar las oportunidades de mejora e implementar las acciones necesarias.',
    weight: 2, sortOrder: 37 },
  { code: '10.2', title: 'No conformidad y acción correctiva', kind: 'requirement',
    requirementText: 'Cuando ocurra una no conformidad, reaccionar, evaluar la necesidad de acciones, y verificar la eficacia de las acciones tomadas.',
    weight: 3, sortOrder: 38 },
  { code: '10.3', title: 'Mejora continua', kind: 'requirement',
    requirementText: 'Mejorar continuamente la conveniencia, adecuación y eficacia del sistema de gestión.',
    weight: 2, sortOrder: 39 },
];
