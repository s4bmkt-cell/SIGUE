/**
 * Aprovisiona el rol de aplicación con privilegios mínimos y fuerza RLS.
 *
 * PostgreSQL **no aplica** Row-Level Security al dueño de una tabla. Mientras la API
 * conectaba como el dueño (`sigue`), las políticas existían pero eran inertes. Este
 * script crea `sigue_app`, le concede solo DML sobre las tablas de negocio y activa
 * `FORCE ROW LEVEL SECURITY` para que incluso el dueño quede sujeto a las políticas.
 *
 * Requiere credenciales con CREATEROLE (por defecto `postgres`):
 *   DATABASE_URL_ADMIN=postgresql://postgres:clave@localhost:5432/sigue
 *   APP_DB_PASSWORD=<clave del rol de aplicación>
 *   node prisma/setup-app-role.mjs
 *
 * Es idempotente: puede ejecutarse en cada despliegue.
 */
import { PrismaClient } from '@prisma/client';
import { config } from 'dotenv';

// Carga `.env` para que el script funcione igual desde npm que desde CI.
config();

const adminUrl = process.env.DATABASE_URL_ADMIN;
const appPassword = process.env.APP_DB_PASSWORD;
const appRole = process.env.APP_DB_ROLE ?? 'sigue_app';
const dbName = process.env.APP_DB_NAME ?? 'sigue';

if (!adminUrl) {
  console.error('Falta DATABASE_URL_ADMIN (rol con CREATEROLE). Abortando.');
  process.exit(1);
}
if (!appPassword) {
  console.error('Falta APP_DB_PASSWORD (contraseña del rol de aplicación). Abortando.');
  process.exit(1);
}
if (!/^[a-z_][a-z0-9_]*$/.test(appRole)) {
  console.error(`Nombre de rol inválido: ${appRole}`);
  process.exit(1);
}

const prisma = new PrismaClient({ datasourceUrl: adminUrl });

/** Tablas de negocio con `orgId`: las únicas que la app debe poder tocar. */
const TENANT_MODELS = [
  'OrgMember', 'OrgBranch', 'OrgArea', 'Invitation', 'OrgStandard', 'RequirementStatus',
  'ContextSwotAnalysis', 'ContextPestelAnalysis',
  'ContextSwot', 'ContextPestel', 'ContextParty', 'ContextIssue', 'LegalRequirement', 'ProcessMap', 'Risk',
  'RiskAssessment', 'RiskTreatment', 'Control', 'Objective', 'ObjectiveKpi', 'ObjectiveResult',
  'WorkPlan', 'PlanTask', 'Document', 'DocumentVersion', 'DocWorkflowStep',
  'DocumentDistribution', 'DocumentFile', 'Template', 'Evidence', 'EvidenceFile', 'EvidenceRequirement',
  'AuditProgram', 'Audit', 'AuditChecklist', 'ChecklistItem', 'Finding', 'Nc', 'NcCorrection',
  'RootCause', 'CorrectiveAction', 'EffectivenessVerification', 'LessonLearned', 'MgmtReview',
  'ReviewEntry', 'ReviewAgreement', 'SecurityAsset', 'StatementOfApplicability',
  'SecurityIncident', 'Bia', 'ContinuityPlan', 'ContinuityExercise', 'Notification', 'AiSystem',
  'AiOrgUseCase', 'AiImpactAssessment', 'AiSystemRisk', 'AiSystemControl', 'AiLifecycleEvent',
  'AiUseCase', 'AiPrompt', 'AiInteraction', 'AiConsumption', 'AiIncident',
  'AiDocumentEmbedding', 'Subscription', 'OrgUsage', 'ExportJob', 'DocumentSignature',
  'ServiceCatalog', 'ServiceLevelAgreement', 'ServiceRequest',
  'BriberyRiskAssessment', 'BriberyControl', 'BriberyIncident',
  'AuditLog',
];

/** Tablas globales de solo lectura para la app (catálogo normativo y proveedores). */
const READONLY_MODELS = ['Standard', 'StandardClause', 'AiProvider', 'AiModel'];

/**
 * Tablas de inquilino con política propia que no encaja en `TENANT_MODELS`.
 *
 * `Organization` usa `id` como clave y admite lectura, alta y edición, pero no
 * borrado. El alta la necesita el panel de plataforma (la política RLS
 * `platform_insert_Organization` la acota a quien trae el GUC `app.platform`);
 * sin ese contexto la app sigue sin poder crear organizaciones. Dar de baja es
 * suspender, nunca borrar.
 */
const CUSTOM_TENANT_MODELS = ['Organization'];

async function main() {
  await prisma.$executeRawUnsafe(`
    DO $$
    BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname = '${appRole}') THEN
        CREATE ROLE "${appRole}" LOGIN;
      END IF;
    END
    $$;
  `);
  await prisma.$executeRawUnsafe(`ALTER ROLE "${appRole}" WITH LOGIN PASSWORD '${appPassword.replace(/'/g, "''")}'`);

  // Atributos del rol de aplicación, uno por uno y tolerando el fallo: un rol no
  // superusuario con CREATEROLE solo puede cambiar los atributos que él mismo
  // posee, y `NOSUPERUSER` está reservado a los superusuarios. En una base
  // gestionada (Neon, RDS) el administrador no es superusuario, así que un único
  // `ALTER ROLE … NOSUPERUSER NOBYPASSRLS …` abortaría el script entero.
  // Lo que importa es el estado final, y eso se comprueba justo abajo.
  for (const attribute of ['NOSUPERUSER', 'NOBYPASSRLS', 'NOCREATEDB', 'NOCREATEROLE']) {
    await prisma.$executeRawUnsafe(`ALTER ROLE "${appRole}" ${attribute}`).catch(() => {});
  }

  const [flags] = await prisma.$queryRawUnsafe(`
    SELECT rolsuper, rolbypassrls, rolcreaterole
    FROM pg_roles WHERE rolname = '${appRole}'
  `);
  const dangerous = [
    flags.rolsuper && 'SUPERUSER',
    flags.rolbypassrls && 'BYPASSRLS',
    flags.rolcreaterole && 'CREATEROLE',
  ].filter(Boolean);
  if (dangerous.length > 0) {
    // Un rol de aplicación con cualquiera de estos atributos puede desactivar RLS
    // o apropiarse de las tablas: el aislamiento entre organizaciones dejaría de
    // existir. Se aborta antes de conceder ningún permiso.
    throw new Error(
      `El rol "${appRole}" conserva atributos peligrosos (${dangerous.join(', ')}) y ` +
        'este usuario no puede retirarlos. Ejecútalo como superusuario o bórralo y repite.',
    );
  }
  await prisma.$executeRawUnsafe(`GRANT CONNECT ON DATABASE "${dbName}" TO "${appRole}"`);
  await prisma.$executeRawUnsafe(`GRANT USAGE ON SCHEMA public TO "${appRole}"`);

  // La app no necesita DDL ni acceso a tablas globales sensibles: solo DML en tenant.
  for (const table of TENANT_MODELS) {
    // La bitácora es append-only: ni siquiera el rol de la app puede reescribirla.
    const privileges =
      table === 'AuditLog' ? 'SELECT, INSERT' : 'SELECT, INSERT, UPDATE, DELETE';
    await prisma.$executeRawUnsafe(
      `GRANT ${privileges} ON TABLE "${table}" TO "${appRole}"`,
    );
    if (table === 'AuditLog') {
      await prisma.$executeRawUnsafe(
        `REVOKE UPDATE, DELETE ON TABLE "AuditLog" FROM "${appRole}"`,
      );
    }
  }
  for (const table of READONLY_MODELS) {
    await prisma.$executeRawUnsafe(`GRANT SELECT ON TABLE "${table}" TO "${appRole}"`);
  }

  // Sesiones y usuarios: la app necesita leer/crear usuarios y administrar tokens.
  for (const table of ['User', 'RefreshToken', 'PasswordResetToken']) {
    await prisma.$executeRawUnsafe(
      `GRANT SELECT, INSERT, UPDATE, DELETE ON TABLE "${table}" TO "${appRole}"`,
    );
  }

  // `Organization` va aparte: lectura, alta y edición, nunca borrado. El alta
  // queda acotada por la política `platform_insert_Organization`, que exige el
  // GUC `app.platform`; sin él, el `WITH CHECK` no se cumple y el INSERT falla.
  for (const table of CUSTOM_TENANT_MODELS) {
    await prisma.$executeRawUnsafe(
      `REVOKE DELETE ON TABLE "${table}" FROM "${appRole}"`,
    );
    await prisma.$executeRawUnsafe(
      `GRANT SELECT, INSERT, UPDATE ON TABLE "${table}" TO "${appRole}"`,
    );
  }

  // Cabeza de las cadenas de auditoría: la app la lee y la avanza en cada evento.
  await prisma.$executeRawUnsafe(
    `GRANT SELECT, INSERT, UPDATE ON TABLE "AuditChain" TO "${appRole}"`,
  );

  // Secuencias (si en el futuro se usan ids seriales).
  await prisma.$executeRawUnsafe(
    `GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO "${appRole}"`,
  );
  // Nuevas tablas creadas por migraciones futuras heredan los mismos privilegios.
  await prisma.$executeRawUnsafe(
    `ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO "${appRole}"`,
  );

  const owner = process.env.APP_DB_OWNER;
  let ownerBypasses = false;
  if (owner) {
    try {
      await prisma.$executeRawUnsafe(`ALTER ROLE "${owner}" BYPASSRLS`);
    } catch {
      // Sin superusuario no se puede conceder; se resuelve más abajo.
    }
    const [rol] = await prisma.$queryRawUnsafe(
      `SELECT rolbypassrls FROM pg_roles WHERE rolname = '${owner.replace(/'/g, "''")}'`,
    );
    ownerBypasses = Boolean(rol?.rolbypassrls);
  }

  // RLS habilitado en todo el modelo de inquilino.
  const rlsTables = [...TENANT_MODELS, ...CUSTOM_TENANT_MODELS];
  for (const table of rlsTables) {
    await prisma.$executeRawUnsafe(`ALTER TABLE "${table}" ENABLE ROW LEVEL SECURITY`);
  }

  // AuditLog admite eventos sin organización (login, recuperación de contraseña).
  // Se ve lo de la organización activa y lo propio del usuario.
  await prisma.$executeRawUnsafe(`DROP POLICY IF EXISTS "tenant_isolation_AuditLog" ON "AuditLog"`);
  await prisma.$executeRawUnsafe(`
    CREATE POLICY "tenant_isolation_AuditLog" ON "AuditLog"
    USING (
      "orgId" = current_setting('app.org_id', true)
      OR ("orgId" IS NULL AND "actorId" = current_setting('app.user_id', true))
    )
    WITH CHECK (
      "orgId" = current_setting('app.org_id', true)
      OR ("orgId" IS NULL AND "actorId" = current_setting('app.user_id', true))
    )
  `);

  // `FORCE` hace que las políticas apliquen también al dueño: defensa en
  // profundidad, pero exige que el dueño pueda saltárselas para migrar, sembrar
  // y reparar la auditoría. En PostgreSQL autogestionado el dueño recibe
  // `BYPASSRLS` con el `ALTER ROLE` de arriba. En una base gestionada (Neon,
  // RDS) no hay superusuario y los atributos de rol **no se heredan** por
  // membresía, así que `FORCE` solo conseguiría que el dueño operara a ciegas:
  // sus escrituras se filtrarían en silencio en lugar de fallar. En ese caso se
  // deja sin `FORCE`: el dueño queda exento, como en cualquier Postgres sin
  // `FORCE`, y el rol de aplicación —que no es propietario— sigue sujeto a las
  // políticas, que es lo que protege el aislamiento de la API.
  for (const table of rlsTables) {
    const clause = ownerBypasses ? 'FORCE' : 'NO FORCE';
    await prisma.$executeRawUnsafe(`ALTER TABLE "${table}" ${clause} ROW LEVEL SECURITY`);
  }

  const enforced = await prisma.$queryRawUnsafe(`
    SELECT count(*)::int AS total
    FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
    WHERE n.nspname = 'public' AND c.relrowsecurity AND c.relforcerowsecurity
  `);
  console.log(`✔ Rol "${appRole}" aprovisionado. Tablas con RLS forzado: ${enforced[0]?.total ?? 0}`);
  if (owner && !ownerBypasses) {
    console.log(
      `   Nota: "${owner}" no tiene BYPASSRLS, así que esas tablas quedan sin FORCE. ` +
        'El rol de aplicación sigue sujeto a RLS; el dueño solo lo usa para migrar y sembrar.',
    );
  }
}

main()
  .catch((error) => {
    console.error('✖ Error aprovisionando el rol de aplicación:', error.message);
    process.exitCode = 1;
  })
  .finally(() => prisma.$disconnect());
