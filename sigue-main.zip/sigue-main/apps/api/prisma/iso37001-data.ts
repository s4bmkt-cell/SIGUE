// Datos de la norma ISO 37001:2025 (redacción propia — sin copiar texto de la norma).
// Estructura armonizada: cláusulas 4..10. Los controles antifraude no viven en
// un anexo aparte, sino en la cláusula 8 (operación).

import type { ClauseSeed } from './iso9001-data';

let order = 0;
const clause = (code: string, title: string): ClauseSeed => ({
  code,
  title,
  kind: 'clause',
  weight: 1,
  sortOrder: ++order,
});
const requirement = (code: string, title: string, requirementText: string, weight = 2): ClauseSeed => ({
  code,
  title,
  requirementText,
  kind: 'requirement',
  weight,
  sortOrder: ++order,
});

export const ISO37001_CLAUSES: ClauseSeed[] = [
  // --- Cláusula 4: Contexto de la organización ---
  clause('4', 'Contexto de la organización'),
  requirement(
    '4.1',
    'Comprensión de la organización y de su contexto',
    'Determinar las cuestiones internas y externas pertinentes al propósito de la organización y al soborno, incluida la relevancia del cambio climático.',
  ),
  requirement(
    '4.2',
    'Comprensión de las necesidades y expectativas de las partes interesadas',
    'Identificar las partes interesadas del sistema antifraude y los requisitos que de ellas se derivan.',
  ),
  requirement(
    '4.3',
    'Determinación del alcance del sistema de gestión antisoborno',
    'Definir los límites del sistema considerando actividades, ubicaciones, filiales y contrapartes.',
    3,
  ),
  requirement('4.4', 'Sistema de gestión antisoborno', 'Establecer, implementar, mantener y mejorar de forma continua el SGAS y sus procesos.'),
  requirement(
    '4.5',
    'Evaluación del riesgo de soborno',
    'Identificar y evaluar el riesgo de soborno de las actividades propias y de las contrapartes, y actualizarlo periódicamente.',
    3,
  ),

  // --- Cláusula 5: Liderazgo ---
  clause('5', 'Liderazgo'),
  requirement('5.1.1', 'Compromiso del órgano de gobierno', 'El órgano de gobierno supervisa el SGAS y asegura su eficacia e independencia.', 3),
  requirement('5.1.2', 'Compromiso de la alta dirección', 'La alta dirección demuestra liderazgo, provee recursos y asume la responsabilidad del SGAS.', 3),
  requirement(
    '5.1.3',
    'Cultura antisoborno',
    'Desarrollar, mantener y promover una cultura de integridad en todos los niveles de la organización.',
    3,
  ),
  requirement('5.2', 'Política antisoborno', 'Establecer y comunicar una política que prohíba el soborno y sea coherente con el contexto legal y operativo.', 3),
  requirement('5.3', 'Roles, responsabilidades y autoridades', 'Asignar responsabilidades, incluida una función antisoborno independiente con autoridad suficiente.'),

  // --- Cláusula 6: Planificación ---
  clause('6', 'Planificación'),
  requirement('6.1', 'Acciones para abordar riesgos y oportunidades', 'Planificar las acciones derivadas de la evaluación de riesgos y su integración en el SGAS.', 3),
  requirement('6.2', 'Objetivos antisoborno y planificación para lograrlos', 'Definir objetivos medibles y las acciones, responsables y plazos para alcanzarlos.'),
  requirement('6.3', 'Planificación de los cambios', 'Planificar los cambios del SGAS de forma controlada, considerando su propósito y consecuencias.'),

  // --- Cláusula 7: Apoyo ---
  clause('7', 'Apoyo'),
  requirement('7.1', 'Recursos', 'Proporcionar los recursos necesarios para el SGAS, incluidos los de la función antisoborno.'),
  requirement('7.2', 'Competencia', 'Asegurar la competencia del personal con responsabilidades en el SGAS y mantener evidencia.'),
  requirement(
    '7.2.2',
    'Proceso de empleo',
    'Aplicar controles de integridad en la selección, contratación y promoción del personal en puestos de riesgo.',
    3,
  ),
  requirement('7.3', 'Toma de conciencia y formación', 'Sensibilizar y formar al personal en la política, sus obligaciones y cómo reportar inquietudes.'),
  requirement('7.4', 'Comunicación', 'Determinar la comunicación interna y externa relevante para el SGAS.'),
  requirement('7.5', 'Información documentada', 'Controlar la información documentada requerida por el SGAS.'),

  // --- Cláusula 8: Operación (controles antifraude) ---
  clause('8', 'Operación'),

  requirement('8.1', 'Planificación y control operacional', 'Planificar y controlar los procesos que implementan los controles antisoborno.', 3),
  requirement(
    '8.2',
    'Diligencia debida',
    'Evaluar la integridad y el riesgo de soborno de contrapartes, proyectos y transacciones antes de contratar.',
    3,
  ),
  requirement('8.3', 'Controles financieros', 'Aplicar controles sobre pagos, autorizaciones, registros y conciliaciones para prevenir y detectar soborno.', 3),
  requirement('8.4', 'Controles no financieros', 'Aplicar controles en compras, contrataciones, donaciones y otras actividades expuestas.'),
  requirement('8.5', 'Controles de organizaciones controladas y socios de negocio', 'Asegurar que las filiales y contrapartes aplican controles antisoborno equivalentes.', 3),
  requirement('8.6', 'Compromisos antisoborno', 'Obtener compromisos antisoborno de socios de negocio cuando el riesgo lo justifique.'),
  requirement('8.7', 'Regalos, hospitalidad, donaciones y beneficios similares', 'Regular y registrar la entrega y recepción de beneficios que puedan interpretarse como soborno.', 3),
  requirement('8.8', 'Gestión de la insuficiencia de los controles antisoborno', 'Definir qué hacer cuando los controles no son suficientes, incluida la revisión de la relación.'),
  requirement('8.9', 'Comunicación de inquietudes', 'Habilitar canales confidenciales para reportar sospechas de soborno sin represalias.', 3),
  requirement('8.10', 'Investigación y tratamiento del soborno', 'Investigar de forma independiente las denuncias y adoptar las medidas que correspondan.', 3),

  // --- Cláusula 9: Evaluación del desempeño ---
  clause('9', 'Evaluación del desempeño'),
  requirement('9.1', 'Seguimiento, medición, análisis y evaluación', 'Definir indicadores del SGAS, medirlos y evaluar su desempeño.'),
  requirement('9.2', 'Auditoría interna', 'Realizar auditorías internas del SGAS a intervalos planificados.', 2),
  requirement('9.3', 'Revisión por la dirección', 'Revisar el SGAS a intervalos planificados con las entradas y salidas requeridas.'),

  // --- Cláusula 10: Mejora ---
  clause('10', 'Mejora'),
  requirement('10.1', 'Mejora continua', 'Mejorar de forma continua la idoneidad, adecuación y eficacia del SGAS.'),
  requirement('10.2', 'No conformidad y acción correctiva', 'Gestionar las no conformidades y verificar la eficacia de las acciones correctivas.', 3),
];

/** Subcláusulas que la vista agrupa como "controles operativos". */
export const ISO37001_CONTROL_CODES = ISO37001_CLAUSES.filter(
  (c) => c.kind === 'requirement' && /^8\.(2|3|4|5|6|7|8|9|10)$/.test(c.code),
).map((c) => c.code);
