/**
 * Seed de desarrollo — SIGUE Iteración 0.
 * Puebla la BD con una organización, sus áreas y usuarios de demostración
 * (con contraseña 'demo-password' hasheada con bcrypt).
 * Ejecutar: npx prisma db seed
 *
 * Usa `DIRECT_URL` (rol dueño) a propósito: el seed escribe en varias
 * organizaciones a la vez y el rol de aplicación está sujeto a RLS.
 */
import { PrismaClient } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import { createHash } from 'crypto';
import { config } from 'dotenv';
import { ISO27001_CLAUSES } from './iso27001-data';
import { ISO42001_CLAUSES } from './iso42001-data';
import { seedCatalog } from './catalog';
import { signaturePayload } from '../src/common/document-signature';

config();

// El seed corre con el rol dueño: es la única vía que puede poblar varios inquilinos.
const prisma = new PrismaClient({
  datasourceUrl: process.env.DIRECT_URL ?? process.env.DATABASE_URL,
});

const DEMO_ORG_IDS = ['org-ejemplo', 'org-demo'];

/**
 * Entero estable 0..99 a partir de una cadena (FNV-1a).
 *
 * El seed necesita repartir estados de cumplimiento "como en la vida real" sin
 * que el resultado cambie entre ejecuciones. Un `Math.random()` rompería la
 * idempotencia; este hash da una distribución uniforme y determinista.
 */
function stableBucket(key: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < key.length; i += 1) {
    h ^= key.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return Math.abs(h) % 100;
}

/**
 * El seed debe poder ejecutarse N veces y dejar el mismo estado.
 * Borra los datos operativos de las organizaciones demo (de hijo a padre) y
 * conserva usuarios, membresías, catálogo de normas y bitácora de auditoría.
 */
async function resetDemoData() {
  const where = { orgId: { in: DEMO_ORG_IDS } };
  const del = async (label: string, fn: () => Promise<unknown>) => {
    await fn();
    void label;
  };

  await del('ai', async () => {
    await prisma.aiSystemControl.deleteMany({ where });
    await prisma.aiSystemRisk.deleteMany({ where });
    await prisma.aiImpactAssessment.deleteMany({ where });
    await prisma.aiOrgUseCase.deleteMany({ where });
    await prisma.aiLifecycleEvent.deleteMany({ where });
    await prisma.aiPrompt.deleteMany({ where });
    await prisma.aiInteraction.deleteMany({ where });
    await prisma.aiConsumption.deleteMany({ where });
    await prisma.aiIncident.deleteMany({ where });
    await prisma.aiDocumentEmbedding.deleteMany({ where });
    await prisma.aiUseCase.deleteMany({ where });
    await prisma.aiSystem.deleteMany({ where });
  });

  await del('docs', async () => {
    await prisma.documentSignature.deleteMany({ where });
    await prisma.documentDistribution.deleteMany({ where });
    await prisma.docWorkflowStep.deleteMany({ where });
    await prisma.documentVersion.deleteMany({ where });
    await prisma.document.deleteMany({ where });
    await prisma.template.deleteMany({ where });
  });

  await del('evidencias', async () => {
    await prisma.evidenceRequirement.deleteMany({ where });
    await prisma.evidenceFile.deleteMany({ where });
    await prisma.evidence.deleteMany({ where });
  });

  await del('auditorías', async () => {
    await prisma.finding.deleteMany({ where });
    await prisma.checklistItem.deleteMany({ where });
    await prisma.auditChecklist.deleteMany({ where });
    await prisma.audit.deleteMany({ where });
    await prisma.auditProgram.deleteMany({ where });
  });

  await del('nc', async () => {
    await prisma.effectivenessVerification.deleteMany({ where });
    await prisma.correctiveAction.deleteMany({ where });
    await prisma.lessonLearned.deleteMany({ where });
    await prisma.rootCause.deleteMany({ where });
    await prisma.ncCorrection.deleteMany({ where });
    await prisma.nc.deleteMany({ where });
  });

  await del('revisión', async () => {
    await prisma.reviewAgreement.deleteMany({ where });
    await prisma.reviewEntry.deleteMany({ where });
    await prisma.mgmtReview.deleteMany({ where });
  });

  await del('seguridad/continuidad', async () => {
    await prisma.securityIncident.deleteMany({ where });
    await prisma.statementOfApplicability.deleteMany({ where });
    await prisma.securityAsset.deleteMany({ where });
    await prisma.continuityExercise.deleteMany({ where });
    await prisma.continuityPlan.deleteMany({ where });
    await prisma.bia.deleteMany({ where });
  });

  await del('itsm/antisoborno', async () => {
    await prisma.serviceRequest.deleteMany({ where });
    await prisma.serviceLevelAgreement.deleteMany({ where });
    await prisma.serviceCatalog.deleteMany({ where });
    await prisma.briberyIncident.deleteMany({ where });
    await prisma.briberyControl.deleteMany({ where });
    await prisma.briberyRiskAssessment.deleteMany({ where });
  });

  await del('planificación', async () => {
    await prisma.planTask.deleteMany({ where });
    await prisma.workPlan.deleteMany({ where });
    await prisma.objectiveResult.deleteMany({ where });
    await prisma.objectiveKpi.deleteMany({ where });
    await prisma.objective.deleteMany({ where });
    await prisma.control.deleteMany({ where });
    await prisma.riskTreatment.deleteMany({ where });
    await prisma.riskAssessment.deleteMany({ where });
    await prisma.risk.deleteMany({ where });
  });

  await del('contexto', async () => {
    // Los elementos caen con su análisis (onDelete: Cascade en la FK); se borran
    // primero para no depender del orden de las FKs al ejecutar en PostgreSQL.
    await prisma.contextSwot.deleteMany({ where });
    await prisma.contextPestel.deleteMany({ where });
    await prisma.contextSwotAnalysis.deleteMany({ where });
    await prisma.contextPestelAnalysis.deleteMany({ where });
    await prisma.contextParty.deleteMany({ where });
    await prisma.contextIssue.deleteMany({ where });
    await prisma.legalRequirement.deleteMany({ where });
    await prisma.processMap.deleteMany({ where });
  });

  await del('transversal', async () => {
    await prisma.notification.deleteMany({ where });
    await prisma.exportJob.deleteMany({ where });
    await prisma.orgUsage.deleteMany({ where });
    await prisma.subscription.deleteMany({ where });
    await prisma.requirementStatus.deleteMany({ where });
  });
}

async function main() {
  console.log('→ Sembrando datos de demostración...');
  await resetDemoData();
  console.log('  ✔ Datos operativos demo reiniciados (seed idempotente)');

  // Organización
  const org = await prisma.organization.upsert({
    where: { id: 'org-ejemplo' },
    update: {},
    create: {
      id: 'org-ejemplo',
      name: 'Organización Ejemplo, S.A. de C.V.',
      legalName: 'Organización Ejemplo, S.A. de C.V.',
      planCode: 'BUSINESS',
    },
  });
  console.log('  ✔ Organización', org.id);

  // Usuarios (contraseña: demo-password)
  const hash = await bcrypt.hash('demo-password', 10);
  const mariana = await prisma.user.upsert({
    where: { email: 'mariana.torres@org.mx' },
    update: { passwordHash: hash },
    create: {
      email: 'mariana.torres@org.mx',
      name: 'Mariana Torres',
      passwordHash: hash,
    },
  });
  const jorge = await prisma.user.upsert({
    where: { email: 'jorge.aldana@org.mx' },
    update: { passwordHash: hash },
    create: {
      email: 'jorge.aldana@org.mx',
      name: 'Jorge Aldana',
      passwordHash: hash,
    },
  });
  console.log('  ✔ Usuarios mariana.torres@org.mx / jorge.aldana@org.mx (demo-password)');

  // Membresías (RBAC)
  await prisma.orgMember.upsert({
    where: { orgId_userId: { orgId: org.id, userId: mariana.id } },
    update: { roles: ['admin_org', 'resp_sgi'], status: 'ACTIVE' },
    create: {
      orgId: org.id,
      userId: mariana.id,
      roles: ['admin_org', 'resp_sgi'],
      status: 'ACTIVE',
    },
  });
  await prisma.orgMember.upsert({
    where: { orgId_userId: { orgId: org.id, userId: jorge.id } },
    update: { roles: ['admin_org'], status: 'ACTIVE' },
    create: {
      orgId: org.id,
      userId: jorge.id,
      roles: ['admin_org'],
      status: 'ACTIVE',
    },
  });
  console.log('  ✔ Membresías org-ejemplo (Mariana: admin_org+resp_sgi · Jorge: admin_org)');

  // Segunda organización (para validar aislamiento)
  const orgDemo = await prisma.organization.upsert({
    where: { id: 'org-demo' },
    update: {},
    create: {
      id: 'org-demo',
      name: 'Demo Consulting Group',
      planCode: 'ESSENTIAL',
    },
  });
  await prisma.orgMember.upsert({
    where: { orgId_userId: { orgId: orgDemo.id, userId: mariana.id } },
    update: { roles: ['colaborador'], status: 'ACTIVE' },
    create: {
      orgId: orgDemo.id,
      userId: mariana.id,
      roles: ['colaborador'],
      status: 'ACTIVE',
    },
  });
  console.log('  ✔ Organización demo + membresía (Mariana como colaborador)');

  // ===== Catálogo normativo (compartido con `db:catalog`) =====
  // El catálogo vive en `catalog.ts` para que producción lo cargue sin ejecutar
  // este seed: aquí solo se activan las normas para la organización demo.
  const standardIds = await seedCatalog(prisma, console.log);
  const std = { id: standardIds.ISO9001 };
  const std27001 = { id: standardIds.ISO27001 };
  const std22301 = { id: standardIds.ISO22301 };
  const std42001 = { id: standardIds.ISO42001 };
  const std20000 = { id: standardIds.ISO20000 };
  const std37001 = { id: standardIds.ISO37001 };

  // Activación de ISO 9001 para la organización ejemplo
  await prisma.orgStandard.upsert({
    where: { orgId_standardId: { orgId: org.id, standardId: std.id } },
    // `update` repite el alcance: una norma activada en una ejecución anterior
    // se quedaba sin descripción, porque el `create` solo corre la primera vez.
    update: {
      scopeText:
        'Diseño, producción y venta de productos de la línea principal en las sedes Monterrey y CDMX.',
      status: 'ACTIVE',
    },
    create: {
      orgId: org.id,
      standardId: std.id,
      scopeText: 'Diseño, producción y venta de productos de la línea principal en las sedes Monterrey y CDMX.',
      exclusions: [{ clause: '8.3', justification: 'No se realizan actividades de diseño y desarrollo de productos.' }],
      status: 'ACTIVE',
      startDate: new Date('2026-01-15'),
      certAuditDate: new Date('2027-03-01'),
    },
  });
  console.log('  ✔ ISO 9001 activada para la organización ejemplo');

  // ===== Contexto de la organización (ejemplo) =====
  // Un análisis «FODA 2026» con sus elementos: la organización puede crear más
  // (por año, sede o línea de negocio) y cada uno mantiene su propia matriz.
  await prisma.contextSwotAnalysis.create({
    data: {
      orgId: org.id,
      name: 'FODA 2026',
      description: 'Análisis del contexto interno y externo para el ciclo 2026.',
      period: '2026',
      items: {
        create: [
          { orgId: org.id, type: 'FORTALEZA', text: 'Equipo de calidad experimentado y comprometido' },
          { orgId: org.id, type: 'FORTALEZA', text: 'Procesos productivos documentados' },
          { orgId: org.id, type: 'OPORTUNIDAD', text: 'Creciente demanda de certificaciones en la industria' },
          { orgId: org.id, type: 'DEBILIDAD', text: 'Control documental aún basado en hojas de cálculo' },
          { orgId: org.id, type: 'AMENAZA', text: 'Competencia con certificaciones consolidadas' },
        ],
      },
    },
  });
  console.log('  ✔ Contexto FODA ejemplo');

  await prisma.contextPestelAnalysis.create({
    data: {
      orgId: org.id,
      name: 'PESTEL 2026',
      description: 'Factores del entorno que condicionan el sistema de gestión.',
      period: '2026',
      items: {
        create: [
          { orgId: org.id, type: 'POLITICO', impact: 'NEUTRO', text: 'Estabilidad regulatoria en el sector industrial' },
          { orgId: org.id, type: 'ECONOMICO', impact: 'NEGATIVO', text: 'Inflación en materias primas y costo logístico' },
          { orgId: org.id, type: 'SOCIAL', impact: 'POSITIVO', text: 'Mayor exigencia de clientes por proveedores certificados' },
          { orgId: org.id, type: 'TECNOLOGICO', impact: 'POSITIVO', text: 'Automatización de registros de calidad disponible en el mercado' },
          { orgId: org.id, type: 'ECOLOGICO', impact: 'NEGATIVO', text: 'Restricciones de agua y energía en temporada seca' },
          { orgId: org.id, type: 'LEGAL', impact: 'NEUTRO', text: 'NOM-035-STPS-2018 y LFPDPPP aplicables a la operación' },
        ],
      },
    },
  });
  console.log('  ✔ Contexto PESTEL ejemplo');

  await prisma.contextParty.createMany({
    data: [
      { orgId: org.id, name: 'Clientes', needs: { calidad: 'Productos conformes a especificación' }, expectations: { entrega: 'Cumplimiento de plazos' }, relevance: 'ALTA' },
      { orgId: org.id, name: 'Empleados', needs: { seguridad: 'Ambiente seguro' }, expectations: { formacion: 'Capacitación continua' }, relevance: 'ALTA' },
      { orgId: org.id, name: 'Proveedores', needs: { pago: 'Pagos oportunos' }, expectations: { colaboracion: 'Relación de largo plazo' }, relevance: 'MEDIA' },
      { orgId: org.id, name: 'Entes reguladores', needs: { cumplimiento: 'Cumplimiento normativo' }, expectations: { reportes: 'Información oportuna' }, relevance: 'ALTA' },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Partes interesadas ejemplo');

  await prisma.legalRequirement.createMany({
    data: [
      { orgId: org.id, source: 'LFPDPPP', reference: 'Ley Federal de Protección de Datos', requirement: 'Proteger los datos personales de clientes y empleados', appliesTo: 'Toda la organización', status: 'ACTIVE' },
      { orgId: org.id, source: 'NOM', reference: 'NOM-035-STPS-2018', requirement: 'Identificar y prevenir factores de riesgo psicosocial', appliesTo: 'Recursos Humanos', status: 'ACTIVE' },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Requisitos legales ejemplo');

  await prisma.processMap.createMany({
    data: [
      { orgId: org.id, name: 'Compras', inputs: 'Requisición de materiales', outputs: 'Materiales conformes', interactions: { clientes: true, proveedores: true } },
      { orgId: org.id, name: 'Producción', inputs: 'Materia prima', outputs: 'Producto terminado', interactions: { compras: true, calidad: true } },
      { orgId: org.id, name: 'Calidad', inputs: 'Producto + especificaciones', outputs: 'Lotes liberados', interactions: { produccion: true, clientes: true } },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Mapa de procesos ejemplo');

  // ===== Planificación: riesgos, objetivos, plan de trabajo =====
  const risk1 = await prisma.risk.create({
    data: { orgId: org.id, title: 'Fallas en la cadena de suministro', description: 'Retrasos de proveedores que impactan la producción', category: 'OPERATIVO', status: 'OPEN' },
  });
  await prisma.riskAssessment.create({
    data: { orgId: org.id, riskId: risk1.id, likelihood: 3, impact: 4, score: 12 },
  });
  await prisma.riskTreatment.create({
    data: { orgId: org.id, riskId: risk1.id, type: 'MITIGATE', plan: 'Diversificar proveedores y mantener stock de seguridad', status: 'IN_PROGRESS' },
  });
  console.log('  ✔ Riesgo de ejemplo');

  const obj = await prisma.objective.create({
    data: { orgId: org.id, title: 'Reducir el índice de no conformidades en 20%', status: 'ACTIVE' },
  });
  await prisma.objectiveKpi.create({
    data: { orgId: org.id, objectiveId: obj.id, name: 'Tasa de NC por lote', formula: 'NC / lotes producidos', target: 2, frequency: 'MENSUAL', unit: '%' },
  });
  console.log('  ✔ Objetivo con KPI ejemplo');

  const plan = await prisma.workPlan.create({
    data: { orgId: org.id, title: 'Implementación ISO 9001:2015', standardId: std.id, startDate: new Date('2026-01-15'), endDate: new Date('2026-12-15'), status: 'ACTIVE' },
  });
  await prisma.planTask.createMany({
    data: [
      { orgId: org.id, planId: plan.id, title: 'Completar diagnóstico inicial', priority: 'HIGH', status: 'DONE', sortOrder: 1 },
      { orgId: org.id, planId: plan.id, title: 'Definir contexto y partes interesadas', priority: 'HIGH', status: 'DONE', sortOrder: 2 },
      { orgId: org.id, planId: plan.id, title: 'Identificar riesgos y oportunidades', priority: 'HIGH', status: 'IN_PROGRESS', sortOrder: 3 },
      { orgId: org.id, planId: plan.id, title: 'Implementar control documental', priority: 'MEDIUM', status: 'PENDING', sortOrder: 4 },
      { orgId: org.id, planId: plan.id, title: 'Realizar auditoría interna', priority: 'MEDIUM', status: 'PENDING', sortOrder: 5 },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Plan de implementación con tareas');

  // ===== Auditorías =====
  const program = await prisma.auditProgram.upsert({
    where: { id: 'prog-2026' },
    update: {},
    create: { id: 'prog-2026', orgId: org.id, year: 2026 },
  });
  const _audit = await prisma.audit.create({
    data: {
      orgId: org.id,
      programId: program.id,
      standardId: std.id,
      title: 'Auditoría interna ISO 9001 · Sede Monterrey',
      scope: 'Todos los procesos productivos',
      startDate: new Date('2026-11-14'),
      endDate: new Date('2026-11-16'),
      status: 'IN_PROGRESS',
      leadAuditorId: mariana.id,
      team: { lider: 'Mariana Torres', miembros: ['Carlos Torres', 'Ana Guzmán'] },
    },
  });
  console.log('  ✔ Programa y auditoría de ejemplo');

  // ===== No conformidades =====
  const nc1 = await prisma.nc.upsert({
    where: { orgId_folio: { orgId: org.id, folio: 'NC-2026-014' } },
    update: {},
    create: {
      orgId: org.id,
      folio: 'NC-2026-014',
      title: 'Falla en etiquetado del producto',
      description: 'El lote 342 salió con etiqueta incorrecta en código de barras.',
      priority: 'ALTA',
      status: 'IN_CORRECTIVE_ACTION',
      standardId: std.id,
      reportedById: mariana.id,
      },
  });
  await prisma.ncCorrection.create({
    data: { orgId: org.id, ncId: nc1.id, description: 'Reetiquetado del lote 342 antes de entrega' },
  });
  await prisma.rootCause.create({
    data: {
      orgId: org.id,
      ncId: nc1.id,
      method: '5_WHYS',
      causes: { c1: 'Formato de etiqueta desactualizado', c2: 'No hubo verificación de primer artículo', c3: 'Instrucción de trabajo no vigente' },
      analysis: 'La causa raíz es la falta de control de cambios en los formatos de etiquetado.',
    },
  });
  const ca1 = await prisma.correctiveAction.create({
    data: {
      orgId: org.id,
      ncId: nc1.id,
      title: 'Implementar verificación de primer artículo en etiquetado',
      status: 'IN_PROGRESS',
      assigneeId: mariana.id,
      dueDate: new Date('2026-09-15'),
    },
  });
  const nc2 = await prisma.nc.upsert({
    where: { orgId_folio: { orgId: org.id, folio: 'NC-2026-011' } },
    update: {},
    create: {
      orgId: org.id,
      folio: 'NC-2026-011',
      title: 'Dato erróneo en factura',
      priority: 'MEDIA',
      status: 'CLOSED',
      standardId: std.id,
      },
  });
  await prisma.correctiveAction.create({
    data: { orgId: org.id, ncId: nc2.id, title: 'Doble validación de datos de facturación', status: 'VERIFIED' },
  });
  await prisma.effectivenessVerification.create({
    data: { orgId: org.id, actionId: ca1.id, result: 'PENDING', verifiedById: mariana.id },
  });
  await prisma.lessonLearned.create({
    data: { orgId: org.id, ncId: nc2.id, lesson: 'Implementar doble revisión en datos de facturación' },
  });
  console.log('  ✔ NC de ejemplo (014 en acción correctiva, 011 cerrada)');

  // ===== Revisión por la dirección =====
  const review = await prisma.mgmtReview.upsert({
    where: { id: 'rd-2026-q3' },
    update: {},
    create: { id: 'rd-2026-q3', orgId: org.id, code: 'RD-2026-Q3', period: 'Q3 2026', status: 'IN_PROGRESS', preparedById: mariana.id },
  });
  await prisma.reviewEntry.createMany({
    data: [
      { orgId: org.id, reviewId: review.id, entryType: 'COMPLIANCE', source: 'cumplimiento global 68%', auto: true },
      { orgId: org.id, reviewId: review.id, entryType: 'AUDITS', source: 'Auditorías: 2 realizadas, 3 NC', auto: true },
      { orgId: org.id, reviewId: review.id, entryType: 'RISKS', source: 'Riesgos: 5 críticos, 3 controles vencidos', auto: true },
      { orgId: org.id, reviewId: review.id, entryType: 'NC', source: 'NC abiertas: 12 (2 críticas)', auto: true },
      { orgId: org.id, reviewId: review.id, entryType: 'OBJECTIVES', source: 'Objetivos: avance 78%', auto: true },
      { orgId: org.id, reviewId: review.id, entryType: 'PROCESS_PERFORMANCE', source: 'Procesos: 3 sin cumplir meta', auto: true },
    ],
    skipDuplicates: true,
  });
  await prisma.reviewAgreement.createMany({
    data: [
      { orgId: org.id, reviewId: review.id, decision: 'Reforzar control documental en Compras', assigneeId: mariana.id, dueDate: new Date('2026-10-15') },
      { orgId: org.id, reviewId: review.id, decision: 'Definir plan de reducción de riesgos críticos', assigneeId: mariana.id, dueDate: new Date('2026-10-30') },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Revisión por la dirección con entradas automáticas y acuerdos');

  // ===== ISO/IEC 27001 =====
  await prisma.orgStandard.upsert({
    where: { orgId_standardId: { orgId: org.id, standardId: std27001.id } },
    update: {
      status: 'ACTIVE',
      scopeText:
        'Procesos de la organización, sus sistemas de información, instalaciones y proveedores con acceso a información de clientes.',
    },
    create: {
      orgId: org.id,
      standardId: std27001.id,
      scopeText:
        'Procesos de la organización, sus sistemas de información, instalaciones y proveedores con acceso a información de clientes.',
      status: 'ACTIVE',
      startDate: new Date('2026-04-01'),
      certAuditDate: new Date('2027-06-15'),
    },
  });
  const controls27001 = ISO27001_CLAUSES.filter(
    (c) => c.kind === 'requirement' && c.code.startsWith('A.'),
  ).length;
  console.log(
    `  ✔ ISO/IEC 27001:2022 con ${ISO27001_CLAUSES.length} cláusulas/requisitos (${controls27001} controles del Anexo A)`,
  );

  // Activos de información
  await prisma.securityAsset.createMany({
    data: [
      { orgId: org.id, name: 'Base de datos de clientes', type: 'INFORMATION', classification: 'CONFIDENCIAL', ownerId: mariana.id },
      { orgId: org.id, name: 'ERP corporativo', type: 'SOFTWARE', classification: 'INTERNO' },
      { orgId: org.id, name: 'Servidor de archivos', type: 'HARDWARE', classification: 'INTERNO' },
      { orgId: org.id, name: 'Red Wi-Fi corporativa', type: 'SERVICE', classification: 'INTERNO' },
    ],
    skipDuplicates: true,
  });

  // Declaración de Aplicabilidad (SOA) completa: un registro por control del Anexo A.
  // Los estados salen de un perfil determinista para que la demo muestre avance
  // realista sin que el resultado cambie entre ejecuciones del seed.
  const notApplicable: Record<string, string> = {
    'A.5.21': 'La organización no integra cadena de suministro de TIC propia; los servicios se contratan a terceros.',
    'A.5.30': 'La continuidad de TIC se cubre en el SGCN (ISO 22301) y no se duplica aquí.',
    'A.8.30': 'No se subcontrata desarrollo de software.',
    'A.8.31': 'No existen entornos de desarrollo propios separados: el software es adquirido.',
    'A.8.34': 'No se realizan pruebas de auditoría que afecten sistemas en producción.',
  };
  const soaStatusFor = (code: string): string => {
    const h = stableBucket(code);
    if (h < 38) return 'IMPLEMENTED';
    if (h < 72) return 'PLANNED';
    return 'NOT_IMPLEMENTED';
  };
  let soaImplemented = 0;
  let soaApplicable = 0;
  for (const c of ISO27001_CLAUSES) {
    if (c.kind !== 'requirement' || !c.code.startsWith('A.')) continue;
    const justification = notApplicable[c.code];
    const applicable = !justification;
    const implementationStatus = applicable ? soaStatusFor(c.code) : 'NOT_IMPLEMENTED';
    if (applicable) soaApplicable += 1;
    if (applicable && implementationStatus === 'IMPLEMENTED') soaImplemented += 1;
    await prisma.statementOfApplicability.upsert({
      where: {
        orgId_standardId_controlCode: {
          orgId: org.id,
          standardId: std27001.id,
          controlCode: c.code,
        },
      },
      update: { controlName: c.title, applicable, justification, implementationStatus },
      create: {
        orgId: org.id,
        standardId: std27001.id,
        controlCode: c.code,
        controlName: c.title,
        applicable,
        justification,
        implementationStatus,
      },
    });
  }
  console.log(`  ✔ SOA con ${controls27001} controles (${soaImplemented}/${soaApplicable} implementados)`);

  // Incidentes de seguridad
  await prisma.securityIncident.createMany({
    data: [
      { orgId: org.id, title: 'Acceso no autorizado a carpeta compartida', severity: 'ALTA', status: 'OPEN', reportedById: mariana.id },
      { orgId: org.id, title: 'Phishing a empleados', severity: 'MEDIA', status: 'RESOLVED', detectedAt: new Date('2026-08-01') },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Incidentes de seguridad de ejemplo');

  // ===== ISO 22301 =====
  await prisma.orgStandard.upsert({
    where: { orgId_standardId: { orgId: org.id, standardId: std22301.id } },
    update: {
      status: 'ACTIVE',
      scopeText:
        'Procesos críticos de producción, procesamiento de pedidos y facturación en las sedes Monterrey y CDMX.',
    },
    create: {
      orgId: org.id,
      standardId: std22301.id,
      scopeText:
        'Procesos críticos de producción, procesamiento de pedidos y facturación en las sedes Monterrey y CDMX.',
      status: 'ACTIVE',
      startDate: new Date('2026-05-01'),
      certAuditDate: new Date('2027-09-01'),
    },
  });

  // BIA con RTO/RPO
  await prisma.bia.createMany({
    data: [
      { orgId: org.id, processName: 'Procesamiento de pedidos', criticality: 'CRITICA', rtoHours: 4, rpoHours: 2, dependencies: { sistemas: ['ERP'], personal: 5 }, status: 'ASSESSED' },
      { orgId: org.id, processName: 'Producción', criticality: 'ALTA', rtoHours: 8, rpoHours: 4, dependencies: { sistemas: ['MES'], proveedores: true }, status: 'ASSESSED' },
      { orgId: org.id, processName: 'Facturación', criticality: 'MEDIA', rtoHours: 24, rpoHours: 12, dependencies: { sistemas: ['ERP'] }, status: 'ASSESSED' },
    ],
    skipDuplicates: true,
  });

  // Planes de continuidad
  await prisma.continuityPlan.createMany({
    data: [
      { orgId: org.id, title: 'Plan de continuidad de procesamiento de pedidos', strategy: 'Replicación en sitio alterno + respaldo en la nube', status: 'ACTIVE' },
      { orgId: org.id, title: 'Plan de recuperación de producción', strategy: 'Maquila de emergencia con proveedor', status: 'REVIEWED' },
    ],
    skipDuplicates: true,
  });

  // Ejercicios de continuidad
  await prisma.continuityExercise.createMany({
    data: [
      { orgId: org.id, title: 'Ejercicio de mesa: interrupción de ERP', type: 'TABLE_TOP', scheduledAt: new Date('2026-11-20'), status: 'PLANNED' },
      { orgId: org.id, title: 'Simulación de caída de producción', type: 'FULL', scheduledAt: new Date('2026-12-10'), status: 'COMPLETED', result: 'RTO cumplido en 6h' },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ BIA + planes + ejercicios de continuidad de ejemplo');

  // ===== Notificaciones =====
  await prisma.notification.createMany({
    data: [
      { orgId: org.id, userId: mariana.id, type: 'APPROVAL', title: 'Documento PR-07 en revisión', body: 'El documento PR-07 está pendiente de tu aprobación.', entity: 'document', entityId: 'pr-07' },
      { orgId: org.id, userId: mariana.id, type: 'TASK', title: 'NC-2026-014: verificar eficacia', body: 'La acción correctiva está lista para verificación.', entity: 'nc' },
      { orgId: org.id, userId: mariana.id, type: 'REMINDER', title: 'Evidencias por revisar', body: '8 evidencias vencen su revisión en los próximos 15 días.', entity: 'evidence' },
      { orgId: org.id, userId: mariana.id, type: 'ALERT', title: 'Controles vencidos', body: '3 controles de riesgo tienen verificación vencida.', entity: 'risk' },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Notificaciones de ejemplo');

  // ===== ISO/IEC 42001:2023 =====
  // Las cláusulas y controles los carga `seedCatalog` junto con el resto del
  // catálogo; aquí solo se activa la norma para la organización demo.
  await prisma.orgStandard.upsert({
    where: { orgId_standardId: { orgId: org.id, standardId: std42001.id } },
    update: {
      status: 'ACTIVE',
      scopeText:
        'Sistemas de IA en uso y en evaluación: asistente documental, chatbot de atención y análisis predictivo.',
    },
    create: {
      orgId: org.id,
      standardId: std42001.id,
      scopeText: 'Sistemas de IA en uso y en evaluación: asistente documental, chatbot de atención y análisis predictivo.',
      status: 'ACTIVE',
      startDate: new Date('2026-07-01'),
      certAuditDate: new Date('2027-11-20'),
    },
  });
  console.log('  ✔ ISO/IEC 42001:2023 activada para la organización ejemplo');

  // Declaración de Aplicabilidad de 42001. La norma también tiene Anexo A y
  // exige justificar qué controles aplican, así que la demo trae la suya. El
  // estado sale de un perfil determinista para que el seed sea reproducible.
  const iso42001Controls = ISO42001_CLAUSES.filter(
    (c) => c.kind === 'requirement' && c.code.startsWith('A.'),
  );
  const notApplicable42001: Record<string, string> = {
    'A.5':
      'La organización no desarrolla modelos de IA propios; usa servicios de terceros con datos validados por contrato.',
    'A.13':
      'Los impactos adversos se evalúan en el registro de riesgos de cada sistema de IA.',
  };
  let soa42001Implemented = 0;
  let soa42001Applicable = 0;
  for (const c of iso42001Controls) {
    const justification = notApplicable42001[c.code];
    const applicable = !justification;
    // Se prefija con la norma para que el perfil no coincida con el de 27001.
    const implementationStatus = applicable
      ? soaStatusFor(`AI${c.code}`)
      : 'NOT_IMPLEMENTED';
    if (applicable) soa42001Applicable += 1;
    if (applicable && implementationStatus === 'IMPLEMENTED') soa42001Implemented += 1;
    await prisma.statementOfApplicability.upsert({
      where: {
        orgId_standardId_controlCode: {
          orgId: org.id,
          standardId: std42001.id,
          controlCode: c.code,
        },
      },
      update: { controlName: c.title, applicable, justification, implementationStatus },
      create: {
        orgId: org.id,
        standardId: std42001.id,
        controlCode: c.code,
        controlName: c.title,
        applicable,
        justification,
        implementationStatus,
      },
    });
  }
  console.log(
    `  ✔ SOA de ISO/IEC 42001 con ${iso42001Controls.length} controles (${soa42001Implemented}/${soa42001Applicable} implementados)`,
  );

  // ===== ISO/IEC 20000-1 e ISO 37001 =====
  // Igual que las anteriores: el catálogo ya está cargado por `seedCatalog`.
  await prisma.orgStandard.upsert({
    where: { orgId_standardId: { orgId: org.id, standardId: std20000.id } },
    update: { status: 'ACTIVE' },
    create: {
      orgId: org.id,
      standardId: std20000.id,
      scopeText:
        'Servicios de TI internos: mesa de ayuda, gestión de infraestructura y soporte a los procesos de negocio.',
      status: 'ACTIVE',
      startDate: new Date('2026-06-01'),
      certAuditDate: new Date('2027-10-05'),
    },
  });
  await prisma.orgStandard.upsert({
    where: { orgId_standardId: { orgId: org.id, standardId: std37001.id } },
    update: { status: 'ACTIVE' },
    create: {
      orgId: org.id,
      standardId: std37001.id,
      scopeText:
        'Todas las actividades de la organización en México, incluidas compras, ventas y relación con intermediarios.',
      status: 'ACTIVE',
      startDate: new Date('2026-08-01'),
      certAuditDate: new Date('2027-12-10'),
    },
  });
  console.log('  ✔ ISO/IEC 20000-1:2018 e ISO 37001:2025 activadas para la organización ejemplo');

  // Servicios de TI (catálogo ITSM)
  await prisma.serviceCatalog.createMany({
    data: [
      { orgId: org.id, code: 'SRV-01', name: 'Mesa de ayuda', description: 'Atención de incidentes y peticiones de usuarios.', category: 'SOPORTE', criticality: 'ALTA', status: 'ACTIVE', ownerId: mariana.id },
      { orgId: org.id, code: 'SRV-02', name: 'Infraestructura y red', description: 'Operación de servidores, red y respaldo.', category: 'INFRAESTRUCTURA', criticality: 'CRITICA', status: 'ACTIVE' },
      { orgId: org.id, code: 'SRV-03', name: 'ERP corporativo', description: 'Disponibilidad y soporte funcional del ERP.', category: 'APLICACION', criticality: 'CRITICA', status: 'ACTIVE' },
    ],
    skipDuplicates: true,
  });
  await prisma.serviceLevelAgreement.createMany({
    data: [
      { orgId: org.id, serviceCode: 'SRV-01', customer: 'Todas las áreas', responseHours: 1, resolutionHours: 8, availabilityPct: 99.5, status: 'ACTIVE' },
      { orgId: org.id, serviceCode: 'SRV-03', customer: 'Finanzas y Operaciones', responseHours: 2, resolutionHours: 12, availabilityPct: 99.9, status: 'ACTIVE' },
    ],
    skipDuplicates: true,
  });
  await prisma.serviceRequest.createMany({
    data: [
      { orgId: org.id, folio: 'INC-2026-091', serviceCode: 'SRV-03', type: 'INCIDENT', title: 'Caída de módulo de facturación', priority: 'ALTA', status: 'IN_PROGRESS', reportedById: mariana.id },
      { orgId: org.id, folio: 'REQ-2026-042', serviceCode: 'SRV-01', type: 'REQUEST', title: 'Alta de usuario en el ERP', priority: 'MEDIA', status: 'RESOLVED', reportedById: mariana.id },
      { orgId: org.id, folio: 'PRB-2026-007', serviceCode: 'SRV-03', type: 'PROBLEM', title: 'Incidentes recurrentes en facturación', priority: 'ALTA', status: 'OPEN', reportedById: mariana.id },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Catálogo de servicios, SLA y peticiones de ejemplo');

  // Registro de riesgo de soborno y controles antisoborno
  await prisma.briberyRiskAssessment.createMany({
    data: [
      { orgId: org.id, area: 'Compras', activity: 'Selección de proveedores', likelihood: 3, impact: 4, score: 12, status: 'ASSESSED', mitigation: 'Diligencia debida y comité de compras' },
      { orgId: org.id, area: 'Ventas', activity: 'Licitaciones públicas', likelihood: 4, impact: 5, score: 20, status: 'ASSESSED', mitigation: 'Revisión de la función antisoborno y doble firma' },
      { orgId: org.id, area: 'Administración', activity: 'Regalos y hospitalidad', likelihood: 2, impact: 3, score: 6, status: 'ASSESSED', mitigation: 'Registro de regalos y umbral de aprobación' },
    ],
    skipDuplicates: true,
  });
  await prisma.briberyControl.createMany({
    data: [
      { orgId: org.id, code: '8.2', title: 'Diligencia debida de contrapartes', description: 'Evaluación de integridad antes de contratar.', status: 'IMPLEMENTED' },
      { orgId: org.id, code: '8.3', title: 'Controles financieros', description: 'Autorización y conciliación de pagos.', status: 'IMPLEMENTED' },
      { orgId: org.id, code: '8.7', title: 'Regalos y hospitalidad', description: 'Registro y límite de beneficios entregados.', status: 'PLANNED' },
      { orgId: org.id, code: '8.9', title: 'Canal de denuncias', description: 'Reporte confidencial de sospechas de soborno.', status: 'IMPLEMENTED' },
    ],
    skipDuplicates: true,
  });
  await prisma.briberyIncident.createMany({
    data: [
      { orgId: org.id, title: 'Sospecha de conflicto de interés en compra', severity: 'MEDIA', status: 'INVESTIGATING', reportedById: mariana.id },
      { orgId: org.id, title: 'Regalo fuera de política recibido por comprador', severity: 'BAJA', status: 'CLOSED', resolution: 'Regalo devuelto y registro actualizado', reportedById: mariana.id },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Riesgos, controles e incidentes de soborno de ejemplo');

  // Sistemas de IA de ejemplo
  const aiSystem = await prisma.aiSystem.create({
    data: {
      orgId: org.id,
      name: 'Asistente de redacción documental',
      type: 'GENERATIVE',
      vendor: 'Proveedor externo (GPT)',
      description: 'Asiste en la redacción de procedimientos y políticas del SGC.',
      dataClassification: 'CONFIDENCIAL',
      lifecycleStage: 'DEPLOYED',
      ownerId: mariana.id,
    },
  });
  await prisma.aiSystem.createMany({
    data: [
      { orgId: org.id, name: 'Chatbot de atención al cliente', type: 'NLP', vendor: 'Interno', dataClassification: 'INTERNO', lifecycleStage: 'DEVELOPMENT', ownerId: mariana.id },
      { orgId: org.id, name: 'Análisis predictivo de demanda', type: 'ANALYTICS', vendor: 'Proveedor', dataClassification: 'INTERNO', lifecycleStage: 'EVALUATION' },
    ],
    skipDuplicates: true,
  });

  // Casos de uso
  await prisma.aiOrgUseCase.createMany({
    data: [
      { orgId: org.id, systemId: aiSystem.id, name: 'Redacción de borradores de documentos', purpose: 'Reducir el esfuerzo de control documental', dataUsed: { metadatos: true, contenido: 'solo borradores' }, supervision: 'HUMAN_IN_LOOP', status: 'APPROVED' },
      { orgId: org.id, systemId: aiSystem.id, name: 'Resumen de auditorías', purpose: 'Preparar resúmenes ejecutivos', dataUsed: { hallazgos: true }, supervision: 'HUMAN_ON_THE_LOOP', status: 'UNDER_REVIEW' },
    ],
    skipDuplicates: true,
  });

  // Evaluación de impacto
  await prisma.aiImpactAssessment.createMany({
    data: [
      { orgId: org.id, systemId: aiSystem.id, riskLevel: 'MEDIUM', impactAreas: { personas: 'bajo', organizacion: 'medio', sociedad: 'bajo' }, mitigations: { supervisiónHumana: true, datosMinimos: true }, status: 'COMPLETED', assessedById: mariana.id },
    ],
    skipDuplicates: true,
  });

  // Riesgos de IA con controles
  const aiRisk = await prisma.aiSystemRisk.create({
    data: { orgId: org.id, systemId: aiSystem.id, title: 'Alucinaciones en documentos generados', description: 'La IA puede inventar cláusulas o referencias', likelihood: 4, impact: 3, score: 12, status: 'OPEN', ownerId: mariana.id },
  });
  await prisma.aiSystemControl.createMany({
    data: [
      { orgId: org.id, riskId: aiRisk.id, title: 'Revisión humana obligatoria de todo borrador', source: 'ANEXO_A', status: 'IMPLEMENTED' },
      { orgId: org.id, riskId: aiRisk.id, title: 'Salidas con referencias a fuentes', source: 'PROPIO', status: 'PLANNED' },
    ],
    skipDuplicates: true,
  });

  // Eventos del ciclo de vida
  await prisma.aiLifecycleEvent.createMany({
    data: [
      { orgId: org.id, systemId: aiSystem.id, eventType: 'DEPLOYED', description: 'Despliegue inicial del asistente de redacción' },
      { orgId: org.id, systemId: aiSystem.id, eventType: 'MONITORED', description: 'Revisión trimestral de calidad de salidas' },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Sistemas IA, casos de uso, evaluaciones, riesgos y controles de ejemplo');

  // ===== Capa transversal de IA (Gateway) =====
  // Proveedores y modelos los registra `seedCatalog`; aquí solo quedan los datos
  // de uso de la organización demo.

  // Casos de uso de IA (gateway) + prompts versionados
  const useCases = [
    { code: 'draft_document', name: 'Preparar borrador de documento', purpose: 'Redactar borradores de políticas y procedimientos', module: 'documents', supervisionLevel: 'HUMAN_IN_LOOP' },
    { code: 'summarize', name: 'Resumir para dirección', purpose: 'Sintetizar el estado del sistema', module: 'dashboards', supervisionLevel: 'HUMAN_ON_THE_LOOP' },
    { code: 'suggest_risks', name: 'Sugerir riesgos', purpose: 'Proponer riesgos y oportunidades', module: 'planning', supervisionLevel: 'HUMAN_IN_LOOP' },
    { code: 'detect_inconsistencies', name: 'Buscar inconsistencias', purpose: 'Detectar vencimientos y desviaciones', module: 'documents', supervisionLevel: 'HUMAN_IN_LOOP' },
    { code: 'root_cause', name: 'Sugerir causa raíz', purpose: 'Hipótesis para NC', module: 'nc', supervisionLevel: 'HUMAN_IN_LOOP' },
    { code: 'classify_evidence', name: 'Sugerir clasificación de evidencia', purpose: 'Proponer clasificación según contenido', module: 'evidences', supervisionLevel: 'HUMAN_IN_LOOP' },
  ];
  for (const uc of useCases) {
    await prisma.aiUseCase.upsert({
      where: { orgId_code: { orgId: org.id, code: uc.code } },
      update: {},
      create: { orgId: org.id, ...uc, monthlyQuota: 5000 },
    });
  }
  console.log(`  ✔ ${useCases.length} casos de uso de IA registrados`);

  // Prompt base (v1) por caso de uso
  for (const uc of useCases) {
    const rec = await prisma.aiUseCase.findUnique({ where: { orgId_code: { orgId: org.id, code: uc.code } } });
    await prisma.aiPrompt.create({
      data: {
        orgId: org.id,
        useCaseId: rec!.id,
        version: 1,
        content: `Eres el asistente SIGUE. Caso de uso: ${uc.code}. Contexto mínimo: {{contexto}}. Genera una recomendación o borrador. NO inventes requisitos, fuentes ni evidencias. Indica cuando no haya evidencia suficiente.`,
        createdById: mariana.id,
      },
    });
  }
  console.log('  ✔ Biblioteca de prompts (v1) por caso de uso');

  // Embedding de ejemplo (RAG) — determinista
  const embed = (text: string): number[] => {
    const dim = 32;
    const v = new Array(dim).fill(0);
    for (let i = 0; i < text.length; i++) v[i % dim] += text.charCodeAt(i);
    const norm = Math.sqrt(v.reduce((a, b) => a + b * b, 0)) || 1;
    return v.map((x) => x / norm);
  };
  await prisma.aiDocumentEmbedding.createMany({
    data: [
      { orgId: org.id, sourceType: 'document', sourceId: 'pr-07', title: 'PR-07 Control de documentos', content: 'Procedimiento de control de documentos del SGC.', embedding: embed('control de documentos procedimiento SGC') },
      { orgId: org.id, sourceType: 'document', sourceId: 'po-03', title: 'PO-03 Compras', content: 'Procedimiento de compras y evaluación de proveedores.', embedding: embed('compras proveedores evaluación') },
      { orgId: org.id, sourceType: 'evidence', sourceId: 'ev-9.3', title: 'Acta de revisión por la dirección', content: 'Minuta de la revisión por la dirección Q3.', embedding: embed('revisión dirección minuta acuerdos') },
    ],
    skipDuplicates: true,
  });
  console.log('  ✔ Embeddings RAG de ejemplo (aislados por organización)');

  // ===== Suscripción y cuotas =====
  const _sub = await prisma.subscription.upsert({
    where: { orgId: org.id },
    update: {},
    create: {
      orgId: org.id,
      // El demo activa ISO 9001, 27001, 22301 y 42001: el plan Profesional solo
      // incluye 3 normas, así que el nivel coherente con esos datos es Empresarial.
      planCode: 'BUSINESS',
      status: 'ACTIVE',
      periodStart: new Date('2026-09-01'),
      periodEnd: new Date('2026-09-30'),
      stripeCustomerId: 'cus_demo_001',
      stripeSubId: 'sub_demo_001',
      cfdiRef: 'FAC-2026-0088',
    },
  });
  console.log('  ✔ Suscripción BUSINESS (Stripe refs + CFDI)');

  // Cuotas del plan (fuente de verdad para límites)
  const planQuotas: Record<string, { users: number; storageGb: number; standards: number; aiTokens: number }> = {
    ESSENTIAL: { users: 25, storageGb: 500, standards: 1, aiTokens: 2000 },
    PROFESSIONAL: { users: 50, storageGb: 2000, standards: 3, aiTokens: 5000 },
    BUSINESS: { users: 200, storageGb: 10000, standards: 6, aiTokens: 20000 },
    CONSULTANT: { users: 100, storageGb: 5000, standards: 6, aiTokens: 10000 },
  };
  const quota = planQuotas.BUSINESS;
  const memberCount = await prisma.orgMember.count({ where: { orgId: org.id, status: 'ACTIVE' } });
  const activeStandards = await prisma.orgStandard.count({ where: { orgId: org.id, status: 'ACTIVE' } });
  await prisma.orgUsage.createMany({
    data: [
      { orgId: org.id, resource: 'users', period: 'TOTAL', used: memberCount, quota: quota.users },
      { orgId: org.id, resource: 'storage_gb', period: 'TOTAL', used: 0, quota: quota.storageGb },
      { orgId: org.id, resource: 'standards', period: 'TOTAL', used: activeStandards, quota: quota.standards },
      { orgId: org.id, resource: 'ai_tokens', period: '2026-08', used: 1500, quota: quota.aiTokens },
    ],
    skipDuplicates: true,
  });
  console.log(`  ✔ Cuotas del plan (${quota.users} usuarios, ${quota.storageGb}GB, ${quota.standards} normas)`);

  // ===== Firma electrónica (documento publicado con firmas de ejemplo) =====
  const signedDoc = await prisma.document.upsert({
    where: { orgId_code: { orgId: org.id, code: 'MT-01' } },
    update: {},
    create: { orgId: org.id, code: 'MT-01', title: 'Manual de calidad', type: 'MANUAL', status: 'PUBLISHED', ownerId: mariana.id },
  });
  const mtContent = 'Manual de calidad v2. Define el alcance, política y procesos del SGC.';
  await prisma.documentVersion.upsert({
    where: { id: 'mt-01-v2' },
    update: {},
    create: { id: 'mt-01-v2', orgId: org.id, documentId: signedDoc.id, version: 'v2', content: mtContent, authorId: mariana.id, changesNote: 'Actualización de política' },
  });
  const contentHash = createHash('sha256').update(mtContent).digest('hex');
  const mtSignedAt = new Date('2026-08-20T10:00:00Z');
  // La firma se recalcula también en el `update`: si se sembró con un esquema
  // anterior, volver a ejecutar el seed la repara en lugar de dejarla inválida.
  const mtSignature = signaturePayload(contentHash, mariana.id, 'APPROVAL', mtSignedAt);
  await prisma.documentSignature.upsert({
    where: { id: 'mt-01-firma-1' },
    update: { contentHash, signature: mtSignature, signedAt: mtSignedAt },
    create: {
      id: 'mt-01-firma-1',
      orgId: org.id,
      documentId: signedDoc.id,
      version: 'v2',
      signerId: mariana.id,
      signerName: 'Mariana Torres',
      signerEmail: 'mariana.torres@org.mx',
      kind: 'APPROVAL',
      contentHash,
      signature: mtSignature,
      signedAt: mtSignedAt,
    },
  });
  console.log('  ✔ Documento MT-01 publicado con firma de aprobación');

  // ===== Consultor multicliente =====
  const consultora = await prisma.user.upsert({
    where: { email: 'consultora@demo.mx' },
    update: { passwordHash: hash },
    create: { email: 'consultora@demo.mx', name: 'Lic. Consultora Global', passwordHash: hash },
  });
  await prisma.orgMember.upsert({
    where: { orgId_userId: { orgId: org.id, userId: consultora.id } },
    update: { roles: ['consultor_externo'], accessEnd: new Date('2027-01-01') },
    create: { orgId: org.id, userId: consultora.id, roles: ['consultor_externo'], accessEnd: new Date('2027-01-01'), status: 'ACTIVE' },
  });
  await prisma.orgMember.upsert({
    where: { orgId_userId: { orgId: orgDemo.id, userId: consultora.id } },
    update: { roles: ['consultor_externo'], accessEnd: new Date('2027-01-01') },
    create: { orgId: orgDemo.id, userId: consultora.id, roles: ['consultor_externo'], accessEnd: new Date('2027-01-01'), status: 'ACTIVE' },
  });
  // Avance de cumplimiento de la organización principal. Sin estas filas el
  // tablero y la consola del consultor reportan 0 % aunque el seed sí cargue
  // cláusulas. Cada norma arranca en un punto distinto del ciclo de
  // implementación para que la demo no muestre cuatro barras idénticas.
  const complianceProfile: { standardId: string; code: string; implemented: number; partial: number }[] = [
    { standardId: std.id, code: 'ISO9001', implemented: 58, partial: 22 },
    { standardId: std27001.id, code: 'ISO27001', implemented: 37, partial: 24 },
    { standardId: std22301.id, code: 'ISO22301', implemented: 26, partial: 21 },
    { standardId: std42001.id, code: 'ISO42001', implemented: 14, partial: 18 },
    { standardId: std20000.id, code: 'ISO20000', implemented: 32, partial: 27 },
    { standardId: std37001.id, code: 'ISO37001', implemented: 21, partial: 33 },
  ];
  let statusRows = 0;
  for (const profile of complianceProfile) {
    const clauses = await prisma.standardClause.findMany({
      where: { standardId: profile.standardId, kind: 'requirement' },
      orderBy: { sortOrder: 'asc' },
      select: { id: true, code: true },
    });
    for (const c of clauses) {
      // Distribución determinista: el mismo código de norma + cláusula siempre
      // cae en el mismo tramo, así el seed es idempotente.
      const h = stableBucket(`${profile.code}${c.code}`);
      const level =
        h < profile.implemented
          ? 'IMPLEMENTED'
          : h < profile.implemented + profile.partial
            ? 'PARTIAL'
            : 'NOT_IMPLEMENTED';
      await prisma.requirementStatus.upsert({
        where: { orgId_clauseId: { orgId: org.id, clauseId: c.id } },
        update: { level, updatedById: mariana.id },
        create: { orgId: org.id, clauseId: c.id, level, updatedById: mariana.id },
      });
      statusRows += 1;
    }
  }
  console.log(`  ✔ Cumplimiento simulado sobre ${statusRows} requisitos de ${complianceProfile.length} normas activas`);
  await prisma.nc.upsert({
    where: { orgId_folio: { orgId: orgDemo.id, folio: 'NC-2026-001' } },
    update: {},
    create: { orgId: orgDemo.id, folio: 'NC-2026-001', title: 'NC demo consultor', status: 'OPEN' },
  });
  console.log('  ✔ Consultora multicliente (2 clientes asignados)');

  // ===== Plantillas propietarias (contenido SIGUE) =====
  // Las carga `seedCatalog` para todas las organizaciones existentes.

  console.log('✓ Seed completado.');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
