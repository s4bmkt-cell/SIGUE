import { SetMetadata } from '@nestjs/common';

export const AUDIT_KEY = 'audit';

/**
 * Declara la acción de auditoría para una ruta.
 * Uso: @Audit('nc.create')
 * El AuditInterceptor registra el evento con el actor y contexto de org.
 */
export const Audit = (action: string) => SetMetadata(AUDIT_KEY, action);
