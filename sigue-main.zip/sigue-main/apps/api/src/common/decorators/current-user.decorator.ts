import { createParamDecorator, ExecutionContext } from '@nestjs/common';

export interface AuthUser {
  sub: string; // user id
  email: string;
  name: string;
  roles: string[];
  orgId: string | null; // organización activa (si aplica)
  /**
   * Administrador de la plataforma: ve todas las organizaciones y gestiona su
   * ciclo de vida. Sale de `User.isPlatformAdmin` y viaja en el token, igual
   * que `roles`. Opcional para no romper los dobles de prueba existentes.
   */
  platform?: boolean;
}

/** Extrae el usuario autenticado del request (inyectado por JwtAuthGuard). */
export const CurrentUser = createParamDecorator(
  (data: keyof AuthUser | undefined, ctx: ExecutionContext) => {
    const request = ctx.switchToHttp().getRequest();
    const user: AuthUser = request.user;
    return data ? user?.[data] : user;
  },
);
