import { SetMetadata } from '@nestjs/common';

export const ROLES_KEY = 'roles';

/**
 * Declara los roles requeridos para una ruta (RBAC).
 * Uso: @RequireRoles('admin_org', 'resp_sgi')
 */
export const RequireRoles = (...roles: string[]) => SetMetadata(ROLES_KEY, roles);
