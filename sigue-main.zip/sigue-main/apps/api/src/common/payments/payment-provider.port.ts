/**
 * Puerto de cobros.
 *
 * La aplicación nunca habla con Stripe directamente: pide una sesión de pago y
 * recibe eventos por webhook. En desarrollo se usa el adaptador local, que no
 * cobra nada; el adaptador de Stripe se enchufa con las mismas dos operaciones
 * cuando existan las claves.
 */
export const PAYMENT_PROVIDER = Symbol('PAYMENT_PROVIDER');

export interface CreateCheckoutInput {
  orgId: string;
  planCode: string;
  amountUsd: number;
  customerEmail?: string;
  successUrl: string;
  cancelUrl: string;
}

export interface CheckoutSession {
  /** `local` = no se cobra nada; el cambio de plan lo aplica un administrador. */
  mode: 'local' | 'live';
  ref: string;
  url: string;
  amountUsd: number;
}

export type WebhookEventType =
  | 'checkout.session.completed'
  | 'customer.subscription.updated'
  | 'customer.subscription.deleted';

export interface PaymentWebhookEvent {
  id: string;
  type: WebhookEventType | string;
  orgId?: string;
  planCode?: string;
  subscriptionRef?: string;
  status?: string;
}

export interface PaymentProviderPort {
  readonly name: string;
  /** `false` mientras no haya claves reales: el cobro está desactivado. */
  readonly live: boolean;
  createCheckout(input: CreateCheckoutInput): Promise<CheckoutSession>;
  /** Verifica la firma y devuelve el evento; lanza si no es auténtico. */
  parseWebhook(rawBody: Buffer | string, signature: string | undefined): PaymentWebhookEvent;
}
