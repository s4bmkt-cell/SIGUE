import { Global, Module } from '@nestjs/common';
import { PAYMENT_PROVIDER } from './payment-provider.port';
import { LocalPaymentProviderAdapter } from './local-payment.adapter';

/**
 * Provee el proveedor de cobros. `PAYMENT_PROVIDER` es el token a inyectar.
 *
 * Para activar Stripe basta registrar un adaptador que implemente
 * `PaymentProviderPort` en `useClass` (y sus variables de entorno). Mientras no
 * exista, el adaptador local no cobra y deja el cambio de plan en manos del
 * administrador.
 */
@Global()
@Module({
  providers: [{ provide: PAYMENT_PROVIDER, useClass: LocalPaymentProviderAdapter }],
  exports: [PAYMENT_PROVIDER],
})
export class PaymentsModule {}
