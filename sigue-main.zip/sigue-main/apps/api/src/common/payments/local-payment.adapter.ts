import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { createHmac, randomUUID, timingSafeEqual } from 'crypto';
import {
  CheckoutSession,
  CreateCheckoutInput,
  PaymentProviderPort,
  PaymentWebhookEvent,
} from './payment-provider.port';

/**
 * Adaptador local: no cobra nada.
 *
 * Se usa mientras no haya claves de Stripe. La "sesión de pago" apunta de vuelta
 * a la app y el cambio de plan lo aplica el propio servidor. El webhook solo
 * acepta peticiones si se configuró `PAYMENTS_WEBHOOK_SECRET`, y cada una debe
 * venir firmada con HMAC-SHA256 del cuerpo:
 *
 *     x-sigue-signature: sha256=<hex>
 */
@Injectable()
export class LocalPaymentProviderAdapter implements PaymentProviderPort {
  readonly name = 'local';
  readonly live = false;
  private readonly logger = new Logger('Payments');
  private readonly secret = process.env.PAYMENTS_WEBHOOK_SECRET ?? '';

  async createCheckout(input: CreateCheckoutInput): Promise<CheckoutSession> {
    const ref = `local_${randomUUID()}`;
    this.logger.log(
      `Sesión local ${ref} para ${input.orgId}: ${input.planCode} ($${input.amountUsd} USD, sin cobro)`,
    );
    const url = new URL(input.successUrl);
    url.searchParams.set('checkout', 'local');
    url.searchParams.set('ref', ref);
    return { mode: 'local', ref, url: url.toString(), amountUsd: input.amountUsd };
  }

  parseWebhook(rawBody: Buffer | string, signature: string | undefined): PaymentWebhookEvent {
    if (!this.secret) {
      throw new BadRequestException(
        'Webhook de pagos no configurado: define PAYMENTS_WEBHOOK_SECRET',
      );
    }
    if (!signature) throw new BadRequestException('Falta la firma del webhook');

    const expected = createHmac('sha256', this.secret).update(rawBody).digest('hex');
    const received = signature.replace(/^sha256=/, '').trim();
    const ok =
      received.length === expected.length &&
      timingSafeEqual(Buffer.from(received, 'utf8'), Buffer.from(expected, 'utf8'));
    if (!ok) throw new BadRequestException('Firma del webhook inválida');

    let payload: PaymentWebhookEvent;
    try {
      payload = JSON.parse(rawBody.toString('utf8')) as PaymentWebhookEvent;
    } catch {
      throw new BadRequestException('Cuerpo del webhook ilegible');
    }
    if (!payload?.id || !payload?.type) {
      throw new BadRequestException('Evento de webhook incompleto');
    }
    return payload;
  }
}
