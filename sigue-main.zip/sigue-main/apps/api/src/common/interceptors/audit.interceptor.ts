import {
  CallHandler,
  ExecutionContext,
  HttpException,
  Injectable,
  NestInterceptor,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable, from, throwError } from 'rxjs';
import { catchError, concatMap } from 'rxjs/operators';
import { AUDIT_KEY } from '../decorators/audit.decorator';
import { AuthUser } from '../decorators/current-user.decorator';
import { AuditService } from '../../modules/audit/audit.service';

/**
 * Registra un evento de auditoría cuando la ruta está decorada con `@Audit('accion')`.
 *
 * Escribe **después** de que el handler termina, para poder capturar el
 * resultado (y con él el `entityId` si el handler creó el registro) y los
 * parámetros con los que se invocó. Los intentos fallidos también se auditan:
 * ignorarlos dejaría fuera los accesos denegados, que es justo lo que interesa
 * investigar.
 *
 * La escritura se espera (`concatMap`) para no perder eventos si el proceso
 * termina, pero un fallo de auditoría no altera la respuesta al cliente.
 */
@Injectable()
export class AuditInterceptor implements NestInterceptor {
  constructor(
    private readonly reflector: Reflector,
    private readonly audit: AuditService,
  ) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const action = this.reflector.get<string>(AUDIT_KEY, context.getHandler());
    if (!action) return next.handle();

    const request = context.switchToHttp().getRequest();
    const user: AuthUser | undefined = request.user;
    const orgId: string | null = request.params?.orgId ?? user?.orgId ?? null;

    const base = {
      orgId,
      actorId: user?.sub ?? null,
      action,
      entity: routeOf(request),
      entityId: null as string | null,
      before: paramsOf(request),
      ip: request.ip ?? null,
      userAgent: (request.headers?.['user-agent'] as string) ?? null,
    };

    return next.handle().pipe(
      concatMap((result) =>
        from(
          this.audit.record({
            ...base,
            entityId: entityIdOf(result, request),
            after: result,
          }),
        ).pipe(concatMap(() => [result])),
      ),
      catchError((error: unknown) => {
        const status = error instanceof HttpException ? error.getStatus() : 500;
        return from(
          this.audit.record({
            ...base,
            // El mensaje de Prisma incluye rutas del repositorio y SQL: se
            // guarda el motivo sin filtrar la estructura del servidor.
            after: { error: safeMessage(error), status, failed: true },
          }),
        ).pipe(concatMap(() => throwError(() => error)));
      }),
    );
  }
}

/** Ruta lógica sin el prefijo de versión, p. ej. `orgs/:orgId/nc/:ncId/corrections`. */function routeOf(request: {
  route?: { path?: string };
  baseUrl?: string;
}): string | null {
  const path = request.route?.path;
  if (!path) return null;
  return path.replace(/^\/+/, '').replace(/^api\/v\d+\//, '');
}

/**
 * Parámetros con los que se invocó la operación. Se descartan los binarios y
 * las credenciales; `AuditService` vuelve a sanear el objeto por si acaso.
 */
function paramsOf(request: {
  params?: Record<string, string>;
  query?: Record<string, unknown>;
  body?: unknown;
}): Record<string, unknown> {
  return {
    params: request.params ?? {},
    query: request.query ?? {},
    body: request.body ?? null,
  };
}

/** Identificador del registro afectado: el que devuelve el handler o el de la ruta. */
function entityIdOf(
  result: unknown,
  request: { params?: Record<string, string> },
): string | null {
  if (result && typeof result === 'object') {
    const rec = result as Record<string, unknown>;
    for (const key of ['id', 'ncId', 'documentId', 'auditId', 'actionId', 'riskId']) {
      const value = rec[key];
      if (typeof value === 'string') return value;
    }
    const data = rec.data as Record<string, unknown> | undefined;
    if (data && typeof data === 'object' && typeof data.id === 'string') return data.id;
  }

  const params = request.params ?? {};
  for (const key of [
    'ncId',
    'documentId',
    'auditId',
    'actionId',
    'riskId',
    'taskId',
    'objectiveId',
    'evidenceId',
    'systemId',
    'incidentId',
    'templateId',
    'planId',
    'userId',
    'memberId',
    'invitationId',
    'branchId',
    'areaId',
    'signatureId',
    'reviewId',
    'agreementId',
    'itemId',
    'controlId',
    'useCaseId',
    'interactionId',
    'standardId',
    'clauseId',
    'fileId',
    'findingId',
    'treatmentId',
    'kpiId',
    'resultId',
    'assetId',
    'notificationId',
    'issueId',
    'partyId',
    'legalId',
    'processId',
    'biaId',
    'exerciseId',
    'id',
  ]) {
    if (params[key]) return params[key];
  }
  return null;
}

/**
 * Mensaje de error apto para la bitácora: sin rutas del servidor ni detalles de
 * Prisma, que revelarían la estructura interna.
 */
function safeMessage(error: unknown): string {
  if (error instanceof HttpException) {
    const response = error.getResponse();
    if (typeof response === 'string') return response;
    const message = (response as { message?: unknown }).message;
    if (Array.isArray(message)) return message.join('; ');
    if (typeof message === 'string') return message;
    return error.message;
  }
  if (error instanceof Error) {
    const firstLine = error.message.split('\n')[0].trim();
    return firstLine || 'Error interno';
  }
  return 'Error interno';
}
