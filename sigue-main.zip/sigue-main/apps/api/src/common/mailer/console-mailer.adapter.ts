import { Injectable, Logger } from '@nestjs/common';
import { mkdir, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { MailerPort, MailMessage } from './mailer.port';

/**
 * Adaptador local: escribe el correo en el log y lo deja en `var/mail/` en lugar
 * de enviarlo. Permite probar los flujos de recuperación sin credenciales de Postmark.
 */
@Injectable()
export class ConsoleMailerAdapter implements MailerPort {
  private readonly logger = new Logger('Mailer');
  private readonly outbox = process.env.MAIL_OUTBOX_DIR ?? join(process.cwd(), 'var', 'mail');

  async send(message: MailMessage): Promise<void> {
    this.logger.log(`→ ${message.to} | ${message.subject}\n${message.text}`);

    try {
      await mkdir(this.outbox, { recursive: true });
      const stamp = new Date().toISOString().replace(/[:.]/g, '-');
      const safeTo = message.to.replace(/[^a-z0-9@._-]/gi, '_');
      await writeFile(
        join(this.outbox, `${stamp}_${safeTo}.txt`),
        [
          `To: ${message.to}`,
          `Subject: ${message.subject}`,
          `Date: ${new Date().toISOString()}`,
          '',
          message.text,
          '',
        ].join('\n'),
        'utf8',
      );
    } catch (error) {
      // El buzón local es una comodidad de desarrollo: si falla, el envío lógico no.
      this.logger.warn(`No se pudo escribir el buzón local: ${(error as Error).message}`);
    }
  }
}
