/**
 * Puerto de correo saliente.
 * La lógica de negocio depende de esta interfaz, nunca de un proveedor concreto:
 * el adaptador activo se elige por configuración (hoy: consola; mañana: Postmark).
 */
export const MAILER = Symbol('MAILER');

export interface MailMessage {
  to: string;
  subject: string;
  text: string;
  html?: string;
}

export interface MailerPort {
  send(message: MailMessage): Promise<void>;
}
