import { Global, Module } from '@nestjs/common';
import { MAILER } from './mailer.port';
import { ConsoleMailerAdapter } from './console-mailer.adapter';

/**
 * Provee el adaptador de correo. `MAILER` es el token a inyectar.
 * Para producción basta registrar otro adaptador en `useClass`.
 */
@Global()
@Module({
  providers: [{ provide: MAILER, useClass: ConsoleMailerAdapter }],
  exports: [MAILER],
})
export class MailerModule {}
