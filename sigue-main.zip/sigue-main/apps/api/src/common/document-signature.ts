import { createHash } from 'crypto';

/**
 * Reglas de hash y firma de documentos. Viven fuera del servicio para que el
 * seed y las pruebas calculen exactamente igual que la aplicación: un esquema
 * duplicado es justo lo que hacía que las firmas no verificaran.
 */

/**
 * Hash del contenido de una versión.
 *
 * Se calcula siempre a partir del texto y **nunca** se toma el `checksum`
 * almacenado: esa columna es una copia que puede quedarse atrás si alguien
 * altera el contenido directamente en la base de datos. Confiar en ella haría
 * que una alteración pasara por íntegra.
 *
 * Sin contenido no hay nada que firmar: se devuelve `null`.
 */
export function contentHashOf(version: { content?: string | null }): string | null {
  if (version.content == null) return null;
  return createHash('sha256').update(version.content).digest('hex');
}

/**
 * Firma = hash(contenido | firmante | tipo | instante). El instante debe ser el
 * `signedAt` que se persiste en la fila; recalcularlo al verificar produce otro
 * valor y la firma aparecería inválida.
 */
export function signaturePayload(
  contentHash: string,
  signerId: string,
  kind: string,
  signedAt: Date | string,
): string {
  const stamp = signedAt instanceof Date ? signedAt.toISOString() : new Date(signedAt).toISOString();
  return createHash('sha256').update(`${contentHash}|${signerId}|${kind}|${stamp}`).digest('hex');
}
