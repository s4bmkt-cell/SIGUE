/**
 * Generación de códigos con secuencia numérica (`NC-2026-007`, `PR-01-03`).
 *
 * Contar filas no sirve: al borrar un registro —o al sembrar folios salteados—
 * el consecutivo vuelve atrás y choca con un código ya usado (la clave única lo
 * rechaza). La secuencia se deriva del mayor número existente, comparando los
 * valores como números y no como texto (`4.10` después de `4.9`, `1000` después
 * de `999`).
 */
export function nextSequentialCode(
  prefix: string,
  existingCodes: readonly string[],
  width = 3,
): string {
  const last = existingCodes.reduce((max, code) => {
    if (!code.startsWith(prefix)) return max;
    const value = Number(code.slice(prefix.length));
    return Number.isFinite(value) && value > max ? value : max;
  }, 0);
  return `${prefix}${String(last + 1).padStart(width, '0')}`;
}
