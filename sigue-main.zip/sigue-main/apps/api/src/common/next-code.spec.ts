import { nextSequentialCode } from './next-code';

describe('nextSequentialCode — consecutivos derivados del mayor código existente', () => {
  it('arranca en 001 cuando no hay códigos', () => {
    expect(nextSequentialCode('NC-2026-', [])).toBe('NC-2026-001');
  });

  it('continúa desde el mayor existente', () => {
    expect(nextSequentialCode('NC-2026-', ['NC-2026-001', 'NC-2026-002'])).toBe('NC-2026-003');
  });

  it('no reutiliza un folio tras un hueco por borrado', () => {
    expect(nextSequentialCode('NC-2026-', ['NC-2026-003', 'NC-2026-011', 'NC-2026-014'])).toBe(
      'NC-2026-015',
    );
  });

  it('compara numéricamente, no como texto', () => {
    expect(nextSequentialCode('NC-2026-', ['NC-2026-999'])).toBe('NC-2026-1000');
    expect(nextSequentialCode('PR-', ['PR-09', 'PR-10'], 2)).toBe('PR-11');
  });

  it('ignora códigos con otro prefijo o sufijo no numérico', () => {
    expect(
      nextSequentialCode('PR-', ['PR-01', 'PR-02', 'OT-99', 'PR-BORRADOR'], 2),
    ).toBe('PR-03');
  });
});
