import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';

/**
 * Módulo compartido de seguridad: exporta JwtModule para que cualquier módulo
 * que use JwtAuthGuard / RolesGuard tenga acceso a JwtService.
 */
@Module({
  imports: [JwtModule.register({})],
  exports: [JwtModule],
})
export class AuthSharedModule {}
