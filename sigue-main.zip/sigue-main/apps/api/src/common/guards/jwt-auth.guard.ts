import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService } from '@nestjs/jwt';
import { Reflector } from '@nestjs/core';
import { IS_PUBLIC_KEY } from '../decorators/public.decorator';
import { AuthUser } from '../decorators/current-user.decorator';
import { ACCESS_COOKIE } from '../../modules/auth/session-cookie.service';

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const request = context.switchToHttp().getRequest();
    // La app web envía el token en cookie httpOnly (no accesible a JavaScript).
    // Los clientes de API pueden seguir usando `Authorization: Bearer`.
    const auth = request.headers.authorization as string | undefined;
    const cookies = (request as { cookies?: Record<string, string> }).cookies;
    const token =
      (auth?.startsWith('Bearer ') ? auth.slice(7) : undefined) ?? cookies?.[ACCESS_COOKIE];
    if (!token) throw new UnauthorizedException('Autenticación requerida');

    try {
      const payload = await this.jwt.verifyAsync(token, {
        secret: this.config.get<string>('JWT_ACCESS_SECRET'),
      });
      request.user = payload as AuthUser;
      return true;
    } catch {
      throw new UnauthorizedException('Token inválido o expirado');
    }
  }
}
