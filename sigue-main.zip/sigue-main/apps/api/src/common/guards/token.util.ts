import type { Request } from 'express';
import type { JwtService } from '@nestjs/jwt';
import { AuthUser } from '../decorators/current-user.decorator';
import { ACCESS_COOKIE } from '../../modules/auth/session-cookie.service';

/** Extrae el access token de la cookie httpOnly o del header Bearer. */
export function extractAccessToken(req: Request): string | undefined {
  const auth = req.headers.authorization;
  if (auth?.startsWith('Bearer ')) return auth.slice(7);
  const cookies = (req as Request & { cookies?: Record<string, string> }).cookies;
  return cookies?.[ACCESS_COOKIE];
}

/**
 * Verifica el token y deja el usuario en `request.user`.
 * Devuelve undefined si el token falta o no es válido.
 */
export async function authenticateRequest(
  req: Request,
  jwt: JwtService,
  secret: string,
): Promise<AuthUser | undefined> {
  const current = (req as Request & { user?: AuthUser }).user;
  if (current) return current;

  const token = extractAccessToken(req);
  if (!token) return undefined;

  try {
    const payload = (await jwt.verifyAsync(token, { secret })) as AuthUser;
    (req as Request & { user?: AuthUser }).user = payload;
    return payload;
  } catch {
    return undefined;
  }
}
