import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { ROLES_KEY } from '../decorators/roles.decorator';
import { AuthUser } from '../decorators/current-user.decorator';

/**
 * Guard de roles. Se ejecuta después de JwtAuthGuard.
 * Si la ruta declara @RequireRoles(...), el usuario debe tener al menos uno
 * de esos roles en el contexto de organización activo.
 */
@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<string[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (!required?.length) return true;

    const request = context.switchToHttp().getRequest();
    const user: AuthUser = request.user;
    if (!user) throw new ForbiddenException('Usuario no identificado');

    // El administrador de plataforma satisface cualquier `@RequireRoles`: su
    // autoridad no viene de una membresía, así que no aparece en `orgRoles` y
    // sin esta rama recibiría 403 en las rutas que declaran `admin_global`.
    // No abre el contenido de ninguna organización: eso lo decide
    // `OrgMembershipGuard`, que sigue exigiendo membresía en las rutas :orgId.
    if (user.platform === true) return true;

    // Dentro de una ruta con :orgId manda el rol en esa organización (lo deja
    // OrgMembershipGuard); fuera de ella se usan los roles del token.
    const roles: string[] = request.orgRoles ?? user.roles ?? [];
    const hasRole = roles.some((r) => required.includes(r));
    if (!hasRole) {
      throw new ForbiddenException(
        `Requiere uno de los roles: ${required.join(', ')}`,
      );
    }
    return true;
  }
}
