/**
 * Catálogo de roles de organización.
 *
 * Es la fuente única de verdad: la usan la validación de invitaciones, la
 * edición de miembros y el endpoint de catálogo que consume la UI. Mantenerlo
 * aquí evita que el frontend y el backend acepten conjuntos distintos.
 *
 * `admin_org` administra personas y plan **y también opera el contenido**: una
 * organización recién aprovisionada tiene como único miembro al administrador,
 * así que negarle la escritura deja el sistema inutilizable hasta que invite a
 * otra persona. Por eso los controladores de los módulos del SGI lo incluyen en
 * sus `@RequireRoles`, en línea con `WRITERS` de `use-permissions` en la web.
 */

export type OrgRole =
  | 'admin_org'
  | 'resp_sgi'
  | 'resp_norma'
  | 'resp_proceso'
  | 'resp_riesgos'
  | 'controlador_doc'
  | 'auditor_interno'
  | 'resp_accion'
  | 'alta_direccion'
  | 'colaborador'
  | 'consultor_externo'
  | 'auditor_externo'
  | 'solo_lectura';

export interface RoleDefinition {
  code: OrgRole;
  /** Clave i18n; la UI traduce con `roles.<key>`. */
  labelKey: string;
  /** Admin del sistema: gestiona miembros, plan y configuración. */
  admin: boolean;
  /** Solo puede consultar. */
  readOnly: boolean;
}

export const ORG_ROLES: RoleDefinition[] = [
  { code: 'admin_org', labelKey: 'admin_org', admin: true, readOnly: false },
  { code: 'resp_sgi', labelKey: 'resp_sgi', admin: false, readOnly: false },
  { code: 'resp_norma', labelKey: 'resp_norma', admin: false, readOnly: false },
  { code: 'resp_proceso', labelKey: 'resp_proceso', admin: false, readOnly: false },
  { code: 'resp_riesgos', labelKey: 'resp_riesgos', admin: false, readOnly: false },
  { code: 'controlador_doc', labelKey: 'controlador_doc', admin: false, readOnly: false },
  { code: 'auditor_interno', labelKey: 'auditor_interno', admin: false, readOnly: false },
  { code: 'resp_accion', labelKey: 'resp_accion', admin: false, readOnly: false },
  { code: 'alta_direccion', labelKey: 'alta_direccion', admin: false, readOnly: false },
  { code: 'colaborador', labelKey: 'colaborador', admin: false, readOnly: false },
  { code: 'consultor_externo', labelKey: 'consultor_externo', admin: false, readOnly: false },
  { code: 'auditor_externo', labelKey: 'auditor_externo', admin: false, readOnly: false },
  { code: 'solo_lectura', labelKey: 'solo_lectura', admin: false, readOnly: true },
];

const ROLE_CODES = new Set<string>(ORG_ROLES.map((r) => r.code));

export function isOrgRole(value: string): value is OrgRole {
  return ROLE_CODES.has(value);
}

/** Roles que pueden administrar la organización. */
export const ADMIN_ROLES: OrgRole[] = ['admin_org'];

/** Roles con acceso temporal por naturaleza (se les pide fecha de fin). */
export const EXTERNAL_ROLES: OrgRole[] = ['consultor_externo', 'auditor_externo'];
