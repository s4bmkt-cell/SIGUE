// Plantillas propietarias SIGUE (contenido original — no copia de normas ISO).
// Se cargan como datos del paquete de contenido por norma.

export interface TemplateSeed {
  code: string;
  title: string;
  kind: string;
  standard: string; // ISO9001 | ISO27001 | ISO22301 | ISO42001
  content: { sections: { heading: string; body: string }[] };
}

export const SIGUE_TEMPLATES: TemplateSeed[] = [
  // ===== ISO 9001 =====
  {
    code: 'T-POL-9001', title: 'Política de calidad', kind: 'POLITICA', standard: 'ISO9001',
    content: { sections: [
      { heading: 'Objetivo', body: '[Definir el compromiso de la alta dirección con la calidad y la mejora continua]' },
      { heading: 'Alcance', body: '[Aplica a todos los procesos y productos de la organización]' },
      { heading: 'Compromisos', body: '1. Cumplir los requisitos de los clientes. 2. Mejorar continuamente la eficacia del SGC. 3. Establecer y revisar los objetivos de calidad. 4. Proporcionar los recursos necesarios.' },
      { heading: 'Revisión', body: 'La política se revisa en la revisión por la dirección.' },
      { heading: 'Aprobación', body: 'Firma de la alta dirección y fecha de vigencia.' },
    ] },
  },
  {
    code: 'T-PROC-9001', title: 'Procedimiento de control de documentos', kind: 'PROCEDIMIENTO', standard: 'ISO9001',
    content: { sections: [
      { heading: 'Objetivo', body: 'Establecer el control de la información documentada del SGC.' },
      { heading: 'Responsabilidades', body: 'Controlador documental: elabora, revisa, aprueba y publica. Responsables de proceso: proponen cambios.' },
      { heading: 'Actividades', body: '1. Elaboración. 2. Revisión. 3. Aprobación. 4. Publicación. 5. Distribución. 6. Control de cambios y versiones.' },
      { heading: 'Registros', body: 'Historial de versiones, lista maestra de documentos, bitácora de distribución.' },
    ] },
  },
  {
    code: 'T-FMT-9001', title: 'Formato de control de cambios', kind: 'FORMATO', standard: 'ISO9001',
    content: { sections: [
      { heading: 'Datos del documento', body: 'Código, título, versión actual, motivo del cambio.' },
      { heading: 'Registro del cambio', body: 'Fecha, solicitante, descripción del cambio, aprobado por.' },
    ] },
  },
  {
    code: 'T-REG-9001', title: 'Registro de no conformidades', kind: 'REGISTRO', standard: 'ISO9001',
    content: { sections: [
      { heading: 'Identificación', body: 'Folio NC, fecha, reportado por, proceso.' },
      { heading: 'Descripción', body: 'Descripción de la no conformidad, evidencia.' },
      { heading: 'Tratamiento', body: 'Corrección, causa raíz, acción correctiva, responsable, fecha límite.' },
      { heading: 'Cierre', body: 'Verificación de eficacia, fecha, verificador.' },
    ] },
  },

  // ===== ISO 27001 =====
  {
    code: 'T-POL-27001', title: 'Política de seguridad de la información', kind: 'POLITICA', standard: 'ISO27001',
    content: { sections: [
      { heading: 'Objetivo', body: 'Proteger la confidencialidad, integridad y disponibilidad de la información.' },
      { heading: 'Compromisos', body: '1. Clasificar la información. 2. Controlar accesos. 3. Gestionar incidentes de seguridad. 4. Concienciar al personal. 5. Cumplir requisitos legales.' },
      { heading: 'Aprobación', body: 'Firma de la dirección y fecha de vigencia.' },
    ] },
  },
  {
    code: 'T-PROC-27001', title: 'Procedimiento de gestión de incidentes de seguridad', kind: 'PROCEDIMIENTO', standard: 'ISO27001',
    content: { sections: [
      { heading: 'Objetivo', body: 'Detectar, reportar y responder a incidentes de seguridad de la información.' },
      { heading: 'Responsabilidades', body: 'Responsable de TI: clasifica y responde. Usuarios: reportan.' },
      { heading: 'Actividades', body: '1. Detección. 2. Reporte. 3. Clasificación (severidad). 4. Respuesta y contención. 5. Análisis de causa. 6. Cierre y lecciones.' },
      { heading: 'Registros', body: 'Registro de incidentes, análisis post-incidente, acciones correctivas.' },
    ] },
  },
  {
    code: 'T-FMT-27001', title: 'Formato de Declaración de Aplicabilidad (SOA)', kind: 'FORMATO', standard: 'ISO27001',
    content: { sections: [
      { heading: 'Control', body: 'Código del control (Anexo A), nombre, aplicable sí/no.' },
      { heading: 'Justificación', body: 'Motivo de aplicabilidad o exclusión.' },
      { heading: 'Estado', body: 'No implementado / Planificado / Implementado, responsable, evidencia.' },
    ] },
  },

  // ===== ISO 22301 =====
  {
    code: 'T-POL-22301', title: 'Política de continuidad del negocio', kind: 'POLITICA', standard: 'ISO22301',
    content: { sections: [
      { heading: 'Objetivo', body: 'Asegurar la continuidad de las operaciones críticas ante interrupciones.' },
      { heading: 'Compromisos', body: '1. Realizar BIA. 2. Establecer RTO/RPO. 3. Mantener planes de continuidad. 4. Realizar ejercicios y pruebas. 5. Revisar periódicamente.' },
    ] },
  },
  {
    code: 'T-PROC-22301', title: 'Procedimiento de análisis de impacto (BIA)', kind: 'PROCEDIMIENTO', standard: 'ISO22301',
    content: { sections: [
      { heading: 'Objetivo', body: 'Identificar procesos críticos y definir objetivos de recuperación.' },
      { heading: 'Actividades', body: '1. Identificar procesos. 2. Evaluar criticidad. 3. Definir RTO y RPO. 4. Documentar dependencias. 5. Priorizar estrategias.' },
      { heading: 'Registros', body: 'Matriz BIA, prioridades de recuperación.' },
    ] },
  },
  {
    code: 'T-FMT-22301', title: 'Formato de ejercicio de continuidad', kind: 'FORMATO', standard: 'ISO22301',
    content: { sections: [
      { heading: 'Datos del ejercicio', body: 'Tipo (mesa/simulación/completo), fecha, plan evaluado, participantes.' },
      { heading: 'Resultados', body: 'Objetivos cumplidos, desviaciones, acciones de mejora.' },
    ] },
  },

  // ===== ISO 42001 =====
  {
    code: 'T-POL-42001', title: 'Política de gestión de IA', kind: 'POLITICA', standard: 'ISO42001',
    content: { sections: [
      { heading: 'Objetivo', body: 'Garantizar un uso responsable, transparente y gobernado de los sistemas de IA.' },
      { heading: 'Compromisos', body: '1. Inventariar los sistemas de IA. 2. Evaluar su impacto. 3. Asignar responsabilidades. 4. Supervisión humana. 5. Gestionar riesgos de IA. 6. Cumplir requisitos legales.' },
    ] },
  },
  {
    code: 'T-FMT-42001', title: 'Formato de evaluación de impacto de IA', kind: 'FORMATO', standard: 'ISO42001',
    content: { sections: [
      { heading: 'Sistema de IA', body: 'Nombre, tipo, proveedor, datos procesados, ciclo de vida.' },
      { heading: 'Impacto', body: 'Personas, organización, sociedad. Nivel de riesgo (bajo/medio/alto/crítico).' },
      { heading: 'Mitigaciones', body: 'Controles, supervisión humana, medidas de transparencia.' },
      { heading: 'Aprobación', body: 'Responsable, fecha, estado.' },
    ] },
  },
];
