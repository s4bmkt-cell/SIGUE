import type { PrismaClient } from '@prisma/client';
import { SIGUE_TEMPLATES } from './templates-data';

export { SIGUE_TEMPLATES, type TemplateSeed } from './templates-data';

/**
 * Suficiente para sembrar plantillas: sirve tanto el cliente completo como el
 * de una transacción (`Prisma.TransactionClient`), que es lo que usa el alta de
 * organizaciones desde la API.
 */
type TemplateClient = Pick<PrismaClient, 'template'>;

/**
 * Plantillas propietarias de una organización.
 *
 * Vive aparte del catálogo porque el aprovisionamiento carga el catálogo
 * **antes** de crear la organización —activar una norma exige que la norma
 * exista—, así que las plantillas se siembran después, cuando ya hay id. Es
 * idempotente: se apoya en el `upsert` por `orgId_code`.
 *
 * Los datos viven en `src` (y no en `prisma/`) para que el panel de plataforma
 * pueda crear una organización completa sin depender de scripts de línea de
 * comandos.
 */
export async function seedTemplates(prisma: TemplateClient, orgId: string): Promise<number> {
  for (const tpl of SIGUE_TEMPLATES) {
    await prisma.template.upsert({
      where: { orgId_code: { orgId, code: tpl.code } },
      update: {},
      create: {
        orgId,
        code: tpl.code,
        title: tpl.title,
        kind: tpl.kind,
        content: tpl.content as object,
        version: 'v1',
      },
    });
  }
  return SIGUE_TEMPLATES.length;
}
