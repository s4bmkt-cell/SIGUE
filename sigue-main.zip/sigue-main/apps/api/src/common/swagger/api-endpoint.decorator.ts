import { applyDecorators } from '@nestjs/common';
import {
  ApiBadRequestResponse,
  ApiCreatedResponse,
  ApiForbiddenResponse,
  ApiNoContentResponse,
  ApiNotFoundResponse,
  ApiOkResponse,
  ApiOperation,
  ApiUnauthorizedResponse,
} from '@nestjs/swagger';

interface ApiEndpointOptions {
  /** Código real que devuelve Nest: 201 en POST sin `@HttpCode`, 200 en acciones. */
  status?: 200 | 201 | 204;
  /** Respuestas de error adicionales que el módulo devuelve de forma explícita. */
  errors?: Array<'notFound' | 'badRequest' | 'conflict'>;
  /** `true` en rutas que exigen membresía de organización (`:orgId`). */
  tenant?: boolean;
  /** `false` en rutas `@Public()`: no devuelven 401 por falta de token. */
  auth?: boolean;
}

/**
 * Documenta un endpoint con su resumen y las respuestas que realmente produce.
 *
 * Centralizarlo evita que la mitad de las operaciones viajen al OpenAPI sin
 * descripción: el catálogo `/docs` es la referencia que consume el equipo de
 * integración y debe decir qué hace cada ruta y qué códigos puede devolver.
 */
export function ApiEndpoint(summary: string, options: ApiEndpointOptions = {}) {
  const { status = 200, errors = [], tenant = true, auth = true } = options;

  const success =
    status === 201
      ? ApiCreatedResponse({ description: summary })
      : status === 204
        ? ApiNoContentResponse({ description: summary })
        : ApiOkResponse({ description: summary });

  const errorResponses = [
    ...(auth ? [ApiUnauthorizedResponse({ description: 'Token ausente, inválido o expirado' })] : []),
    ...(tenant
      ? [ApiForbiddenResponse({ description: 'El usuario no pertenece a la organización' })]
      : []),
    ...(errors.includes('notFound') ? [ApiNotFoundResponse({ description: 'Recurso no encontrado' })] : []),
    ...(errors.includes('badRequest')
      ? [ApiBadRequestResponse({ description: 'Datos de entrada inválidos' })]
      : []),
    ...(errors.includes('conflict')
      ? [ApiBadRequestResponse({ description: 'El recurso ya existe o está en un estado incompatible' })]
      : []),
  ];

  return applyDecorators(ApiOperation({ summary }), success, ...errorResponses);
}
