import { Injectable, Logger } from '@nestjs/common';
import { createHash } from 'node:crypto';
import {
  BlobSASPermissions,
  BlobServiceClient,
  ContainerClient,
  SASProtocol,
  generateBlobSASQueryParameters,
} from '@azure/storage-blob';
import { DefaultAzureCredential } from '@azure/identity';
import { ObjectInfo, StoragePort, StoredObject, UploadTicket } from './storage.port';

/**
 * Adaptador de Azure Blob Storage.
 *
 * Autentica con `DefaultAzureCredential`: en Azure Container Apps la identidad
 * del sistema recibe el rol *Storage Blob Data Contributor* sobre la cuenta, así
 * que no hay claves en el entorno. En un host fuera de Azure (Render) las
 * mismas credenciales se resuelven con las variables `AZURE_TENANT_ID`,
 * `AZURE_CLIENT_ID` y `AZURE_CLIENT_SECRET` de una entidad de servicio.
 *
 * La cuenta se publica sin acceso público: los archivos se descargan siempre a
 * través de la API, que valida la membresía de la organización antes de servir
 * el binario. La única URL que se entrega al navegador es la de **subida**,
 * firmada, acotada a un blob concreto y con caducidad corta.
 */
@Injectable()
export class AzureBlobStorageAdapter implements StoragePort {
  private readonly logger = new Logger('Storage');
  private readonly service: BlobServiceClient;
  private readonly container: ContainerClient;
  private readonly accountName: string;

  constructor(accountUrl = process.env.AZURE_STORAGE_ACCOUNT_URL) {
    if (!accountUrl) {
      throw new Error(
        'Falta AZURE_STORAGE_ACCOUNT_URL: con STORAGE_DRIVER=azure hay que indicar la cuenta de almacenamiento',
      );
    }
    const containerName = process.env.AZURE_STORAGE_CONTAINER ?? 'evidences';
    this.accountName = new URL(accountUrl).hostname.split('.')[0];
    this.service = new BlobServiceClient(accountUrl, new DefaultAzureCredential());
    this.container = this.service.getContainerClient(containerName);
  }

  async put(key: string, data: Buffer, mime = 'application/octet-stream'): Promise<StoredObject> {
    const client = this.container.getBlockBlobClient(key);
    await client.uploadData(data, {
      blobHTTPHeaders: { blobContentType: mime },
      // El nombre del blob ya es único por versión; sobrescribir es seguro y
      // evita que un reintento deje el objeto anterior huérfano.
      conditions: undefined,
    });
    return {
      key,
      size: data.byteLength,
      sha256: createHash('sha256').update(data).digest('hex'),
      mime,
    };
  }

  /** Devuelve `null` si el blob no existe (el puerto no debe lanzar ahí). */
  async get(key: string): Promise<Buffer | null> {
    try {
      return await this.container.getBlobClient(key).downloadToBuffer();
    } catch (error) {
      if (isNotFound(error)) return null;
      throw error;
    }
  }

  async remove(key: string): Promise<void> {
    await this.container.getBlobClient(key).deleteIfExists();
  }

  async exists(key: string): Promise<boolean> {
    try {
      return await this.container.getBlobClient(key).exists();
    } catch (error) {
      if (isNotFound(error)) return false;
      this.logger.warn(`No se pudo comprobar el blob ${key}: ${(error as Error).message}`);
      return false;
    }
  }

  async stat(key: string): Promise<ObjectInfo | null> {
    try {
      const props = await this.container.getBlobClient(key).getProperties();
      return { size: props.contentLength ?? 0, mime: props.contentType ?? null };
    } catch (error) {
      if (isNotFound(error)) return null;
      throw error;
    }
  }

  /**
   * Firma con *user delegation key* (no con la clave de la cuenta): el permiso
   * lo emite la propia identidad de la aplicación, así que rotar la clave de la
   * cuenta no afecta y no hay secretos de larga vida para firmar.
   *
   * Solo se conceden `create` y `write` sobre **un** blob: no permite listar ni
   * leer nada, y caduca en minutos.
   */
  async presignPut(key: string, mime: string, ttlSeconds: number): Promise<UploadTicket | null> {
    // Un minuto de margen por desfase de reloj entre el navegador y Azure.
    const startsOn = new Date(Date.now() - 60_000);
    const expiresOn = new Date(Date.now() + ttlSeconds * 1000);

    const delegationKey = await this.service.getUserDelegationKey(startsOn, expiresOn);
    const sas = generateBlobSASQueryParameters(
      {
        containerName: this.container.containerName,
        blobName: key,
        permissions: BlobSASPermissions.parse('cw'),
        startsOn,
        expiresOn,
        protocol: SASProtocol.Https,
      },
      delegationKey,
      this.accountName,
    ).toString();

    const blob = this.container.getBlobClient(key);
    return {
      key,
      url: `${blob.url}?${sas}`,
      method: 'PUT',
      // `BlockBlob` es obligatorio en una subida por HTTP simple; el segundo se
      // guarda como tipo del objeto para servirlo luego con el MIME correcto.
      headers: { 'x-ms-blob-type': 'BlockBlob', 'Content-Type': mime },
      expiresAt: expiresOn,
    };
  }
}

/** Azure responde 404 (o `BlobNotFound`) cuando la clave no existe. */
function isNotFound(error: unknown): boolean {
  const candidate = error as { statusCode?: number; code?: string };
  return candidate?.statusCode === 404 || candidate?.code === 'BlobNotFound';
}
