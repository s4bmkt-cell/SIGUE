import { Global, Module } from '@nestjs/common';
import { STORAGE } from './storage.port';
import { LocalStorageAdapter } from './local-storage.adapter';
import { AzureBlobStorageAdapter } from './azure-blob-storage.adapter';

/**
 * Provee el adaptador de almacenamiento. `STORAGE` es el token a inyectar.
 *
 * Se declara global porque lo consumen evidencias, documentos y exportaciones.
 * El adaptador se elige con `STORAGE_DRIVER`:
 *  - `local` (por defecto): disco bajo `STORAGE_DIR`, para desarrollo y pruebas.
 *  - `azure`: Azure Blob Storage con identidad administrada (producción).
 */
@Global()
@Module({
  providers: [
    {
      provide: STORAGE,
      useFactory: () =>
        process.env.STORAGE_DRIVER === 'azure'
          ? new AzureBlobStorageAdapter()
          : new LocalStorageAdapter(),
    },
  ],
  exports: [STORAGE],
})
export class StorageModule {}
