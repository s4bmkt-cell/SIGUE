/**
 * Puerto de almacenamiento de archivos.
 *
 * La lógica de negocio nunca toca el disco ni un SDK de nube: pide `put`, `get`
 * o `remove` a esta interfaz. El adaptador activo se elige por configuración
 * (`STORAGE_DRIVER`): disco local en desarrollo; Azure Blob en producción.
 */
export const STORAGE = Symbol('STORAGE');

export interface StoredObject {
  /** Clave lógica, p. ej. `org-x/ev-123/archivo.pdf`. Nunca una ruta absoluta. */
  key: string;
  size: number;
  sha256: string;
  mime: string;
}

/**
 * Permiso temporal para que el **navegador** suba un archivo directo al
 * almacenamiento, sin pasar por la API.
 *
 * Existe porque el proxy `/api/*` de la web corre como función en Vercel, que
 * corta el cuerpo de la petición en 4,5 MB: por ahí no caben documentos
 * grandes. Con una URL firmada el binario va del navegador al almacén y la API
 * solo registra los metadatos.
 */
export interface UploadTicket {
  /** Clave donde debe quedar el objeto. La decide el servidor, no el cliente. */
  key: string;
  url: string;
  method: 'PUT';
  /** Cabeceras obligatorias en la subida (tipo de blob, por ejemplo). */
  headers: Record<string, string>;
  expiresAt: Date;
}

/** Metadatos de un objeto, sin descargar el binario. */
export interface ObjectInfo {
  size: number;
  mime: string | null;
}

export interface StoragePort {
  put(key: string, data: Buffer, mime?: string): Promise<StoredObject>;
  /** Devuelve `null` si el objeto no existe (no lanza). */
  get(key: string): Promise<Buffer | null>;
  remove(key: string): Promise<void>;
  exists(key: string): Promise<boolean>;
  /**
   * URL temporal para subir directo al almacén. `null` cuando el adaptador no
   * lo soporta (disco local): en ese caso el cliente usa la subida clásica.
   */
  presignPut?(key: string, mime: string, ttlSeconds: number): Promise<UploadTicket | null>;
  /** Tamaño y tipo del objeto; `null` si no existe. */
  stat?(key: string): Promise<ObjectInfo | null>;
}
