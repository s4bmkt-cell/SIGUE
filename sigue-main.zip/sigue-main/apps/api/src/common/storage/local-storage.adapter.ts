import { Injectable, Logger } from '@nestjs/common';
import { createHash } from 'node:crypto';
import { mkdir, readFile, rm, rmdir, stat, writeFile } from 'node:fs/promises';
import { dirname, join, resolve, sep } from 'node:path';
import { StoragePort, StoredObject } from './storage.port';

/**
 * Adaptador local: guarda cada objeto como archivo bajo `var/storage`.
 *
 * La clave (`org-x/ev-1/contrato.pdf`) se resuelve contra la raíz y se verifica
 * que el resultado siga dentro de ella: sin esta comprobación una clave con
 * `../` permitiría leer o escribir fuera del directorio de la aplicación.
 */
@Injectable()
export class LocalStorageAdapter implements StoragePort {
  private readonly logger = new Logger('Storage');
  private readonly root = resolve(process.env.STORAGE_DIR ?? join(process.cwd(), 'var', 'storage'));

  async put(key: string, data: Buffer, mime = 'application/octet-stream'): Promise<StoredObject> {
    const target = this.pathOf(key);
    await mkdir(dirname(target), { recursive: true });
    await writeFile(target, data);
    return {
      key,
      size: data.byteLength,
      sha256: createHash('sha256').update(data).digest('hex'),
      mime,
    };
  }

  async get(key: string): Promise<Buffer | null> {
    try {
      return await readFile(this.pathOf(key));
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return null;
      throw error;
    }
  }

  async remove(key: string): Promise<void> {
    const target = this.pathOf(key);
    await rm(target, { force: true });
    await this.pruneEmptyDirs(dirname(target));
  }

  /** Borra los directorios que quedaron vacíos, sin salir de la raíz. */
  private async pruneEmptyDirs(dir: string): Promise<void> {
    let current = dir;
    while (current !== this.root && current.startsWith(this.root + sep)) {
      try {
        await rmdir(current);
      } catch {
        return; // no está vacío (o ya no existe): se detiene el ascenso
      }
      current = dirname(current);
    }
  }

  async exists(key: string): Promise<boolean> {
    try {
      const info = await stat(this.pathOf(key));
      return info.isFile();
    } catch {
      return false;
    }
  }

  /** Resuelve la clave dentro de la raíz y rechaza cualquier escape. */
  private pathOf(key: string): string {
    const clean = key.replace(/\\/g, '/').replace(/^\/+/, '');
    const target = resolve(this.root, clean);
    if (target !== this.root && !target.startsWith(this.root + sep)) {
      this.logger.warn(`Clave de almacenamiento fuera de la raíz: ${key}`);
      throw new Error('Clave de almacenamiento no válida');
    }
    return target;
  }
}
