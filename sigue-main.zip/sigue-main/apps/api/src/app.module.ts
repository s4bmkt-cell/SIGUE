import { Module } from '@nestjs/common';
import { APP_GUARD, APP_INTERCEPTOR } from '@nestjs/core';
import { ConfigModule } from '@nestjs/config';
import { validateEnv } from './config/env.validation';
import { PrismaModule } from './prisma/prisma.module';
import { HealthModule } from './modules/health/health.module';
import { AuthModule } from './modules/auth/auth.module';
import { UsersModule } from './modules/users/users.module';
import { OrgsModule } from './modules/orgs/orgs.module';
import { AuditModule } from './modules/audit/audit.module';
import { StandardsModule } from './modules/standards/standards.module';
import { DiagnosisModule } from './modules/diagnosis/diagnosis.module';
import { ContextModule } from './modules/context/context.module';
import { PlanningModule } from './modules/planning/planning.module';
import { DocumentsModule } from './modules/documents/documents.module';
import { EvidencesModule } from './modules/evidences/evidences.module';
import { AuditsModule } from './modules/audits/audits.module';
import { NcModule } from './modules/nc/nc.module';
import { MgmtReviewModule } from './modules/mgmt-review/mgmt-review.module';
import { DashboardsModule } from './modules/dashboards/dashboards.module';
import { IsmsModule } from './modules/isms/isms.module';
import { BcmsModule } from './modules/bcms/bcms.module';
import { ItsmModule } from './modules/itsm/itsm.module';
import { AbmsModule } from './modules/abms/abms.module';
import { NotificationsModule } from './modules/notifications/notifications.module';
import { AiSystemsModule } from './modules/ai-systems/ai-systems.module';
import { AiModule } from './modules/ai/ai.module';
import { BillingModule } from './modules/billing/billing.module';
import { ExportModule } from './modules/export/export.module';
import { ConsultantModule } from './modules/consultant/consultant.module';
import { PlatformModule } from './modules/platform/platform.module';
import { AuditInterceptor } from './common/interceptors/audit.interceptor';
import { MailerModule } from './common/mailer/mailer.module';
import { StorageModule } from './common/storage/storage.module';
import { PaymentsModule } from './common/payments/payments.module';
import { AuthSharedModule } from './common/auth-shared.module';
import { TenancyModule } from './tenancy/tenancy.module';
import { OrgMembershipGuard } from './tenancy/org-membership.guard';

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
      validate: validateEnv,
    }),
    PrismaModule,
    MailerModule,
    StorageModule,
    PaymentsModule,
    // JwtService para el guard global de tenancy.
    AuthSharedModule,
    HealthModule,
    AuditModule,
    UsersModule,
    OrgsModule,
    AuthModule,
    StandardsModule,
    DiagnosisModule,
    ContextModule,
    PlanningModule,
    DocumentsModule,
    EvidencesModule,
    AuditsModule,
    NcModule,
    MgmtReviewModule,
    DashboardsModule,
    IsmsModule,
    BcmsModule,
    ItsmModule,
    AbmsModule,
    NotificationsModule,
    AiSystemsModule,
    AiModule,
    BillingModule,
    ExportModule,
    ConsultantModule,
    PlatformModule,
    TenancyModule,
  ],
  providers: [
    // Tenancy global: autentica y exige membresía en toda ruta con :orgId.
    { provide: APP_GUARD, useClass: OrgMembershipGuard },
    // Interceptor global de auditoría: registra eventos para rutas con @Audit()
    { provide: APP_INTERCEPTOR, useClass: AuditInterceptor },
  ],
})
export class AppModule {}
