import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  NotFoundException,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { IS_PUBLIC_KEY } from '../common/decorators/public.decorator';
import { TenancyService } from './tenancy.service';
import { authenticateRequest } from '../common/guards/token.util';
import { AuditService } from '../modules/audit/audit.service';

/**
 * Guard global de tenancy.
 *
 * Sustituye al middleware que nunca se ejecutaba (estaba registrado con el prefijo
 * `/api` duplicado). Corre antes que los guards de controlador, por lo que
 * autentica por sí mismo y deja `request.user` listo para los demás.
 *
 * Si la ruta lleva `:orgId`, exige que la organización esté activa y que el
 * usuario sea miembro, y deja en el request:
 *  - `orgContext`: la organización resuelta
 *  - `orgRoles`: los roles del usuario **en esa organización**
 *
 * El administrador de plataforma **no** exime de esta comprobación: ve el
 * catálogo de organizaciones desde `/platform`, pero no el contenido del SGI de
 * un cliente. El aislamiento entre inquilinos no tiene excepciones.
 */
@Injectable()
export class OrgMembershipGuard implements CanActivate {
  constructor(
    private readonly reflector: Reflector,
    private readonly tenancy: TenancyService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly audit: AuditService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) return true;

    const request = context.switchToHttp().getRequest();
    const orgId = request.params?.orgId as string | undefined;

    const user = await authenticateRequest(
      request,
      this.jwt,
      this.config.get<string>('JWT_ACCESS_SECRET') ?? '',
    );

    if (!orgId) return true;
    if (!user) throw new UnauthorizedException('Autenticación requerida');

    const org = await this.tenancy.getOrg(orgId);
    if (!org) throw new NotFoundException('Organización no encontrada');

    // Suspender una organización tiene que significar algo: hasta ahora el
    // campo `status` solo filtraba el listado y cualquiera con sesión seguía
    // operando con normalidad. Se corta aquí, antes de mirar la membresía, para
    // cubrir de una vez todas las rutas :orgId.
    if (org.status !== 'ACTIVE') {
      await this.audit.record({
        orgId,
        actorId: user.sub,
        action: 'security.org_suspended',
        entity: 'organization',
        entityId: orgId,
        after: { method: request.method, path: request.originalUrl, status: org.status },
        ip: request.ip ?? null,
        userAgent: request.headers?.['user-agent'] ?? null,
      });
      throw new ForbiddenException('La organización está suspendida');
    }

    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      // Los guards corren antes que los interceptores: un acceso denegado no
      // llegaría nunca al interceptor de auditoría, y es justo el evento que
      // más interesa conservar.
      await this.audit.record({
        orgId,
        actorId: user.sub,
        action: 'security.access_denied',
        entity: 'membership',
        entityId: orgId,
        after: { method: request.method, path: request.originalUrl, reason: 'not_a_member' },
        ip: request.ip ?? null,
        userAgent: request.headers?.['user-agent'] ?? null,
      });
      throw new ForbiddenException('No perteneces a esta organización');
    }

    request.orgContext = org;
    // Los roles del token agregan todas las membresías: para autorizar dentro de una
    // organización hay que usar los roles de esa organización.
    request.orgRoles = await this.tenancy.rolesIn(orgId, user.sub);
    return true;
  }
}
