import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Contexto de una operación con inquilino.
 * `orgId` fija la organización activa; `userId` permite ver las propias membresías
 * y los eventos de auditoría globales (login, recuperación de contraseña).
 * `platform` abre la rendija de RLS del panel de plataforma: solo lo fija el
 * módulo `platform`, y sin él las políticas `platform_*` no son verdaderas.
 */
export interface TenantContext {
  orgId?: string | null;
  userId?: string | null;
  platform?: boolean;
}

type TxClient = Prisma.TransactionClient;

/**
 * Ejecuta `fn` dentro de una transacción con las variables que consumen las políticas
 * RLS (`app.org_id`, `app.user_id`). Las variables se fijan con alcance de transacción
 * (`set_config(..., true)`), así que nunca se filtran a otra petición del pool.
 *
 * Toda consulta a tablas con `orgId` **debe** pasar por aquí: con el rol de aplicación
 * el contexto es obligatorio, y sin él PostgreSQL devuelve cero filas.
 */
/**
 * Límites de la transacción. Los valores por defecto de Prisma (2 s para obtener
 * una conexión, 5 s de vigencia) son demasiado cortos cuando varias operaciones
 * compiten por la conexión —p. ej. escrituras de auditoría serializadas por
 * `pg_advisory_xact_lock`—: la transacción no llega a empezar y el negocio falla
 * con "Unable to start a transaction in the given time".
 */
const TRANSACTION_OPTIONS = { maxWait: 10_000, timeout: 30_000 } as const;

export async function withTenant<T>(
  prisma: PrismaService,
  context: TenantContext,
  fn: (tx: TxClient) => Promise<T>,
): Promise<T> {
  return prisma.$transaction(async (tx) => {
    if (context.orgId) {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${context.orgId}, true)`;
    }
    if (context.userId) {
      await tx.$executeRaw`SELECT set_config('app.user_id', ${context.userId}, true)`;
    }
    if (context.platform) {
      await tx.$executeRaw`SELECT set_config('app.platform', 'true', true)`;
    }
    return fn(tx);
  }, TRANSACTION_OPTIONS);
}
