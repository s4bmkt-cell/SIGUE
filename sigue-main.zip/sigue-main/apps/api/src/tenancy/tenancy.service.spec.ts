import { TenancyService } from './tenancy.service';
import { PrismaService } from '../prisma/prisma.service';

describe('TenancyService — aislamiento entre organizaciones (PostgreSQL)', () => {
  const prisma = {
    organization: { findUnique: jest.fn() },
    $queryRaw: jest.fn(),
    $executeRaw: jest.fn(),
    $transaction: jest.fn(async (fn: (tx: unknown) => Promise<unknown>) => fn(prisma)),
  } as unknown as PrismaService;
  const svc = new TenancyService(prisma);

  beforeEach(() => jest.clearAllMocks());

  it('devuelve la organización si existe', async () => {
    (prisma.organization.findUnique as jest.Mock).mockResolvedValue({
      id: 'org-a',
      name: 'Org A',
    });
    await expect(svc.getOrg('org-a')).resolves.toEqual({ orgId: 'org-a', name: 'Org A' });
  });

  it('no devuelve organizaciones inexistentes', async () => {
    (prisma.organization.findUnique as jest.Mock).mockResolvedValue(null);
    await expect(svc.getOrg('no-existe')).resolves.toBeUndefined();
  });

  it('valida membresía activa', async () => {
    (prisma.$queryRaw as jest.Mock).mockResolvedValue([{ id: 'm1' }]);
    await expect(svc.isMember('org-a', 'u1')).resolves.toBe(true);
  });

  it('rechaza no-miembros', async () => {
    (prisma.$queryRaw as jest.Mock).mockResolvedValue([]);
    await expect(svc.isMember('org-a', 'u-externo')).resolves.toBe(false);
  });
});
