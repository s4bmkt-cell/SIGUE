/**
 * Pruebas de aislamiento entre inquilinos contra PostgreSQL real.
 *
 * Requieren una base de datos de pruebas con el rol de aplicación (`sigue_app`)
 * y RLS forzado. Se ejecutan solo si `TEST_DATABASE_URL` está definida; en CI sin
 * base de datos se omiten para no romper el pipeline.
 *
 *   TEST_DATABASE_URL=postgresql://sigue_app:clave@localhost:5432/sigue_test
 *   npm test -- tenant-isolation
 */
import { PrismaClient } from '@prisma/client';
import { withTenant } from './with-tenant';
import { PrismaService } from '../prisma/prisma.service';

const url = process.env.TEST_DATABASE_URL;
const describeDb = url ? describe : describe.skip;

describeDb('Aislamiento entre inquilinos (RLS en PostgreSQL)', () => {
  let prisma: PrismaService;
  const orgA = 'org-ejemplo';
  const orgB = 'org-demo';

  beforeAll(async () => {
    prisma = new PrismaClient({ datasourceUrl: url }) as unknown as PrismaService;
    await prisma.$connect();
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('sin contexto de tenant no se ve ninguna fila', async () => {
    const rows = await prisma.$queryRawUnsafe<{ n: number }[]>(
      'SELECT count(*)::int AS n FROM "Document"',
    );
    expect(rows[0].n).toBe(0);
  });

  it('con contexto de tenant solo se ven las filas de esa organización', async () => {
    const enA = await withTenant(prisma, { orgId: orgA }, (tx) =>
      tx.$queryRawUnsafe<{ n: number }[]>('SELECT count(*)::int AS n FROM "Document"'),
    );
    const enB = await withTenant(prisma, { orgId: orgB }, (tx) =>
      tx.$queryRawUnsafe<{ n: number }[]>('SELECT count(*)::int AS n FROM "Document"'),
    );

    expect(enA[0].n).toBeGreaterThan(0);
    expect(enB[0].n).toBe(0);
  });

  it('las filas devueltas pertenecen siempre al tenant activo', async () => {
    const filas = await withTenant(prisma, { orgId: orgA }, (tx) =>
      tx.document.findMany({ select: { orgId: true } }),
    );
    expect(filas.length).toBeGreaterThan(0);
    expect(filas.every((f) => f.orgId === orgA)).toBe(true);
  });

  it('no se puede escribir con el orgId de otra organización', async () => {
    await expect(
      withTenant(prisma, { orgId: orgA }, (tx) =>
        tx.document.create({
          data: { orgId: orgB, code: 'FUGA-001', title: 'Intento de fuga', type: 'PROCEDURE' },
        }),
      ),
    ).rejects.toThrow();
  });

  it('la membresía de otra organización no es visible', async () => {
    const propio = await withTenant(
      prisma,
      { orgId: orgA, userId: 'u-mariana' },
      (tx) => tx.orgMember.findMany({ select: { orgId: true } }),
    );
    expect(propio.every((m) => m.orgId === orgA)).toBe(true);
  });

  // Las tablas de ISO/IEC 20000-1 e ISO 37001 se crearon en una migración
  // posterior; si esa migración algún día deja de aplicar RLS, los datos de
  // servicios y soborno serían legibles entre inquilinos sin que nada falle.
  it.each([
    'ServiceCatalog',
    'ServiceLevelAgreement',
    'ServiceRequest',
    'BriberyRiskAssessment',
    'BriberyControl',
    'BriberyIncident',
  ])('%s respeta el aislamiento por organización', async (tabla) => {
    const enA = await withTenant(prisma, { orgId: orgA }, (tx) =>
      tx.$queryRawUnsafe<{ n: number }[]>(`SELECT count(*)::int AS n FROM "${tabla}"`),
    );
    const enB = await withTenant(prisma, { orgId: orgB }, (tx) =>
      tx.$queryRawUnsafe<{ n: number }[]>(`SELECT count(*)::int AS n FROM "${tabla}"`),
    );

    expect(enA[0].n).toBeGreaterThan(0);
    expect(enB[0].n).toBe(0);
  });

  // `Organization` usaba `id` como clave, no `orgId`, y quedó fuera del bloque
  // genérico de RLS: el rol de aplicación podía leerla entera, insertar filas y
  // modificar la de otro inquilino. Estas pruebas fijan el comportamiento.
  describe('Organization', () => {
    it('sin contexto solo se ve la propia membresía, no todas las organizaciones', async () => {
      const sinContexto = await prisma.$queryRawUnsafe<{ n: number }[]>(
        'SELECT count(*)::int AS n FROM "Organization"',
      );
      expect(sinContexto[0].n).toBe(0);

      // El id se resuelve de la base: con un id inventado la subconsulta a
      // `OrgMember` no devuelve nada y la prueba pasaría sin comprobar nada.
      const [mariana] = await prisma.$queryRawUnsafe<{ id: string }[]>(
        `SELECT id FROM "User" WHERE email = 'mariana.torres@org.mx'`,
      );
      expect(mariana?.id).toBeTruthy();

      const conUsuario = await withTenant(prisma, { userId: mariana.id }, (tx) =>
        tx.organization.findMany({ select: { id: true } }),
      );
      expect(conUsuario.length).toBeGreaterThan(0);
      expect(conUsuario.every((o) => o.id === orgA || o.id === orgB)).toBe(true);
    });

    it('no se puede leer ni escribir la organización de otro inquilino', async () => {
      const enA = await withTenant(prisma, { orgId: orgA }, (tx) =>
        tx.organization.findMany({ select: { id: true } }),
      );
      expect(enA.map((o) => o.id)).toEqual([orgA]);

      const enB = await withTenant(prisma, { orgId: orgB }, (tx) =>
        tx.organization.findMany({ select: { id: true } }),
      );
      expect(enB.map((o) => o.id)).toEqual([orgB]);

      await expect(
        withTenant(prisma, { orgId: orgA }, (tx) =>
          tx.organization.update({ where: { id: orgB }, data: { name: 'Manipulada' } }),
        ),
      ).rejects.toThrow();
    });

    it('el rol de aplicación solo puede crear organizaciones con contexto de plataforma, y nunca borrarlas', async () => {
      // Sin el GUC `app.platform` la política `platform_insert_Organization` no
      // se cumple: la app no puede inventarse una organización en una ruta
      // corriente.
      await expect(
        prisma.$executeRawUnsafe(
          `INSERT INTO "Organization" (id, name, "legalName", "planCode", status, "createdAt", "updatedAt")
           VALUES ('org-intrusa', 'Intrusa', 'Intrusa', 'BUSINESS', 'ACTIVE', now(), now())`,
        ),
      ).rejects.toThrow();

      // Con el contexto de plataforma sí puede (es el alta del panel). Se fuerza
      // el rollback para no dejar la fila: `DELETE` está revocado a propósito.
      const rollback = new Error('rollback de la prueba');
      await expect(
        withTenant(prisma, { platform: true }, async (tx) => {
          await tx.organization.create({
            data: { id: 'org-alta-plataforma', name: 'Alta de plataforma', planCode: 'BUSINESS' },
          });
          throw rollback;
        }),
      ).rejects.toThrow('rollback de la prueba');

      // Dar de baja es suspender, no borrar: el DELETE sigue sin existir para la
      // aplicación ni siquiera con contexto de plataforma.
      await expect(
        withTenant(prisma, { platform: true }, (tx) =>
          tx.organization.delete({ where: { id: orgA } }),
        ),
      ).rejects.toThrow();
    });

    it('el contexto de plataforma ve todas las organizaciones; el de inquilino, solo la suya', async () => {
      const todas = await withTenant(prisma, { platform: true }, (tx) =>
        tx.organization.findMany({ select: { id: true } }),
      );
      expect(todas.map((o) => o.id).sort()).toEqual(
        expect.arrayContaining([orgA, orgB]),
      );

      const soloA = await withTenant(prisma, { orgId: orgA }, (tx) =>
        tx.organization.findMany({ select: { id: true } }),
      );
      expect(soloA.map((o) => o.id)).toEqual([orgA]);
    });
  });
});
