import { Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { withTenant } from './with-tenant';

export interface OrgContext {
  orgId: string;
  name: string;
  /** `ACTIVE` | `SUSPENDED` | … — el guard lo usa para cortar el acceso. */
  status: string;
}

/**
 * Contexto de tenancy: resuelve la organización y valida la membresía
 * contra PostgreSQL (orgMember activo) fijando `app.org_id`/`app.user_id`
 * para que las políticas RLS se apliquen a la consulta.
 */
@Injectable()
export class TenancyService {
  constructor(private readonly prisma: PrismaService) {}

  /**
   * Resuelve la organización para el guard, **antes** de saber si el usuario es
   * miembro (ese es justo el paso siguiente).
   *
   * Con RLS activa en `Organization`, leer sin contexto devolvería `null` y el
   * guard respondería «no existe» a cualquiera que no fuera ya miembro, incluso
   * para organizaciones que sí existen. Se fija `app.org_id` al id consultado:
   * la política deja ver esa fila y ninguna otra.
   */
  async getOrg(orgId: string): Promise<OrgContext | undefined> {
    const org = await withTenant(this.prisma, { orgId }, (tx) =>
      tx.organization.findUnique({
        where: { id: orgId },
        select: { id: true, name: true, status: true },
      }),
    );
    return org ? { orgId: org.id, name: org.name, status: org.status } : undefined;
  }

  /**
   * Valida que el usuario sea miembro activo de la organización y que su acceso
   * no haya expirado (`accessEnd` es el vencimiento típico de consultores y
   * auditores externos).
   */
  async isMember(orgId: string, userSub: string): Promise<boolean> {
    const rows = await withTenant(this.prisma, { orgId, userId: userSub }, (tx) =>
      tx.$queryRaw`
        SELECT m."id" FROM "OrgMember" m
        WHERE m."orgId" = ${orgId} AND m."userId" = ${userSub} AND m."status" = 'ACTIVE'
          AND (m."accessEnd" IS NULL OR m."accessEnd" > now())
        LIMIT 1
      ` as Promise<{ id: string }[]>,
    );
    return rows.length > 0;
  }

  /**
   * Roles del usuario **dentro de esta organización**. El token de acceso agrega los
   * roles de todas sus membresías, así que autorizar con ellos permitiría, p. ej., ser
   * admin en A y usar ese rol en B.
   */
  async rolesIn(orgId: string, userSub: string): Promise<string[]> {
    const rows = await withTenant(this.prisma, { orgId, userId: userSub }, (tx) =>
      tx.$queryRaw`
        SELECT unnest(m."roles") AS role FROM "OrgMember" m
        WHERE m."orgId" = ${orgId} AND m."userId" = ${userSub} AND m."status" = 'ACTIVE'
          AND (m."accessEnd" IS NULL OR m."accessEnd" > now())
      ` as Promise<{ role: string }[]>,
    );
    return rows.map((r) => r.role);
  }

  /**
   * Organizaciones activas del usuario. Se ejecuta con `app.user_id` fijado: la
   * política RLS de `OrgMember` deja ver únicamente las propias.
   */
  async listForUser(userSub: string): Promise<{ id: string; name: string }[]> {
    return withTenant(this.prisma, { userId: userSub }, (tx) =>
      tx.$queryRaw`
        SELECT o."id", o."name" FROM "Organization" o
        JOIN "OrgMember" m ON m."orgId" = o."id"
        WHERE m."userId" = ${userSub} AND m."status" = 'ACTIVE' AND o."status" = 'ACTIVE'
        ORDER BY o."name"
      ` as Promise<{ id: string; name: string }[]>,
    );
  }
}
