import { Module } from '@nestjs/common';
import { TenancyService } from './tenancy.service';
import { AuditModule } from '../modules/audit/audit.module';

@Module({
  imports: [AuditModule],
  providers: [TenancyService],
  exports: [TenancyService],
})
export class TenancyModule {}
