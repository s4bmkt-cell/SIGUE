import { validateEnv } from './env.validation';

const base = {
  JWT_ACCESS_SECRET: 'a'.repeat(32),
  JWT_REFRESH_SECRET: 'b'.repeat(32),
};

describe('validateEnv — almacenamiento', () => {
  it('con `local` no exige cuenta de almacenamiento', () => {
    const env = validateEnv({ ...base, STORAGE_DRIVER: 'local' });
    expect(env.STORAGE_DRIVER).toBe('local');
    expect(env.AZURE_STORAGE_ACCOUNT_URL).toBeUndefined();
  });

  it('con `azure` exige AZURE_STORAGE_ACCOUNT_URL', () => {
    expect(() => validateEnv({ ...base, STORAGE_DRIVER: 'azure' })).toThrow(
      /AZURE_STORAGE_ACCOUNT_URL/,
    );
  });

  it('con `azure` y cuenta válida arranca', () => {
    const env = validateEnv({
      ...base,
      STORAGE_DRIVER: 'azure',
      AZURE_STORAGE_ACCOUNT_URL: 'https://siguefiles.blob.core.windows.net',
      AZURE_STORAGE_CONTAINER: 'sigue-files',
    });
    expect(env.STORAGE_DRIVER).toBe('azure');
    expect(env.AZURE_STORAGE_CONTAINER).toBe('sigue-files');
  });

  it('el mensaje nombra la variable que falta', () => {
    try {
      validateEnv({ ...base, STORAGE_DRIVER: 'azure' });
      throw new Error('debió lanzar');
    } catch (error) {
      expect((error as Error).message).toContain('AZURE_STORAGE_ACCOUNT_URL');
      expect((error as Error).message).toContain('STORAGE_DRIVER=azure');
    }
  });
});
