import { z } from 'zod';

/**
 * Validación de variables de entorno con Zod.
 * La app no arranca si falta una variable crítica o es inválida (fail-fast).
 */
export const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.coerce.number().int().positive().default(3001),
  CORS_ORIGINS: z.string().default('http://localhost:3000'),
  // Saltos de proxy de confianza. `1` cuando la API está detrás del proxy de
  // Next o del ingress de Container Apps: así `req.ip` es la IP del cliente y
  // el rate limit no mezcla a todos los usuarios en un mismo cubo.
  TRUST_PROXY: z.string().optional(),
  JWT_ACCESS_SECRET: z.string().min(32, 'JWT_ACCESS_SECRET debe tener al menos 32 caracteres'),
  JWT_REFRESH_SECRET: z.string().min(32, 'JWT_REFRESH_SECRET debe tener al menos 32 caracteres'),
  JWT_ACCESS_TTL: z.string().default('10m'),
  JWT_REFRESH_TTL: z.string().default('7d'),
  // ===== MFA =====
  // Nombre que verá el usuario en su app de autenticación.
  MFA_ISSUER: z.string().default('SIGUE'),
  // Clave con la que se cifra la semilla TOTP en reposo. Si falta se deriva de
  // JWT_ACCESS_SECRET (válido para desarrollo, no recomendado en producción:
  // rotar el secreto JWT invalidaría los autenticadores registrados).
  MFA_ENCRYPTION_KEY: z.string().min(16).optional(),
  DATABASE_URL: z.string().url().optional(),
  // ===== Cobros =====
  // Sin secretos de Stripe el sistema cobra en modo local (no cobra nada).
  STRIPE_SECRET_KEY: z.string().optional(),
  STRIPE_WEBHOOK_SECRET: z.string().optional(),
  // Firma HMAC del adaptador local (mismo formato que el proveedor real).
  PAYMENTS_WEBHOOK_SECRET: z.string().optional(),
  MAX_UPLOAD_MB: z.coerce.number().int().positive().default(25),
  // Tope para la subida directa al almacenamiento (URL firmada): no pasa por la
  // API ni por el proxy de la web, así que puede ser mucho mayor que el anterior.
  MAX_DIRECT_UPLOAD_MB: z.coerce.number().int().positive().default(250),
  STORAGE_DIR: z.string().optional(),
  // `local` en desarrollo; `azure` en producción (Blob Storage). El puerto
  // `StoragePort` es el mismo en ambos casos.
  STORAGE_DRIVER: z.enum(['local', 'azure']).default('local'),
  AZURE_STORAGE_ACCOUNT_URL: z.string().url().optional(),
  AZURE_STORAGE_CONTAINER: z.string().default('evidences'),

  OIDC_ISSUER: z.string().url().optional(),
  OIDC_CLIENT_ID: z.string().optional(),
  OIDC_CLIENT_SECRET: z.string().optional(),
}).superRefine((env, ctx) => {
  // Sin la cuenta el adaptador lanza en el constructor; conviene que el proceso
  // no arranque siquiera y el mensaje diga qué variable falta.
  if (env.STORAGE_DRIVER === 'azure' && !env.AZURE_STORAGE_ACCOUNT_URL) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      path: ['AZURE_STORAGE_ACCOUNT_URL'],
      message: 'es obligatoria con STORAGE_DRIVER=azure (https://<cuenta>.blob.core.windows.net)',
    });
  }
});

export type Env = z.infer<typeof envSchema>;

export function validateEnv(config: Record<string, unknown>): Env {
  const parsed = envSchema.safeParse(config);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((i) => `  - ${i.path.join('.')}: ${i.message}`)
      .join('\n');
    throw new Error(`Configuración de entorno inválida:\n${issues}`);
  }
  return parsed.data;
}
