import { INestApplication, ValidationPipe, VersioningType } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DocumentBuilder, OpenAPIObject, SwaggerModule } from '@nestjs/swagger';
import helmet from 'helmet';
import * as cookieParserNs from 'cookie-parser';

// `cookie-parser` es CommonJS y exporta la función directamente. Según el módulo
// que emita TypeScript, el valor útil llega en el namespace o en `.default`.
const cookieParser = ((cookieParserNs as unknown as { default?: typeof cookieParserNs }).default ??
  cookieParserNs) as unknown as (() => import('express').RequestHandler);

/**
 * Configuración HTTP compartida entre `main.ts` y las pruebas de integración.
 *
 * Si las pruebas montaran la app sin esto, no probarían la API real: el prefijo
 * `/api`, el versionado `/v1`, la validación de DTOs y las cookies son parte del
 * contrato que consumen el frontend y los clientes externos.
 */
export function configureApp(app: INestApplication): void {
  const config = app.get(ConfigService);
  const origins = (config.get<string>('CORS_ORIGINS') ?? '')
    .split(',')
    .map((o) => o.trim())
    .filter(Boolean);

  // Detrás de un proxy (el proxy de Next en local, el ingress de Container Apps
  // en producción) `req.ip` sería la IP del proxy: todo el tráfico compartiría
  // el mismo cubo de rate limit. Con `TRUST_PROXY` se lee `x-forwarded-for`.
  const trustProxy = config.get<string>('TRUST_PROXY');
  if (trustProxy) {
    const hops = Number(trustProxy);
    const http = app.getHttpAdapter().getInstance() as {
      set: (key: string, value: unknown) => void;
    };
    http.set('trust proxy', Number.isFinite(hops) ? hops : trustProxy);
  }

  // Seguridad básica de transporte
  app.use(helmet());

  // Cookies: la sesión viaja en cookies httpOnly firmadas por el navegador.
  app.use(cookieParser());

  // CORS restringido a orígenes configurados
  app.enableCors({ origin: origins, credentials: true, exposedHeaders: ['Content-Disposition'] });

  // Prefijo global + versionado de API
  app.setGlobalPrefix('api');
  app.enableVersioning({ type: VersioningType.URI, defaultVersion: '1' });

  // Validación global de DTOs (whitelist: rechaza propiedades no declaradas)
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      forbidNonWhitelisted: true,
      transform: true,
      transformOptions: { enableImplicitConversion: true },
    }),
  );
}

/** Documento OpenAPI con el mismo contenido que publica `/docs`. */
export function buildOpenApiDocument(app: INestApplication): OpenAPIObject {
  const doc = new DocumentBuilder()
    .setTitle('SIGUE API')
    .setDescription('API de SIGUE — Sistemas de Gestión ISO. Monolito modular NestJS.')
    .setVersion('1.0')
    .addBearerAuth()
    .build();
  return SwaggerModule.createDocument(app, doc);
}
