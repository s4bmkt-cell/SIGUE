/**
 * Pruebas de integración de la API sobre HTTP real.
 *
 * Levantan la aplicación completa (guards globales, pipes, cookies, versionado)
 * contra PostgreSQL y hablan con ella a través de Supertest. A diferencia de las
 * pruebas unitarias —que usan dobles— aquí se ejerce el contrato que consumen el
 * frontend y los clientes externos: `/api/v1/...`, cookies httpOnly, rotación de
 * refresh y aislamiento entre organizaciones.
 *
 * Se omiten solas si `TEST_DATABASE_URL` no está definida (CI sin base de datos).
 * La base debe estar migrada y sembrada (`npm run db:setup`).
 */
import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import { PrismaClient } from '@prisma/client';
import * as request from 'supertest';
import { AppModule } from '../app.module';
import { buildOpenApiDocument, configureApp } from '../app.setup';

const url = process.env.TEST_DATABASE_URL;
const describeDb = url ? describe : describe.skip;

const ORG_CON_MEMBRESIA = 'org-ejemplo';
const ORG_SIN_MEMBRESIA = 'org-demo';
const DEMO_EMAIL = 'mariana.torres@org.mx';
const DEMO_PASSWORD = 'demo-password';

describeDb('API — integración HTTP', () => {
  let app: INestApplication;
  let owner: PrismaClient;
  const creados: string[] = [];
  /** Registros ITSM/ABMS creados por las pruebas, para borrarlos al final. */
  const creadosServicios: string[] = [];
  const creadosFolios: string[] = [];
  const creadosRiesgos: string[] = [];
  const creadosIncidentes: string[] = [];
  /** Factores PESTEL creados por las pruebas. */
  const creadosPestel: string[] = [];
  /** Análisis FODA/PESTEL creados por las pruebas (se borran con sus elementos). */
  const creadosSwotAnalisis: string[] = [];
  const creadosPestelAnalisis: string[] = [];
  /** Documentos creados por las pruebas, para borrarlos al final. */
  const creadosDocumentos: string[] = [];

  /** Correo irrepetible para no chocar con ejecuciones anteriores. */
  const correoNuevo = () =>
    `it.${Date.now()}.${Math.random().toString(36).slice(2, 7)}@org.mx`;

  const servidor = () => app.getHttpServer();

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = moduleRef.createNestApplication({ rawBody: true });
    configureApp(app);
    await app.init();

    // Rol dueño (sin RLS) solo para limpiar los usuarios que crean las pruebas.
    owner = new PrismaClient({ datasourceUrl: process.env.DIRECT_URL });
  });

  afterAll(async () => {
    if (creados.length) {
      await owner.user.deleteMany({ where: { email: { in: creados } } });
    }
    // La base de pruebas conserva el seed: se borran solo las filas que
    // agregaron estas pruebas para que el tablero no acumule datos falsos.
    if (creadosServicios.length) {
      await owner.serviceCatalog.deleteMany({
        where: { orgId: ORG_CON_MEMBRESIA, code: { in: creadosServicios } },
      });
    }
    if (creadosFolios.length) {
      await owner.serviceRequest.deleteMany({
        where: { orgId: ORG_CON_MEMBRESIA, folio: { in: creadosFolios } },
      });
    }
    if (creadosRiesgos.length) {
      await owner.briberyRiskAssessment.deleteMany({
        where: { orgId: ORG_CON_MEMBRESIA, id: { in: creadosRiesgos } },
      });
    }
    if (creadosIncidentes.length) {
      await owner.briberyIncident.deleteMany({
        where: { orgId: ORG_CON_MEMBRESIA, id: { in: creadosIncidentes } },
      });
    }
    if (creadosPestel.length) {
      await owner.contextPestel.deleteMany({
        where: { orgId: ORG_CON_MEMBRESIA, id: { in: creadosPestel } },
      });
    }
    // Los análisis se borran al final: arrastran sus elementos por la FK.
    if (creadosSwotAnalisis.length) {
      await owner.contextSwotAnalysis.deleteMany({
        where: { orgId: ORG_CON_MEMBRESIA, id: { in: creadosSwotAnalisis } },
      });
    }
    if (creadosPestelAnalisis.length) {
      await owner.contextPestelAnalysis.deleteMany({
        where: { orgId: ORG_CON_MEMBRESIA, id: { in: creadosPestelAnalisis } },
      });
    }
    // El documento creado en la prueba de permisos no se borra por API (queda
    // vigente a propósito), así que se retira aquí para no ensuciar el inventario.
    if (creadosDocumentos.length) {
      await owner.document.deleteMany({
        where: { orgId: ORG_CON_MEMBRESIA, code: { in: creadosDocumentos } },
      });
    }
    await owner.$disconnect();
    await app.close();
  });

  describe('salud y autenticación', () => {
    it('GET /health responde sin autenticación', async () => {
      const res = await request(servidor()).get('/api/v1/health').expect(200);
      expect(res.body).toMatchObject({ status: 'ok', service: 'sigue-api' });
    });

    it('sin token, /auth/me devuelve 401', async () => {
      const res = await request(servidor()).get('/api/v1/auth/me').expect(401);
      expect(res.body.message).toBeTruthy();
    });

    it('valida el DTO y rechaza propiedades no declaradas', async () => {
      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: DEMO_EMAIL, password: DEMO_PASSWORD, admin: true })
        .expect(400);
      expect(res.body.message).toEqual(
        expect.arrayContaining([expect.stringContaining('admin')]),
      );
    });

    it('rechaza credenciales incorrectas', async () => {
      await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: DEMO_EMAIL, password: 'clave-incorrecta' })
        .expect(401);
    });

    it('registra, inicia sesión y entrega las tres cookies de sesión', async () => {
      const email = correoNuevo();
      creados.push(email);

      await request(servidor())
        .post('/api/v1/auth/register')
        .send({ name: 'Prueba Integración', email, password: 'integracion-123' })
        .expect(201);

      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email, password: 'integracion-123' })
        .expect(200);

      expect(res.body.accessToken).toEqual(expect.any(String));
      expect(res.body.refreshToken).toEqual(expect.any(String));

      const cookies = res.headers['set-cookie'] as unknown as string[];
      const nombres = cookies.map((c) => c.split('=')[0]);
      expect(nombres).toEqual(expect.arrayContaining(['sigue_at', 'sigue_rt', 'sigue_session']));

      // El access token no puede ir en una cookie legible por JavaScript.
      const at = cookies.find((c) => c.startsWith('sigue_at='));
      expect(at).toContain('HttpOnly');
      expect(at).toContain('SameSite=Lax');
    });

    it('devuelve el perfil real del usuario autenticado', async () => {
      const email = correoNuevo();
      creados.push(email);
      await request(servidor())
        .post('/api/v1/auth/register')
        .send({ name: 'Perfil Prueba', email, password: 'integracion-123' })
        .expect(201);

      const login = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email, password: 'integracion-123' })
        .expect(200);

      const res = await request(servidor())
        .get('/api/v1/auth/me')
        .set('Authorization', `Bearer ${login.body.accessToken}`)
        .expect(200);

      expect(res.body).toMatchObject({ email, mfaEnabled: false });
      expect(res.body.roles).toEqual([]);
      expect(res.body.orgId).toBeNull();
    });

    it('duplica el alta de un correo ya registrado con 409', async () => {
      const email = correoNuevo();
      creados.push(email);
      const alta = { name: 'Duplicado', email, password: 'integracion-123' };
      await request(servidor()).post('/api/v1/auth/register').send(alta).expect(201);
      await request(servidor()).post('/api/v1/auth/register').send(alta).expect(409);
    });
  });

  describe('sesión', () => {
    it('rota el refresh token y la reutilización invalida la sesión', async () => {
      const email = correoNuevo();
      creados.push(email);
      await request(servidor())
        .post('/api/v1/auth/register')
        .send({ name: 'Rotación', email, password: 'integracion-123' })
        .expect(201);

      const login = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email, password: 'integracion-123' })
        .expect(200);
      const primero = login.body.refreshToken as string;

      const segundo = await request(servidor())
        .post('/api/v1/auth/refresh')
        .send({ refreshToken: primero })
        .expect(200);
      expect(segundo.body.refreshToken).not.toBe(primero);

      // Reutilizar el token ya rotado se interpreta como robo: 401 y sesión caída.
      await request(servidor())
        .post('/api/v1/auth/refresh')
        .send({ refreshToken: primero })
        .expect(401);

      // El token emitido en la rotación también quedó revocado por la detección.
      await request(servidor())
        .post('/api/v1/auth/refresh')
        .send({ refreshToken: segundo.body.refreshToken })
        .expect(401);
    });

    it('logout revoca el refresh y limpia las cookies', async () => {
      const email = correoNuevo();
      creados.push(email);
      await request(servidor())
        .post('/api/v1/auth/register')
        .send({ name: 'Logout', email, password: 'integracion-123' })
        .expect(201);

      const login = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email, password: 'integracion-123' })
        .expect(200);

      const res = await request(servidor())
        .post('/api/v1/auth/logout')
        .send({ refreshToken: login.body.refreshToken })
        .expect(200);
      expect(res.body).toEqual({ ok: true });

      await request(servidor())
        .post('/api/v1/auth/refresh')
        .send({ refreshToken: login.body.refreshToken })
        .expect(401);
    });
  });

  describe('aislamiento entre organizaciones en HTTP', () => {
    const loginDemo = async () => {
      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: DEMO_EMAIL, password: DEMO_PASSWORD })
        .expect(200);
      return res.body.accessToken as string;
    };

    it('un usuario sin membresía recibe 403 y no ve datos del inquilino', async () => {
      const email = correoNuevo();
      creados.push(email);
      await request(servidor())
        .post('/api/v1/auth/register')
        .send({ name: 'Ajeno', email, password: 'integracion-123' })
        .expect(201);
      const login = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email, password: 'integracion-123' })
        .expect(200);

      await request(servidor())
        .get(`/api/v1/orgs/${ORG_SIN_MEMBRESIA}/documents`)
        .set('Authorization', `Bearer ${login.body.accessToken}`)
        .expect(403);

      // Sin membresías activas, el listado de organizaciones viene vacío.
      const orgs = await request(servidor())
        .get('/api/v1/orgs')
        .set('Authorization', `Bearer ${login.body.accessToken}`)
        .expect(200);
      expect(orgs.body.organizations).toEqual([]);
    });

    it('un miembro accede a su organización pero no a la ajena', async () => {
      const token = await loginDemo();

      await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/documents`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      // Mariana es colaboradora en org-demo (sí es miembro), así que se usa una
      // organización inexistente para el caso de recurso ausente y se comprueba
      // que el guard no filtra datos de una organización donde no participa.
      await request(servidor())
        .get('/api/v1/orgs/org-inexistente/documents')
        .set('Authorization', `Bearer ${token}`)
        .expect(404);
    });
  });

  describe('ISO/IEC 20000-1 e ISO 37001', () => {
    const loginDemo = async () => {
      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: DEMO_EMAIL, password: DEMO_PASSWORD })
        .expect(200);
      return res.body.accessToken as string;
    };

    /** Folio único por ejecución: el seed ya ocupa los folios de ejemplo. */
    const folioNuevo = () => `IT-${Date.now().toString(36).toUpperCase()}`;

    it('GET /itsm devuelve el catálogo sembrado con sus SLA y casos', async () => {
      const token = await loginDemo();
      const res = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/itsm`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(res.body.services.map((s: { code: string }) => s.code)).toEqual(
        expect.arrayContaining(['SRV-01', 'SRV-02', 'SRV-03']),
      );
      expect(res.body.slas.length).toBeGreaterThan(0);
      expect(res.body.requests.length).toBeGreaterThan(0);
      expect(res.body.summary.services).toBe(3);
    });

    it('rechaza un servicio duplicado y deja crear uno nuevo', async () => {
      const token = await loginDemo();
      const servicio = {
        code: `SRV-IT-${Date.now().toString(36).toUpperCase()}`,
        name: 'Servicio de prueba de integración',
        category: 'SOPORTE',
      };
      creadosServicios.push(servicio.code);

      const creado = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/itsm/services`)
        .set('Authorization', `Bearer ${token}`)
        .send(servicio)
        .expect(201);
      expect(creado.body).toMatchObject({ code: servicio.code, status: 'ACTIVE' });

      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/itsm/services`)
        .set('Authorization', `Bearer ${token}`)
        .send(servicio)
        .expect(409);
    });

    it('no permite un SLA sobre un servicio que no está en el catálogo', async () => {
      const token = await loginDemo();
      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/itsm/slas`)
        .set('Authorization', `Bearer ${token}`)
        .send({ serviceCode: 'NO-EXISTE', customer: 'Área X' })
        .expect(404);
    });

    it('registra un caso y fija resolvedAt al resolverlo', async () => {
      const token = await loginDemo();
      const folio = folioNuevo();
      creadosFolios.push(folio);      const creado = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/itsm/requests`)
        .set('Authorization', `Bearer ${token}`)
        .send({
          folio,
          title: 'Caso de integración',
          type: 'INCIDENT',
          priority: 'ALTA',
          serviceCode: 'SRV-01',
        })
        .expect(201);
      expect(creado.body.resolvedAt).toBeNull();

      const resuelto = await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/itsm/requests/${creado.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ status: 'RESOLVED' })
        .expect(200);
      expect(resuelto.body.status).toBe('RESOLVED');
      expect(resuelto.body.resolvedAt).not.toBeNull();
    });

    it('GET /abms devuelve riesgos, controles e incidentes con el puntaje calculado', async () => {
      const token = await loginDemo();
      const res = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/abms`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(res.body.risks.length).toBeGreaterThan(0);
      expect(res.body.controls.length).toBeGreaterThan(0);
      // El seed registra el riesgo de licitaciones con 4 × 5 = 20.
      expect(
        res.body.risks.some((r: { score: number }) => r.score === 20),
      ).toBeTruthy();
      expect(res.body.summary.controlProgress).toBeGreaterThan(0);
    });

    it('recalcula el puntaje del riesgo al cambiar probabilidad o impacto', async () => {
      const token = await loginDemo();
      const creado = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/abms/risks`)
        .set('Authorization', `Bearer ${token}`)
        .send({ area: 'Integración', activity: 'Prueba', likelihood: 2, impact: 3 })
        .expect(201);
      creadosRiesgos.push(creado.body.id);
      expect(creado.body.score).toBe(6);

      const actualizado = await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/abms/risks/${creado.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ likelihood: 4 })
        .expect(200);
      expect(actualizado.body.score).toBe(12);
      expect(actualizado.body.impact).toBe(3);
    });

    it('exige resolución escrita para cerrar un incidente de soborno', async () => {
      const token = await loginDemo();
      const creado = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/abms/incidents`)
        .set('Authorization', `Bearer ${token}`)
        .send({ title: 'Incidente de integración', severity: 'ALTA' })
        .expect(201);
      creadosIncidentes.push(creado.body.id);

      await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/abms/incidents/${creado.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ status: 'CLOSED' })
        .expect(409);

      const cerrado = await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/abms/incidents/${creado.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ status: 'CLOSED', resolution: 'Investigado y sin hallazgos.' })
        .expect(200);
      expect(cerrado.body.status).toBe('CLOSED');
    });
  });

  describe('Contexto — PESTEL', () => {
    const loginDemo = async () => {
      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: DEMO_EMAIL, password: DEMO_PASSWORD })
        .expect(200);
      return res.body.accessToken as string;
    };

    it('GET /context devuelve el análisis sembrado con sus seis dimensiones', async () => {
      const token = await loginDemo();
      const res = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      // Los FODA/PESTEL llegan agrupados: el análisis trae sus elementos.
      expect(Array.isArray(res.body.pestelAnalyses)).toBe(true);
      const analisis = res.body.pestelAnalyses.find(
        (a: { name: string }) => a.name === 'PESTEL 2026',
      );
      expect(analisis).toBeTruthy();
      expect(analisis.items.length).toBeGreaterThan(0);

      const dimensiones = new Set(
        analisis.items.map((p: { type: string }) => p.type),
      );
      for (const tipo of [
        'POLITICO',
        'ECONOMICO',
        'SOCIAL',
        'TECNOLOGICO',
        'ECOLOGICO',
        'LEGAL',
      ]) {
        expect(dimensiones.has(tipo)).toBe(true);
      }
    });

    it('crea, actualiza y elimina un análisis PESTEL con sus factores', async () => {
      const token = await loginDemo();
      const nombre = `PESTEL prueba ${Date.now().toString(36)}`;

      const analisis = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel/analyses`)
        .set('Authorization', `Bearer ${token}`)
        .send({ name: nombre, description: 'Análisis de prueba', period: '2027' })
        .expect(201);
      creadosPestelAnalisis.push(analisis.body.id);
      expect(analisis.body).toMatchObject({
        name: nombre,
        description: 'Análisis de prueba',
        period: '2027',
      });
      expect(analisis.body.items).toEqual([]);

      const factor = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel`)
        .set('Authorization', `Bearer ${token}`)
        .send({
          analysisId: analisis.body.id,
          type: 'TECNOLOGICO',
          impact: 'POSITIVO',
          text: `Factor de prueba ${nombre}`,
        })
        .expect(201);
      expect(factor.body.analysisId).toBe(analisis.body.id);

      // El elemento aparece dentro de su análisis, no suelto.
      const contexto = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      const guardado = contexto.body.pestelAnalyses.find(
        (a: { id: string }) => a.id === analisis.body.id,
      );
      expect(guardado.items.map((i: { id: string }) => i.id)).toEqual([factor.body.id]);

      const renombrado = await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel/analyses/${analisis.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ name: `${nombre} revisado`, period: '2028' })
        .expect(200);
      expect(renombrado.body).toMatchObject({ name: `${nombre} revisado`, period: '2028' });

      // Borrar el análisis arrastra sus factores.
      await request(servidor())
        .delete(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel/analyses/${analisis.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      const sinAnalisis = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(
        sinAnalisis.body.pestelAnalyses.some((a: { id: string }) => a.id === analisis.body.id),
      ).toBe(false);
      // El análisis de prueba ya no existe: se quita de la lista de limpieza.
      creadosPestelAnalisis.pop();
    });

    it('crea, actualiza y elimina un factor PESTEL', async () => {
      const token = await loginDemo();
      const texto = `Factor de prueba ${Date.now().toString(36)}`;

      // Todo factor necesita un análisis: se usa uno propio para no tocar el seed.
      const analisis = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel/analyses`)
        .set('Authorization', `Bearer ${token}`)
        .send({ name: `PESTEL factores ${texto}` })
        .expect(201);
      creadosPestelAnalisis.push(analisis.body.id);
      const analysisId = analisis.body.id as string;

      const creado = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel`)
        .set('Authorization', `Bearer ${token}`)
        .send({ analysisId, type: 'TECNOLOGICO', impact: 'POSITIVO', text: texto })
        .expect(201);
      creadosPestel.push(creado.body.id);
      expect(creado.body).toMatchObject({ type: 'TECNOLOGICO', impact: 'POSITIVO', text: texto });

      // Sin `impact` explícito el factor queda neutro, no con un vacío.
      const neutro = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel`)
        .set('Authorization', `Bearer ${token}`)
        .send({ analysisId, type: 'LEGAL', text: `${texto} sin impacto` })
        .expect(201);
      creadosPestel.push(neutro.body.id);
      expect(neutro.body.impact).toBe('NEUTRO');

      const actualizado = await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel/${creado.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ impact: 'NEGATIVO', text: `${texto} revisado` })
        .expect(200);
      expect(actualizado.body).toMatchObject({ impact: 'NEGATIVO', text: `${texto} revisado` });

      await request(servidor())
        .delete(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel/${creado.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
    });

    it('rechaza propiedades fuera del DTO y un id inexistente', async () => {
      const token = await loginDemo();

      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel`)
        .set('Authorization', `Bearer ${token}`)
        .send({ analysisId: 'x', type: 'SOCIAL', text: 'x', orgId: ORG_SIN_MEMBRESIA })
        .expect(400);

      // Un factor sin análisis tampoco pasa la validación.
      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel`)
        .set('Authorization', `Bearer ${token}`)
        .send({ type: 'SOCIAL', text: 'x' })
        .expect(400);

      // Un análisis de otra organización (o inexistente) no admite factores.
      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel`)
        .set('Authorization', `Bearer ${token}`)
        .send({ analysisId: 'no-existe', type: 'SOCIAL', text: 'x' })
        .expect(404);

      await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/pestel/no-existe`)
        .set('Authorization', `Bearer ${token}`)
        .send({ text: 'x' })
        .expect(404);
    });

    it('no expone factores de otra organización', async () => {
      // Mariana es colaboradora de `org-demo`, así que no sirve para probar el
      // aislamiento: hace falta un usuario sin membresía alguna.
      const email = correoNuevo();
      creados.push(email);
      await request(servidor())
        .post('/api/v1/auth/register')
        .send({ name: 'Ajeno PESTEL', email, password: 'integracion-123' })
        .expect(201);
      const login = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email, password: 'integracion-123' })
        .expect(200);

      await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context`)
        .set('Authorization', `Bearer ${login.body.accessToken}`)
        .expect(403);
    });
  });

  describe('Contexto — FODA', () => {
    const loginDemo = async () => {
      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: DEMO_EMAIL, password: DEMO_PASSWORD })
        .expect(200);
      return res.body.accessToken as string;
    };

    it('GET /context devuelve el FODA sembrado con sus elementos', async () => {
      const token = await loginDemo();
      const res = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(Array.isArray(res.body.swotAnalyses)).toBe(true);
      const analisis = res.body.swotAnalyses.find(
        (a: { name: string }) => a.name === 'FODA 2026',
      );
      expect(analisis).toBeTruthy();
      expect(analisis.items.length).toBeGreaterThan(0);
    });

    it('admite varios FODA y aísla los elementos de cada uno', async () => {
      const token = await loginDemo();
      const nombre = `FODA prueba ${Date.now().toString(36)}`;

      const crear = (name: string) =>
        request(servidor())
          .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot/analyses`)
          .set('Authorization', `Bearer ${token}`)
          .send({ name, period: '2027' })
          .expect(201);

      const primero = await crear(`${nombre} A`);
      const segundo = await crear(`${nombre} B`);
      creadosSwotAnalisis.push(primero.body.id, segundo.body.id);

      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot`)
        .set('Authorization', `Bearer ${token}`)
        .send({ analysisId: primero.body.id, type: 'FORTALEZA', text: `${nombre} solo en A` })
        .expect(201);

      const contexto = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      const a = contexto.body.swotAnalyses.find((x: { id: string }) => x.id === primero.body.id);
      const b = contexto.body.swotAnalyses.find((x: { id: string }) => x.id === segundo.body.id);
      expect(a.items).toHaveLength(1);
      expect(b.items).toHaveLength(0);
    });

    it('rechaza un elemento sin análisis o con un análisis ajeno', async () => {
      const token = await loginDemo();

      // El tipo inline anterior aceptaba cualquier cuerpo; el DTO exige analysisId.
      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot`)
        .set('Authorization', `Bearer ${token}`)
        .send({ type: 'FORTALEZA', text: 'sin análisis' })
        .expect(400);

      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot`)
        .set('Authorization', `Bearer ${token}`)
        .send({ analysisId: 'no-existe', type: 'FORTALEZA', text: 'análisis ajeno' })
        .expect(404);

      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot`)
        .set('Authorization', `Bearer ${token}`)
        .send({ analysisId: 'no-existe', type: 'NO_EXISTE', text: 'tipo inválido' })
        .expect(400);
    });

    it('borrar un FODA elimina también sus elementos', async () => {
      const token = await loginDemo();
      const analisis = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot/analyses`)
        .set('Authorization', `Bearer ${token}`)
        .send({ name: `FODA temporal ${Date.now().toString(36)}` })
        .expect(201);

      const item = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot`)
        .set('Authorization', `Bearer ${token}`)
        .send({ analysisId: analisis.body.id, type: 'AMENAZA', text: 'Elemento que se va' })
        .expect(201);

      await request(servidor())
        .delete(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot/analyses/${analisis.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      // El elemento ya no existe: se consulta el contexto y no debe aparecer.
      const contexto = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      const ids = contexto.body.swotAnalyses.flatMap((a: { items: { id: string }[] }) =>
        a.items.map((i) => i.id),
      );
      expect(ids).not.toContain(item.body.id);
    });
  });

  describe('Roles — escritura del administrador de la organización', () => {
    /**
     * `admin_org` administra personas y plan, y además opera el contenido: si no
     * puede crear un FODA, una organización recién aprovisionada (cuyo único
     * miembro es el administrador) queda sin poder capturar nada. La UI ya lo
     * trataba como escritor (`WRITERS` en `use-permissions`), así que la API debe
     * aceptarlo en los módulos del sistema de gestión.
     */
    const loginJorge = async () => {
      // Jorge solo tiene `admin_org`: no hereda permisos de `resp_sgi`.
      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: 'jorge.aldana@org.mx', password: DEMO_PASSWORD })
        .expect(200);
      return res.body.accessToken as string;
    };

    it('un admin_org sin otros roles puede crear y borrar un FODA', async () => {
      const token = await loginJorge();

      const creado = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot/analyses`)
        .set('Authorization', `Bearer ${token}`)
        .send({ name: `FODA del administrador ${Date.now().toString(36)}` })
        .expect(201);
      creadosSwotAnalisis.push(creado.body.id);

      await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot/analyses/${creado.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ period: '2027' })
        .expect(200);

      await request(servidor())
        .delete(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot/analyses/${creado.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
    });

    it('un admin_org puede escribir en planificación, documentos y auditorías', async () => {
      const token = await loginJorge();

      // Planificación: un plan de implementación (la escritura más básica del módulo).
      const plan = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/planning/plans`)
        .set('Authorization', `Bearer ${token}`)
        .send({ title: `Plan del administrador ${Date.now().toString(36)}` })
        .expect(201);

      // Documentos: crear el registro documental.
      const documento = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/documents`)
        .set('Authorization', `Bearer ${token}`)
        .send({ code: `ADM-${Date.now().toString(36)}`, title: 'Documento del administrador' })
        .expect(201);
      creadosDocumentos.push(documento.body.code);

      // Auditorías: programar una.
      const auditoria = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/audits`)
        .set('Authorization', `Bearer ${token}`)
        .send({ title: `Auditoría del administrador ${Date.now().toString(36)}` })
        .expect(201);

      await request(servidor())
        .delete(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/audits/${auditoria.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      await request(servidor())
        .delete(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/planning/plans/${plan.body.id}`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
    });

    it('el rol solo_lectura sigue sin poder escribir, pero sí leer', async () => {
      const email = correoNuevo();
      creados.push(email);
      await request(servidor())
        .post('/api/v1/auth/register')
        .send({ name: 'Solo Lectura', email, password: 'integracion-123' })
        .expect(201);

      // La membresía la crea el dueño porque `POST /users` exige ser admin:
      // el rol que interesa probar es el de lectura, no quién invita.
      const user = await owner.user.findUnique({ where: { email } });
      await owner.orgMember.create({
        data: { orgId: ORG_CON_MEMBRESIA, userId: user!.id, roles: ['solo_lectura'], status: 'ACTIVE' },
      });

      const login = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email, password: 'integracion-123' })
        .expect(200);
      const token = login.body.accessToken as string;

      await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/context/swot/analyses`)
        .set('Authorization', `Bearer ${token}`)
        .send({ name: 'No debería crearse' })
        .expect(403);
    });
  });

  describe('Normas', () => {
    const loginDemo = async () => {
      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: DEMO_EMAIL, password: DEMO_PASSWORD })
        .expect(200);
      return res.body.accessToken as string;
    };

    it('todas las normas activas traen alcance declarado', async () => {
      const token = await loginDemo();
      const res = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/standards`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      expect(res.body.active.length).toBe(6);
      // Regresión: las normas activadas con un `update` que solo tocaba
      // `status` se quedaban sin descripción y la UI mostraba un hueco.
      const sinAlcance = res.body.active
        .filter((a: { scopeText: string | null }) => !a.scopeText?.trim())
        .map((a: { standard: { code: string } }) => a.standard.code);
      expect(sinAlcance).toEqual([]);
    });

    it('actualiza el alcance de una norma activa y descarta el vacío', async () => {
      const token = await loginDemo();
      const lista = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/standards`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      const objetivo = lista.body.active.find(
        (a: { standard: { code: string } }) => a.standard.code === 'ISO22301',
      );
      const original = objetivo.scopeText as string;
      const nuevo = `${original} (actualizado por la prueba)`;

      const res = await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/standards/${objetivo.standardId}/scope`)
        .set('Authorization', `Bearer ${token}`)
        .send({ scopeText: nuevo })
        .expect(200);
      expect(res.body.scopeText).toBe(nuevo);

      // Se restaura para no alterar las demás suites.
      await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/standards/${objetivo.standardId}/scope`)
        .set('Authorization', `Bearer ${token}`)
        .send({ scopeText: original })
        .expect(200);
    });

    it('reactivar una norma sin alcance no borra el que ya tenía', async () => {
      const token = await loginDemo();
      const lista = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/standards`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      const objetivo = lista.body.active.find(
        (a: { standard: { code: string } }) => a.standard.code === 'ISO9001',
      );
      const original = objetivo.scopeText as string;
      expect(original).toBeTruthy();

      const res = await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/standards/${objetivo.standardId}/activate`)
        .set('Authorization', `Bearer ${token}`)
        .send({})
        .expect(201);
      expect(res.body.scopeText).toBe(original);
    });
  });

  describe('Declaración de Aplicabilidad por norma', () => {
    const loginDemo = async () => {
      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email: DEMO_EMAIL, password: DEMO_PASSWORD })
        .expect(200);
      return res.body.accessToken as string;
    };

    it('expone la SOA de 27001 y de 42001 por separado', async () => {
      const token = await loginDemo();
      const res = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/isms/soa/by-standard`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      // El orden depende de los UUID de cada norma, así que se compara el conjunto.
      const codigos = [
        ...new Set(res.body.map((r: { standard: { code: string } }) => r.standard.code)),
      ].sort();
      expect(codigos).toEqual(['ISO27001', 'ISO42001']);
      // El seed siembra los 93 controles del Anexo A de 27001 y los 10 de 42001.
      const porNorma = (code: string) =>
        res.body.filter((r: { standard: { code: string } }) => r.standard.code === code);
      expect(porNorma('ISO27001')).toHaveLength(93);
      expect(porNorma('ISO42001')).toHaveLength(10);

      // Cada fila trae su norma y un `standardId` que permite filtrar.
      const primera = res.body[0];
      expect(primera.standardId).toBeTruthy();
      expect(primera.standard.edition).toBeTruthy();
    });

    it('filtra la SOA por `standardId` y rechaza propiedades desconocidas', async () => {
      const token = await loginDemo();
      const lista = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/standards`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      const iso42001 = lista.body.active.find(
        (a: { standard: { code: string } }) => a.standard.code === 'ISO42001',
      );

      const filtrada = await request(servidor())
        .get(
          `/api/v1/orgs/${ORG_CON_MEMBRESIA}/isms/soa/by-standard?standardId=${iso42001.standardId}`,
        )
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(filtrada.body).toHaveLength(10);
      expect(
        filtrada.body.every((r: { standardId: string }) => r.standardId === iso42001.standardId),
      ).toBe(true);

      const control = filtrada.body[0];
      const original = control.justification as string | null;

      // El DTO con clase deja de aceptar campos ajenos: antes un `orgId` en el
      // cuerpo se colaba porque el tipo inline no pasaba por el ValidationPipe.
      await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/isms/soa/${control.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ justification: 'texto', orgId: ORG_SIN_MEMBRESIA })
        .expect(400);

      const actualizado = await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/isms/soa/${control.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ justification: 'Justificado por la prueba de integración.' })
        .expect(200);
      expect(actualizado.body.justification).toBe('Justificado por la prueba de integración.');

      // Restauración: el resto de suites (y la demo) esperan el dato original.
      await request(servidor())
        .patch(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/isms/soa/${control.id}`)
        .set('Authorization', `Bearer ${token}`)
        .send({ justification: original ?? '' })
        .expect(200);
    });

    it('reactivar una norma no duplica ni borra su SOA', async () => {
      const token = await loginDemo();
      const lista = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/standards`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      const iso42001 = lista.body.active.find(
        (a: { standard: { code: string } }) => a.standard.code === 'ISO42001',
      );

      const antes = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/isms/soa/by-standard`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      const filaAntes = antes.body.find(
        (r: { standardId: string; applicable: boolean }) =>
          r.standardId === iso42001.standardId && !r.applicable,
      );
      expect(filaAntes).toBeTruthy();

      await request(servidor())
        .post(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/standards/${iso42001.standardId}/activate`)
        .set('Authorization', `Bearer ${token}`)
        .send({})
        .expect(201);

      const despues = await request(servidor())
        .get(`/api/v1/orgs/${ORG_CON_MEMBRESIA}/isms/soa/by-standard`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(despues.body).toHaveLength(antes.body.length);
      const filaDespues = despues.body.find(
        (r: { id: string }) => r.id === filaAntes.id,
      );
      // La exclusión justificada del seed sigue intacta tras reactivar.
      expect(filaDespues).toMatchObject({
        applicable: false,
        justification: filaAntes.justification,
      });
    });
  });

  describe('Plataforma — administración global', () => {
    // El flag vive en `User`, no en `OrgMember`, y no hay endpoint que lo
    // conceda: se otorga aquí con el rol dueño, igual que `db:platform-admin`.
    const ADMIN_EMAIL = 'jorge.aldana@org.mx';
    const plataforma: { orgId?: string; email?: string; password?: string } = {};

    const login = async (email: string, password: string) => {
      const res = await request(servidor())
        .post('/api/v1/auth/login')
        .send({ email, password })
        .expect(200);
      return res.body.accessToken as string;
    };

    beforeAll(async () => {
      await owner.user.update({
        where: { email: ADMIN_EMAIL },
        data: { isPlatformAdmin: true },
      });
    });

    afterAll(async () => {
      await owner.user.update({
        where: { email: ADMIN_EMAIL },
        data: { isPlatformAdmin: false },
      });
      // La organización de prueba arrastra sus miembros, normas y plantillas por
      // las claves foráneas en cascada.
      if (plataforma.orgId) {
        await owner.organization
          .delete({ where: { id: plataforma.orgId } })
          .catch(() => undefined);
      }
      if (plataforma.email) {
        await owner.user.deleteMany({ where: { email: plataforma.email } });
      }
    });

    it('un admin_org sin el flag de plataforma recibe 403', async () => {
      // Mariana administra org-ejemplo y org-demo, pero no la plataforma.
      const token = await login(DEMO_EMAIL, DEMO_PASSWORD);
      await request(servidor())
        .get('/api/v1/platform/orgs')
        .set('Authorization', `Bearer ${token}`)
        .expect(403);
    });

    it('con el flag, lista todas las organizaciones', async () => {
      const token = await login(ADMIN_EMAIL, DEMO_PASSWORD);
      const res = await request(servidor())
        .get('/api/v1/platform/orgs')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);

      const ids = res.body.map((o: { id: string }) => o.id);
      expect(ids).toEqual(expect.arrayContaining([ORG_CON_MEMBRESIA, ORG_SIN_MEMBRESIA]));
      const propia = res.body.find((o: { id: string }) => o.id === ORG_CON_MEMBRESIA);
      expect(propia).toMatchObject({ plan: expect.any(String), status: 'ACTIVE' });
      expect(propia.users).toBeGreaterThan(0);
    });

    it('expone planes y normas para el alta sin duplicar el catálogo en la web', async () => {
      const token = await login(ADMIN_EMAIL, DEMO_PASSWORD);
      const planes = await request(servidor())
        .get('/api/v1/platform/plans')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(planes.body.map((p: { code: string }) => p.code)).toContain('BUSINESS');

      const normas = await request(servidor())
        .get('/api/v1/platform/standards')
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(normas.body.map((n: { code: string }) => n.code)).toContain('ISO9001');
    });

    it('crea una organización con su administrador y devuelve la clave temporal una vez', async () => {
      const token = await login(ADMIN_EMAIL, DEMO_PASSWORD);
      const email = correoNuevo();
      plataforma.email = email;

      const alta = await request(servidor())
        .post('/api/v1/platform/orgs')
        .set('Authorization', `Bearer ${token}`)
        .send({
          name: `Empresa de plataforma ${Date.now().toString(36)}`,
          legalName: 'Empresa de Plataforma, S.A. de C.V.',
          plan: 'BUSINESS',
          standards: ['ISO9001'],
          adminName: 'Administrador de Prueba',
          adminEmail: email,
        })
        .expect(201);

      plataforma.orgId = alta.body.orgId;
      plataforma.password = alta.body.temporaryPassword;
      expect(alta.body).toMatchObject({ adminEmail: email });
      expect(alta.body.temporaryPassword).toMatch(/^[A-Za-z0-9_-]{24}$/);

      // El detalle muestra el administrador recién creado y el plan.
      const detalle = await request(servidor())
        .get(`/api/v1/platform/orgs/${plataforma.orgId}`)
        .set('Authorization', `Bearer ${token}`)
        .expect(200);
      expect(detalle.body).toMatchObject({ plan: 'BUSINESS', status: 'ACTIVE', users: 1 });
      expect(detalle.body.admins.map((a: { email: string }) => a.email)).toContain(email);

      // El alta sí deja al usuario con acceso real a su organización.
      const tokenNuevo = await login(email, alta.body.temporaryPassword);
      await request(servidor())
        .get(`/api/v1/orgs/${plataforma.orgId}/context`)
        .set('Authorization', `Bearer ${tokenNuevo}`)
        .expect(200);
    });

    it('suspender corta el acceso de los miembros y reactivar lo devuelve', async () => {
      const token = await login(ADMIN_EMAIL, DEMO_PASSWORD);
      // El administrador de la organización creada arriba conserva su sesión:
      // se inicia una antes de suspender para comprobar que se le corta después.
      const tokenCliente = await login(plataforma.email!, plataforma.password!);

      await request(servidor())
        .get(`/api/v1/orgs/${plataforma.orgId}/context`)
        .set('Authorization', `Bearer ${tokenCliente}`)
        .expect(200);

      await request(servidor())
        .patch(`/api/v1/platform/orgs/${plataforma.orgId}/status`)
        .set('Authorization', `Bearer ${token}`)
        .send({ status: 'SUSPENDED' })
        .expect(200);

      const suspendida = await request(servidor())
        .get(`/api/v1/orgs/${plataforma.orgId}/context`)
        .set('Authorization', `Bearer ${tokenCliente}`)
        .expect(403);
      expect(suspendida.body.message).toBe('La organización está suspendida');

      // El administrador de plataforma NO entra al SGI del cliente: no es miembro.
      await request(servidor())
        .get(`/api/v1/orgs/${plataforma.orgId}/context`)
        .set('Authorization', `Bearer ${token}`)
        .expect(403);

      await request(servidor())
        .patch(`/api/v1/platform/orgs/${plataforma.orgId}/status`)
        .set('Authorization', `Bearer ${token}`)
        .send({ status: 'ACTIVE' })
        .expect(200);

      // Al reactivar, el miembro recupera el acceso con la misma sesión.
      await request(servidor())
        .get(`/api/v1/orgs/${plataforma.orgId}/context`)
        .set('Authorization', `Bearer ${tokenCliente}`)
        .expect(200);
    });

    it('rechaza un estado no permitido y un plan inexistente', async () => {
      const token = await login(ADMIN_EMAIL, DEMO_PASSWORD);

      await request(servidor())
        .patch(`/api/v1/platform/orgs/${plataforma.orgId}/status`)
        .set('Authorization', `Bearer ${token}`)
        .send({ status: 'DELETED' })
        .expect(400);

      await request(servidor())
        .post('/api/v1/platform/orgs')
        .set('Authorization', `Bearer ${token}`)
        .send({
          name: 'Empresa inválida',
          plan: 'ENTERPRISE',
          adminName: 'Nadie',
          adminEmail: correoNuevo(),
        })
        .expect(400);
    });
  });

  describe('OpenAPI', () => {
    it('documenta todas las operaciones con resumen y respuestas', () => {
      const spec = buildOpenApiDocument(app);
      const operaciones = Object.entries(spec.paths).flatMap(([ruta, item]) =>
        Object.entries(item)
          .filter(([metodo]) => ['get', 'post', 'put', 'patch', 'delete'].includes(metodo))
          .map(([metodo, operacion]) => ({ ruta, metodo, operacion })),
      );

      expect(operaciones.length).toBeGreaterThanOrEqual(200);

      const sinResumen = operaciones.filter((o) => !o.operacion.summary);
      expect(sinResumen.map((o) => `${o.metodo} ${o.ruta}`)).toEqual([]);

      const sinExito = operaciones.filter(
        (o) => !['200', '201', '204'].some((codigo) => o.operacion.responses?.[codigo]),
      );
      expect(sinExito.map((o) => `${o.metodo} ${o.ruta}`)).toEqual([]);

      const sinEtiqueta = operaciones.filter((o) => !o.operacion.tags?.length);
      expect(sinEtiqueta.map((o) => `${o.metodo} ${o.ruta}`)).toEqual([]);
    });

    it('las rutas con :orgId declaran 401 y 403', () => {
      const spec = buildOpenApiDocument(app);
      const rutas = Object.entries(spec.paths).filter(([ruta]) => ruta.includes('{orgId}'));
      expect(rutas.length).toBeGreaterThan(0);

      const incompletas = rutas.flatMap(([ruta, item]) =>
        Object.entries(item)
          .filter(([metodo]) => ['get', 'post', 'put', 'patch', 'delete'].includes(metodo))
          .filter(([, op]) => !op.responses?.['401'] || !op.responses?.['403'])
          .map(([metodo]) => `${metodo} ${ruta}`),
      );
      expect(incompletas).toEqual([]);
    });
  });
});
