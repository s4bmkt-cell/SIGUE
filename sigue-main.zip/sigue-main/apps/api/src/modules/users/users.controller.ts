import { Body, Controller, Get, HttpCode, HttpStatus, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiProperty, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { IsEmail, IsString } from 'class-validator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { ORG_ROLES } from '../../common/roles';
import { InvitationsService } from './invitations.service';
import { Public } from '../../common/decorators/public.decorator';

class AcceptInvitationDto {
  @ApiProperty({ description: 'Id de la invitación pendiente' })
  @IsString()
  invitationId!: string;
}

class AcceptInvitationTokenDto {
  @ApiProperty({ description: 'Token recibido por correo' })
  @IsString()
  token!: string;
}

class PreviewInvitationDto {
  @ApiProperty({ description: 'Token recibido por correo' })
  @IsString()
  token!: string;

  @ApiProperty({ description: 'Correo con el que se registrará la cuenta' })
  @IsEmail()
  email!: string;
}

/**
 * Rutas de la cuenta del usuario (sin organización activa).
 * `GET /users/roles` es el catálogo que consume la UI de invitaciones.
 */
@ApiTags('users')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'users', version: '1' })
export class UsersController {
  constructor(private readonly invitations: InvitationsService) {}

  @ApiEndpoint('Catálogo de roles de organización y sus permisos', { status: 200, tenant: false })
  @Get('roles')
  @RequireRoles('admin_org', 'admin_global')
  roles() {
    return {
      roles: ORG_ROLES.map((r) => r.code),
      // Metadatos para que la UI pueda agrupar y explicar cada rol.
      definitions: ORG_ROLES,
    };
  }

  /** Invitaciones pendientes del correo de la cuenta autenticada. */
  @ApiEndpoint('Invitaciones pendientes del usuario autenticado', { status: 200, tenant: false })
  @Get('invitations')
  async pending(@CurrentUser() user: AuthUser) {
    return { invitations: await this.invitations.pendingForUser(user) };
  }

  /**
   * Acepta una invitación desde la lista de pendientes.
   * La auditoría la escribe `InvitationsService`: aquí no hay `:orgId` en la
   * ruta, así que el interceptor no sabría a qué cadena pertenece el evento.
   */
  @ApiEndpoint('Acepta una invitación de la organización', { status: 200, tenant: false })
  @Post('invitations/accept')
  @HttpCode(HttpStatus.OK)
  accept(@CurrentUser() user: AuthUser, @Body() dto: AcceptInvitationDto) {
    return this.invitations.accept(user, dto.invitationId);
  }

  /** Acepta la invitación de un enlace recibido por correo. */
  @ApiEndpoint('Acepta una invitación a partir del token del enlace', { status: 200, tenant: false })
  @Post('invitations/accept-token')
  @HttpCode(HttpStatus.OK)
  acceptToken(@CurrentUser() user: AuthUser, @Body() dto: AcceptInvitationTokenDto) {
    return this.invitations.acceptToken(user, dto.token);
  }

  /**
   * Valida un enlace de invitación antes de registrarse.
   * Es público porque la pantalla de registro se abre sin sesión; no revela más
   * que el nombre de la organización y el rol ya contenidos en el correo.
   */
  @Public()
  @ApiEndpoint('Datos públicos de una invitación antes de aceptarla', { status: 200, tenant: false, auth: false })
  @Post('invitations/preview')
  @HttpCode(HttpStatus.OK)
  preview(@Body() dto: PreviewInvitationDto) {
    return this.invitations.previewToken(dto.token, dto.email);
  }
}
