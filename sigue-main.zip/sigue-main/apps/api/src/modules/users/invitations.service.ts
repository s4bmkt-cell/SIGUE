import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { createHash, randomBytes } from 'crypto';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { withTenant } from '../../tenancy/with-tenant';
import { AuditService } from '../audit/audit.service';
import { UsageService } from '../billing/usage.service';

/**
 * Invitaciones a una organización.
 *
 * El token crudo solo viaja por correo; en la base de datos queda su hash, igual
 * que en la recuperación de contraseña. Aceptar la invitación exige que el
 * usuario autenticado tenga exactamente el correo invitado: así el enlace no
 * sirve para apropiarse de una invitación ajena.
 */
@Injectable()
export class InvitationsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly audit: AuditService,
    private readonly usage: UsageService,
  ) {}

  /** Token de invitación con el correo y la organización dentro (5 días). */
  signInviteToken(invitationId: string, orgId: string, email: string): string {
    return this.jwt.sign(
      { typ: 'invitation', invitationId, orgId, email: email.toLowerCase() },
      {
        secret: this.config.get<string>('JWT_ACCESS_SECRET') ?? '',
        expiresIn: '5d',
      },
    );
  }

  verifyInviteToken(token: string): {
    invitationId: string;
    orgId: string;
    email: string;
  } {
    let payload: { typ?: string; invitationId?: string; orgId?: string; email?: string };
    try {
      payload = this.jwt.verify<typeof payload>(token, {
        secret: this.config.get<string>('JWT_ACCESS_SECRET') ?? '',
      });
    } catch {
      throw new BadRequestException('El enlace de invitación no es válido o ya caducó');
    }

    if (
      payload.typ !== 'invitation' ||
      !payload.invitationId ||
      !payload.orgId ||
      !payload.email
    ) {
      throw new BadRequestException('El enlace de invitación no es válido');
    }
    return {
      invitationId: payload.invitationId,
      orgId: payload.orgId,
      email: payload.email,
    };
  }

  static hashToken(token: string): string {
    return createHash('sha256').update(token).digest('hex');
  }

  static newToken(): string {
    return randomBytes(32).toString('hex');
  }

  /**
   * Invitaciones pendientes del correo del usuario autenticado, para que al
   * entrar a la app pueda unirse sin salir a buscar el correo otra vez.
   *
   * Se consulta con `app.user_id` fijado: la política `invitation_for_own_email`
   * permite leer únicamente las invitaciones dirigidas a ese usuario.
   */
  async pendingForUser(user: AuthUser) {
    const rows = await withTenant(this.prisma, { userId: user.sub }, (tx) =>
      tx.invitation.findMany({
        where: {
          email: user.email.toLowerCase(),
          status: 'PENDING',
          expiresAt: { gt: new Date() },
        },
        include: { org: { select: { id: true, name: true } } },
        orderBy: { createdAt: 'desc' },
      }),
    );

    return rows.map((r) => ({
      id: r.id,
      orgId: r.orgId,
      orgName: r.org.name,
      role: r.role,
      expiresAt: r.expiresAt,
      accessEnd: r.accessEnd,
      createdAt: r.createdAt,
    }));
  }

  /**
   * Valida el enlace antes de crear una cuenta, para no dejar usuarios huérfanos
   * si el token está manipulado, caducado o la invitación ya se usó.
   *
   * El token firmado trae el `orgId`, así que se puede leer la invitación con el
   * contexto de esa organización (la RLS lo permite) sin que exista un usuario.
   */
  async previewToken(token: string, email: string) {
    const payload = this.verifyInviteToken(token);
    if (payload.email.toLowerCase() !== email.trim().toLowerCase()) {
      throw new ForbiddenException('La invitación fue emitida para otro correo');
    }

    const invitation = await withTenant(this.prisma, { orgId: payload.orgId }, (tx) =>
      tx.invitation.findFirst({
        where: { id: payload.invitationId, orgId: payload.orgId },
        include: { org: { select: { name: true } } },
      }),
    );

    if (!invitation) throw new NotFoundException('Invitación no encontrada');
    if (invitation.status !== 'PENDING') {
      throw new BadRequestException('La invitación ya no está pendiente');
    }
    if (invitation.expiresAt.getTime() < Date.now()) {
      throw new BadRequestException('La invitación caducó; pide que te la reenvíen');
    }

    return {
      invitationId: invitation.id,
      orgId: invitation.orgId,
      orgName: invitation.org.name,
      role: invitation.role,
      accessEnd: invitation.accessEnd,
    };
  }

  /** Acepta una invitación a partir del token recibido por correo. */
  async acceptToken(user: AuthUser, token: string) {
    const payload = this.verifyInviteToken(token);
    return this.acceptById(user, payload.invitationId, payload.email);
  }

  /** Acepta una invitación desde la lista de pendientes de la propia cuenta. */
  async accept(user: AuthUser, invitationId: string) {
    return this.acceptById(user, invitationId, null);
  }

  /**
   * Vincula al usuario con la organización de la invitación.
   *
   * La lectura se hace con `app.user_id` (la invitación es para el correo del
   * usuario) y la escritura con `app.org_id`: RLS exige ese contexto para crear
   * la membresía.
   */
  private async acceptById(
    user: AuthUser,
    invitationId: string,
    expectedEmail: string | null,
  ) {
    const invitation = await withTenant(this.prisma, { userId: user.sub }, (tx) =>
      tx.invitation.findFirst({
        where: { id: invitationId },
        include: { org: { select: { id: true, name: true } } },
      }),
    );

    // RLS solo deja ver las invitaciones dirigidas al correo de la sesión, así
    // que "no existe" casi siempre significa "abriste el enlace con otra cuenta".
    if (!invitation) {
      throw new ForbiddenException(
        expectedEmail && expectedEmail.toLowerCase() !== user.email.toLowerCase()
          ? `La invitación es para ${expectedEmail}; la sesión abierta es de ${user.email}`
          : 'La invitación no está disponible para esta cuenta',
      );
    }
    if (invitation.email.toLowerCase() !== user.email.toLowerCase()) {
      throw new ForbiddenException('La invitación fue emitida para otro correo');
    }
    if (expectedEmail && invitation.email.toLowerCase() !== expectedEmail.toLowerCase()) {
      throw new ForbiddenException('La invitación no corresponde al enlace utilizado');
    }
    if (invitation.status === 'ACCEPTED') {
      // Reabrir el enlace ya usado no es un error: la persona ya es miembro.
      return { orgId: invitation.orgId, orgName: invitation.org.name, role: invitation.role };
    }
    if (invitation.status !== 'PENDING') {
      throw new BadRequestException('La invitación ya no está pendiente');
    }
    if (invitation.expiresAt.getTime() < Date.now()) {
      throw new BadRequestException('La invitación caducó; pide que te la reenvíen');
    }

    const orgId = invitation.orgId;

    await withTenant(this.prisma, { orgId, userId: user.sub }, async (tx) => {
      const existing = await tx.orgMember.findUnique({
        where: { orgId_userId: { orgId, userId: user.sub } },
      });

      if (existing) {
        // Ya era miembro (p. ej. reingreso): se reactiva y se suman los roles.
        const roles = [...new Set([...existing.roles, invitation.role])];
        await tx.orgMember.update({
          where: { id: existing.id },
          data: { status: 'ACTIVE', roles, accessEnd: invitation.accessEnd },
        });
      } else {
        // La invitación reservaba su lugar; si mientras tanto el plan cambió de
        // cupo, se rechaza antes de crear la membresía.
        await this.usage.assertSeatTx(tx, orgId);
        await tx.orgMember.create({
          data: {
            orgId,
            userId: user.sub,
            roles: [invitation.role],
            status: 'ACTIVE',
            accessEnd: invitation.accessEnd,
          },
        });
      }

      await tx.invitation.update({
        where: { id: invitation.id },
        data: { status: 'ACCEPTED', acceptedById: user.sub, acceptedAt: new Date() },
      });
    });

    await this.audit.record({
      orgId,
      actorId: user.sub,
      action: 'invitations.accept',
      entity: 'org_invitations',
      entityId: invitation.id,
      after: { email: invitation.email, role: invitation.role, orgName: invitation.org.name },
    });

    return { orgId, orgName: invitation.org.name, role: invitation.role };
  }
}
