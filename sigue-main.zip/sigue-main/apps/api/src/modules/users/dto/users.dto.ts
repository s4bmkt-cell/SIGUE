import {
  ArrayNotEmpty,
  IsArray,
  IsEmail,
  IsIn,
  IsISO8601,
  IsOptional,
  IsString,
  Length,
  MaxLength,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ORG_ROLES } from '../../../common/roles';

const ROLE_CODES = ORG_ROLES.map((r) => r.code);

export class InviteMemberDto {
  @ApiProperty({ example: 'nuevo.colaborador@org.mx' })
  @IsEmail()
  email!: string;

  @ApiProperty({ enum: ROLE_CODES, example: 'colaborador' })
  @IsIn(ROLE_CODES)
  role!: string;

  @ApiPropertyOptional({ description: 'Fecha de fin de acceso (externa/consultor)' })
  @IsOptional()
  @IsISO8601()
  accessEnd?: string;
}

export class UpdateMemberDto {
  @ApiPropertyOptional({ enum: ROLE_CODES, isArray: true })
  @IsOptional()
  @IsArray()
  @ArrayNotEmpty()
  @IsIn(ROLE_CODES, { each: true })
  roles?: string[];

  @ApiPropertyOptional({ enum: ['ACTIVE', 'SUSPENDED'] })
  @IsOptional()
  @IsIn(['ACTIVE', 'SUSPENDED'])
  status?: string;

  @ApiPropertyOptional({ description: 'Fecha de fin de acceso' })
  @IsOptional()
  @IsISO8601()
  accessEnd?: string;
}

export class UpdateOrgDto {
  @ApiPropertyOptional({ example: 'Organización Ejemplo, S.A. de C.V.' })
  @IsOptional()
  @IsString()
  @Length(2, 160)
  name?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(200)
  legalName?: string;

  @ApiPropertyOptional({ example: 'MX' })
  @IsOptional()
  @IsString()
  @Length(2, 2)
  country?: string;

  @ApiPropertyOptional({ enum: ['es-MX', 'en-US'] })
  @IsOptional()
  @IsIn(['es-MX', 'en-US'])
  lang?: string;

  @ApiPropertyOptional({ example: 'America/Mexico_City' })
  @IsOptional()
  @IsString()
  @MaxLength(64)
  timezone?: string;
}

export class CreateBranchDto {
  @ApiProperty({ example: 'Planta Monterrey' })
  @IsString()
  @Length(2, 120)
  name!: string;

  @ApiPropertyOptional({ example: 'MX' })
  @IsOptional()
  @IsString()
  @Length(2, 2)
  country?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(80)
  state?: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @MaxLength(80)
  city?: string;
}

export class UpdateBranchDto extends CreateBranchDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @Length(2, 120)
  declare name: string;
}

export class CreateAreaDto {
  @ApiProperty({ example: 'Calidad' })
  @IsString()
  @Length(2, 120)
  name!: string;

  @ApiPropertyOptional({ description: 'Sucursal a la que pertenece' })
  @IsOptional()
  @IsString()
  branchId?: string;

  @ApiPropertyOptional({ description: 'Área padre (jerarquía)' })
  @IsOptional()
  @IsString()
  parentId?: string;
}

export class UpdateAreaDto extends CreateAreaDto {
  @ApiPropertyOptional()
  @IsOptional()
  @IsString()
  @Length(2, 120)
  declare name: string;
}
