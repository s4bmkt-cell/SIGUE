import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Patch,
  Post,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { Audit } from '../../common/decorators/audit.decorator';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { InviteMemberDto, UpdateMemberDto } from './dto/users.dto';
import { MembersService } from './members.service';

/**
 * Miembros e invitaciones de una organización.
 *
 * El guard global de tenancy valida la membresía del `:orgId`; el servicio
 * exige además rol de administrador para cualquier cambio o listado completo.
 */
@ApiTags('org-members')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/members', version: '1' })
export class MembersController {
  constructor(private readonly members: MembersService) {}

  @ApiEndpoint('Miembros de la organización con sus roles y estado', { status: 200, tenant: true })
  @Get()
  list(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.members.list(orgId, user);
  }

  @Audit('members.update')
  @ApiEndpoint('Cambia roles o estado de un miembro', { status: 200, tenant: true })
  @Patch(':memberId')
  update(
    @Param('orgId') orgId: string,
    @Param('memberId') memberId: string,
    @Body() dto: UpdateMemberDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.members.updateMember(orgId, user, memberId, dto);
  }

  @Audit('members.remove')
  @ApiEndpoint('Retira a un miembro de la organización', { status: 200, tenant: true })
  @Delete(':memberId')
  @HttpCode(HttpStatus.OK)
  remove(
    @Param('orgId') orgId: string,
    @Param('memberId') memberId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.members.removeMember(orgId, user, memberId);
  }
}

/** Invitaciones pendientes de la organización. */
@ApiTags('org-invitations')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/invitations', version: '1' })
export class InvitationsController {
  constructor(private readonly members: MembersService) {}

  @ApiEndpoint('Invitaciones de la organización', { status: 200, tenant: true })
  @Get()
  list(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.members.listInvitations(orgId, user);
  }

  @Audit('invitations.create')
  @ApiEndpoint('Invita a una persona a la organización', { status: 201, tenant: true })
  @Post()
  invite(
    @Param('orgId') orgId: string,
    @Body() dto: InviteMemberDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.members.invite(orgId, user, dto);
  }

  @Audit('invitations.revoke')
  @ApiEndpoint('Revoca una invitación pendiente', { status: 200, tenant: true })
  @Delete(':invitationId')
  @HttpCode(HttpStatus.OK)
  revoke(
    @Param('orgId') orgId: string,
    @Param('invitationId') invitationId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.members.revokeInvitation(orgId, user, invitationId);
  }

  @Audit('invitations.resend')
  @ApiEndpoint('Reenvía el correo de una invitación', { status: 200, tenant: true })
  @Post(':invitationId/resend')
  @HttpCode(HttpStatus.OK)
  resend(
    @Param('orgId') orgId: string,
    @Param('invitationId') invitationId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.members.resendInvitation(orgId, user, invitationId);
  }
}
