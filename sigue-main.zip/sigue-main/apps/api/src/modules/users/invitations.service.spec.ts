import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { InvitationsService } from './invitations.service';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { UsageService } from '../billing/usage.service';

const SECRET = 'test-secret';

function build(opts: { invitation?: Record<string, unknown> | null } = {}) {
  const invitation = opts.invitation === undefined ? null : opts.invitation;

  const tx = {
    $executeRaw: jest.fn().mockResolvedValue(undefined),
    invitation: {
      findFirst: jest.fn().mockResolvedValue(invitation),
      update: jest.fn().mockResolvedValue({}),
    },
    orgMember: {
      findUnique: jest.fn().mockResolvedValue(null),
      create: jest.fn().mockResolvedValue({}),
      update: jest.fn().mockResolvedValue({}),
    },
  };

  const prisma = {
    $transaction: jest.fn(async (fn: (client: unknown) => Promise<unknown>) => fn(tx)),
  } as unknown as PrismaService;

  const jwt = new JwtService({});
  const config = { get: jest.fn().mockReturnValue(SECRET) } as unknown as ConfigService;
  const audit = { record: jest.fn().mockResolvedValue(undefined) } as never;
  const usage = { assertSeatTx: jest.fn().mockResolvedValue(undefined) } as unknown as UsageService;

  const service = new InvitationsService(prisma, jwt, config, audit, usage);

  return {
    service,
    jwt,
    tx,
    usage,
    /** `acceptById` es privado por diseño; la prueba lo invoca para aislar la lógica. */
    acceptById: (who: AuthUser, id: string) =>
      (service as unknown as {
        acceptById(u: AuthUser, i: string, e: string | null): Promise<unknown>;
      }).acceptById(who, id, null),
  };
}

const user: AuthUser = {
  sub: 'u1',
  email: 'persona@org.mx',
  name: 'Persona',
  roles: [],
  orgId: null,
};

const future = () => new Date(Date.now() + 60_000);
const past = () => new Date(Date.now() - 60_000);

describe('InvitationsService — validación de enlaces', () => {
  it('rechaza un token con firma inválida', () => {
    const { service } = build();
    expect(() => service.verifyInviteToken('no-es-un-jwt')).toThrow(BadRequestException);
  });

  it('rechaza un token firmado con el secreto correcto pero de otro tipo', () => {
    const { service, jwt } = build();
    const token = jwt.sign({ typ: 'refresh', invitationId: 'i1', orgId: 'o1', email: 'a@b.mx' }, {
      secret: SECRET,
    });
    expect(() => service.verifyInviteToken(token)).toThrow(BadRequestException);
  });

  it('acepta un token de invitación válido', () => {
    const { service, jwt } = build();
    const token = jwt.sign(
      { typ: 'invitation', invitationId: 'i1', orgId: 'o1', email: 'a@b.mx' },
      { secret: SECRET },
    );
    expect(service.verifyInviteToken(token)).toEqual({
      invitationId: 'i1',
      orgId: 'o1',
      email: 'a@b.mx',
    });
  });

  it('no permite canjear un enlace emitido para otro correo', async () => {
    const { service } = build();
    const token = service.signInviteToken('i1', 'o1', 'otra@org.mx');
    await expect(service.previewToken(token, 'persona@org.mx')).rejects.toBeInstanceOf(
      ForbiddenException,
    );
  });

  it('rechaza invitaciones que ya no están pendientes', async () => {
    const token = build().service.signInviteToken('i1', 'o1', 'persona@org.mx');
    const { service } = build({
      invitation: {
        id: 'i1',
        orgId: 'o1',
        email: 'persona@org.mx',
        role: 'colaborador',
        status: 'ACCEPTED',
        expiresAt: future(),
        accessEnd: null,
        org: { name: 'Org' },
      },
    });
    await expect(service.previewToken(token, 'persona@org.mx')).rejects.toBeInstanceOf(
      BadRequestException,
    );
  });

  it('rechaza invitaciones caducadas', async () => {
    const token = build().service.signInviteToken('i1', 'o1', 'persona@org.mx');
    const { service } = build({
      invitation: {
        id: 'i1',
        orgId: 'o1',
        email: 'persona@org.mx',
        role: 'colaborador',
        status: 'PENDING',
        expiresAt: past(),
        accessEnd: null,
        org: { name: 'Org' },
      },
    });
    await expect(service.previewToken(token, 'persona@org.mx')).rejects.toBeInstanceOf(
      BadRequestException,
    );
  });

  it('devuelve los datos de una invitación válida', async () => {
    const token = build().service.signInviteToken('i1', 'o1', 'persona@org.mx');
    const { service } = build({
      invitation: {
        id: 'i1',
        orgId: 'o1',
        email: 'persona@org.mx',
        role: 'auditor_externo',
        status: 'PENDING',
        expiresAt: future(),
        accessEnd: future(),
        org: { name: 'Org Ejemplo' },
      },
    });
    await expect(service.previewToken(token, 'persona@org.mx')).resolves.toMatchObject({
      invitationId: 'i1',
      orgId: 'o1',
      orgName: 'Org Ejemplo',
      role: 'auditor_externo',
    });
  });
});

describe('InvitationsService — aceptación', () => {
  const invitation = {
    id: 'i1',
    orgId: 'o1',
    email: 'persona@org.mx',
    role: 'colaborador',
    status: 'PENDING',
    expiresAt: future(),
    accessEnd: null,
    org: { id: 'o1', name: 'Org Ejemplo' },
  };

  it('rechaza aceptar una invitación de otro correo', async () => {
    const { acceptById } = build({ invitation });
    await expect(acceptById({ ...user, email: 'intruso@org.mx' }, 'i1')).rejects.toBeInstanceOf(
      ForbiddenException,
    );
  });

  it('rechaza una invitación que no es visible para la cuenta (otra persona)', async () => {
    const { acceptById } = build({ invitation: null });
    await expect(acceptById(user, 'i1')).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('reabrir una invitación ya aceptada devuelve la organización sin error', async () => {
    const { acceptById, tx } = build({ invitation: { ...invitation, status: 'ACCEPTED' } });
    const result = await acceptById(user, 'i1');
    expect(result).toEqual({ orgId: 'o1', orgName: 'Org Ejemplo', role: 'colaborador' });
    expect(tx.invitation.update).not.toHaveBeenCalled();
  });

  it('crea la membresía y marca la invitación como aceptada', async () => {
    const { acceptById, tx } = build({ invitation });
    const result = await acceptById(user, 'i1');

    expect(result).toEqual({ orgId: 'o1', orgName: 'Org Ejemplo', role: 'colaborador' });
    expect(tx.orgMember.create).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ orgId: 'o1', userId: 'u1', roles: ['colaborador'] }),
      }),
    );
    expect(tx.invitation.update).toHaveBeenCalledWith(
      expect.objectContaining({
        data: expect.objectContaining({ status: 'ACCEPTED', acceptedById: 'u1' }),
      }),
    );
  });
});
