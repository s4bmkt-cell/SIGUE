import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Inject,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { ADMIN_ROLES, isOrgRole } from '../../common/roles';
import { MAILER, MailerPort } from '../../common/mailer/mailer.port';
import { PrismaService } from '../../prisma/prisma.service';
import { TenancyService } from '../../tenancy/tenancy.service';
import { withTenant } from '../../tenancy/with-tenant';
import { UsageService } from '../billing/usage.service';
import { InvitationsService } from './invitations.service';
import { ConfigService } from '@nestjs/config';

export interface MemberView {
  id: string;
  userId: string;
  name: string;
  email: string;
  roles: string[];
  status: string;
  areaId: string | null;
  accessStart: Date | null;
  accessEnd: Date | null;
  createdAt: Date;
  lastLoginAt: Date | null;
}

@Injectable()
export class MembersService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
    private readonly invitations: InvitationsService,
    private readonly usage: UsageService,
    private readonly config: ConfigService,
    @Inject(MAILER) private readonly mailer: MailerPort,
  ) {}

  async list(orgId: string, user: AuthUser): Promise<MemberView[]> {
    await this.assertAdmin(orgId, user);

    const rows = await withTenant(this.prisma, { orgId, userId: user.sub }, (tx) =>
      tx.orgMember.findMany({
        where: { orgId },
        include: { user: { select: { id: true, name: true, email: true, lastLoginAt: true } } },
        orderBy: [{ status: 'asc' }, { createdAt: 'asc' }],
      }),
    );

    return rows.map((m) => ({
      id: m.id,
      userId: m.userId,
      name: m.user.name,
      email: m.user.email,
      roles: m.roles,
      status: m.status,
      areaId: m.areaId,
      accessStart: m.accessStart,
      accessEnd: m.accessEnd,
      createdAt: m.createdAt,
      lastLoginAt: m.user.lastLoginAt,
    }));
  }

  /**
   * Invita a un correo. Se rechaza si ya es miembro activo o si hay otra
   * invitación pendiente, y se respeta la cuota de usuarios del plan.
   */
  async invite(
    orgId: string,
    actor: AuthUser,
    input: { email: string; role: string; accessEnd?: string },
  ) {
    await this.assertAdmin(orgId, actor);
    const email = input.email.trim().toLowerCase();
    if (!isOrgRole(input.role)) throw new BadRequestException('Rol no válido');

    const accessEnd = input.accessEnd ? new Date(input.accessEnd) : null;
    if (accessEnd && accessEnd.getTime() <= Date.now()) {
      throw new BadRequestException('La fecha de fin de acceso debe ser futura');
    }

    const org = await withTenant(this.prisma, { orgId, userId: actor.sub }, (tx) =>
      tx.organization.findUnique({
        where: { id: orgId },
        select: { id: true, name: true },
      }),
    );
    if (!org) throw new NotFoundException('Organización no encontrada');

    const existingUser = await this.prisma.user.findUnique({
      where: { email },
      select: { id: true },
    });

    const result = await withTenant(this.prisma, { orgId, userId: actor.sub }, async (tx) => {
      if (existingUser) {
        const member = await tx.orgMember.findUnique({
          where: { orgId_userId: { orgId, userId: existingUser.id } },
        });
        if (member?.status === 'ACTIVE') {
          throw new ConflictException('Ese correo ya pertenece a la organización');
        }
      }

      const pending = await tx.invitation.findFirst({
        where: { orgId, email, status: 'PENDING' },
      });
      if (pending) throw new ConflictException('Ya hay una invitación pendiente para ese correo');

      // La cuota se evalúa con datos reales dentro de esta misma transacción:
      // el consumo guardado en `OrgUsage` solo alimenta los tableros.
      await this.usage.assertUsersTx(tx, orgId, 1);

      const token = InvitationsService.newToken();
      const invitation = await tx.invitation.create({
        data: {
          orgId,
          email,
          role: input.role,
          tokenHash: InvitationsService.hashToken(token),
          // El enlace vale 7 días; el acceso concedido es independiente y puede
          // durar más (o ser indefinido, si no se indicó fecha).
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          accessEnd,
          invitedById: actor.sub,
        },
      });

      return { invitation, token };
    });

    // El token firmado lleva la invitación dentro: aceptar no requiere buscarla
    // por el token opaco, y caduca solo aunque el usuario tarde.
    const token = this.invitations.signInviteToken(result.invitation.id, orgId, email);
    const url = `${this.webAppUrl()}/accept-invitation?token=${token}`;

    await this.mailer.send({
      to: email,
      subject: `${actor.name} te invitó a ${org.name} en SIGN`,
      text:
        `${actor.name} (${actor.email}) te invitó a unirte a "${org.name}" con el rol ${input.role}.\n\n` +
        `Acepta la invitación (válida 7 días):\n${url}\n\n` +
        `Si no esperabas este correo, ignóralo.`,
    });

    return {
      id: result.invitation.id,
      email,
      role: input.role,
      expiresAt: result.invitation.expiresAt,
      status: result.invitation.status,
    };
  }

  async listInvitations(orgId: string, user: AuthUser) {
    await this.assertAdmin(orgId, user);
    const rows = await withTenant(this.prisma, { orgId, userId: user.sub }, (tx) =>
      tx.invitation.findMany({
        where: { orgId, status: 'PENDING' },
        orderBy: { createdAt: 'desc' },
      }),
    );
    return rows.map((r) => ({
      id: r.id,
      email: r.email,
      role: r.role,
      status: r.expiresAt.getTime() < Date.now() ? 'EXPIRED' : r.status,
      expiresAt: r.expiresAt,
      accessEnd: r.accessEnd,
      createdAt: r.createdAt,
    }));
  }

  async revokeInvitation(orgId: string, user: AuthUser, invitationId: string) {
    await this.assertAdmin(orgId, user);
    return withTenant(this.prisma, { orgId, userId: user.sub }, async (tx) => {
      const invitation = await tx.invitation.findFirst({
        where: { id: invitationId, orgId },
      });
      if (!invitation) throw new NotFoundException('Invitación no encontrada');
      if (invitation.status !== 'PENDING') {
        throw new ConflictException('La invitación ya no está pendiente');
      }
      const updated = await tx.invitation.update({
        where: { id: invitationId },
        data: { status: 'REVOKED', revokedAt: new Date() },
      });
      // No se devuelve `tokenHash` ni el resto de columnas internas.
      return {
        id: updated.id,
        email: updated.email,
        role: updated.role,
        status: updated.status,
        revokedAt: updated.revokedAt,
      };
    });
  }

  /** Reenvía el correo rotando el token anterior. */
  async resendInvitation(orgId: string, actor: AuthUser, invitationId: string) {
    await this.assertAdmin(orgId, actor);
    const org = await withTenant(this.prisma, { orgId, userId: actor.sub }, (tx) =>
      tx.organization.findUnique({
        where: { id: orgId },
        select: { name: true },
      }),
    );
    if (!org) throw new NotFoundException('Organización no encontrada');

    const updated = await withTenant(this.prisma, { orgId, userId: actor.sub }, async (tx) => {
      const invitation = await tx.invitation.findFirst({
        where: { id: invitationId, orgId },
      });
      if (!invitation) throw new NotFoundException('Invitación no encontrada');
      if (invitation.status !== 'PENDING') {
        throw new ConflictException('La invitación ya no está pendiente');
      }
      return tx.invitation.update({
        where: { id: invitation.id },
        data: {
          tokenHash: InvitationsService.hashToken(InvitationsService.newToken()),
          expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
          lastSentAt: new Date(),
        },
      });
    });

    const token = this.invitations.signInviteToken(updated.id, orgId, updated.email);
    await this.mailer.send({
      to: updated.email,
      subject: `Recordatorio: invitación a ${org.name} en SIGN`,
      text: `${actor.name} te recuerda la invitación a "${org.name}".\n\nAbrir: ${this.webAppUrl()}/accept-invitation?token=${token}`,
    });

    return { ok: true, expiresAt: updated.expiresAt };
  }

  /**
   * Cambia roles o estado de un miembro.
   *
   * Reglas que protegen la organización de quedarse sin administración:
   *  - nadie puede quitarse a sí mismo el rol de administrador;
   *  - no se puede suspender al último administrador activo.
   */
  async updateMember(
    orgId: string,
    actor: AuthUser,
    memberId: string,
    input: { roles?: string[]; status?: string; accessEnd?: string },
  ) {
    await this.assertAdmin(orgId, actor);

    if (input.roles) {
      const invalid = input.roles.filter((r) => !isOrgRole(r));
      if (invalid.length) throw new BadRequestException(`Roles no válidos: ${invalid.join(', ')}`);
      if (input.roles.length === 0) throw new BadRequestException('El miembro necesita al menos un rol');
    }

    return withTenant(this.prisma, { orgId, userId: actor.sub }, async (tx) => {
      const member = await tx.orgMember.findFirst({ where: { id: memberId, orgId } });
      if (!member) throw new NotFoundException('Miembro no encontrado');

      const losesAdmin =
        Boolean(input.roles) && !input.roles!.some((r) => ADMIN_ROLES.includes(r as never));
      const suspends = input.status === 'SUSPENDED';
      if ((losesAdmin || suspends) && member.userId === actor.sub) {
        throw new BadRequestException('No puedes quitarte el rol de administrador ni suspenderte');
      }

      const remainsAdmin =
        (input.roles ?? member.roles).some((r) => ADMIN_ROLES.includes(r as never)) &&
        (input.status ?? member.status) === 'ACTIVE';

      if (!remainsAdmin && (member.roles.some((r) => ADMIN_ROLES.includes(r as never)) || suspends)) {
        const admins = await tx.orgMember.count({
          where: { orgId, status: 'ACTIVE', roles: { hasSome: ADMIN_ROLES } },
        });
        if (admins <= 1) {
          throw new BadRequestException('La organización debe conservar al menos un administrador activo');
        }
      }

      return tx.orgMember.update({
        where: { id: memberId },
        data: {
          ...(input.roles ? { roles: input.roles } : {}),
          ...(input.status ? { status: input.status } : {}),
          ...(input.accessEnd !== undefined
            ? { accessEnd: input.accessEnd ? new Date(input.accessEnd) : null }
            : {}),
        },
      });
    });
  }

  /** Retira a un miembro de la organización. */
  async removeMember(orgId: string, actor: AuthUser, memberId: string) {
    await this.assertAdmin(orgId, actor);

    return withTenant(this.prisma, { orgId, userId: actor.sub }, async (tx) => {
      const member = await tx.orgMember.findFirst({ where: { id: memberId, orgId } });
      if (!member) throw new NotFoundException('Miembro no encontrado');
      if (member.userId === actor.sub) {
        throw new BadRequestException('No puedes retirarte a ti mismo; pide a otro administrador');
      }

      if (member.roles.some((r) => ADMIN_ROLES.includes(r as never))) {
        const admins = await tx.orgMember.count({
          where: { orgId, status: 'ACTIVE', roles: { hasSome: ADMIN_ROLES } },
        });
        if (admins <= 1) {
          throw new BadRequestException('La organización debe conservar al menos un administrador activo');
        }
      }

      await tx.orgMember.delete({ where: { id: memberId } });
      return { ok: true };
    });
  }

  private async assertAdmin(orgId: string, user: AuthUser) {
    const roles = await this.tenancy.rolesIn(orgId, user.sub);
    if (!roles.some((r) => ADMIN_ROLES.includes(r as never))) {
      throw new ForbiddenException('Requiere el rol de administrador de la organización');
    }
  }

  private webAppUrl(): string {
    const explicit = this.config.get<string>('WEB_APP_URL');
    if (explicit) return explicit.replace(/\/$/, '');
    const origins = this.config.get<string>('CORS_ORIGINS') ?? 'http://localhost:3000';
    return origins.split(',')[0].trim();
  }
}
