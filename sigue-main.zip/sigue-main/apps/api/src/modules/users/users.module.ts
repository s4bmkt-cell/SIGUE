import { Module } from '@nestjs/common';
import { UsersController } from './users.controller';
import { MembersController, InvitationsController } from './members.controller';
import { MembersService } from './members.service';
import { InvitationsService } from './invitations.service';
import { AuthSharedModule } from '../../common/auth-shared.module';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuditModule } from '../audit/audit.module';
import { BillingModule } from '../billing/billing.module';

@Module({
  imports: [AuthSharedModule, TenancyModule, AuditModule, BillingModule],
  controllers: [UsersController, MembersController, InvitationsController],
  providers: [MembersService, InvitationsService],
  // AuthService lo usa para canjear `inviteCode` al registrar la cuenta.
  exports: [InvitationsService],
})
export class UsersModule {}
