import { BadRequestException, ConflictException, ForbiddenException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { MembersService } from './members.service';
import { PrismaService } from '../../prisma/prisma.service';
import { TenancyService } from '../../tenancy/tenancy.service';
import { InvitationsService } from './invitations.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { UsageService } from '../billing/usage.service';

const admin: AuthUser = {
  sub: 'u-admin',
  email: 'admin@org.mx',
  name: 'Admin',
  roles: ['admin_org'],
  orgId: 'o1',
};

function build(opts: { roles?: string[]; member?: Record<string, unknown> | null } = {}) {
  const member = opts.member === undefined ? null : opts.member;

  const tx = {
    $executeRaw: jest.fn().mockResolvedValue(undefined),
    // La organización se lee dentro de la transacción: `Organization` tiene RLS y
    // necesita `app.org_id` fijado, como el resto de tablas del inquilino.
    organization: { findUnique: jest.fn().mockResolvedValue({ id: 'o1', name: 'Org' }) },
    orgMember: {
      findUnique: jest.fn().mockResolvedValue(member),
      findFirst: jest.fn().mockResolvedValue(member),
      findMany: jest.fn().mockResolvedValue([]),
      count: jest.fn().mockResolvedValue(1),
      create: jest.fn().mockResolvedValue({}),
      update: jest.fn().mockResolvedValue({}),
      delete: jest.fn().mockResolvedValue({}),
    },
    invitation: {
      findFirst: jest.fn().mockResolvedValue(null),
      findMany: jest.fn().mockResolvedValue([]),
      count: jest.fn().mockResolvedValue(0),
      create: jest.fn().mockResolvedValue({ id: 'i1', email: 'x@org.mx', role: 'colaborador', status: 'PENDING', expiresAt: new Date() }),
      update: jest.fn().mockResolvedValue({}),
    },
  };

  const prisma = {
    $transaction: jest.fn(async (fn: (client: unknown) => Promise<unknown>) => fn(tx)),
    organization: { findUnique: jest.fn().mockResolvedValue({ id: 'o1', name: 'Org', planCode: 'PROFESSIONAL' }) },
    user: { findUnique: jest.fn().mockResolvedValue(null) },
  } as unknown as PrismaService;

  const tenancy = {
    rolesIn: jest.fn().mockResolvedValue(opts.roles ?? ['admin_org']),
  } as unknown as TenancyService;

  const invitations = {
    signInviteToken: jest.fn().mockReturnValue('signed'),
  } as unknown as InvitationsService;

  const config = {
    get: jest.fn().mockReturnValue('http://localhost:3000'),
  } as unknown as ConfigService;

  const mailer = { send: jest.fn().mockResolvedValue(undefined) };

  const usage = {
    assertUsersTx: jest.fn().mockResolvedValue(undefined),
  } as unknown as UsageService;

  return {
    service: new MembersService(prisma, tenancy, invitations, usage, config, mailer as never),
    tx,
    mailer,
    usage,
  };
}

describe('MembersService — autorización', () => {
  it('solo los administradores listan miembros', async () => {
    const { service } = build({ roles: ['colaborador'] });
    await expect(service.list('o1', admin)).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('no permite invitar desde una cuenta sin rol de administrador', async () => {
    const { service } = build({ roles: ['resp_sgi'] });
    await expect(
      service.invite('o1', admin, { email: 'nuevo@org.mx', role: 'colaborador' }),
    ).rejects.toBeInstanceOf(ForbiddenException);
  });
});

describe('MembersService — reglas que protegen la administración', () => {
  it('impide que un administrador se quite el rol a sí mismo', async () => {
    const { service } = build({
      member: { id: 'm1', orgId: 'o1', userId: 'u-admin', roles: ['admin_org'], status: 'ACTIVE' },
    });
    await expect(
      service.updateMember('o1', admin, 'm1', { roles: ['colaborador'] }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('impide que un administrador se suspenda a sí mismo', async () => {
    const { service } = build({
      member: { id: 'm1', orgId: 'o1', userId: 'u-admin', roles: ['admin_org'], status: 'ACTIVE' },
    });
    await expect(
      service.updateMember('o1', admin, 'm1', { status: 'SUSPENDED' }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('impide retirar al último administrador activo', async () => {
    const { service } = build({
      member: { id: 'm1', orgId: 'o1', userId: 'u-otro', roles: ['admin_org'], status: 'ACTIVE' },
    });
    await expect(service.removeMember('o1', admin, 'm1')).rejects.toBeInstanceOf(
      BadRequestException,
    );
  });

  it('no permite retirarse a uno mismo', async () => {
    const { service } = build({
      member: { id: 'm1', orgId: 'o1', userId: 'u-admin', roles: ['admin_org'], status: 'ACTIVE' },
    });
    await expect(service.removeMember('o1', admin, 'm1')).rejects.toBeInstanceOf(
      BadRequestException,
    );
  });
});

describe('MembersService — invitaciones', () => {
  it('rechaza invitar un correo que ya es miembro activo', async () => {
    const { service } = build();
    const prisma = (service as unknown as { prisma: PrismaService }).prisma;
    (prisma.user.findUnique as jest.Mock).mockResolvedValue({ id: 'u-existente' });
    const tx = {
      $executeRaw: jest.fn(),
      organization: { findUnique: jest.fn().mockResolvedValue({ id: 'o1', name: 'Org' }) },
      orgMember: { findUnique: jest.fn().mockResolvedValue({ status: 'ACTIVE' }) },
      invitation: { findFirst: jest.fn() },
    };
    (prisma.$transaction as jest.Mock).mockImplementation(
      async (fn: (client: unknown) => Promise<unknown>) => fn(tx),
    );

    await expect(
      service.invite('o1', admin, { email: 'ya@org.mx', role: 'colaborador' }),
    ).rejects.toBeInstanceOf(ConflictException);
  });

  it('rechaza una segunda invitación pendiente al mismo correo', async () => {
    const { service } = build();
    const prisma = (service as unknown as { prisma: PrismaService }).prisma;
    const tx = {
      $executeRaw: jest.fn(),
      organization: { findUnique: jest.fn().mockResolvedValue({ id: 'o1', name: 'Org' }) },
      orgMember: { findUnique: jest.fn().mockResolvedValue(null) },
      invitation: { findFirst: jest.fn().mockResolvedValue({ id: 'pendiente' }) },
    };
    (prisma.$transaction as jest.Mock).mockImplementation(
      async (fn: (client: unknown) => Promise<unknown>) => fn(tx),
    );

    await expect(
      service.invite('o1', admin, { email: 'pendiente@org.mx', role: 'colaborador' }),
    ).rejects.toBeInstanceOf(ConflictException);
  });

  it('envía el correo con el enlace de aceptación', async () => {
    const { service, mailer } = build();
    await service.invite('o1', admin, { email: 'nuevo@org.mx', role: 'colaborador' });

    expect(mailer.send).toHaveBeenCalledWith(
      expect.objectContaining({
        to: 'nuevo@org.mx',
        text: expect.stringContaining('/accept-invitation?token=signed'),
      }),
    );
  });
});
