import { createCipheriv, createDecipheriv, createHash, randomBytes } from 'crypto';

const VERSION = 'v1';
const ALGORITHM = 'aes-256-gcm';

/**
 * Cifra en reposo secretos de un solo uso (hoy: la semilla TOTP de cada usuario).
 *
 * La semilla permite generar códigos válidos indefinidamente, así que no puede
 * quedar en claro en la base: un volcado de `User` bastaría para suplantar a
 * cualquier usuario con MFA activo. Se usa AES-256-GCM (cifrado autenticado: un
 * valor manipulado no descifra, devuelve `null`).
 *
 * La clave se toma de `MFA_ENCRYPTION_KEY` o, si no está definida, se deriva del
 * secreto de acceso con separación de dominio. Nunca se usa el secreto JWT
 * directamente como clave.
 *
 * Formato: `v1:<iv base64>:<tag base64>:<cifrado base64>`. Los valores sin
 * prefijo se consideran legado en claro (se cifran la próxima vez que se guarde
 * el secreto) para no invalidar MFA ya enrolado.
 */
export class SecretBox {
  private readonly key: Buffer;

  constructor(masterSecret: string) {
    if (!masterSecret) throw new Error('SecretBox requiere una clave maestra');
    this.key = createHash('sha256')
      .update(`sigue.mfa.secret-box:v1:${masterSecret}`)
      .digest();
  }

  seal(plain: string): string {
    const iv = randomBytes(12);
    const cipher = createCipheriv(ALGORITHM, this.key, iv);
    const encrypted = Buffer.concat([cipher.update(plain, 'utf8'), cipher.final()]);
    return [
      VERSION,
      iv.toString('base64'),
      cipher.getAuthTag().toString('base64'),
      encrypted.toString('base64'),
    ].join(':');
  }

  /** Descifra; devuelve `null` si el valor fue alterado o la clave no coincide. */
  open(value: string): string | null {
    if (!value.startsWith(`${VERSION}:`)) return value;
    const [, iv, tag, data] = value.split(':');
    if (!iv || !tag || !data) return null;
    try {
      const decipher = createDecipheriv(ALGORITHM, this.key, Buffer.from(iv, 'base64'));
      decipher.setAuthTag(Buffer.from(tag, 'base64'));
      const plain = Buffer.concat([
        decipher.update(Buffer.from(data, 'base64')),
        decipher.final(),
      ]);
      return plain.toString('utf8');
    } catch {
      return null;
    }
  }
}
