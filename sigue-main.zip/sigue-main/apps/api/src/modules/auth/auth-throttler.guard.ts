import { Injectable } from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';

/**
 * Límite de intentos de autenticación por IP **y** por cuenta.
 *
 * El tracker por defecto es solo la IP, y eso tiene dos problemas en una app
 * multiinquilino: un mismo usuario detrás de NAT comparte cuota con el resto de
 * la oficina, y las pruebas E2E que entran con cuentas distintas desde la misma
 * IP agotaban el límite entre sí. Al añadir el identificador de la cuenta, cada
 * cuenta tiene su propio contador, pero un ataque por fuerza bruta contra una
 * sola cuenta desde una IP sigue limitado a 5 intentos por minuto.
 */
@Injectable()
export class AuthThrottlerGuard extends ThrottlerGuard {
  protected async getTracker(req: Record<string, unknown>): Promise<string> {
    const ip = await super.getTracker(req);
    const body = (req.body ?? {}) as { email?: unknown };
    // El correo se normaliza igual que en el login para que no baste con
    // cambiar mayúsculas y así esquivar el contador.
    const email =
      typeof body.email === 'string' ? body.email.trim().toLowerCase() : '';
    return email ? `${ip}:${email}` : ip;
  }
}
