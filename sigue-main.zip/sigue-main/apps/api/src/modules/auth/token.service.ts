import { randomUUID } from 'crypto';
import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { authenticator } from 'otplib';
import { AuthUser } from '../../common/decorators/current-user.decorator';

export interface RefreshTokenRecord {
  jti: string;
  userId: string;
  expiresAt: string;
  revoked: boolean;
}

/**
 * Gestión de tokens:
 *  - access token JWT corto (10m) firmado con JWT_ACCESS_SECRET
 *  - refresh token rotativo con jti único (7d): al usarse se revoca el anterior
 *    y se emite uno nuevo; la reutilización invalida todos los del usuario.
 *  - MFA TOTP: generación de secreto y verificación (otplib)
 * Los registros de refresh se persisten en PostgreSQL (RefreshToken table).
 */
@Injectable()
export class TokenService {
  constructor(
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
  ) {}

  signAccess(user: AuthUser): Promise<string> {
    return this.jwt.signAsync(
      {
        sub: user.sub,
        email: user.email,
        name: user.name,
        roles: user.roles,
        orgId: user.orgId,
        platform: user.platform ?? false,
      },
      { secret: this.config.get<string>('JWT_ACCESS_SECRET'), expiresIn: this.config.get('JWT_ACCESS_TTL') },
    );
  }

  async issueRefresh(userId: string): Promise<{ token: string; jti: string }> {
    const jti = randomUUID();
    const token = await this.jwt.signAsync(
      { sub: userId, type: 'refresh', jti },
      { secret: this.config.get<string>('JWT_REFRESH_SECRET'), expiresIn: this.config.get('JWT_REFRESH_TTL') },
    );
    return { token, jti };
  }

  /**
   * Valida un refresh token sin rotarlo (verificación de firma + estado).
   * La rotación real (revocar el anterior, emitir el nuevo) la coordina el
   * AuthService con la BD vía el jti.
   */
  async verifyRefresh(token: string): Promise<{ sub: string; jti: string }> {
    const payload = await this.jwt.verifyAsync(token, {
      secret: this.config.get<string>('JWT_REFRESH_SECRET'),
    });
    return { sub: payload.sub as string, jti: payload.jti as string };
  }

  /**
   * Lógica de rotación con detección de reutilización.
   * Devuelve el nuevo token y su jti; el registro anterior se revoca en BD.
   * Si el token ya está revocado → reutilización: se revocan todos los del usuario.
   */
  async rotateRefresh(token: string, userId: string): Promise<{ token: string; jti: string }> {
    const payload = this.jwt.decode(token) as { sub?: string; jti?: string } | null;
    if (payload?.sub !== userId) {
      throw new Error('refresh_token_reuse_detected');
    }
    // La verificación de estado (revocado/activo) y la revocación masiva se hacen en
    // el AuthService con la BD; aquí solo generamos el nuevo token.
    const next = await this.issueRefresh(userId);
    return next;
  }

  /** MFA TOTP */
  generateMfaSecret(
    email: string,
    issuer = this.config.get<string>('MFA_ISSUER') ?? 'SIGUE',
  ): { secret: string; otpauthUrl: string } {
    const secret = authenticator.generateSecret();
    const otpauthUrl = authenticator.keyuri(email, issuer, secret);
    return { secret, otpauthUrl };
  }

  verifyMfa(secret: string, code: string): boolean {
    return authenticator.verify({ token: code, secret });
  }

  /**
   * Desafío MFA: JWT firmado de 5 minutos que sustituye al Map en memoria.
   * Sobrevive a reinicios del proceso y a despliegues con varias réplicas, y
   * no puede falsificarse porque va firmado con el secreto de acceso.
   */
  signMfaChallenge(userId: string): Promise<string> {
    return this.jwt.signAsync(
      { sub: userId, type: 'mfa_challenge' },
      { secret: this.config.get<string>('JWT_ACCESS_SECRET'), expiresIn: '5m' },
    );
  }

  async verifyMfaChallenge(challengeId: string): Promise<string> {
    const payload = await this.jwt.verifyAsync(challengeId, {
      secret: this.config.get<string>('JWT_ACCESS_SECRET'),
    });
    if (payload.type !== 'mfa_challenge' || !payload.sub) {
      throw new Error('mfa_challenge_invalid');
    }
    return payload.sub as string;
  }
}
