import { TokenService } from './token.service';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';

describe('TokenService — MFA TOTP y emisión de refresh tokens', () => {
  const config = new ConfigService({
    JWT_ACCESS_SECRET: 'test-access-secret-abcdefghijklmnopqrstuvwxyz123456',
    JWT_REFRESH_SECRET: 'test-refresh-secret-abcdefghijklmnopqrstuvwxyz123456',
    JWT_ACCESS_TTL: '10m',
    JWT_REFRESH_TTL: '7d',
  });
  const jwt = new JwtService({});
  const svc = new TokenService(jwt, config);

  it('genera y verifica un secreto TOTP', () => {
    const { secret } = svc.generateMfaSecret('user@example.com');
    expect(secret).toBeTruthy();
    expect(svc.verifyMfa(secret, '000000')).toBe(false); // código inválido
  });

  it('emite refresh tokens con jti único', async () => {
    const a = await svc.issueRefresh('u1');
    const b = await svc.issueRefresh('u1');
    expect(a.token).not.toBe(b.token);
    expect(a.jti).not.toBe(b.jti);
    expect(a.jti).toBeTruthy();
  });

  it('verifica un refresh token y devuelve sub y jti', async () => {
    const { token, jti } = await svc.issueRefresh('u2');
    await expect(svc.verifyRefresh(token)).resolves.toEqual(
      expect.objectContaining({ sub: 'u2', jti }),
    );
  });

  it('rota generando un token nuevo con jti distinto', async () => {
    const { token } = await svc.issueRefresh('u3');
    const next = await svc.rotateRefresh(token, 'u3');
    expect(next.token).not.toBe(token);
    expect(next.jti).toBeTruthy();
  });

  it('detecta rotación de token de otro usuario', async () => {
    const { token } = await svc.issueRefresh('u4');
    await expect(svc.rotateRefresh(token, 'otro')).rejects.toThrow('refresh_token_reuse_detected');
  });
});
