import {
  BadRequestException,
  ConflictException,
  Inject,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcryptjs';
import { createHash, randomBytes } from 'crypto';
import * as QRCode from 'qrcode';
import { LoginDto, MfaVerifyDto, RefreshDto, RegisterDto, MfaSetupDto, MfaDisableDto } from './dto/auth.dto';
import { TokenService } from './token.service';
import { SecretBox } from './secret-box';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { AuditService } from '../audit/audit.service';
import { PrismaService } from '../../prisma/prisma.service';
import { MAILER, MailerPort } from '../../common/mailer/mailer.port';
import { InvitationsService } from '../users/invitations.service';
import { parseDuration } from './session-cookie.service';

/** Contexto de red que acompaña a los eventos de identidad. */
export interface AuditContext {
  ip?: string | null;
  userAgent?: string | null;
}

/** Perfil expuesto por `GET /auth/me`: el token no lleva el estado de MFA. */
export interface AuthProfile extends AuthUser {
  mfaEnabled: boolean;
}

@Injectable()
export class AuthService {
  private readonly secrets: SecretBox;

  constructor(
    private readonly token: TokenService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService,
    private readonly audit: AuditService,
    private readonly prisma: PrismaService,
    private readonly invitations: InvitationsService,
    @Inject(MAILER) private readonly mailer: MailerPort,
  ) {
    // Clave dedicada si existe; en desarrollo se deriva del secreto de acceso.
    this.secrets = new SecretBox(
      this.config.get<string>('MFA_ENCRYPTION_KEY') ??
        this.config.get<string>('JWT_ACCESS_SECRET') ??
        'sigue-dev-mfa',
    );
  }

  /** Registro: crea el usuario en PostgreSQL con hash bcrypt. */
  async register(dto: RegisterDto) {
    const email = dto.email.trim().toLowerCase();
    const exists = await this.prisma.user.findUnique({ where: { email } });
    if (exists) throw new ConflictException('El correo ya está registrado');

    // Con `inviteCode` la cuenta nace vinculada a la organización: se valida
    // ANTES de crear el usuario para no dejar cuentas huérfanas si el enlace
    // está manipulado, caducado o ya se usó.
    const invitation = dto.inviteCode
      ? await this.invitations.previewToken(dto.inviteCode, email)
      : null;

    const hash = await bcrypt.hash(dto.password, 10);
    const user = await this.prisma.user.create({
      data: { email, name: dto.name, passwordHash: hash },
    });

    if (invitation && dto.inviteCode) {
      await this.invitations.acceptToken(
        { sub: user.id, email, name: user.name, roles: [], orgId: null },
        dto.inviteCode,
      );
    }

    await this.audit.record({
      orgId: invitation?.orgId ?? null,
      actorId: user.id,
      action: 'auth.register',
      entity: 'users',
      entityId: user.id,
      after: { invitationId: invitation?.invitationId ?? null },
    });

    return {
      ok: true,
      message: invitation
        ? 'Cuenta creada y unida a la organización. Inicia sesión.'
        : 'Usuario registrado. Inicia sesión.',
      joinedOrg: invitation ? { id: invitation.orgId, name: invitation.orgName } : null,
    };
  }

  /** Login: verifica credenciales contra la BD y MFA si está habilitado. */
  async login(dto: LoginDto, context: AuditContext = {}) {
    const user = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (!user?.passwordHash || user.status !== 'ACTIVE') {
      // Se audita el intento aunque el correo no exista: es la única forma de
      // detectar fuerza bruta contra cuentas inexistentes. No se guarda el
      // correo (sería dato personal en la bitácora); el actor queda anónimo.
      await this.audit.record({
        orgId: null,
        actorId: null,
        action: 'auth.login.failed',
        entity: 'users',
        after: { reason: user ? 'user_inactive' : 'unknown_email' },
        ...context,
      });
      throw new UnauthorizedException(
        user ? 'Usuario desactivado' : 'Credenciales inválidas',
      );
    }

    const ok = await bcrypt.compare(dto.password, user.passwordHash);
    if (!ok) {
      await this.audit.record({
        orgId: null,
        actorId: user.id,
        action: 'auth.login.failed',
        entity: 'users',
        after: { reason: 'bad_password' },
        ...context,
      });
      throw new UnauthorizedException('Credenciales inválidas');
    }

    if (user.mfaEnabled && this.openSecret(user.mfaSecretEnc)) {
      const challengeId = await this.token.signMfaChallenge(user.id);
      await this.audit.record({
        orgId: null,
        actorId: user.id,
        action: 'auth.login.mfa_challenge',
        ...context,
      });
      return { mfaRequired: true, challengeId };
    }

    await this.prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    return this.issueTokens(user);
  }

  async verifyMfa(dto: MfaVerifyDto): Promise<TokensResponse> {
    let userId: string;
    try {
      userId = await this.token.verifyMfaChallenge(dto.challengeId);
    } catch {
      throw new UnauthorizedException('Desafío MFA inválido o expirado');
    }

    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    const secret = this.openSecret(user?.mfaSecretEnc);
    if (!user || !secret) throw new UnauthorizedException('Usuario no encontrado');

    if (!this.token.verifyMfa(secret, dto.code)) {
      throw new UnauthorizedException('Código MFA incorrecto');
    }
    await this.prisma.user.update({ where: { id: user.id }, data: { lastLoginAt: new Date() } });
    return this.issueTokens(user);
  }

  /**
   * Rotación del refresh token.
   *
   * La revocación del token presentado es un UPDATE condicional (`revoked: false`):
   * si dos peticiones llegan a la vez con el mismo token, solo una consigue
   * revocarlo y la otra se interpreta como reutilización. Así no hay carrera.
   */
  async refresh(dto: RefreshDto) {
    try {
      if (!dto.refreshToken) throw new Error('refresh_token_invalid');
      const { sub, jti } = await this.token.verifyRefresh(dto.refreshToken);
      const user = await this.prisma.user.findUnique({ where: { id: sub } });
      if (!user || user.status !== 'ACTIVE') {
        throw new UnauthorizedException('Usuario no encontrado o desactivado');
      }

      const record = await this.prisma.refreshToken.findUnique({ where: { jti } });
      if (!record || record.userId !== sub) throw new Error('refresh_token_invalid');

      const claimed = await this.prisma.refreshToken.updateMany({
        where: { jti, revoked: false },
        data: { revoked: true, usedAt: new Date() },
      });

      if (claimed.count === 0) {
        // Reutilización: el token ya se había consumido. Se invalida la sesión completa.
        await this.prisma.refreshToken.updateMany({
          where: { userId: sub, revoked: false },
          data: { revoked: true },
        });
        await this.audit.record({ orgId: null, actorId: sub, action: 'auth.refresh.reuse_detected' });
        throw new Error('refresh_token_reuse_detected');
      }

      const { token, jti: newJti } = await this.token.issueRefresh(sub);
      await this.prisma.refreshToken.create({
        data: { jti: newJti, userId: sub, expiresAt: new Date(Date.now() + this.refreshTtlMs()) },
      });

      const authUser = await this.toAuthUser(user);
      return { accessToken: await this.token.signAccess(authUser), refreshToken: token };
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'invalid';
      if (msg === 'refresh_token_reuse_detected') {
        throw new UnauthorizedException('Reutilización de refresh token detectada. Sesión invalidada.');
      }
      throw new UnauthorizedException('Refresh token inválido o expirado');
    }
  }

  /** Cierra la sesión actual: revoca el refresh token presentado (si sigue vigente). */
  async logout(refreshToken: string | undefined) {
    if (refreshToken) {
      try {
        const { sub, jti } = await this.token.verifyRefresh(refreshToken);
        await this.prisma.refreshToken.updateMany({
          where: { jti, userId: sub, revoked: false },
          data: { revoked: true, usedAt: new Date() },
        });
        await this.audit.record({ orgId: null, actorId: sub, action: 'auth.logout' });
      } catch {
        // Token ilegible o ya expirado: el logout igualmente limpia las cookies.
      }
    }
    return { ok: true };
  }

  /** Cierra todas las sesiones del usuario autenticado. */
  async logoutAll(user: AuthUser) {
    await this.prisma.refreshToken.updateMany({
      where: { userId: user.sub, revoked: false },
      data: { revoked: true },
    });
    await this.audit.record({ orgId: user.orgId, actorId: user.sub, action: 'auth.logout_all' });
    return { ok: true };
  }

  /**
   * Solicita recuperación de contraseña. Responde igual exista o no el correo
   * (evita enumerar usuarios). El token crudo solo viaja al correo; en BD queda el hash.
   */
  async forgotPassword(email: string) {
    const user = await this.prisma.user.findUnique({ where: { email } });
    if (user) {
      const raw = randomBytes(32).toString('hex');
      await this.prisma.passwordResetToken.create({
        data: {
          userId: user.id,
          tokenHash: sha256(raw),
          expiresAt: new Date(Date.now() + 60 * 60 * 1000),
        },
      });
      const url = `${this.webAppUrl()}/reset-password?token=${raw}`;
      await this.mailer.send({
        to: user.email,
        subject: 'Restablece tu contraseña de SIGN',
        text: `Recibimos una solicitud para restablecer tu contraseña.\n\nAbre este enlace (válido 1 hora):\n${url}\n\nSi no fuiste tú, ignora este correo.`,
      });
      await this.audit.record({ orgId: null, actorId: user.id, action: 'auth.password.forgot' });
    }
    return { ok: true, message: 'Si el correo existe, recibirás instrucciones.' };
  }

  /** Restablece la contraseña usando el token de un solo uso. */
  async resetPassword(token: string, password: string) {
    const record = await this.prisma.passwordResetToken.findUnique({
      where: { tokenHash: sha256(token) },
    });
    if (!record || record.usedAt || record.expiresAt.getTime() < Date.now()) {
      throw new UnauthorizedException('El enlace de recuperación es inválido o expiró');
    }

    const hash = await bcrypt.hash(password, 10);
    await this.prisma.$transaction([
      this.prisma.user.update({ where: { id: record.userId }, data: { passwordHash: hash } }),
      this.prisma.passwordResetToken.update({
        where: { id: record.id },
        data: { usedAt: new Date() },
      }),
      // Cambiar la contraseña cierra todas las sesiones abiertas.
      this.prisma.refreshToken.updateMany({
        where: { userId: record.userId, revoked: false },
        data: { revoked: true },
      }),
    ]);

    await this.audit.record({ orgId: null, actorId: record.userId, action: 'auth.password.reset' });
    return { ok: true, message: 'Contraseña actualizada. Inicia sesión de nuevo.' };
  }

  /**
   * Perfil del usuario autenticado.
   *
   * `mfaEnabled` no viaja en el token (añadirlo invalidaría todos los tokens
   * emitidos), así que se lee de la base en cada llamada: es una sola consulta
   * y permite que la UI muestre el estado real.
   */
  async profile(user: AuthUser): Promise<AuthProfile> {
    const rec = await this.prisma.user.findUnique({
      where: { id: user.sub },
      select: { mfaEnabled: true },
    });
    return { ...user, mfaEnabled: rec?.mfaEnabled ?? false };
  }

  /**
   * Inicia el registro de un autenticador TOTP.
   *
   * El secreto se persiste **cifrado** y con `mfaEnabled = false` (estado
   * pendiente): la confirmación debe verificar el mismo secreto que se mostró
   * en el QR. Sin persistirlo, cada llamada generaba una semilla nueva y ningún
   * código podía coincidir.
   */
  async beginMfaEnrollment(user: AuthUser) {
    const rec = await this.prisma.user.findUnique({ where: { id: user.sub } });
    if (!rec) throw new UnauthorizedException('Usuario no encontrado');
    if (rec.mfaEnabled) {
      throw new ConflictException('El MFA ya está activado en esta cuenta');
    }

    const { secret, otpauthUrl } = this.token.generateMfaSecret(user.email);
    await this.prisma.user.update({
      where: { id: user.sub },
      data: { mfaSecretEnc: this.secrets.seal(secret), mfaEnabled: false },
    });

    // El QR evita teclear la semilla; el secreto en texto queda como respaldo
    // para autenticadores que no pueden escanear.
    const qrDataUrl = await QRCode.toDataURL(otpauthUrl, { margin: 1, width: 232 });
    return {
      secret,
      otpauthUrl,
      qrDataUrl,
      message: 'Escanea el código con tu app de autenticación y confirma con un código de 6 dígitos',
    };
  }

  /** Confirma el registro verificando el código contra la semilla pendiente. */
  async confirmMfaEnrollment(user: AuthUser, dto: MfaSetupDto) {
    const rec = await this.prisma.user.findUnique({ where: { id: user.sub } });
    if (!rec) throw new UnauthorizedException('Usuario no encontrado');
    if (rec.mfaEnabled) {
      throw new ConflictException('El MFA ya está activado en esta cuenta');
    }

    const secret = this.openSecret(rec.mfaSecretEnc);
    if (!secret) {
      throw new UnauthorizedException('No hay un registro MFA pendiente. Genera el código QR de nuevo.');
    }
    if (!this.token.verifyMfa(secret, dto.code)) {
      throw new UnauthorizedException('Código MFA incorrecto');
    }

    await this.prisma.user.update({
      where: { id: user.sub },
      data: { mfaEnabled: true },
    });
    await this.audit.record({ orgId: user.orgId, actorId: user.sub, action: 'auth.mfa.enabled' });
    return { ok: true, mfaEnabled: true, message: 'MFA activado correctamente' };
  }

  /**
   * Desactiva el MFA. Exige un código vigente: un access token robado no basta
   * para quitar el segundo factor de la cuenta.
   */
  async disableMfa(user: AuthUser, dto: MfaDisableDto) {
    const rec = await this.prisma.user.findUnique({ where: { id: user.sub } });
    if (!rec) throw new UnauthorizedException('Usuario no encontrado');
    if (!rec.mfaEnabled) throw new BadRequestException('El MFA no está activado');

    const secret = this.openSecret(rec.mfaSecretEnc);
    if (!secret || !this.token.verifyMfa(secret, dto.code)) {
      throw new UnauthorizedException('Código MFA incorrecto');
    }

    await this.prisma.user.update({
      where: { id: user.sub },
      data: { mfaEnabled: false, mfaSecretEnc: null },
    });
    await this.audit.record({ orgId: user.orgId, actorId: user.sub, action: 'auth.mfa.disabled' });
    return { ok: true, mfaEnabled: false, message: 'MFA desactivado' };
  }

  /** Descifra la semilla persistida; `null` si falta o fue manipulada. */
  private openSecret(value: string | null | undefined): string | null {
    if (!value) return null;
    return this.secrets.open(value);
  }

  /** Resuelve los roles del usuario en una organización (RBAC) para el token. */
  async resolveRoles(userId: string): Promise<string[]> {
    const rows = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.user_id', ${userId}, true)`;
      return tx.$queryRaw`
        SELECT unnest(m."roles") AS role FROM "OrgMember" m
        WHERE m."userId" = ${userId} AND m."status" = 'ACTIVE'
      ` as unknown as { role: string }[];
    });
    return [...new Set(rows.map((r) => r.role))];
  }

  /** Duración del refresh token en ms, según configuración. */
  refreshTtlMs(): number {
    return parseDuration(this.config.get<string>('JWT_REFRESH_TTL') ?? '7d');
  }

  private async issueTokens(user: {
    id: string;
    email: string;
    name: string;
  }): Promise<TokensResponse> {
    const authUser = await this.toAuthUser(user);
    const access = await this.token.signAccess(authUser);
    const { token, jti } = await this.token.issueRefresh(user.id);
    await this.prisma.refreshToken.create({
      data: { jti, userId: user.id, expiresAt: new Date(Date.now() + this.refreshTtlMs()) },
    });
    await this.audit.record({ orgId: authUser.orgId, actorId: user.id, action: 'auth.login.success' });
    return { accessToken: access, refreshToken: token };
  }

  private async toAuthUser(u: { id: string; email: string; name: string }): Promise<AuthUser> {
    const roles = await this.resolveRoles(u.id);
    // orgId: primera organización activa del usuario. El contexto real por petición
    // lo resuelve el OrgMembershipGuard a partir del :orgId de la ruta.
    const first = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.user_id', ${u.id}, true)`;
      return tx.$queryRaw`
        SELECT m."orgId" FROM "OrgMember" m
        WHERE m."userId" = ${u.id} AND m."status" = 'ACTIVE'
        ORDER BY m."createdAt" ASC LIMIT 1
      ` as unknown as { orgId: string }[];
    });
    // `User` no lleva RLS (se protege por privilegios), así que la lectura del
    // flag de plataforma no necesita contexto. Se consulta en cada emisión para
    // que una revocación surta efecto en el siguiente refresh, sin esperar a
    // que caduque el access token.
    const admin = await this.prisma.user.findUnique({
      where: { id: u.id },
      select: { isPlatformAdmin: true },
    });
    return {
      sub: u.id,
      email: u.email,
      name: u.name,
      roles,
      orgId: first[0]?.orgId ?? null,
      platform: admin?.isPlatformAdmin ?? false,
    };
  }

  private webAppUrl(): string {
    const explicit = this.config.get<string>('WEB_APP_URL');
    if (explicit) return explicit.replace(/\/$/, '');
    const origins = this.config.get<string>('CORS_ORIGINS') ?? 'http://localhost:3000';
    return origins.split(',')[0].trim();
  }
}

function sha256(value: string): string {
  return createHash('sha256').update(value).digest('hex');
}

interface TokensResponse {
  accessToken: string;
  refreshToken: string;
}
export type { TokensResponse };
