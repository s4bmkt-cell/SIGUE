import { SecretBox } from './secret-box';

describe('SecretBox — cifrado de la semilla TOTP en reposo', () => {
  const box = new SecretBox('clave-maestra-de-prueba-con-mas-de-32-caracteres');

  it('descifra lo que cifra', () => {
    const secret = 'JBSWY3DPEHPK3PXP';
    const sealed = box.seal(secret);
    expect(sealed).not.toContain(secret);
    expect(box.open(sealed)).toBe(secret);
  });

  it('usa un IV distinto en cada cifrado', () => {
    expect(box.seal('mismo-valor')).not.toBe(box.seal('mismo-valor'));
  });

  it('detecta un valor manipulado', () => {
    const sealed = box.seal('JBSWY3DPEHPK3PXP');
    const parts = sealed.split(':');
    // Cambia un byte del bloque cifrado conservando el formato.
    parts[3] = Buffer.from('otro-contenido').toString('base64');
    expect(box.open(parts.join(':'))).toBeNull();
  });

  it('no descifra con otra clave', () => {
    const other = new SecretBox('otra-clave-maestra-igualmente-larga-para-la-prueba');
    expect(other.open(box.seal('JBSWY3DPEHPK3PXP'))).toBeNull();
  });

  it('admite el formato legado en claro', () => {
    // Semillas guardadas antes del cifrado: se leen tal cual y se cifran al
    // volver a guardarlas.
    expect(box.open('JBSWY3DPEHPK3PXP')).toBe('JBSWY3DPEHPK3PXP');
  });
});
