import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Post,
  Req,
  Res,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { Throttle } from '@nestjs/throttler';
import type { Request, Response } from 'express';
import { AuthService, type AuditContext } from './auth.service';
import {
  ForgotPasswordDto,
  LoginDto,
  MfaDisableDto,
  MfaSetupDto,
  MfaVerifyDto,
  RefreshDto,
  RegisterDto,
  ResetPasswordDto,
} from './dto/auth.dto';
import { Public } from '../../common/decorators/public.decorator';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { AuthThrottlerGuard } from './auth-throttler.guard';
import { REFRESH_COOKIE, SessionCookieService } from './session-cookie.service';

/**
 * Rutas de identidad.
 *
 * Los tokens viajan en cookies httpOnly (además de devolverse en el cuerpo para
 * clientes no web). `refresh` acepta el token por cookie o por cuerpo: la cookie
 * es el camino de la app; el cuerpo mantiene compatibles a los clientes de API.
 */
@ApiTags('auth')
@Controller({ path: 'auth', version: '1' })
export class AuthController {
  constructor(
    private readonly auth: AuthService,
    private readonly cookies: SessionCookieService,
  ) {}

  @Public()
  @ApiEndpoint('Registra un usuario (opcionalmente con invitación)', { status: 201, tenant: false, auth: false })
  @Post('register')
  register(@Body() dto: RegisterDto) {
    return this.auth.register(dto);
  }

  @Public()
  @UseGuards(AuthThrottlerGuard)
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @ApiEndpoint('Inicia sesión; devuelve tokens o un desafío MFA', { status: 200, tenant: false })
  @Post('login')
  @HttpCode(HttpStatus.OK)
  async login(@Body() dto: LoginDto, @Req() req: Request, @Res({ passthrough: true }) res: Response) {
    const result = await this.auth.login(dto, requestContext(req));
    if ('accessToken' in result) this.cookies.set(res, result, this.auth.refreshTtlMs());
    return result;
  }

  @Public()
  @UseGuards(AuthThrottlerGuard)
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @ApiEndpoint('Verifica el código MFA y emite los tokens', { status: 200, tenant: false })
  @Post('mfa/verify')
  @HttpCode(HttpStatus.OK)
  async verifyMfa(@Body() dto: MfaVerifyDto, @Res({ passthrough: true }) res: Response) {
    const tokens = await this.auth.verifyMfa(dto);
    this.cookies.set(res, tokens, this.auth.refreshTtlMs());
    return tokens;
  }

  @Public()
  @ApiEndpoint('Rota el refresh token y emite un access token nuevo', { status: 200, tenant: false })
  @Post('refresh')
  @HttpCode(HttpStatus.OK)
  async refresh(
    @Body() dto: RefreshDto,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    const token = dto.refreshToken || readCookie(req, REFRESH_COOKIE);
    try {
      const tokens = await this.auth.refresh({ refreshToken: token ?? '' });
      this.cookies.set(res, tokens, this.auth.refreshTtlMs());
      return tokens;
    } catch (e) {
      // Un refresh inválido deja al cliente sin sesión: borrar las cookies evita
      // que la pista siga diciendo "hay sesión" y que el navegador reintente en
      // cada petición.
      this.cookies.clear(res);
      throw e;
    }
  }

  @Public()
  @ApiEndpoint('Cierra la sesión actual y limpia las cookies', { status: 200, tenant: false, auth: false })
  @Post('logout')
  @HttpCode(HttpStatus.OK)
  async logout(
    @Body() dto: RefreshDto,
    @Req() req: Request,
    @Res({ passthrough: true }) res: Response,
  ) {
    // El navegador manda el refresh en cookie httpOnly; los clientes de API que
    // no manejan cookies pueden enviarlo en el cuerpo, igual que en `/refresh`.
    const result = await this.auth.logout(dto.refreshToken || readCookie(req, REFRESH_COOKIE));
    this.cookies.clear(res);
    return result;
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @ApiEndpoint('Cierra todas las sesiones del usuario', { status: 200, tenant: false })
  @Post('logout-all')
  @HttpCode(HttpStatus.OK)
  async logoutAll(@CurrentUser() user: AuthUser, @Res({ passthrough: true }) res: Response) {
    const result = await this.auth.logoutAll(user);
    this.cookies.clear(res);
    return result;
  }

  @Public()
  @UseGuards(AuthThrottlerGuard)
  @Throttle({ default: { limit: 3, ttl: 60_000 } })
  @ApiEndpoint('Envía instrucciones de recuperación (respuesta neutra)', { status: 200, tenant: false, auth: false })
  @Post('password/forgot')
  @HttpCode(HttpStatus.OK)
  forgotPassword(@Body() dto: ForgotPasswordDto) {
    return this.auth.forgotPassword(dto.email);
  }

  @Public()
  @UseGuards(AuthThrottlerGuard)
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @ApiEndpoint('Restablece la contraseña con el token recibido', { status: 200, tenant: false, auth: false })
  @Post('password/reset')
  @HttpCode(HttpStatus.OK)
  resetPassword(@Body() dto: ResetPasswordDto) {
    return this.auth.resetPassword(dto.token, dto.password);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @ApiEndpoint('Perfil del usuario autenticado, incluido el estado de MFA', { status: 200, tenant: false })
  @Get('me')
  me(@CurrentUser() user: AuthUser) {
    return this.auth.profile(user);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard)
  @ApiEndpoint('Genera la semilla TOTP pendiente y su código QR', { status: 200, tenant: false })
  @Get('mfa/setup')
  mfaSetup(@CurrentUser() user: AuthUser) {
    return this.auth.beginMfaEnrollment(user);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, AuthThrottlerGuard)
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @ApiEndpoint('Confirma el código y activa el MFA', { status: 200, tenant: false })
  @Post('mfa/setup')
  @HttpCode(HttpStatus.OK)
  confirmMfa(@CurrentUser() user: AuthUser, @Body() dto: MfaSetupDto) {
    return this.auth.confirmMfaEnrollment(user, dto);
  }

  @ApiBearerAuth()
  @UseGuards(JwtAuthGuard, AuthThrottlerGuard)
  @Throttle({ default: { limit: 5, ttl: 60_000 } })
  @ApiEndpoint('Desactiva el MFA verificando un código vigente', { status: 200, tenant: false })
  @Delete('mfa')
  @HttpCode(HttpStatus.OK)
  disableMfa(@CurrentUser() user: AuthUser, @Body() dto: MfaDisableDto) {
    return this.auth.disableMfa(user, dto);
  }
}

function readCookie(req: Request, name: string): string | undefined {
  const cookies = (req as Request & { cookies?: Record<string, string> }).cookies;
  return cookies?.[name];
}

/** Datos de red para la bitácora. */
function requestContext(req: Request): AuditContext {
  return {
    ip: req.ip ?? null,
    userAgent: (req.headers['user-agent'] as string | undefined) ?? null,
  };
}
