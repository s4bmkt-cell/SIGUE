import { ConfigService } from '@nestjs/config';
import { authenticator } from 'otplib';
import { AuthService } from './auth.service';
import { TokenService } from './token.service';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';

const user: AuthUser = {
  sub: 'u1',
  email: 'mariana.torres@org.mx',
  name: 'Mariana Torres',
  roles: ['admin_org'],
  orgId: 'org-ejemplo',
};

/**
 * Regresión del fallo de activación: la confirmación debe verificar el código
 * contra la MISMA semilla que se mostró en el QR. Antes se generaba una nueva
 * en cada `GET`, así que ningún código podía coincidir y además la semilla
 * quedaba en claro en la base.
 */
describe('AuthService — enrolamiento MFA', () => {
  function build() {
    const config = new ConfigService({
      JWT_ACCESS_SECRET: 'test-access-secret-abcdefghijklmnopqrstuvwxyz123456',
      JWT_REFRESH_SECRET: 'test-refresh-secret-abcdefghijklmnopqrstuvwxyz123456',
      MFA_ISSUER: 'SIGUE-test',
    });

    const stored: { mfaSecretEnc: string | null; mfaEnabled: boolean } = {
      mfaSecretEnc: null,
      mfaEnabled: false,
    };

    const prisma = {
      user: {
        findUnique: jest.fn(async () => ({ id: user.sub, ...stored })),
        update: jest.fn(async ({ data }: { data: Partial<typeof stored> }) => {
          Object.assign(stored, data);
          return { id: user.sub, ...stored };
        }),
      },
    } as unknown as PrismaService;

    const audit = { record: jest.fn().mockResolvedValue(undefined) };

    const service = new AuthService(
      new TokenService(new JwtService({}), config),
      new JwtService({}),
      config,
      audit as never,
      prisma,
      {} as never,
      { send: jest.fn() } as never,
    );

    return { service, stored, audit };
  }

  it('persiste la semilla cifrada y la misma sirve para confirmar', async () => {
    const { service, stored } = build();

    const enrollment = await service.beginMfaEnrollment(user);
    expect(stored.mfaEnabled).toBe(false);
    expect(stored.mfaSecretEnc).toContain('v1:');
    expect(stored.mfaSecretEnc).not.toContain(enrollment.secret);
    expect(enrollment.qrDataUrl.startsWith('data:image/png;base64,')).toBe(true);
    expect(enrollment.otpauthUrl).toContain('issuer=SIGUE-test');

    const code = authenticator.generate(enrollment.secret);
    await expect(service.confirmMfaEnrollment(user, { code })).resolves.toEqual(
      expect.objectContaining({ mfaEnabled: true }),
    );
    expect(stored.mfaEnabled).toBe(true);
  });

  it('un nuevo intento de registro sustituye la semilla pendiente anterior', async () => {
    const { service } = build();
    const first = await service.beginMfaEnrollment(user);
    const second = await service.beginMfaEnrollment(user);

    expect(second.secret).not.toBe(first.secret);
    // Solo el QR más reciente activa: volver a pedirlo invalida el anterior
    // (por si el primero se compartió por error).
    await expect(
      service.confirmMfaEnrollment(user, { code: authenticator.generate(first.secret) }),
    ).rejects.toThrow('Código MFA incorrecto');
    await expect(
      service.confirmMfaEnrollment(user, { code: authenticator.generate(second.secret) }),
    ).resolves.toBeTruthy();
  });

  it('rechaza un código incorrecto sin activar el MFA', async () => {
    const { service, stored } = build();
    await service.beginMfaEnrollment(user);
    await expect(
      service.confirmMfaEnrollment(user, { code: '000000' }),
    ).rejects.toThrow('Código MFA incorrecto');
    expect(stored.mfaEnabled).toBe(false);
  });

  it('desactiva el MFA solo con un código vigente', async () => {
    const { service, stored, audit } = build();
    const enrollment = await service.beginMfaEnrollment(user);
    const code = authenticator.generate(enrollment.secret);
    await service.confirmMfaEnrollment(user, { code });

    await expect(service.disableMfa(user, { code: '000000' })).rejects.toThrow(
      'Código MFA incorrecto',
    );
    // El generador puede repetir el mismo código dentro de la ventana de 30 s:
    // se acepta cualquiera de los dos resultados de la verificación real.
    const fresh = authenticator.generate(enrollment.secret);
    await expect(service.disableMfa(user, { code: fresh })).resolves.toEqual(
      expect.objectContaining({ mfaEnabled: false }),
    );
    expect(stored.mfaEnabled).toBe(false);
    expect(stored.mfaSecretEnc).toBeNull();
    expect(audit.record).toHaveBeenCalledWith(
      expect.objectContaining({ action: 'auth.mfa.disabled' }),
    );
  });

  it('no deja activar MFA dos veces sobre la misma cuenta', async () => {
    const { service } = build();
    const enrollment = await service.beginMfaEnrollment(user);
    await service.confirmMfaEnrollment(user, { code: authenticator.generate(enrollment.secret) });
    await expect(service.beginMfaEnrollment(user)).rejects.toThrow('ya está activado');
  });
});
