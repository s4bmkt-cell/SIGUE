import { Module } from '@nestjs/common';
import { ThrottlerModule } from '@nestjs/throttler';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { TokenService } from './token.service';
import { SessionCookieService } from './session-cookie.service';
import { AuditModule } from '../audit/audit.module';
import { UsersModule } from '../users/users.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [
    AuthSharedModule,
    AuditModule,
    // Registro con invitación: el código se canjea contra UsersModule.
    UsersModule,
    // Límite de intentos por IP para login/MFA/recuperación (anti fuerza bruta).
    // En las pruebas se desactiva: la suite de integración hace decenas de
    // inicios de sesión desde la misma IP y agotaría la cuota de un minuto.
    ThrottlerModule.forRoot([
      { ttl: 60_000, limit: 20, skipIf: () => process.env.NODE_ENV === 'test' },
    ]),
  ],
  providers: [AuthService, TokenService, SessionCookieService],
  controllers: [AuthController],
  exports: [TokenService],
})
export class AuthModule {}
