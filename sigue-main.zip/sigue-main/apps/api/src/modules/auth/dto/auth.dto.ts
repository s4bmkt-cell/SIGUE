import { IsEmail, IsOptional, IsString, Length } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class LoginDto {
  @ApiProperty({ example: 'mariana.torres@org.mx' })
  @IsEmail()
  email!: string;

  @ApiProperty({ example: 'secret-password' })
  @IsString()
  @Length(8, 128)
  password!: string;
}

export class MfaVerifyDto {
  @ApiProperty({ description: 'Código TOTP de 6 dígitos' })
  @IsString()
  @Length(6, 6)
  code!: string;

  @ApiProperty({ description: 'ID del desafío MFA iniciado en el login' })
  @IsString()
  challengeId!: string;
}

export class RefreshDto {
  @ApiProperty({
    required: false,
    description: 'Refresh token. Si se omite, se toma de la cookie httpOnly.',
  })
  @IsOptional()
  @IsString()
  refreshToken?: string;
}

export class RegisterDto {
  @ApiProperty({ example: 'Mariana Torres' })
  @IsString()
  @Length(2, 120)
  name!: string;

  @ApiProperty({ example: 'mariana.torres@org.mx' })
  @IsEmail()
  email!: string;

  @ApiProperty()
  @IsString()
  @Length(8, 128)
  password!: string;

  @ApiProperty({ required: false, description: 'Código de invitación (opcional en Iteración 0)' })
  @IsOptional()
  @IsString()
  inviteCode?: string;
}

export class MfaSetupDto {
  @ApiProperty({ description: 'Código TOTP para confirmar el registro del autenticador' })
  @IsString()
  @Length(6, 6)
  code!: string;
}

export class MfaDisableDto {
  @ApiProperty({ description: 'Código TOTP vigente; impide desactivar el MFA con solo el access token' })
  @IsString()
  @Length(6, 6)
  code!: string;
}

export class ForgotPasswordDto {
  @ApiProperty({ example: 'mariana.torres@org.mx' })
  @IsEmail()
  email!: string;
}

export class ResetPasswordDto {
  @ApiProperty({ description: 'Token recibido por correo' })
  @IsString()
  @Length(32, 128)
  token!: string;

  @ApiProperty({ description: 'Contraseña nueva' })
  @IsString()
  @Length(8, 128)
  password!: string;
}
