import { Injectable } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import type { CookieOptions, Response } from 'express';

export const ACCESS_COOKIE = 'sigue_at';
export const REFRESH_COOKIE = 'sigue_rt';
/**
 * Pista legible por JavaScript de que existe una sesión.
 *
 * Los tokens son `httpOnly` a propósito, así que el frontend no puede saber si
 * hay sesión sin llamar a la API. Esta cookie no contiene ningún secreto: solo
 * evita disparar `GET /auth/me` y un refresh condenado a 401 en cada visita
 * anónima (login, invitación, recuperación de contraseña).
 */
export const SESSION_HINT_COOKIE = 'sigue_session';

/**
 * Centraliza el ciclo de vida de las cookies de sesión.
 *
 * Los tokens viven en cookies httpOnly para que JavaScript no pueda leerlos (mitiga
 * XSS). La app web los envía automáticamente al mismo origen gracias al rewrite
 * de Next (`/api/*` → API), por lo que también deben viajar en `SameSite=Lax`.
 * El backend sigue aceptando `Authorization: Bearer` para clientes no web.
 */
@Injectable()
export class SessionCookieService {
  private readonly secure: boolean;

  constructor(private readonly config: ConfigService) {
    this.secure = this.config.get<string>('NODE_ENV') === 'production';
  }

  private base(): CookieOptions {
    return {
      httpOnly: true,
      secure: this.secure,
      sameSite: 'lax',
      path: '/',
    };
  }

  /** `expiresInMs` se usa solo para la cookie de refresh (la de acceso es de sesión corta). */
  set(res: Response, tokens: { accessToken: string; refreshToken: string }, refreshExpiresInMs: number): void {
    res.cookie(ACCESS_COOKIE, tokens.accessToken, {
      ...this.base(),
      maxAge: this.accessExpiresInMs(),
    });
    res.cookie(REFRESH_COOKIE, tokens.refreshToken, {
      ...this.base(),
      maxAge: refreshExpiresInMs,
    });
    // La pista debe sobrevivir lo mismo que el refresh: es la que permite al
    // frontend decidir si vale la pena intentar renovar la sesión. No es
    // `httpOnly` porque la lee JavaScript, y no es un secreto.
    res.cookie(SESSION_HINT_COOKIE, '1', {
      httpOnly: false,
      secure: this.secure,
      sameSite: 'lax',
      path: '/',
      maxAge: refreshExpiresInMs,
    });
  }

  clear(res: Response): void {
    res.clearCookie(ACCESS_COOKIE, this.base());
    res.clearCookie(REFRESH_COOKIE, this.base());
    res.clearCookie(SESSION_HINT_COOKIE, { ...this.base(), httpOnly: false });
  }

  /** Duración del access token en ms (para `maxAge` de la cookie). */
  accessExpiresInMs(): number {
    return parseDuration(this.config.get<string>('JWT_ACCESS_TTL') ?? '10m');
  }
}

/** Convierte duraciones estilo `10m` / `7d` / `3600s` a milisegundos. */
export function parseDuration(value: string): number {
  const match = /^(\d+)\s*([smhd])?$/.exec(value.trim());
  if (!match) return 0;
  const amount = Number(match[1]);
  const unit = match[2] ?? 's';
  const factor = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 }[unit] as number;
  return amount * factor;
}
