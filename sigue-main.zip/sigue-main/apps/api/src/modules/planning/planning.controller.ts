import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { PlanningService } from './planning.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('planning')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/planning', version: '1' })
export class PlanningController {
  constructor(private readonly planning: PlanningService) {}

  @ApiEndpoint('Riesgos, objetivos y planes de la organización', { status: 200, tenant: true })
  @Get()
  get(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.planning.getPlanning(orgId, user);
  }

  // ===== Riesgos =====
  @Audit('planning.add_risk')
  @ApiEndpoint('Registra un riesgo', { status: 201, tenant: true })
  @Post('risks')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_riesgos', 'resp_proceso', 'admin_org')
  addRisk(@Param('orgId') orgId: string, @Body() data: { title: string; description?: string; category?: string }, @CurrentUser() user: AuthUser) {
    return this.planning.addRisk(orgId, user, data);
  }

  @Audit('planning.update_risk')
  @ApiEndpoint('Actualiza un riesgo', { status: 200, tenant: true })
  @Patch('risks/:riskId')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_riesgos', 'admin_org')
  updateRisk(
    @Param('orgId') orgId: string,
    @Param('riskId') riskId: string,
    @Body() data: { title?: string; description?: string | null; category?: string | null; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.planning.updateRisk(orgId, user, riskId, data);
  }

  @Audit('planning.delete_risk')
  @ApiEndpoint('Elimina un riesgo', { status: 200, tenant: true })
  @Delete('risks/:riskId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteRisk(@Param('orgId') orgId: string, @Param('riskId') riskId: string, @CurrentUser() user: AuthUser) {
    return this.planning.deleteRisk(orgId, user, riskId);
  }

  @Audit('planning.assess')
  @ApiEndpoint('Registra una evaluación de riesgo', { status: 201, tenant: true })
  @Post('risks/:riskId/assess')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_riesgos', 'admin_org')
  assess(@Param('orgId') orgId: string, @Param('riskId') riskId: string, @Body() data: { likelihood: number; impact: number }, @CurrentUser() user: AuthUser) {
    return this.planning.assessRisk(orgId, user, riskId, data.likelihood, data.impact);
  }

  // ===== Tratamientos =====
  @ApiEndpoint('Tratamientos de riesgo', { status: 200, tenant: true })
  @Get('treatments')
  treatments(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.planning.listTreatments(orgId, user);
  }

  @Audit('planning.treat')
  @ApiEndpoint('Agrega un tratamiento a un riesgo', { status: 201, tenant: true })
  @Post('risks/:riskId/treatments')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_riesgos', 'admin_org')
  treat(@Param('orgId') orgId: string, @Param('riskId') riskId: string, @Body() data: { type: string; plan: string }, @CurrentUser() user: AuthUser) {
    return this.planning.addTreatment(orgId, user, riskId, data.type, data.plan);
  }

  @Audit('planning.update_treatment')
  @ApiEndpoint('Actualiza un tratamiento', { status: 200, tenant: true })
  @Patch('treatments/:treatmentId')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_riesgos', 'admin_org')
  updateTreatment(
    @Param('orgId') orgId: string,
    @Param('treatmentId') treatmentId: string,
    @Body() data: { type?: string; plan?: string | null; dueDate?: string | null; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.planning.updateTreatment(orgId, user, treatmentId, data);
  }

  @Audit('planning.delete_treatment')
  @ApiEndpoint('Elimina un tratamiento', { status: 200, tenant: true })
  @Delete('treatments/:treatmentId')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_riesgos', 'admin_org')
  deleteTreatment(@Param('orgId') orgId: string, @Param('treatmentId') treatmentId: string, @CurrentUser() user: AuthUser) {
    return this.planning.deleteTreatment(orgId, user, treatmentId);
  }

  // ===== Objetivos =====
  @Audit('planning.add_objective')
  @ApiEndpoint('Crea un objetivo de calidad', { status: 201, tenant: true })
  @Post('objectives')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addObjective(@Param('orgId') orgId: string, @Body() data: { title: string; dueDate?: string }, @CurrentUser() user: AuthUser) {
    return this.planning.addObjective(orgId, user, data.title, data.dueDate);
  }

  @Audit('planning.update_objective')
  @ApiEndpoint('Actualiza un objetivo', { status: 200, tenant: true })
  @Patch('objectives/:objectiveId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateObjective(
    @Param('orgId') orgId: string,
    @Param('objectiveId') objectiveId: string,
    @Body() data: { title?: string; dueDate?: string | null; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.planning.updateObjective(orgId, user, objectiveId, data);
  }

  @Audit('planning.delete_objective')
  @ApiEndpoint('Elimina un objetivo', { status: 200, tenant: true })
  @Delete('objectives/:objectiveId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteObjective(@Param('orgId') orgId: string, @Param('objectiveId') objectiveId: string, @CurrentUser() user: AuthUser) {
    return this.planning.deleteObjective(orgId, user, objectiveId);
  }

  // ===== KPI =====
  @Audit('planning.add_kpi')
  @ApiEndpoint('Agrega un KPI a un objetivo', { status: 201, tenant: true })
  @Post('objectives/:objectiveId/kpis')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addKpi(
    @Param('orgId') orgId: string,
    @Param('objectiveId') objectiveId: string,
    @Body() data: { name: string; formula?: string; target?: number; frequency?: string; unit?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.planning.addKpi(orgId, user, objectiveId, data);
  }

  @Audit('planning.update_kpi')
  @ApiEndpoint('Actualiza un KPI', { status: 200, tenant: true })
  @Patch('kpis/:kpiId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateKpi(
    @Param('orgId') orgId: string,
    @Param('kpiId') kpiId: string,
    @Body() data: { name?: string; formula?: string | null; target?: number | null; frequency?: string | null; unit?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.planning.updateKpi(orgId, user, kpiId, data);
  }

  @Audit('planning.delete_kpi')
  @ApiEndpoint('Elimina un KPI', { status: 200, tenant: true })
  @Delete('kpis/:kpiId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteKpi(@Param('orgId') orgId: string, @Param('kpiId') kpiId: string, @CurrentUser() user: AuthUser) {
    return this.planning.deleteKpi(orgId, user, kpiId);
  }

  @Audit('planning.add_kpi_result')
  @ApiEndpoint('Registra un resultado de KPI', { status: 201, tenant: true })
  @Post('kpis/:kpiId/results')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  addKpiResult(
    @Param('orgId') orgId: string,
    @Param('kpiId') kpiId: string,
    @Body() data: { period: string; value: number; evidenceId?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.planning.addKpiResult(orgId, user, kpiId, data);
  }

  @Audit('planning.delete_kpi_result')
  @ApiEndpoint('Elimina un resultado de KPI', { status: 200, tenant: true })
  @Delete('kpi-results/:resultId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteKpiResult(@Param('orgId') orgId: string, @Param('resultId') resultId: string, @CurrentUser() user: AuthUser) {
    return this.planning.deleteKpiResult(orgId, user, resultId);
  }

  // ===== Planes de trabajo =====
  @ApiEndpoint('Planes de implementación', { status: 200, tenant: true })
  @Get('plans')
  plans(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.planning.getPlans(orgId, user);
  }

  @Audit('planning.add_plan')
  @ApiEndpoint('Crea un plan de implementación', { status: 201, tenant: true })
  @Post('plans')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addPlan(
    @Param('orgId') orgId: string,
    @Body() data: { title: string; standardId?: string; startDate?: string; endDate?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.planning.addPlan(orgId, user, data);
  }

  @Audit('planning.update_plan')
  @ApiEndpoint('Actualiza un plan', { status: 200, tenant: true })
  @Patch('plans/:planId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updatePlan(
    @Param('orgId') orgId: string,
    @Param('planId') planId: string,
    @Body() data: { title?: string; status?: string; startDate?: string | null; endDate?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.planning.updatePlan(orgId, user, planId, data);
  }

  @Audit('planning.delete_plan')
  @ApiEndpoint('Elimina un plan', { status: 200, tenant: true })
  @Delete('plans/:planId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deletePlan(@Param('orgId') orgId: string, @Param('planId') planId: string, @CurrentUser() user: AuthUser) {
    return this.planning.deletePlan(orgId, user, planId);
  }

  @Audit('planning.add_task')
  @ApiEndpoint('Agrega una tarea a un plan', { status: 201, tenant: true })
  @Post('plans/:planId/tasks')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  addTask(@Param('orgId') orgId: string, @Param('planId') planId: string, @Body() data: { title: string; priority?: string; dueDate?: string }, @CurrentUser() user: AuthUser) {
    return this.planning.addTask(orgId, user, planId, data);
  }

  @Audit('planning.update_task')
  @ApiEndpoint('Cambia el estado de una tarea', { status: 200, tenant: true })
  @Patch('tasks/:taskId/status')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'resp_accion', 'admin_org')
  updateTask(@Param('orgId') orgId: string, @Param('taskId') taskId: string, @Body('status') status: string, @CurrentUser() user: AuthUser) {
    return this.planning.updateTaskStatus(orgId, user, taskId, status);
  }

  @Audit('planning.edit_task')
  @ApiEndpoint('Actualiza los datos de una tarea', { status: 200, tenant: true })
  @Patch('tasks/:taskId')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'resp_accion', 'admin_org')
  editTask(
    @Param('orgId') orgId: string,
    @Param('taskId') taskId: string,
    @Body() data: { title?: string; priority?: string; dueDate?: string | null; status?: string; assigneeId?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.planning.updateTask(orgId, user, taskId, data);
  }

  @Audit('planning.delete_task')
  @ApiEndpoint('Elimina una tarea', { status: 200, tenant: true })
  @Delete('tasks/:taskId')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  deleteTask(@Param('orgId') orgId: string, @Param('taskId') taskId: string, @CurrentUser() user: AuthUser) {
    return this.planning.deleteTask(orgId, user, taskId);
  }
}
