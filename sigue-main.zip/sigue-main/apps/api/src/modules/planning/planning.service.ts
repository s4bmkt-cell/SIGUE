import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

@Injectable()
export class PlanningService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Todo el panorama de planificación: riesgos, objetivos, planes. */
  async getPlanning(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [risks, objectives, plans] = await Promise.all([
        tx.risk.findMany({
          where: { orgId },
          include: { assessments: { orderBy: { assessedAt: 'desc' } }, treatments: { include: { controls: true } } },
          orderBy: { createdAt: 'desc' },
        }),
        tx.objective.findMany({
          where: { orgId },
          include: { kpis: { include: { results: { orderBy: { createdAt: 'desc' } } } } },
          orderBy: { createdAt: 'desc' },
        }),
        tx.workPlan.findMany({
          where: { orgId },
          include: { tasks: { orderBy: { sortOrder: 'asc' } } },
          orderBy: { createdAt: 'desc' },
        }),
      ]);
      return { risks, objectives, plans };
    });
  }

  // --- Riesgos ---
  async addRisk(orgId: string, user: AuthUser, data: { title: string; description?: string; category?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.risk.create({
        data: { orgId, title: data.title, description: data.description, category: data.category, ownerId: user.sub },
      });
    });
  }

  async updateRisk(
    orgId: string,
    user: AuthUser,
    riskId: string,
    data: { title?: string; description?: string | null; category?: string | null; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findRisk(tx, orgId, riskId);
      return tx.risk.update({ where: { id: riskId }, data });
    });
  }

  async deleteRisk(orgId: string, user: AuthUser, riskId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findRisk(tx, orgId, riskId);
      await tx.risk.delete({ where: { id: riskId } });
      return { ok: true, deleted: riskId };
    });
  }

  async assessRisk(orgId: string, user: AuthUser, riskId: string, likelihood: number, impact: number) {
    await this.assertMember(orgId, user);
    const score = likelihood * impact;
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findRisk(tx, orgId, riskId);
      return tx.riskAssessment.create({
        data: { orgId, riskId, likelihood, impact, score, assessedById: user.sub },
      });
    });
  }

  // --- Tratamientos ---
  async addTreatment(orgId: string, user: AuthUser, riskId: string, type: string, plan: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findRisk(tx, orgId, riskId);
      return tx.riskTreatment.create({
        data: { orgId, riskId, type, plan, ownerId: user.sub, status: 'IN_PROGRESS' },
      });
    });
  }

  async listTreatments(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.riskTreatment.findMany({
        where: { orgId },
        include: { risk: { select: { id: true, title: true } }, controls: true },
        orderBy: { createdAt: 'desc' },
      });
    });
  }

  async updateTreatment(
    orgId: string,
    user: AuthUser,
    treatmentId: string,
    data: { type?: string; plan?: string | null; dueDate?: string | null; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.riskTreatment.findUnique({ where: { id: treatmentId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Tratamiento no encontrado');
      return tx.riskTreatment.update({
        where: { id: treatmentId },
        data: {
          ...(data.type !== undefined ? { type: data.type } : {}),
          ...(data.plan !== undefined ? { plan: data.plan } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.dueDate !== undefined
            ? { dueDate: data.dueDate ? new Date(data.dueDate) : null }
            : {}),
        },
        include: { controls: true },
      });
    });
  }

  async deleteTreatment(orgId: string, user: AuthUser, treatmentId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.riskTreatment.findUnique({ where: { id: treatmentId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Tratamiento no encontrado');
      await tx.riskTreatment.delete({ where: { id: treatmentId } });
      return { ok: true, deleted: treatmentId };
    });
  }

  // --- Objetivos ---
  async addObjective(orgId: string, user: AuthUser, title: string, dueDate?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.objective.create({
        data: { orgId, title, ownerId: user.sub, dueDate: dueDate ? new Date(dueDate) : null },
      });
    });
  }

  async updateObjective(
    orgId: string,
    user: AuthUser,
    objectiveId: string,
    data: { title?: string; dueDate?: string | null; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.objective.findUnique({ where: { id: objectiveId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Objetivo no encontrado');
      return tx.objective.update({
        where: { id: objectiveId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.dueDate !== undefined
            ? { dueDate: data.dueDate ? new Date(data.dueDate) : null }
            : {}),
        },
      });
    });
  }

  async deleteObjective(orgId: string, user: AuthUser, objectiveId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.objective.findUnique({ where: { id: objectiveId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Objetivo no encontrado');
      await tx.objective.delete({ where: { id: objectiveId } });
      return { ok: true, deleted: objectiveId };
    });
  }

  // --- KPI y resultados ---
  async addKpi(orgId: string, user: AuthUser, objectiveId: string, data: { name: string; formula?: string; target?: number; frequency?: string; unit?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const obj = await tx.objective.findUnique({ where: { id: objectiveId } });
      if (!obj || obj.orgId !== orgId) throw new NotFoundException('Objetivo no encontrado');
      return tx.objectiveKpi.create({
        data: { orgId, objectiveId, name: data.name, formula: data.formula, target: data.target ?? null, frequency: data.frequency, unit: data.unit },
      });
    });
  }

  async updateKpi(
    orgId: string,
    user: AuthUser,
    kpiId: string,
    data: { name?: string; formula?: string | null; target?: number | null; frequency?: string | null; unit?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.objectiveKpi.findUnique({ where: { id: kpiId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('KPI no encontrado');
      return tx.objectiveKpi.update({ where: { id: kpiId }, data });
    });
  }

  async deleteKpi(orgId: string, user: AuthUser, kpiId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.objectiveKpi.findUnique({ where: { id: kpiId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('KPI no encontrado');
      await tx.objectiveKpi.delete({ where: { id: kpiId } });
      return { ok: true, deleted: kpiId };
    });
  }

  /** Registra la medición de un KPI en un periodo. */
  async addKpiResult(
    orgId: string,
    user: AuthUser,
    kpiId: string,
    data: { period: string; value: number; evidenceId?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.objectiveKpi.findUnique({ where: { id: kpiId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('KPI no encontrado');
      return tx.objectiveResult.create({
        data: { orgId, kpiId, period: data.period, value: data.value, evidenceId: data.evidenceId },
      });
    });
  }

  async deleteKpiResult(orgId: string, user: AuthUser, resultId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.objectiveResult.findUnique({ where: { id: resultId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Medición no encontrada');
      await tx.objectiveResult.delete({ where: { id: resultId } });
      return { ok: true, deleted: resultId };
    });
  }

  // --- Planes de trabajo ---
  async getPlans(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.workPlan.findMany({ where: { orgId }, include: { tasks: { orderBy: { sortOrder: 'asc' } } } });
    });
  }

  async addPlan(
    orgId: string,
    user: AuthUser,
    data: { title: string; standardId?: string; startDate?: string; endDate?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.workPlan.create({
        data: {
          orgId,
          title: data.title,
          standardId: data.standardId,
          ownerId: user.sub,
          startDate: data.startDate ? new Date(data.startDate) : null,
          endDate: data.endDate ? new Date(data.endDate) : null,
        },
        include: { tasks: true },
      });
    });
  }

  async updatePlan(
    orgId: string,
    user: AuthUser,
    planId: string,
    data: { title?: string; status?: string; startDate?: string | null; endDate?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.workPlan.findUnique({ where: { id: planId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Plan no encontrado');
      return tx.workPlan.update({
        where: { id: planId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.startDate !== undefined
            ? { startDate: data.startDate ? new Date(data.startDate) : null }
            : {}),
          ...(data.endDate !== undefined
            ? { endDate: data.endDate ? new Date(data.endDate) : null }
            : {}),
        },
      });
    });
  }

  async deletePlan(orgId: string, user: AuthUser, planId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.workPlan.findUnique({ where: { id: planId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Plan no encontrado');
      await tx.workPlan.delete({ where: { id: planId } });
      return { ok: true, deleted: planId };
    });
  }

  async addTask(orgId: string, user: AuthUser, planId: string, data: { title: string; priority?: string; dueDate?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const plan = await tx.workPlan.findUnique({ where: { id: planId } });
      if (!plan || plan.orgId !== orgId) throw new NotFoundException('Plan no encontrado');
      const count = await tx.planTask.count({ where: { planId } });
      return tx.planTask.create({
        data: {
          orgId,
          planId,
          title: data.title,
          priority: data.priority ?? 'MEDIUM',
          assigneeId: user.sub,
          dueDate: data.dueDate ? new Date(data.dueDate) : null,
          sortOrder: count,
        },
      });
    });
  }

  async updateTaskStatus(orgId: string, user: AuthUser, taskId: string, status: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findTask(tx, orgId, taskId);
      return tx.planTask.update({ where: { id: taskId }, data: { status } });
    });
  }

  async updateTask(
    orgId: string,
    user: AuthUser,
    taskId: string,
    data: { title?: string; priority?: string; dueDate?: string | null; status?: string; assigneeId?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findTask(tx, orgId, taskId);
      return tx.planTask.update({
        where: { id: taskId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.priority !== undefined ? { priority: data.priority } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.assigneeId !== undefined ? { assigneeId: data.assigneeId } : {}),
          ...(data.dueDate !== undefined
            ? { dueDate: data.dueDate ? new Date(data.dueDate) : null }
            : {}),
        },
      });
    });
  }

  async deleteTask(orgId: string, user: AuthUser, taskId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findTask(tx, orgId, taskId);
      await tx.planTask.delete({ where: { id: taskId } });
      return { ok: true, deleted: taskId };
    });
  }

  private async findRisk(
    tx: { risk: { findUnique: (a: { where: { id: string } }) => Promise<{ orgId: string } | null> } },
    orgId: string,
    riskId: string,
  ) {
    const row = await tx.risk.findUnique({ where: { id: riskId } });
    if (!row || row.orgId !== orgId) throw new NotFoundException('Riesgo no encontrado');
    return row;
  }

  private async findTask(
    tx: { planTask: { findUnique: (a: { where: { id: string } }) => Promise<{ orgId: string } | null> } },
    orgId: string,
    taskId: string,
  ) {
    const row = await tx.planTask.findUnique({ where: { id: taskId } });
    if (!row || row.orgId !== orgId) throw new NotFoundException('Tarea no encontrada');
    return row;
  }
}
