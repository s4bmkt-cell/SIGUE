import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Res,
  StreamableFile,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import type { Response } from 'express';
import { ApiBearerAuth, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import {
  DocumentsService,
  type DocumentFilters,
  type UploadedFile as UploadedDocFile,
} from './documents.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB ?? 25);

/** Una sola pieza: un documento se adjunta con su archivo original. */
const uploadOptions = { limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 1 } };

@ApiTags('documents')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/documents', version: '1' })
export class DocumentsController {
  constructor(private readonly documents: DocumentsService) {}

  /**
   * Filtros del inventario. Se parsean uno a uno: `@Query()` sin tipar
   * devuelve cadenas y el servicio espera números y uniones literales.
   */
  private filters(query: {
    status?: string;
    type?: string;
    areaId?: string;
    q?: string;
    due?: string;
    page?: string;
    pageSize?: string;
  }): DocumentFilters {
    return {
      status: query.status || undefined,
      type: query.type || undefined,
      areaId: query.areaId || undefined,
      q: query.q?.trim() || undefined,
      due: query.due === 'overdue' || query.due === 'soon' ? query.due : undefined,
      // `?page=abc` no debe convertirse en `NaN`: se ignora y se usa la primera.
      page: this.positiveInt(query.page),
      pageSize: this.positiveInt(query.pageSize),
    };
  }

  private positiveInt(value: string | undefined): number | undefined {
    if (!value) return undefined;
    const n = Number(value);
    return Number.isFinite(n) && n > 0 ? Math.floor(n) : undefined;
  }

  @ApiEndpoint('Documentos de la organización', { status: 200, tenant: true })
  @Get()
  list(
    @Param('orgId') orgId: string,
    @Query()
    query: {
      status?: string;
      type?: string;
      areaId?: string;
      q?: string;
      due?: string;
      page?: string;
      pageSize?: string;
    },
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.list(orgId, user, this.filters(query));
  }

  @ApiEndpoint('Documentos con revisión vencida o próxima', { status: 200, tenant: true })
  @Get('review-alerts')
  reviewAlerts(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.documents.reviewAlerts(orgId, user);
  }

  @ApiEndpoint('Inventario documental en CSV', { status: 200, tenant: true })
  @Get('export.csv')
  async exportCsv(
    @Param('orgId') orgId: string,
    @Query()
    query: {
      status?: string;
      type?: string;
      areaId?: string;
      q?: string;
      due?: string;
    },
    @CurrentUser() user: AuthUser,
    @Res({ passthrough: true }) res: Response,
  ) {
    const csv = await this.documents.exportCsv(orgId, user, this.filters(query));
    const stamp = new Date().toISOString().slice(0, 10);
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="inventario-documental-${stamp}.csv"`);
    res.setHeader('Cache-Control', 'private, no-store');
    // BOM: sin él Excel abre el archivo como Latin-1 y rompe los acentos.
    return `\uFEFF${csv}`;
  }

  @Audit('documents.create')
  @ApiEndpoint('Crea un documento en borrador', { status: 201, tenant: true })
  @Post()
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  create(
    @Param('orgId') orgId: string,
    @Body()
    data: {
      code: string;
      title: string;
      type?: string;
      content?: string;
      templateId?: string;
      areaId?: string | null;
      validityUntil?: string | null;
      reviewDate?: string | null;
      sourceProvider?: string | null;
      sourceRef?: string | null;
      branchIds?: string[];
    },
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.create(orgId, user, data);
  }

  @Audit('documents.submit')
  @ApiEndpoint('Envía un documento a revisión', { status: 201, tenant: true })
  @Post(':documentId/submit')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  submit(@Param('orgId') orgId: string, @Param('documentId') documentId: string, @CurrentUser() user: AuthUser) {
    return this.documents.submitForReview(orgId, user, documentId);
  }

  @Audit('documents.approve')
  @ApiEndpoint('Aprueba un documento en revisión', { status: 201, tenant: true })
  @Post(':documentId/approve')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  approve(
    @Param('orgId') orgId: string,
    @Param('documentId') documentId: string,
    @Body('comment') comment: string | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.approveReview(orgId, user, documentId, comment);
  }

  @Audit('documents.publish')
  @ApiEndpoint('Publica un documento aprobado', { status: 201, tenant: true })
  @Post(':documentId/publish')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  publish(@Param('orgId') orgId: string, @Param('documentId') documentId: string, @CurrentUser() user: AuthUser) {
    return this.documents.publish(orgId, user, documentId);
  }

  @Audit('documents.new_version')
  @ApiEndpoint('Crea una versión nueva del documento', { status: 201, tenant: true })
  @Post(':documentId/versions')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  newVersion(
    @Param('orgId') orgId: string,
    @Param('documentId') documentId: string,
    @Body() data: { content: string; changesNote?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.newVersion(orgId, user, documentId, data.content, data.changesNote);
  }

  @Audit('documents.update')
  @ApiEndpoint('Actualiza los metadatos del documento', { status: 200, tenant: true })
  @Patch(':documentId')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  update(
    @Param('orgId') orgId: string,
    @Param('documentId') documentId: string,
    @Body()
    data: {
      title?: string;
      type?: string;
      areaId?: string | null;
      validityUntil?: string | null;
      reviewDate?: string | null;
      sourceProvider?: string | null;
      sourceRef?: string | null;
      branchIds?: string[];
    },
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.update(orgId, user, documentId, data);
  }

  // ===== Archivo original del documento =====

  /**
   * Capacidad de subida del entorno. Se declara antes que las rutas con
   * `:documentId` para que `upload-capabilities` no se interprete como un id.
   */
  @ApiEndpoint('Capacidad de subida de archivos', { status: 200, tenant: true })
  @Get('upload-capabilities')
  uploadCapabilities(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    // El guard ya valida la sesión; se comprueba la membresía igual que el resto
    // para no revelar la configuración a quien no pertenece a la organización.
    return this.documents.uploadCapabilitiesFor(orgId, user);
  }

  @Audit('documents.add_file')
  @ApiEndpoint('Adjunta el archivo original de un documento', { status: 201, tenant: true })
  @Post(':documentId/files')
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(FileInterceptor('file', uploadOptions))
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  addFile(
    @Param('orgId') orgId: string,
    @Param('documentId') documentId: string,
    @UploadedFile() file: UploadedDocFile | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    if (!file) throw new BadRequestException('Adjunta el archivo del documento');
    return this.documents.addFile(orgId, user, documentId, file);
  }

  @ApiEndpoint('Archivos adjuntos de un documento', { status: 200, tenant: true })
  @Get(':documentId/files')  files(@Param('orgId') orgId: string, @Param('documentId') documentId: string, @CurrentUser() user: AuthUser) {
    return this.documents.listFiles(orgId, user, documentId);
  }

  /**
   * Permiso de subida directa al almacén.
   *
   * Devuelve `null` si el adaptador de almacenamiento no firma URLs (disco
   * local): el cliente lo interpreta como «usa la subida multipart».
   */
  @Audit('documents.upload_ticket')
  @ApiEndpoint('Permiso para subir el archivo directo al almacén', { status: 201, tenant: true })
  @Post(':documentId/files/ticket')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  uploadTicket(
    @Param('orgId') orgId: string,
    @Param('documentId') documentId: string,
    @Body() data: { filename: string; mime?: string; size: number },
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.requestUploadTicket(orgId, user, documentId, data);
  }

  @Audit('documents.confirm_upload')
  @ApiEndpoint('Registra el archivo subido directo al almacén', { status: 201, tenant: true })
  @Post(':documentId/files/confirm')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  confirmUpload(
    @Param('orgId') orgId: string,
    @Param('documentId') documentId: string,
    @Body() data: { key: string; filename: string; mime?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.confirmDirectUpload(orgId, user, documentId, data);
  }

  /** Descarga el binario con el nombre original y sin caché. */
  @ApiEndpoint('Descarga el archivo de un documento', { status: 200, tenant: true })
  @Get('files/:fileId/download')
  async downloadFile(
    @Param('orgId') orgId: string,
    @Param('fileId') fileId: string,
    @CurrentUser() user: AuthUser,
    @Res({ passthrough: true }) res: Response,
  ) {
    const file = await this.documents.readFile(orgId, user, fileId);
    const ascii = file.filename.replace(/[^\x20-\x7E]+/g, '_').replace(/"/g, '');
    res.setHeader('Content-Type', file.mime);
    res.setHeader('Content-Length', String(file.size));
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(file.filename)}`,
    );
    res.setHeader('Cache-Control', 'private, no-store');
    return new StreamableFile(file.buffer);
  }

  @Audit('documents.remove_file')
  @ApiEndpoint('Quita el archivo adjunto de un documento', { status: 200, tenant: true })
  @Delete('files/:fileId')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  removeFile(@Param('orgId') orgId: string, @Param('fileId') fileId: string, @CurrentUser() user: AuthUser) {
    return this.documents.removeFile(orgId, user, fileId);
  }

  @Audit('documents.distribute')
  @ApiEndpoint('Registra la entrega del documento a un área o persona', { status: 201, tenant: true })
  @Post(':documentId/distributions')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  distribute(
    @Param('orgId') orgId: string,
    @Param('documentId') documentId: string,
    @Body() data: { areaId?: string | null; userId?: string | null; channel?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.distribute(orgId, user, documentId, data);
  }

  @Audit('documents.undo_distribution')
  @ApiEndpoint('Quita una entrega registrada', { status: 200, tenant: true })
  @Delete('distributions/:distributionId')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  undoDistribution(
    @Param('orgId') orgId: string,
    @Param('distributionId') distributionId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.undoDistribution(orgId, user, distributionId);
  }

  @Audit('documents.notify_review')
  @ApiEndpoint('Avisa al responsable de la revisión pendiente', { status: 201, tenant: true })
  @Post(':documentId/notify-review')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  notifyReview(
    @Param('orgId') orgId: string,
    @Param('documentId') documentId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.notifyReviewDue(orgId, user, documentId);
  }

  @Audit('documents.delete')
  @ApiEndpoint('Elimina un documento', { status: 200, tenant: true })
  @Delete(':documentId')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  remove(@Param('orgId') orgId: string, @Param('documentId') documentId: string, @CurrentUser() user: AuthUser) {
    return this.documents.remove(orgId, user, documentId);
  }

  @Audit('documents.obsolete')
  @ApiEndpoint('Marca un documento como obsoleto', { status: 201, tenant: true })
  @Post(':documentId/obsolete')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  obsolete(@Param('orgId') orgId: string, @Param('documentId') documentId: string, @CurrentUser() user: AuthUser) {
    return this.documents.obsolete(orgId, user, documentId);
  }

  @Audit('documents.revoke_signature')
  @ApiEndpoint('Revoca una firma de documento', { status: 200, tenant: true })
  @Delete('signatures/:signatureId')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  revokeSignature(
    @Param('orgId') orgId: string,
    @Param('signatureId') signatureId: string,
    @Body('reason') reason: string | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    return this.documents.revokeSignature(orgId, user, signatureId, reason);
  }

  @ApiEndpoint('Historial de versiones, flujo y distribución', { status: 200, tenant: true })
  @Get(':documentId/history')
  history(@Param('orgId') orgId: string, @Param('documentId') documentId: string, @CurrentUser() user: AuthUser) {
    return this.documents.history(orgId, user, documentId);
  }

  @ApiEndpoint('Plantillas de documentos disponibles', { status: 200, tenant: true })
  @Get('templates')
  templates(@Param('orgId') orgId: string, @Query('kind') kind: string | undefined, @CurrentUser() user: AuthUser) {
    return this.documents.listTemplates(orgId, user, kind);
  }

  @Audit('documents.create_from_template')
  @ApiEndpoint('Crea un documento a partir de una plantilla', { status: 201, tenant: true })
  @Post('templates/:templateId/create')
  @RequireRoles('controlador_doc', 'resp_sgi', 'resp_norma', 'admin_org')
  createFromTemplate(@Param('orgId') orgId: string, @Param('templateId') templateId: string, @CurrentUser() user: AuthUser) {
    return this.documents.createFromTemplate(orgId, user, templateId);
  }

  // ===== Firma electrónica =====
  @Audit('documents.accept')
  @ApiEndpoint('Firma la aceptación de un documento', { status: 201, tenant: true })
  @Post(':documentId/accept')
  @RequireRoles('colaborador', 'resp_proceso', 'resp_sgi', 'resp_norma', 'admin_org')
  accept(@Param('orgId') orgId: string, @Param('documentId') documentId: string, @CurrentUser() user: AuthUser) {
    return this.documents.accept(orgId, user, documentId);
  }

  @ApiEndpoint('Firmas registradas de un documento', { status: 200, tenant: true })
  @Get(':documentId/signatures')
  signatures(@Param('orgId') orgId: string, @Param('documentId') documentId: string, @CurrentUser() user: AuthUser) {
    return this.documents.listSignatures(orgId, user, documentId);
  }

  @ApiEndpoint('Verifica la integridad de una firma', { status: 200, tenant: true })
  @Get('signatures/:signatureId/verify')
  verifySignature(@Param('orgId') orgId: string, @Param('signatureId') signatureId: string, @CurrentUser() user: AuthUser) {
    return this.documents.verifySignature(orgId, user, signatureId);
  }
}
