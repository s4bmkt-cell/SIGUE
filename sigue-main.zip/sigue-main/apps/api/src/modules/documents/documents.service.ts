import {
  BadRequestException,
  ForbiddenException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { createHash } from 'crypto';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { nextSequentialCode } from '../../common/next-code';
import { contentHashOf, signaturePayload } from '../../common/document-signature';
import { STORAGE, StoragePort } from '../../common/storage/storage.port';
import { UsageService } from '../billing/usage.service';
import { TenancyService } from '../../tenancy/tenancy.service';

/** Límite por archivo; la cuota del plan se valida además por organización. */
const MAX_UPLOAD_BYTES = Number(process.env.MAX_UPLOAD_MB ?? 25) * 1024 * 1024;

/**
 * Tope de la subida directa al almacén. Al no cruzar la API ni el proxy de la
 * web, el límite de 4,5 MB de las funciones de Vercel deja de aplicar.
 */
const MAX_DIRECT_UPLOAD_BYTES = Number(process.env.MAX_DIRECT_UPLOAD_MB ?? 250) * 1024 * 1024;

/** Validez del permiso de subida: suficiente para un archivo grande con red lenta. */
const DIRECT_UPLOAD_TTL_SECONDS = 15 * 60;

/**
 * Tope del proxy `/api/*` de la web. Vercel corta el cuerpo de una función en
 * 4,5 MB; se deja margen para el envoltorio multipart. Solo informa a la UI.
 */
const MAX_PROXY_UPLOAD_MB = 4;

/** Archivo recibido por multipart (mismo contrato que evidencias). */
export interface UploadedFile {
  originalname: string;
  buffer: Buffer;
  size: number;
  mimetype: string;
}

export const DOC_STATUS = {
  DRAFT: 'DRAFT',
  IN_REVIEW: 'IN_REVIEW',
  IN_APPROVAL: 'IN_APPROVAL',
  PUBLISHED: 'PUBLISHED',
  OBSOLETE: 'OBSOLETE',
} as const;

export const DOC_TYPES = [
  'POLITICA',
  'PROCESO',
  'PROCEDIMIENTO',
  'INSTRUCTIVO',
  'GUIA',
  'MANUAL',
  'FORMATO',
  'REGISTRO',
  'EXTERNO',
] as const;

/** Ventana de aviso previo a la fecha de revisión. */
export const REVIEW_SOON_DAYS = 30;

/** Filtros del inventario documental. `undefined` = sin restricción. */
export interface DocumentFilters {
  status?: string;
  type?: string;
  areaId?: string;
  /** Búsqueda libre por código o título. */
  q?: string;
  /** `overdue` = revisión vencida; `soon` = vence en los próximos 30 días. */
  due?: 'overdue' | 'soon';
  page?: number;
  pageSize?: number;
}

const MAX_PAGE_SIZE = 200;

/** Tope de filas de una exportación: un CSV de 10 000 documentos no cabe en memoria. */
const MAX_EXPORT_ROWS = 5000;

@Injectable()
export class DocumentsService {
  private readonly logger = new Logger('Documents');

  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
    @Inject(STORAGE) private readonly storage: StoragePort,
    private readonly usage: UsageService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /**
   * Condición `where` del inventario a partir de los filtros de la vista.
   *
   * La comparten el listado y la exportación: si divergieran, el CSV no
   * correspondería con lo que el usuario está viendo en pantalla.
   */
  private whereOf(orgId: string, filters: DocumentFilters): Prisma.DocumentWhereInput {
    const now = new Date();
    const soon = new Date(now.getTime() + REVIEW_SOON_DAYS * 24 * 60 * 60 * 1000);

    const baseWhere: Prisma.DocumentWhereInput = {
      // La política RLS ya limita al tenant; el filtro explícito evita depender
      // solo de ella.
      orgId,
      ...(filters.status ? { status: filters.status } : {}),
      ...(filters.type ? { type: filters.type } : {}),
      ...(filters.areaId ? { areaId: filters.areaId } : {}),
      ...(filters.q
        ? {
            OR: [
              { code: { contains: filters.q, mode: 'insensitive' as const } },
              { title: { contains: filters.q, mode: 'insensitive' as const } },
            ],
          }
        : {}),
    };

    // El vencimiento se combina con los demás filtros sin pisarlos: un
    // documento obsoleto no genera aviso porque ya no está vigente.
    const where: Prisma.DocumentWhereInput = {
      ...baseWhere,
      ...(filters.due === 'overdue'
        ? { reviewDate: { lt: now } }
        : filters.due === 'soon'
          ? { reviewDate: { gte: now, lte: soon } }
          : {}),
      ...(filters.due ? { status: filters.status ?? { not: DOC_STATUS.OBSOLETE } } : {}),
    };

    return where;
  }

  /**
   * Lista documentos de la organización con su última versión y sus firmas.
   *
   * Los filtros se aplican en la base: el inventario de una organización real
   * crece hasta miles de filas y traerlas todas para filtrar en el navegador
   * dejaba de ser viable.
   */
  async list(orgId: string, user: AuthUser, filters: DocumentFilters = {}) {
    await this.assertMember(orgId, user);

    const page = Math.max(1, filters.page ?? 1);
    const pageSize = Math.min(MAX_PAGE_SIZE, Math.max(1, filters.pageSize ?? 50));
    const where = this.whereOf(orgId, filters);

    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [items, total] = await Promise.all([
        tx.document.findMany({
          where,
          include: {
            versions: { orderBy: { createdAt: 'desc' }, take: 1 },
            signatures: { orderBy: { signedAt: 'desc' } },
            // Solo metadatos: la fila necesita saber si hay archivo adjunto.
            files: { select: { id: true, filename: true, size: true, mime: true }, orderBy: { createdAt: 'desc' } },
          },
          // El listado por vencimiento se ordena por la fecha que se está
          // revisando; el resto, por actividad reciente.
          orderBy:
            filters.due === 'overdue' || filters.due === 'soon'
              ? [{ reviewDate: 'asc' }, { code: 'asc' }]
              : { updatedAt: 'desc' },
          skip: (page - 1) * pageSize,
          take: pageSize,
        }),
        tx.document.count({ where }),
      ]);
      return { items, page, pageSize, total, pages: Math.ceil(total / pageSize) };
    });
  }

  /**
   * Documentos con revisión pendiente o próxima, para el aviso del inventario.
   * Se calcula en el servidor para que el aviso no dependa del reloj del equipo.
   */
  async reviewAlerts(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    const now = new Date();
    const soon = new Date(now.getTime() + REVIEW_SOON_DAYS * 24 * 60 * 60 * 1000);

    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const items = await tx.document.findMany({
        where: {
          orgId,
          status: { not: DOC_STATUS.OBSOLETE },
          reviewDate: { not: null, lte: soon },
        },
        select: { id: true, code: true, title: true, reviewDate: true, validityUntil: true, status: true },
        orderBy: { reviewDate: 'asc' },
      });
      const overdue = items.filter((d) => d.reviewDate && d.reviewDate < now);
      return {
        items,
        overdue: overdue.length,
        dueSoon: items.length - overdue.length,
        soonUntil: soon,
      };
    });
  }

  /** Crea un documento (borrador) con su primera versión. */
  async create(
    orgId: string,
    user: AuthUser,
    data: {
      code: string;
      title: string;
      type?: string;
      content?: string;
      templateId?: string;
      areaId?: string | null;
      validityUntil?: string | null;
      reviewDate?: string | null;
      sourceProvider?: string | null;
      sourceRef?: string | null;
      /** Sedes a las que aplica; vacío = toda la organización. */
      branchIds?: string[];
    },
  ) {
    await this.assertMember(orgId, user);
    const validityUntil = this.parseDate(data.validityUntil, 'La fecha de vigencia');
    const reviewDate = this.parseDate(data.reviewDate, 'La fecha de revisión');
    this.assertDateOrder(validityUntil, reviewDate);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const exists = await tx.document.findUnique({ where: { orgId_code: { orgId, code: data.code } } });
      if (exists) throw new BadRequestException('Ya existe un documento con ese código');
      if (data.areaId) await this.assertArea(tx, orgId, data.areaId);
      const branchIds = await this.assertBranches(tx, orgId, data.branchIds);
      const doc = await tx.document.create({
        data: {
          orgId,
          code: data.code,
          title: data.title,
          type: data.type ?? 'PROCEDIMIENTO',
          status: DOC_STATUS.DRAFT,
          ownerId: user.sub,
          areaId: data.areaId ?? null,
          validityUntil,
          reviewDate,
          sourceProvider: data.sourceProvider?.trim() || null,
          sourceRef: data.sourceRef?.trim() || null,
          branchIds,
        },
      });
      await tx.documentVersion.create({
        data: {
          orgId,
          documentId: doc.id,
          version: 'v1',
          content: data.content,
          checksum: data.content ? createHash('sha256').update(data.content).digest('hex') : null,
          authorId: user.sub,
          changesNote: 'Versión inicial',
        },
      });
      return doc;
    });
  }

  /** Envía a revisión (DRAFT → IN_REVIEW) registrando el paso del flujo. */
  async submitForReview(orgId: string, user: AuthUser, documentId: string) {
    return this.transition(orgId, user, documentId, DOC_STATUS.IN_REVIEW, 'REVIEW');
  }

  /** Aprueba la revisión (IN_REVIEW → IN_APPROVAL). */
  async approveReview(orgId: string, user: AuthUser, documentId: string, comment?: string) {
    return this.transition(orgId, user, documentId, DOC_STATUS.IN_APPROVAL, 'APPROVE', comment);
  }

  /** Publica (IN_APPROVAL → PUBLISHED) registrando distribución + firma del aprobador. */
  async publish(orgId: string, user: AuthUser, documentId: string) {
    const result = await this.transition(orgId, user, documentId, DOC_STATUS.PUBLISHED, 'PUBLISH');
    await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await tx.documentDistribution.create({
        data: { orgId, documentId, channel: 'SISTEMA', userId: user.sub },
      });
      // Firma electrónica de aprobación (hash del contenido + identidad + timestamp)
      const version = await tx.documentVersion.findFirst({ where: { documentId }, orderBy: { createdAt: 'desc' } });
      const signer = await tx.user.findUnique({ where: { id: user.sub } });
      const contentHash = version ? contentHashOf(version) : null;
      if (contentHash && version) {
        // `signedAt` se fija aquí y se guarda: la verificación recalcula la firma
        // a partir de los mismos valores, así que no puede depender del reloj de
        // la base de datos (que devolvería un instante distinto al de la firma).
        const signedAt = new Date();
        await tx.documentSignature.create({
          data: {
            orgId,
            documentId,
            version: version.version,
            signerId: user.sub,
            signerName: signer?.name,
            signerEmail: signer?.email,
            kind: 'APPROVAL',
            contentHash,
            signature: signaturePayload(contentHash, user.sub, 'APPROVAL', signedAt),
            signedAt,
          },
        });
      }
    });
    return result;
  }

  /** Firma de aceptación: un colaborador acepta/lee un documento publicado. */
  async accept(orgId: string, user: AuthUser, documentId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const doc = await tx.document.findUnique({ where: { id: documentId } });
      if (!doc || doc.orgId !== orgId) throw new NotFoundException('Documento no encontrado');
      if (doc.status !== DOC_STATUS.PUBLISHED) throw new BadRequestException('Solo se aceptan documentos publicados');
      const version = await tx.documentVersion.findFirst({ where: { documentId }, orderBy: { createdAt: 'desc' } });
      const signer = await tx.user.findUnique({ where: { id: user.sub } });
      const contentHash = version ? contentHashOf(version) : null;
      if (!contentHash || !version) throw new BadRequestException('El documento no tiene contenido');
      // La aceptación es idempotente: repetirla no crea una firma nueva.
      const exists = await tx.documentSignature.findFirst({ where: { documentId, signerId: user.sub, kind: 'ACCEPTANCE' } });
      if (exists) return exists;
      const signedAt = new Date();
      return tx.documentSignature.create({
        data: {
          orgId,
          documentId,
          version: version.version,
          signerId: user.sub,
          signerName: signer?.name,
          signerEmail: signer?.email,
          kind: 'ACCEPTANCE',
          contentHash,
          signature: signaturePayload(contentHash, user.sub, 'ACCEPTANCE', signedAt),
          signedAt,
        },
      });
    });
  }

  /** Lista las firmas de un documento. */
  async listSignatures(orgId: string, user: AuthUser, documentId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const doc = await tx.document.findUnique({ where: { id: documentId } });
      if (!doc || doc.orgId !== orgId) throw new NotFoundException('Documento no encontrado');
      return tx.documentSignature.findMany({ where: { documentId }, orderBy: { signedAt: 'desc' } });
    });
  }

  /**
   * Verifica la integridad de una firma.
   *
   * Dos comprobaciones independientes:
   * 1. La firma corresponde a la identidad y al instante registrados.
   * 2. El contenido actual de la versión firmada sigue produciendo el mismo
   *    hash. Si alguien alteró el texto después de firmar, `contentIntact` es
   *    `false` aunque la firma esté bien formada: ese es el caso que un
   *    auditor busca y el que antes pasaba desapercibido.
   */
  async verifySignature(orgId: string, user: AuthUser, signatureId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const sig = await tx.documentSignature.findUnique({ where: { id: signatureId } });
      if (!sig || sig.orgId !== orgId) throw new NotFoundException('Firma no encontrada');
      if (!sig.signerId) {
        return { valid: false, contentIntact: false, signedAt: sig.signedAt, signerName: sig.signerName, version: sig.version };
      }

      const expected = signaturePayload(sig.contentHash, sig.signerId, sig.kind as 'APPROVAL' | 'ACCEPTANCE', sig.signedAt);
      const signatureValid = expected === sig.signature;

      const version = await tx.documentVersion.findFirst({
        where: { documentId: sig.documentId, version: sig.version },
      });
      const currentHash = version ? contentHashOf(version) : null;
      // Sin versión localizable no se puede afirmar que el contenido esté intacto.
      const contentIntact = currentHash != null && currentHash === sig.contentHash;

      return {
        valid: signatureValid,
        contentIntact,
        signedAt: sig.signedAt,
        signerName: sig.signerName,
        version: sig.version,
      };
    });
  }

  /** Transición genérica del flujo con registro en workflow + hash. */
  private async transition(orgId: string, user: AuthUser, documentId: string, to: string, step: string, comment?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const doc = await tx.document.findUnique({ where: { id: documentId } });
      if (!doc || doc.orgId !== orgId) throw new NotFoundException('Documento no encontrado');

      const allowed: Record<string, string[]> = {
        [DOC_STATUS.DRAFT]: [DOC_STATUS.IN_REVIEW],
        [DOC_STATUS.IN_REVIEW]: [DOC_STATUS.IN_APPROVAL, DOC_STATUS.DRAFT],
        [DOC_STATUS.IN_APPROVAL]: [DOC_STATUS.PUBLISHED, DOC_STATUS.IN_REVIEW],
      };
      if (!allowed[doc.status]?.includes(to)) {
        throw new BadRequestException(`Transición inválida: ${doc.status} → ${to}`);
      }

      await tx.docWorkflowStep.create({
        data: { orgId, documentId, step, assigneeId: user.sub, action: to, comment },
      });
      return tx.document.update({ where: { id: documentId }, data: { status: to } });
    });
  }

  /**
   * Adjunta el archivo original del documento.
   *
   * Se escribe primero en el almacenamiento y luego la fila: si la transacción
   * falla, el objeto se borra para no dejar huérfanos (mismo patrón que las
   * evidencias). El archivo no sustituye a la versión de texto: la firma sigue
   * calculándose sobre `DocumentVersion.content`.
   */
  async addFile(orgId: string, user: AuthUser, documentId: string, file: UploadedFile) {
    await this.assertMember(orgId, user);
    if (!file?.buffer?.length) throw new BadRequestException('El archivo está vacío');
    if (file.size > MAX_UPLOAD_BYTES) {
      throw new BadRequestException(
        `El archivo supera el límite de ${Math.round(MAX_UPLOAD_BYTES / 1024 / 1024)} MB`,
      );
    }

    // Lectura corta: se valida el documento antes de escribir en el almacén,
    // para no subir un archivo que luego no tendría a quién pertenecer.
    await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const doc = await tx.document.findUnique({ where: { id: documentId } });
      if (!doc || doc.orgId !== orgId) throw new NotFoundException('Documento no encontrado');
    });

    // La cuota se mide con datos reales de la organización.
    await this.usage.assertStorage(orgId, file.size);

    const filename = safeFilename(file.originalname);
    const key = `org-${orgId}/doc-${documentId}/${Date.now()}-${filename}`;
    const stored = await this.storage.put(key, file.buffer, file.mimetype);

    try {
      return await this.prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
        return tx.documentFile.create({
          data: {
            orgId,
            documentId,
            filename,
            blobName: stored.key,
            size: stored.size,
            sha256: stored.sha256,
            mime: stored.mime,
            uploadedBy: user.sub,
          },
        });
      });
    } catch (error) {
      // Sin fila no hay archivo que consultar: se retira el objeto huérfano.
      await this.storage.remove(key).catch(() => undefined);
      throw error;
    }
  }

  /**
   * Capacidad de subida del entorno actual.
   *
   * La UI la consulta para validar el tamaño antes de enviar nada: con
   * almacenamiento en la nube el binario va directo al almacén y cabe un archivo
   * grande; con disco local cruza el proxy `/api/*`, que Vercel corta en 4,5 MB.
   * Sin este dato la web solo podría adivinar y el usuario vería un 413 opaco.
   */
  uploadCapabilities() {
    const direct = Boolean(this.storage.presignPut);
    return {
      direct,
      // Sin subida directa el único camino es el proxy, que corta antes que el
      // límite propio de la API: el tope efectivo es el menor de los dos.
      maxMb: direct
        ? Math.round(MAX_DIRECT_UPLOAD_BYTES / 1024 / 1024)
        : MAX_PROXY_UPLOAD_MB,
      proxyMaxMb: MAX_PROXY_UPLOAD_MB,
    };
  }

  /** Igual que `uploadCapabilities`, pero exige ser miembro de la organización. */
  async uploadCapabilitiesFor(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.uploadCapabilities();
  }

  /** Lista los archivos adjuntos de un documento (solo metadatos). */
  async listFiles(orgId: string, user: AuthUser, documentId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findDoc(tx, orgId, documentId);
      return tx.documentFile.findMany({
        where: { documentId },
        orderBy: { createdAt: 'desc' },
      });
    });
  }

  /**
   * Pide permiso para que el navegador suba el archivo **directo al almacén**.
   *
   * El proxy `/api/*` de la web corre como función en Vercel, que corta el
   * cuerpo en 4,5 MB. Con este ticket el binario no pasa por ahí: el navegador
   * lo envía al almacén y después confirma aquí, donde se registran los
   * metadatos. Si el adaptador no firma URLs (disco local) se devuelve `null` y
   * el cliente recurre a la subida clásica.
   */
  async requestUploadTicket(
    orgId: string,
    user: AuthUser,
    documentId: string,
    data: { filename: string; mime?: string; size: number },
  ) {
    await this.assertMember(orgId, user);
    if (!this.storage.presignPut) return null;
    if (!data?.size || data.size <= 0) throw new BadRequestException('El archivo está vacío');
    if (data.size > MAX_DIRECT_UPLOAD_BYTES) {
      throw new BadRequestException(
        `El archivo supera el límite de ${Math.round(MAX_DIRECT_UPLOAD_BYTES / 1024 / 1024)} MB`,
      );
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findDoc(tx, orgId, documentId);
    });
    // La cuota se comprueba antes de firmar: no tiene sentido dejar subir un
    // archivo que luego se rechazaría al confirmarlo.
    await this.usage.assertStorage(orgId, data.size);

    const filename = safeFilename(data.filename);
    const mime = data.mime?.trim() || 'application/octet-stream';
    const key = `org-${orgId}/doc-${documentId}/${Date.now()}-${filename}`;
    const ticket = await this.storage.presignPut(key, mime, DIRECT_UPLOAD_TTL_SECONDS);
    if (!ticket) return null;
    return { ...ticket, filename };
  }

  /**
   * Registra el archivo después de que el navegador lo subió al almacén.
   *
   * Se comprueba que el objeto exista y se toma su tamaño real: el cliente no
   * puede declarar un tamaño distinto del que quedó guardado. Si no aparece, la
   * subida no se completó y no se crea la fila.
   */
  async confirmDirectUpload(
    orgId: string,
    user: AuthUser,
    documentId: string,
    data: { key: string; filename: string; mime?: string },
  ) {
    await this.assertMember(orgId, user);
    // La clave la generó esta API, pero se limita a la carpeta del documento:
    // así un `key` manipulado no puede apuntar a otra organización.
    const prefix = `org-${orgId}/doc-${documentId}/`;
    if (!data?.key?.startsWith(prefix)) {
      throw new BadRequestException('La referencia del archivo no corresponde a este documento');
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.findDoc(tx, orgId, documentId);
    });

    const info = this.storage.stat
      ? await this.storage.stat(data.key)
      : await this.statFromBuffer(data.key);
    if (!info || info.size <= 0) {
      throw new BadRequestException('La subida no se completó: el archivo no está en el almacén');
    }
    if (info.size > MAX_DIRECT_UPLOAD_BYTES) {
      await this.storage.remove(data.key).catch(() => undefined);
      throw new BadRequestException(
        `El archivo supera el límite de ${Math.round(MAX_DIRECT_UPLOAD_BYTES / 1024 / 1024)} MB`,
      );
    }
    await this.usage.assertStorage(orgId, info.size);

    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      return tx.documentFile.create({
        data: {
          orgId,
          documentId,
          filename: safeFilename(data.filename),
          blobName: data.key,
          size: info.size,
          // El hash se calcula al subir por la API; en la subida directa el
          // binario no pasa por aquí, así que se guarda sin él y la descarga
          // solo valida lo que haya.
          sha256: null,
          mime: info.mime ?? data.mime ?? 'application/octet-stream',
          uploadedBy: user.sub,
        },
      });
    });
  }

  /** Respaldo de `stat` para adaptadores que no lo implementan (disco local). */
  private async statFromBuffer(key: string) {
    const buffer = await this.storage.get(key);
    return buffer ? { size: buffer.byteLength, mime: null } : null;
  }

  /** Devuelve el binario del archivo adjunto, validando organización y hash. */
  async readFile(orgId: string, user: AuthUser, fileId: string) {
    await this.assertMember(orgId, user);
    const file = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.documentFile.findUnique({ where: { id: fileId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Archivo no encontrado');
      return row;
    });

    const buffer = await this.storage.get(file.blobName);
    if (!buffer) throw new NotFoundException('El archivo ya no está disponible');

    // El hash se guardó al subir: si no coincide, el objeto cambió en disco.
    const sha256 = createHash('sha256').update(buffer).digest('hex');
    if (file.sha256 && file.sha256 !== sha256) {
      this.logger.error(`Integridad rota en archivo de documento ${fileId}`);
      throw new BadRequestException('El archivo no coincide con el registrado');
    }

    return {
      buffer,
      filename: file.filename,
      mime: file.mime ?? 'application/octet-stream',
      size: buffer.byteLength,
    };
  }

  /** Quita un archivo adjunto y borra el objeto del almacenamiento. */
  async removeFile(orgId: string, user: AuthUser, fileId: string) {
    await this.assertMember(orgId, user);
    const file = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.documentFile.findUnique({ where: { id: fileId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Archivo no encontrado');
      await tx.documentFile.delete({ where: { id: fileId } });
      return row;
    });

    await this.storage.remove(file.blobName).catch((error: Error) => {
      this.logger.warn(`No se pudo borrar ${file.blobName}: ${error.message}`);
    });
    return { ok: true, deleted: fileId };
  }

  /** Agrega una nueva versión a un documento publicado/obsoleto. */
  async newVersion(orgId: string, user: AuthUser, documentId: string, content: string, changesNote?: string) {    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const doc = await tx.document.findUnique({ where: { id: documentId } });
      if (!doc || doc.orgId !== orgId) throw new NotFoundException('Documento no encontrado');
      const lastVersion = await tx.documentVersion.findFirst({ where: { documentId }, orderBy: { createdAt: 'desc' } });
      const next = lastVersion ? `v${parseInt(lastVersion.version.slice(1), 10) + 1}` : 'v1';
      await tx.documentVersion.create({
        data: {
          orgId,
          documentId,
          version: next,
          content,
          checksum: createHash('sha256').update(content).digest('hex'),
          authorId: user.sub,
          changesNote: changesNote ?? `Versión ${next}`,
        },
      });
      return tx.document.update({ where: { id: documentId }, data: { status: DOC_STATUS.IN_REVIEW } });
    });
  }

  /** Historial completo de un documento (versiones + flujo + distribución + firmas). */
  async history(orgId: string, user: AuthUser, documentId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const doc = await tx.document.findUnique({
        where: { id: documentId },
        include: {
          versions: { orderBy: { createdAt: 'desc' } },
          workflowSteps: { orderBy: { at: 'asc' } },
          distributions: true,
          signatures: { orderBy: { signedAt: 'desc' } },
          files: { orderBy: { createdAt: 'desc' } },
        },
      });
      if (!doc || doc.orgId !== orgId) throw new NotFoundException('Documento no encontrado');
      return doc;
    });
  }

  /** Actualiza datos generales del documento (no el contenido: eso es una versión). */  async update(
    orgId: string,
    user: AuthUser,
    documentId: string,
    data: {
      title?: string;
      type?: string;
      areaId?: string | null;
      validityUntil?: string | null;
      reviewDate?: string | null;
      sourceProvider?: string | null;
      sourceRef?: string | null;
      /** Sedes a las que aplica; una lista vacía significa "toda la organización". */
      branchIds?: string[];
    },
  ) {
    await this.assertMember(orgId, user);
    // Las fechas se validan solo si llegan: `undefined` significa "no tocar" y
    // `null` significa "borrar la fecha".
    const validityUntil =
      data.validityUntil === undefined ? undefined : this.parseDate(data.validityUntil, 'La fecha de vigencia');
    const reviewDate =
      data.reviewDate === undefined ? undefined : this.parseDate(data.reviewDate, 'La fecha de revisión');
    this.assertDateOrder(validityUntil, reviewDate);

    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      // `findDoc` valida que el documento exista y sea de la organización.
      await this.findDoc(tx, orgId, documentId);
      if (data.areaId) await this.assertArea(tx, orgId, data.areaId);
      const branchIds =
        data.branchIds === undefined ? undefined : await this.assertBranches(tx, orgId, data.branchIds);
      // El orden entre dos fechas ya guardadas también debe cumplirse cuando
      // solo se envía una de las dos.
      if (validityUntil !== undefined || reviewDate !== undefined) {
        const current = await tx.document.findUnique({
          where: { id: documentId },
          select: { validityUntil: true, reviewDate: true },
        });
        this.assertDateOrder(
          validityUntil === undefined ? current?.validityUntil ?? null : validityUntil,
          reviewDate === undefined ? current?.reviewDate ?? null : reviewDate,
        );
      }
      return tx.document.update({
        where: { id: documentId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.type !== undefined ? { type: data.type } : {}),
          ...(data.areaId !== undefined ? { areaId: data.areaId } : {}),
          ...(validityUntil !== undefined ? { validityUntil } : {}),
          ...(reviewDate !== undefined ? { reviewDate } : {}),
          ...(data.sourceProvider !== undefined
            ? { sourceProvider: data.sourceProvider?.trim() || null }
            : {}),
          ...(data.sourceRef !== undefined ? { sourceRef: data.sourceRef?.trim() || null } : {}),
          ...(branchIds !== undefined ? { branchIds } : {}),
        },
      });
    });
  }

  /**
   * Convierte una fecha de entrada en `Date`. Acepta ISO completo y `AAAA-MM-DD`
   * (lo que devuelve un `<input type="date">`), y rechaza una cadena inválida en
   * lugar de guardar `Invalid Date` en la base.
   */
  private parseDate(value: string | null | undefined, label: string): Date | null {
    if (value == null || value === '') return null;
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) throw new BadRequestException(`${label} no es una fecha válida`);
    return date;
  }

  /**
   * La revisión debe caer antes (o el mismo día) del fin de vigencia: no tiene
   * sentido revisar un documento cuando ya caducó.
   */
  private assertDateOrder(validityUntil?: Date | null, reviewDate?: Date | null) {
    if (validityUntil && reviewDate && reviewDate > validityUntil) {
      throw new BadRequestException(
        'La fecha de revisión no puede ser posterior al fin de vigencia',
      );
    }
  }

  /**
   * Elimina un documento solo mientras sea borrador: publicado u obsoleto forma
   * parte del expediente y se marca `OBSOLETE` en lugar de borrarse.
   */
  async remove(orgId: string, user: AuthUser, documentId: string) {
    await this.assertMember(orgId, user);
    const blobs = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const doc = await this.findDoc(tx, orgId, documentId);
      if (doc.status !== DOC_STATUS.DRAFT && doc.status !== DOC_STATUS.OBSOLETE) {
        throw new BadRequestException(
          'Solo se eliminan borradores u obsoletos; un documento vigente debe declararse obsoleto',
        );
      }
      // El borrado en cascada se lleva las filas de `DocumentFile`, pero no los
      // objetos del almacén: se anotan aquí para retirarlos después.
      const files = await tx.documentFile.findMany({
        where: { documentId },
        select: { blobName: true },
      });
      await tx.document.delete({ where: { id: documentId } });
      return files.map((f) => f.blobName);
    });

    for (const blob of blobs) {
      await this.storage.remove(blob).catch((error: Error) => {
        this.logger.warn(`No se pudo borrar ${blob}: ${error.message}`);
      });
    }
    return { ok: true, deleted: documentId };
  }

  /** Marca el documento como obsoleto (retiro controlado). */
  async obsolete(orgId: string, user: AuthUser, documentId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findDoc(tx, orgId, documentId);
      await tx.docWorkflowStep.create({
        data: { orgId, documentId, step: 'OBSOLETE', assigneeId: user.sub, action: 'OBSOLETE' },
      });
      return tx.document.update({ where: { id: documentId }, data: { status: DOC_STATUS.OBSOLETE } });
    });
  }

  /** Revoca una firma (p. ej. aceptación errónea registrada sobre otra versión). */
  async revokeSignature(orgId: string, user: AuthUser, signatureId: string, reason?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const sig = await tx.documentSignature.findUnique({ where: { id: signatureId } });
      if (!sig || sig.orgId !== orgId) throw new NotFoundException('Firma no encontrada');
      await tx.documentSignature.delete({ where: { id: signatureId } });
      await tx.docWorkflowStep.create({
        data: {
          orgId,
          documentId: sig.documentId,
          step: 'SIGNATURE_REVOKED',
          assigneeId: user.sub,
          action: 'REVOKED',
          comment: reason ?? `Firma ${sig.kind} de ${sig.signerEmail ?? sig.signerId ?? 'desconocido'} revocada`,
        },
      });
      return { ok: true, revoked: signatureId };
    });
  }

  /**
   * Registra la entrega del documento a un área o a una persona concreta.
   *
   * ISO 9001 7.5.3 pide controlar la distribución de la información
   * documentada; el registro ya existía para la publicación automática, pero
   * no había forma de dar de alta una entrega ni de consultarla por documento.
   */
  async distribute(
    orgId: string,
    user: AuthUser,
    documentId: string,
    data: { areaId?: string | null; userId?: string | null; channel?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const doc = await this.findDoc(tx, orgId, documentId);
      if (doc.status !== DOC_STATUS.PUBLISHED) {
        throw new BadRequestException('Solo se distribuye un documento publicado');
      }
      // Un destino por entrega: o un área o una persona. Sin destino, la fila no
      // dice nada y no serviría como evidencia de distribución.
      if (!data.areaId && !data.userId) {
        throw new BadRequestException('Indica el área o la persona que recibe el documento');
      }
      if (data.areaId) await this.assertArea(tx, orgId, data.areaId);
      if (data.userId) {
        const member = await tx.orgMember.findFirst({
          where: { orgId, userId: data.userId, status: 'ACTIVE' },
          select: { id: true },
        });
        if (!member) throw new BadRequestException('La persona indicada no es miembro activo de la organización');
      }
      return tx.documentDistribution.create({
        data: {
          orgId,
          documentId,
          areaId: data.areaId ?? null,
          userId: data.userId ?? null,
          channel: data.channel?.trim() || 'SISTEMA',
        },
      });
    });
  }

  /** Quita una entrega registrada por error. */
  async undoDistribution(orgId: string, user: AuthUser, distributionId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const row = await tx.documentDistribution.findUnique({ where: { id: distributionId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Distribución no encontrada');
      await tx.documentDistribution.delete({ where: { id: distributionId } });
      return { ok: true, deleted: distributionId };
    });
  }

  /**
   * Inventario en CSV para revisión externa o migración.
   *
   * Se exporta el inventario (metadatos), no el contenido: es lo que pide una
   * auditoría para verificar que existe control documental, y evita sacar todo
   * el texto del sistema de una sola vez.
   */
  async exportCsv(orgId: string, user: AuthUser, filters: DocumentFilters = {}) {
    await this.assertMember(orgId, user);
    const where = this.whereOf(orgId, filters);

    // Se lee en una sola transacción: recorrer el listado página a página
    // exportaría una foto distinta en cada página si alguien edita mientras
    // tanto. Se pide una fila de más para detectar el exceso sin exportar un
    // CSV cortado en silencio; el tope evita cargar un inventario entero en
    // memoria.
    const { items, total } = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [items, total] = await Promise.all([
        tx.document.findMany({
          where,
          include: {
            versions: { orderBy: { createdAt: 'desc' }, take: 1 },
            signatures: { orderBy: { signedAt: 'desc' } },
          },
          orderBy:
            filters.due === 'overdue' || filters.due === 'soon'
              ? [{ reviewDate: 'asc' }, { code: 'asc' }]
              : { updatedAt: 'desc' },
          take: MAX_EXPORT_ROWS + 1,
        }),
        tx.document.count({ where }),
      ]);
      return { items, total };
    });

    if (total > MAX_EXPORT_ROWS) {
      throw new BadRequestException(
        `El inventario filtrado tiene ${total} documentos y la exportación admite ${MAX_EXPORT_ROWS}. Filtra por área, tipo o estado para exportarlo por partes.`,
      );
    }

    const areaIds = [...new Set(items.map((d) => d.areaId).filter((v): v is string => !!v))];
    const areas = areaIds.length
      ? await this.prisma.$transaction(async (tx) => {
          await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
          return tx.orgArea.findMany({
            where: { orgId, id: { in: areaIds } },
            select: { id: true, name: true },
          });
        })
      : [];
    const areaName = new Map(areas.map((a) => [a.id, a.name]));

    const header = [
      'Código',
      'Título',
      'Tipo',
      'Estado',
      'Versión',
      'Área',
      'Vigencia hasta',
      'Revisión',
      'Proveedor',
      'Referencia externa',
      'Creado',
    ];
    const rows = items.map((d) => [
      d.code,
      d.title,
      d.type,
      d.status,
      d.versions[0]?.version ?? '',
      d.areaId ? areaName.get(d.areaId) ?? '' : '',
      d.validityUntil ? this.toIsoDate(d.validityUntil) : '',
      d.reviewDate ? this.toIsoDate(d.reviewDate) : '',
      d.sourceProvider ?? '',
      d.sourceRef ?? '',
      this.toIsoDate(d.createdAt),
    ]);

    return [header, ...rows].map((row) => row.map((cell) => this.csvCell(cell)).join(',')).join('\r\n');
  }

  /** `AAAA-MM-DD` sin desplazamiento de zona horaria. */
  private toIsoDate(date: Date): string {
    return date.toISOString().slice(0, 10);
  }

  /**
   * Escapa una celda CSV. Se antepone un apóstrofo a los valores que empiezan
   * por `=`, `+`, `-` o `@`: son fórmulas en Excel y una hoja de cálculo
   * abriría contenido del sistema como código.
   */
  private csvCell(value: string): string {
    const safe = /^[=+\-@]/.test(value) ? `'${value}` : value;
    return `"${safe.replace(/"/g, '""')}"`;
  }

  /** Catálogo de plantillas de la organización (opcional: por tipo). */
  async listTemplates(orgId: string, user: AuthUser, kind?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.template.findMany({ where: { orgId, ...(kind ? { kind } : {}) }, orderBy: { code: 'asc' } });
    });
  }

  /** Crea un documento a partir de una plantilla (con contenido prefabricado). */
  async createFromTemplate(orgId: string, user: AuthUser, templateId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const tpl = await tx.template.findUnique({ where: { id: templateId } });
      if (!tpl || tpl.orgId !== orgId) throw new NotFoundException('Plantilla no encontrada');

      // Código único (código de plantilla + sufijo). Se parte del mayor sufijo
      // existente: contar documentos reutilizaría un código si alguno se borró.
      const prefix = `${tpl.code}-`;
      const used = await tx.document.findMany({
        where: { orgId, code: { startsWith: prefix } },
        select: { code: true },
      });
      const code = nextSequentialCode(prefix, used.map((row) => row.code), 2);
      const content = this.templateToText(tpl.content as { sections?: { heading: string; body: string }[] });

      const doc = await tx.document.create({
        data: { orgId, code, title: tpl.title, type: tpl.kind, status: DOC_STATUS.DRAFT, ownerId: user.sub },
      });
      await tx.documentVersion.create({
        data: { orgId, documentId: doc.id, version: 'v1', content, checksum: createHash('sha256').update(content).digest('hex'), authorId: user.sub, changesNote: `Creado desde plantilla ${tpl.code}` },
      });
      return doc;
    });
  }

  /**
   * Crea un aviso de revisión para el responsable del documento.
   *
   * Es explícito y no un proceso programado: la instalación no tiene
   * planificador y un aviso repetido cada vez que alguien abre la vista sería
   * ruido. Se registra una notificación por documento y día, de modo que pulsar
   * dos veces el mismo día no duplica el aviso.
   */
  async notifyReviewDue(orgId: string, user: AuthUser, documentId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const doc = await this.findDoc(tx, orgId, documentId);
      const full = await tx.document.findUnique({
        where: { id: documentId },
        select: { code: true, title: true, reviewDate: true, ownerId: true },
      });
      if (!full?.reviewDate) throw new BadRequestException('El documento no tiene fecha de revisión');
      if (doc.status === DOC_STATUS.OBSOLETE) {
        throw new BadRequestException('Un documento obsoleto no requiere revisión');
      }

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const already = await tx.notification.findFirst({
        where: {
          orgId,
          type: 'DOC_REVIEW',
          entity: 'document',
          entityId: documentId,
          createdAt: { gte: today },
        },
        select: { id: true },
      });
      if (already) return already;

      const overdue = full.reviewDate < new Date();
      return tx.notification.create({
        data: {
          orgId,
          userId: full.ownerId ?? user.sub,
          type: 'DOC_REVIEW',
          title: overdue
            ? `Revisión vencida: ${full.code}`
            : `Revisión próxima: ${full.code}`,
          body: `${full.title} — revisión prevista para ${full.reviewDate.toISOString().slice(0, 10)}.`,
          entity: 'document',
          entityId: documentId,
        },
      });
    });
  }

  private templateToText(tpl: { sections?: { heading: string; body: string }[] } | null | undefined): string {
    if (!tpl?.sections) return '';
    return tpl.sections.map((s) => `${s.heading.toUpperCase()}\n${s.body}`).join('\n\n');
  }

  /**
   * Comprueba que el área pertenezca a la organización activa. Sin esto un
   * `areaId` de otra organización quedaría guardado y rompería la segmentación
   * por área al filtrar.
   */
  private async assertArea(
    tx: { orgArea: { findFirst: (a: { where: { id: string; orgId: string } }) => Promise<{ id: string } | null> } },
    orgId: string,
    areaId: string,
  ) {
    const area = await tx.orgArea.findFirst({ where: { id: areaId, orgId } });
    if (!area) throw new BadRequestException('El área indicada no existe en esta organización');
    return area;
  }

  /**
   * Valida las sedes elegidas y devuelve la lista sin duplicados.
   *
   * Una sede de otra organización no debe poder asignarse aunque su id llegue en
   * el cuerpo: se consultan todas de golpe y se compara el número de encontradas.
   */
  private async assertBranches(
    tx: { orgBranch: { findMany: (a: { where: { id: { in: string[] }; orgId: string } }) => Promise<{ id: string }[]> } },
    orgId: string,
    branchIds: string[] | undefined,
  ): Promise<string[]> {
    const ids = [...new Set((branchIds ?? []).filter(Boolean))];
    if (ids.length === 0) return [];
    const found = await tx.orgBranch.findMany({ where: { id: { in: ids }, orgId } });
    if (found.length !== ids.length) {
      throw new BadRequestException('Alguna de las sedes indicadas no existe en esta organización');
    }
    return ids;
  }

  private async findDoc(
    tx: { document: { findUnique: (a: { where: { id: string } }) => Promise<{ orgId: string; status: string } | null> } },
    orgId: string,
    documentId: string,
  ) {
    const doc = await tx.document.findUnique({ where: { id: documentId } });
    if (!doc || doc.orgId !== orgId) throw new NotFoundException('Documento no encontrado');
    return doc;
  }
}

/**
 * Nombre de archivo sin rutas ni caracteres problemáticos.
 *
 * Se conservan letras acentuadas (`\p{L}`) a propósito: el nombre se vuelve a
 * mostrar al descargar y un "Pol_tica.pdf" no es el archivo que subió nadie.
 * Fuera quedan las barras, los caracteres reservados de Windows y los de control.
 */
function safeFilename(name: string): string {
  const base = (name.split(/[/\\]/).pop() ?? 'archivo')
    .replace(/[^\p{L}\p{N}._\- ()]/gu, '_')
    .trim();
  return base.slice(-120) || 'archivo';
}
