import { BadRequestException, NotFoundException } from '@nestjs/common';
import { createHash } from 'crypto';
import { DOC_TYPES, DocumentsService } from './documents.service';
import { PrismaService } from '../../prisma/prisma.service';
import { TenancyService } from '../../tenancy/tenancy.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { contentHashOf, signaturePayload } from '../../common/document-signature';
import type { StoragePort } from '../../common/storage/storage.port';
import type { UsageService } from '../billing/usage.service';

const user: AuthUser = {
  sub: 'u1',
  email: 'persona@org.mx',
  name: 'Persona',
  roles: ['controlador_doc'],
  orgId: 'o1',
};

const content = 'Contenido del procedimiento.';

/** Documento publicado con una versión y, opcionalmente, una firma guardada. */
function build(
  opts: {
    signature?: Record<string, unknown> | null;
    content?: string | null;
    checksum?: string | null;
    /** Área existente en la organización; `null` simula un área ajena o inexistente. */
    area?: { id: string } | null;
    /** Miembro activo que recibe la distribución; `null` simula un extraño. */
    member?: { id: string } | null;
    /** Documento devuelto por `findUnique` (por defecto publicado). */
    document?: Record<string, unknown>;
    /** Sedes existentes; `undefined` = todas las que se pidan. */
    branches?: { id: string }[];
    /** Sobrescribe campos del archivo adjunto simulado. */
    file?: Record<string, unknown>;
    /** `true` simula un almacenamiento que firma URLs (Azure Blob). */
    presign?: boolean;
    /** Tamaño que reporta `stat` en la subida directa. */
    storedSize?: number;
    /** Filas que devuelve `list()`. */
    listItems?: Record<string, unknown>[];
    /**
     * Total real del inventario simulado. Si se indica, `findMany` recorta las
     * filas según `skip`/`take` y `count` devuelve este total: así se reproduce
     * un inventario de varias páginas.
     */
    listTotal?: number;
    areas?: { id: string; name: string }[];
    notification?: { id: string } | null;
    distribution?: { id: string; orgId: string } | null;
  } = {},
) {
  const version = {
    id: 'v1',
    documentId: 'd1',
    version: 'v1',
    content: opts.content === undefined ? content : opts.content,
    // Por omisión el checksum coincide con el contenido; `null` simula una fila
    // antigua sin checksum y un valor fijo simula una copia que quedó atrás.
    checksum:
      opts.checksum === undefined
        ? opts.content === undefined
          ? createHash('sha256').update(content).digest('hex')
          : null
        : opts.checksum,
  };

  const tx = {
    $executeRaw: jest.fn().mockResolvedValue(undefined),
    document: {
      // La comprobación de código único usa `orgId_code`; el resto busca por id.
      findUnique: jest
        .fn()
        .mockImplementation(({ where }: { where: Record<string, unknown> }) =>
          Promise.resolve(
            where.orgId_code
              ? null
              : { id: 'd1', orgId: 'o1', status: 'PUBLISHED', ...(opts.document ?? {}) },
          ),
        ),
      findMany: jest.fn().mockImplementation(({ skip = 0, take }: { skip?: number; take?: number }) => {
        const rows = opts.listItems ?? [];
        return Promise.resolve(take === undefined ? rows : rows.slice(skip, skip + take));
      }),
      count: jest.fn().mockResolvedValue(opts.listTotal ?? opts.listItems?.length ?? 0),
      update: jest.fn().mockImplementation(({ where, data }) => Promise.resolve({ id: where.id, ...data })),
      create: jest.fn().mockImplementation(({ data }) => Promise.resolve({ id: 'dnew', ...data })),
      delete: jest.fn().mockResolvedValue({}),
    },
    orgArea: {
      findFirst: jest
        .fn()
        .mockResolvedValue(opts.area === undefined ? { id: 'a1' } : opts.area),
      findMany: jest.fn().mockResolvedValue(opts.areas ?? [{ id: 'a1', name: 'Calidad' }]),
    },
    orgMember: {
      findFirst: jest.fn().mockResolvedValue(opts.member === undefined ? { id: 'm1' } : opts.member),
    },
    notification: {
      findFirst: jest.fn().mockResolvedValue(opts.notification ?? null),
      create: jest.fn().mockImplementation(({ data }) => Promise.resolve({ id: 'n1', ...data })),
    },
    documentVersion: {
      findFirst: jest.fn().mockResolvedValue(version),
      create: jest.fn().mockImplementation(({ data }) => Promise.resolve({ id: 'vnew', ...data })),
    },
    documentSignature: {
      findUnique: jest.fn().mockResolvedValue(opts.signature ?? null),
      findFirst: jest.fn().mockResolvedValue(opts.signature ?? null),
      create: jest.fn().mockImplementation(({ data }) => Promise.resolve({ id: 's1', ...data })),
      delete: jest.fn().mockResolvedValue({}),
    },
    documentDistribution: {
      create: jest.fn().mockImplementation(({ data }) => Promise.resolve({ id: 'x1', ...data })),
      findUnique: jest
        .fn()
        .mockResolvedValue(opts.distribution === undefined ? { id: 'x1', orgId: 'o1' } : opts.distribution),
      delete: jest.fn().mockResolvedValue({}),
    },
    docWorkflowStep: { create: jest.fn().mockResolvedValue({}) },
    user: {
      findUnique: jest.fn().mockResolvedValue({ id: 'u1', name: 'Persona', email: 'persona@org.mx' }),
    },
    // Sedes: por omisión acepta las que se le piden. `branches` permite simular
    // una sede ajena devolviendo menos filas que ids.
    orgBranch: {
      findMany: jest.fn().mockImplementation(({ where }: { where: { id: { in: string[] } } }) =>
        Promise.resolve(opts.branches ?? where.id.in.map((id) => ({ id }))),
      ),
    },
    documentFile: {
      create: jest.fn().mockImplementation(({ data }) => Promise.resolve({ id: 'f1', ...data })),
      findUnique: jest.fn().mockImplementation(({ where }: { where: { id: string } }) =>
        Promise.resolve(
          where.id === 'missing'
            ? null
            : {
                id: where.id,
                orgId: 'o1',
                documentId: 'd1',
                filename: 'politica.pdf',
                blobName: 'org-o1/doc-d1/politica.pdf',
                size: 3,
                sha256: createHash('sha256').update('abc').digest('hex'),
                mime: 'application/pdf',
                ...(opts.file ?? {}),
              },
        ),
      ),
      findMany: jest.fn().mockResolvedValue([]),
      delete: jest.fn().mockResolvedValue({}),
    },
  };

  const prisma = {
    $transaction: jest.fn().mockImplementation((fn: (t: typeof tx) => unknown) => fn(tx)),
  } as unknown as PrismaService;

  const tenancy = { isMember: jest.fn().mockResolvedValue(true) } as unknown as TenancyService;

  const storage = {
    put: jest.fn().mockImplementation((key: string) =>
      Promise.resolve({
        key,
        size: 3,
        sha256: createHash('sha256').update('abc').digest('hex'),
        mime: 'application/pdf',
      }),
    ),
    get: jest.fn().mockResolvedValue(Buffer.from('abc')),
    remove: jest.fn().mockResolvedValue(undefined),
    exists: jest.fn().mockResolvedValue(true),
    // Por omisión el almacenamiento **no** firma URLs (disco local). Las pruebas
    // de subida directa activan `presign: true`.
    ...(opts.presign
      ? {
          presignPut: jest.fn().mockImplementation((key: string, mime: string) =>
            Promise.resolve({
              key,
              url: `https://storage.test/${key}?sig=abc`,
              method: 'PUT' as const,
              headers: { 'x-ms-blob-type': 'BlockBlob', 'Content-Type': mime },
              expiresAt: new Date(Date.now() + 900_000),
            }),
          ),
          stat: jest.fn().mockImplementation(() =>
            Promise.resolve({ size: opts.storedSize ?? 4_000_000, mime: 'application/pdf' }),
          ),
        }
      : {}),
  } as unknown as StoragePort;

  const usage = { assertStorage: jest.fn().mockResolvedValue(undefined) } as unknown as UsageService;

  return { service: new DocumentsService(prisma, tenancy, storage, usage), tx, storage, usage };
}

describe('DocumentsService — firma electrónica', () => {
  it('la firma de aceptación verifica con el mismo esquema que la creó', async () => {
    const { service, tx } = build();
    const created = await service.accept('o1', user, 'd1');
    const data = (tx.documentSignature.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;

    expect(data.contentHash).toBe(contentHashOf({ content }));
    expect(data.signature).toBe(
      signaturePayload(data.contentHash as string, 'u1', 'ACCEPTANCE', data.signedAt as Date),
    );
    expect(created.id).toBe('s1');
  });

  it('rechaza aceptar un documento sin contenido', async () => {
    const { service } = build({ content: null });
    await expect(service.accept('o1', user, 'd1')).rejects.toBeInstanceOf(BadRequestException);
  });

  it('la firma de aceptación es idempotente: repetirla no crea otra', async () => {
    const existing = { id: 's0', kind: 'ACCEPTANCE' };
    const { service, tx } = build({ signature: existing });
    const result = await service.accept('o1', user, 'd1');

    expect(result).toBe(existing);
    expect(tx.documentSignature.create).not.toHaveBeenCalled();
  });

  it('verifica una firma válida cuyo contenido sigue intacto', async () => {
    const signedAt = new Date('2026-08-20T10:00:00Z');
    const hash = createHash('sha256').update(content).digest('hex');
    const signature = signaturePayload(hash, 'u1', 'APPROVAL', signedAt);
    const { service } = build({
      signature: {
        id: 's1',
        orgId: 'o1',
        documentId: 'd1',
        version: 'v1',
        signerId: 'u1',
        signerName: 'Persona',
        kind: 'APPROVAL',
        contentHash: hash,
        signature,
        signedAt,
      },
    });

    const result = await service.verifySignature('o1', user, 's1');
    expect(result).toMatchObject({ valid: true, contentIntact: true, version: 'v1' });
  });

  it('marca la firma válida pero detecta que el contenido fue alterado', async () => {
    const signedAt = new Date('2026-08-20T10:00:00Z');
    const signedHash = createHash('sha256').update(content).digest('hex');
    const signature = signaturePayload(signedHash, 'u1', 'APPROVAL', signedAt);
    // La versión en base de datos ya no coincide con lo firmado.
    const { service } = build({
      content: 'Contenido modificado después de firmar.',
      signature: {
        id: 's1',
        orgId: 'o1',
        documentId: 'd1',
        version: 'v1',
        signerId: 'u1',
        signerName: 'Persona',
        kind: 'APPROVAL',
        contentHash: signedHash,
        signature,
        signedAt,
      },
    });

    const result = await service.verifySignature('o1', user, 's1');
    // La firma está bien formada, pero el texto ya no es el firmado.
    expect(result).toMatchObject({ valid: true, contentIntact: false });
  });

  it('detecta la alteración aunque el checksum almacenado siga siendo el original', async () => {
    // Caso real de manipulación: alguien cambia el texto en la base de datos y
    // deja la columna `checksum` con el valor viejo. Si la verificación confiara
    // en ese checksum, la alteración pasaría desapercibida.
    const signedAt = new Date('2026-08-20T10:00:00Z');
    const signedHash = createHash('sha256').update(content).digest('hex');
    const signature = signaturePayload(signedHash, 'u1', 'APPROVAL', signedAt);
    const { service } = build({
      content: 'TEXTO MANIPULADO DIRECTAMENTE EN LA BD',
      checksum: signedHash,
      signature: {
        id: 's1',
        orgId: 'o1',
        documentId: 'd1',
        version: 'v1',
        signerId: 'u1',
        signerName: 'Persona',
        kind: 'APPROVAL',
        contentHash: signedHash,
        signature,
        signedAt,
      },
    });

    const result = await service.verifySignature('o1', user, 's1');
    expect(result).toMatchObject({ valid: true, contentIntact: false });
  });

  it('invalida una firma cuyo contenido registrado fue manipulado', async () => {
    const signedAt = new Date('2026-08-20T10:00:00Z');
    const hash = createHash('sha256').update(content).digest('hex');
    const { service } = build({
      signature: {
        id: 's1',
        orgId: 'o1',
        documentId: 'd1',
        version: 'v1',
        signerId: 'u1',
        signerName: 'Persona',
        kind: 'APPROVAL',
        contentHash: hash,
        signature: 'firma-falsificada',
        signedAt,
      },
    });

    const result = await service.verifySignature('o1', user, 's1');
    expect(result.valid).toBe(false);
  });

  it('una firma sin firmante no puede darse por válida', async () => {
    const { service } = build({
      signature: {
        id: 's1',
        orgId: 'o1',
        documentId: 'd1',
        version: 'v1',
        signerId: null,
        signerName: null,
        kind: 'APPROVAL',
        contentHash: 'x',
        signature: 'y',
        signedAt: new Date(),
      },
    });

    const result = await service.verifySignature('o1', user, 's1');
    expect(result.valid).toBe(false);
    expect(result.contentIntact).toBe(false);
  });
});

describe('DocumentsService — área responsable', () => {
  it('guarda el área cuando pertenece a la organización', async () => {
    const { service, tx } = build();
    await service.create('o1', user, {
      code: 'PR-99',
      title: 'Procedimiento',
      content,
      areaId: 'a1',
    });

    const data = (tx.document.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data.areaId).toBe('a1');
    expect(tx.orgArea.findFirst).toHaveBeenCalledWith({ where: { id: 'a1', orgId: 'o1' } });
  });

  it('rechaza un área de otra organización al crear', async () => {
    // `orgArea.findFirst` ya filtra por orgId: si el área no aparece, es ajena.
    const { service, tx } = build({ area: null });
    await expect(
      service.create('o1', user, { code: 'PR-99', title: 'Procedimiento', content, areaId: 'ajena' }),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(tx.document.create).not.toHaveBeenCalled();
  });

  it('rechaza un área de otra organización al actualizar', async () => {
    const { service } = build({ area: null });
    await expect(
      service.update('o1', user, 'd1', { areaId: 'ajena' }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('permite quitar el área asignada', async () => {
    const { service, tx } = build();
    await service.update('o1', user, 'd1', { areaId: null });

    // Sin área no se consulta la tabla de áreas: `null` es un valor legítimo.
    expect(tx.orgArea.findFirst).not.toHaveBeenCalled();
    const data = (tx.document.update.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data.areaId).toBeNull();
  });
});

describe('DocumentsService — tipos documentales', () => {
  it('acepta proceso, instructivo y guía como tipo al crear', async () => {
    for (const type of ['PROCESO', 'INSTRUCTIVO', 'GUIA']) {
      const { service, tx } = build();
      await service.create('o1', user, { code: `SD-${type}`, title: 'Documento', type, content });

      const data = (tx.document.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
      expect(data.type).toBe(type);
    }
  });

  it('mantiene el catálogo sin duplicados', () => {
    expect(new Set(DOC_TYPES).size).toBe(DOC_TYPES.length);
  });
});

describe('DocumentsService — vigencia y revisión', () => {
  it('guarda vigencia y revisión al crear', async () => {
    const { service, tx } = build();
    await service.create('o1', user, {
      code: 'PR-90',
      title: 'Procedimiento',
      content,
      validityUntil: '2027-06-30',
      reviewDate: '2027-06-01',
    });

    const data = (tx.document.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data.validityUntil).toEqual(new Date('2027-06-30'));
    expect(data.reviewDate).toEqual(new Date('2027-06-01'));
  });

  it('rechaza una revisión posterior al fin de vigencia', async () => {
    const { service, tx } = build();
    await expect(
      service.create('o1', user, {
        code: 'PR-91',
        title: 'Procedimiento',
        content,
        validityUntil: '2027-01-31',
        reviewDate: '2027-03-01',
      }),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(tx.document.create).not.toHaveBeenCalled();
  });

  it('rechaza una fecha inválida en lugar de guardar Invalid Date', async () => {
    const { service } = build();
    await expect(
      service.update('o1', user, 'd1', { reviewDate: 'no-es-fecha' }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('compara la fecha nueva con la ya guardada al actualizar solo una', async () => {
    // Vigencia existente en junio; se intenta revisar en agosto.
    const { service } = build({
      document: { validityUntil: new Date('2027-06-30') },
    });
    await expect(
      service.update('o1', user, 'd1', { reviewDate: '2027-08-01' }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('permite borrar las fechas con null', async () => {
    const { service, tx } = build();
    await service.update('o1', user, 'd1', { reviewDate: null, validityUntil: null });

    const data = (tx.document.update.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data.reviewDate).toBeNull();
    expect(data.validityUntil).toBeNull();
  });
});

describe('DocumentsService — distribución', () => {
  it('registra la entrega a un área de un documento publicado', async () => {
    const { service, tx } = build();
    await service.distribute('o1', user, 'd1', { areaId: 'a1' });

    const data = (tx.documentDistribution.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data).toMatchObject({ orgId: 'o1', documentId: 'd1', areaId: 'a1' });
  });

  it('no distribuye un documento que no está publicado', async () => {
    const { service } = build({ document: { status: 'DRAFT' } });
    await expect(service.distribute('o1', user, 'd1', { areaId: 'a1' })).rejects.toBeInstanceOf(
      BadRequestException,
    );
  });

  it('exige un destino: ni área ni persona deja una entrega sin significado', async () => {
    const { service } = build();
    await expect(service.distribute('o1', user, 'd1', {})).rejects.toBeInstanceOf(BadRequestException);
  });

  it('rechaza distribuir a alguien que no es miembro activo', async () => {
    const { service } = build({ member: null });
    await expect(
      service.distribute('o1', user, 'd1', { userId: 'u-externo' }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });
});

describe('DocumentsService — exportación e inventario', () => {
  it('exporta CSV con cabecera y una fila por documento', async () => {
    const { service } = build({
      listItems: [
        {
          id: 'd1',
          code: 'PR-01',
          title: 'Procedimiento',
          type: 'PROCEDIMIENTO',
          status: 'PUBLISHED',
          areaId: 'a1',
          validityUntil: new Date('2027-06-30'),
          reviewDate: new Date('2027-06-01'),
          sourceProvider: null,
          sourceRef: null,
          createdAt: new Date('2026-01-15'),
          versions: [{ version: 'v2' }],
        },
      ],
    });

    const csv = await service.exportCsv('o1', user);
    const [header, row] = csv.split('\r\n');
    expect(header).toContain('Código');
    expect(row).toContain('"PR-01"');
    expect(row).toContain('"v2"');
    // El área se resuelve a su nombre, no al identificador.
    expect(row).toContain('"Calidad"');
    expect(row).toContain('"2027-06-30"');
  });

  it('neutraliza fórmulas: un título que empieza por = no se ejecuta en Excel', async () => {
    const { service } = build({
      listItems: [
        {
          id: 'd1',
          code: 'PR-02',
          title: '=HYPERLINK("http://malicioso","clic")',
          type: 'PROCEDIMIENTO',
          status: 'DRAFT',
          areaId: null,
          validityUntil: null,
          reviewDate: null,
          sourceProvider: null,
          sourceRef: null,
          createdAt: new Date('2026-01-15'),
          versions: [],
        },
      ],
    });

    const csv = await service.exportCsv('o1', user);
    expect(csv).toContain(`"'=HYPERLINK`);
    // El valor sigue entre comillas y con las internas duplicadas.
    expect(csv).toContain(`""http://malicioso""`);
  });

  it('exporta todas las páginas: un inventario de 250 filas no se corta en 200', async () => {
    const rows = Array.from({ length: 250 }, (_, i) => ({
      id: `d${i}`,
      code: `PR-${i}`,
      title: `Documento ${i}`,
      type: 'PROCEDIMIENTO',
      status: 'PUBLISHED',
      areaId: null,
      validityUntil: null,
      reviewDate: null,
      sourceProvider: null,
      sourceRef: null,
      createdAt: new Date('2026-01-15'),
      versions: [{ version: 'v1' }],
    }));
    const { service } = build({ listItems: rows });

    const csv = await service.exportCsv('o1', user);
    // Cabecera + 250 filas: el resto de la exportación no se pierde.
    expect(csv.split('\r\n')).toHaveLength(251);
    expect(csv).toContain('"PR-0"');
    expect(csv).toContain('"PR-249"');
  });

  it('rechaza exportar un inventario mayor al tope en lugar de truncarlo en silencio', async () => {
    const { service } = build({ listTotal: 5001 });

    await expect(service.exportCsv('o1', user)).rejects.toBeInstanceOf(BadRequestException);
  });

  it('pagina el inventario y devuelve el total real', async () => {
    const { service, tx } = build({ listItems: [{ id: 'd1' }] });
    const res = await service.list('o1', user, { page: 2, pageSize: 10 });

    const args = tx.document.findMany.mock.calls[0][0] as { skip: number; take: number };
    expect(args).toMatchObject({ skip: 10, take: 10 });
    expect(res).toMatchObject({ page: 2, pageSize: 10, total: 1 });
  });

  it('limita el tamaño de página para no permitir volcar la tabla entera', async () => {
    const { service, tx } = build();
    await service.list('o1', user, { pageSize: 100000 });

    const args = tx.document.findMany.mock.calls[0][0] as { take: number };
    expect(args.take).toBe(200);
  });

  it('no pisa el filtro de estado cuando se pide por vencimiento', async () => {
    const { service, tx } = build();
    await service.list('o1', user, { status: 'PUBLISHED', due: 'overdue' });

    const args = tx.document.findMany.mock.calls[0][0] as { where: Record<string, unknown> };
    expect(args.where.status).toBe('PUBLISHED');
    expect(args.where.reviewDate).toEqual({ lt: expect.any(Date) });
  });

  it('excluye los obsoletos del aviso de revisión', async () => {
    const { service, tx } = build();
    await service.list('o1', user, { due: 'soon' });

    const args = tx.document.findMany.mock.calls[0][0] as { where: Record<string, unknown> };
    expect(args.where.status).toEqual({ not: 'OBSOLETE' });
  });
});

describe('DocumentsService — alertas de revisión', () => {
  it('separa vencidos de próximos y marca el horizonte de aviso', async () => {
    const past = new Date(Date.now() - 86_400_000);
    const future = new Date(Date.now() + 86_400_000);
    const { service } = build({
      listItems: [
        { id: 'd1', code: 'PR-01', reviewDate: past },
        { id: 'd2', code: 'PR-02', reviewDate: future },
      ],
    });

    const res = await service.reviewAlerts('o1', user);
    expect(res).toMatchObject({ overdue: 1, dueSoon: 1 });
    // El aviso cubre una ventana, no solo el día exacto.
    expect(res.soonUntil.getTime()).toBeGreaterThan(Date.now());
  });

  it('consulta solo documentos con revisión dentro de la ventana', async () => {
    const { service, tx } = build();
    await service.reviewAlerts('o1', user);

    const args = tx.document.findMany.mock.calls[0][0] as { where: Record<string, unknown> };
    expect(args.where).toMatchObject({
      orgId: 'o1',
      status: { not: 'OBSOLETE' },
      reviewDate: { not: null, lte: expect.any(Date) },
    });
  });
});

describe('DocumentsService — aviso de revisión', () => {
  it('crea la notificación para el responsable del documento', async () => {
    const { service, tx } = build({
      document: { reviewDate: new Date('2026-01-01'), ownerId: 'u-owner' },
    });
    await service.notifyReviewDue('o1', user, 'd1');

    const data = (tx.notification.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data).toMatchObject({ userId: 'u-owner', type: 'DOC_REVIEW', entity: 'document' });
    // La fecha ya pasó: el aviso lo dice.
    expect(String(data.title)).toContain('vencida');
  });

  it('no duplica el aviso del mismo día', async () => {
    const { service, tx } = build({
      document: { reviewDate: new Date('2026-01-01'), ownerId: 'u-owner' },
      notification: { id: 'n-existente' },
    });
    const res = await service.notifyReviewDue('o1', user, 'd1');

    expect(res).toEqual({ id: 'n-existente' });
    expect(tx.notification.create).not.toHaveBeenCalled();
  });

  it('rechaza avisar de un documento sin fecha de revisión', async () => {
    const { service } = build({ document: { reviewDate: null } });
    await expect(service.notifyReviewDue('o1', user, 'd1')).rejects.toBeInstanceOf(BadRequestException);
  });

  it('rechaza avisar de un documento obsoleto', async () => {
    const { service } = build({
      document: { status: 'OBSOLETE', reviewDate: new Date('2026-01-01') },
    });
    await expect(service.notifyReviewDue('o1', user, 'd1')).rejects.toBeInstanceOf(BadRequestException);
  });
});


describe('DocumentsService — sedes del documento', () => {
  it('guarda las sedes elegidas al crear', async () => {
    const { service, tx } = build();
    await service.create('o1', user, {
      code: 'PR-10',
      title: 'Procedimiento',
      content,
      branchIds: ['b1', 'b2'],
    });

    const data = (tx.document.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data.branchIds).toEqual(['b1', 'b2']);
  });

  it('sin sedes el documento aplica a toda la organización', async () => {
    const { service, tx } = build();
    await service.create('o1', user, { code: 'PR-10', title: 'Documento', content });

    const data = (tx.document.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data.branchIds).toEqual([]);
    // Sin ids no hay nada que validar contra la tabla de sedes.
    expect(tx.orgBranch.findMany).not.toHaveBeenCalled();
  });

  it('rechaza una sede de otra organización al crear', async () => {
    // `orgBranch` filtra por orgId: devolver menos sedes que ids es una ajena.
    const { service, tx } = build({ branches: [{ id: 'b1' }] });
    await expect(
      service.create('o1', user, { code: 'PR-10', title: 'Doc', content, branchIds: ['b1', 'ajena'] }),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(tx.document.create).not.toHaveBeenCalled();
  });

  it('descarta sedes repetidas antes de guardar', async () => {
    const { service, tx } = build();
    await service.create('o1', user, {
      code: 'PR-10',
      title: 'Doc',
      content,
      branchIds: ['b1', 'b1', 'b2'],
    });

    const data = (tx.document.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data.branchIds).toEqual(['b1', 'b2']);
  });

  it('actualizar sin `branchIds` no toca las sedes guardadas', async () => {
    const { service, tx } = build();
    await service.update('o1', user, 'd1', { title: 'Otro título' });

    const data = (tx.document.update.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data).not.toHaveProperty('branchIds');
    expect(tx.orgBranch.findMany).not.toHaveBeenCalled();
  });

  it('una lista vacía al actualizar devuelve el documento a toda la organización', async () => {
    const { service, tx } = build();
    await service.update('o1', user, 'd1', { branchIds: [] });

    const data = (tx.document.update.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    expect(data.branchIds).toEqual([]);
  });
});

describe('DocumentsService — archivo adjunto', () => {
  const pdf = {
    originalname: 'Política de calidad.pdf',
    buffer: Buffer.from('abc'),
    size: 3,
    mimetype: 'application/pdf',
  };

  it('guarda el archivo con su nombre saneado y verifica la cuota', async () => {
    const { service, tx, storage, usage } = build();
    const created = await service.addFile('o1', user, 'd1', pdf);

    expect(usage.assertStorage).toHaveBeenCalledWith('o1', 3);
    const data = (tx.documentFile.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    // El nombre conserva el original pero sin espacios problemáticos ni rutas.
    expect(data.filename).toBe('Política de calidad.pdf');
    expect(String(data.blobName)).toContain('/doc-d1/');
    expect(created).toMatchObject({ id: 'f1' });
    expect(storage.put).toHaveBeenCalled();
  });

  it('rechaza un archivo vacío', async () => {
    const { service } = build();
    await expect(
      service.addFile('o1', user, 'd1', { ...pdf, buffer: Buffer.alloc(0), size: 0 }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('no sube nada si el documento no existe', async () => {
    const { service, tx, storage } = build({ document: { orgId: 'otra' } });
    await expect(service.addFile('o1', user, 'd1', pdf)).rejects.toBeInstanceOf(NotFoundException);
    expect(storage.put).not.toHaveBeenCalled();
    expect(tx.documentFile.create).not.toHaveBeenCalled();
  });

  it('descarga el archivo cuando el hash coincide', async () => {
    const { service } = build();
    const file = await service.readFile('o1', user, 'f1');

    expect(file.filename).toBe('politica.pdf');
    expect(file.mime).toBe('application/pdf');
    expect(file.buffer.toString()).toBe('abc');
  });

  it('no entrega un archivo alterado en disco', async () => {
    const { service, storage } = build({ file: { sha256: 'hash-distinto' } });
    await expect(service.readFile('o1', user, 'f1')).rejects.toBeInstanceOf(BadRequestException);
    expect(storage.get).toHaveBeenCalled();
  });

  it('quitar un archivo borra la fila y el objeto', async () => {
    const { service, tx, storage } = build();
    const res = await service.removeFile('o1', user, 'f1');

    expect(res).toEqual({ ok: true, deleted: 'f1' });
    expect(tx.documentFile.delete).toHaveBeenCalledWith({ where: { id: 'f1' } });
    expect(storage.remove).toHaveBeenCalledWith('org-o1/doc-d1/politica.pdf');
  });
});

describe('DocumentsService — limpieza al borrar', () => {
  it('borra también los objetos del documento eliminado', async () => {
    const { service, tx, storage } = build({ document: { status: 'DRAFT' } });
    tx.documentFile.findMany.mockResolvedValueOnce([
      { blobName: 'org-o1/doc-d1/a.pdf' },
      { blobName: 'org-o1/doc-d1/b.pdf' },
    ]);

    await service.remove('o1', user, 'd1');

    expect(storage.remove).toHaveBeenCalledWith('org-o1/doc-d1/a.pdf');
    expect(storage.remove).toHaveBeenCalledWith('org-o1/doc-d1/b.pdf');
  });

  it('un archivo que no se puede borrar no impide eliminar el documento', async () => {
    const { service, tx, storage } = build({ document: { status: 'DRAFT' } });
    tx.documentFile.findMany.mockResolvedValueOnce([{ blobName: 'org-o1/doc-d1/a.pdf' }]);
    (storage.remove as jest.Mock).mockRejectedValueOnce(new Error('disco lleno'));

    await expect(service.remove('o1', user, 'd1')).resolves.toEqual({ ok: true, deleted: 'd1' });
  });
});

describe('DocumentsService — subida directa al almacenamiento', () => {
  const big = { filename: 'manual.pdf', mime: 'application/pdf', size: 4_000_000 };

  it('sin almacenamiento que firme URLs la capacidad es la del proxy', async () => {
    const { service } = build();
    const caps = await service.uploadCapabilitiesFor('o1', user);

    // Sin subida directa el archivo cruza el proxy, que corta en 4 MB: es el
    // tope efectivo aunque la API por sí sola admita más.
    expect(caps).toEqual({ direct: false, maxMb: 4, proxyMaxMb: 4 });
  });

  it('con almacenamiento en la nube la capacidad es la de la subida directa', async () => {
    const { service } = build({ presign: true });
    const caps = await service.uploadCapabilitiesFor('o1', user);

    expect(caps.direct).toBe(true);
    expect(caps.maxMb).toBe(250);
  });

  it('firma una URL acotada a la carpeta del documento', async () => {
    const { service, storage, usage } = build({ presign: true });
    const ticket = await service.requestUploadTicket('o1', user, 'd1', big);

    expect(ticket).not.toBeNull();
    expect(ticket!.key.startsWith('org-o1/doc-d1/')).toBe(true);
    expect(ticket!.url).toContain(ticket!.key);
    expect(ticket!.method).toBe('PUT');
    expect(ticket!.filename).toBe('manual.pdf');
    // La cuota se comprueba antes de firmar.
    expect(usage.assertStorage).toHaveBeenCalledWith('o1', 4_000_000);
    expect(storage.put).not.toHaveBeenCalled();
  });

  it('devuelve `null` cuando el almacenamiento no firma URLs', async () => {
    const { service } = build();
    await expect(service.requestUploadTicket('o1', user, 'd1', big)).resolves.toBeNull();
  });

  it('rechaza firmar un archivo por encima del tope directo', async () => {
    const { service } = build({ presign: true });
    await expect(
      service.requestUploadTicket('o1', user, 'd1', { ...big, size: 300 * 1024 * 1024 }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('confirma la subida tomando el tamaño real del almacén', async () => {
    const { service, tx } = build({ presign: true, storedSize: 4_000_000 });
    const created = await service.confirmDirectUpload('o1', user, 'd1', {
      key: 'org-o1/doc-d1/123-manual.pdf',
      filename: 'manual.pdf',
      mime: 'application/pdf',
    });

    const data = (tx.documentFile.create.mock.calls[0][0] as { data: Record<string, unknown> }).data;
    // El tamaño lo dicta el objeto guardado, no lo que declare el cliente.
    expect(data.size).toBe(4_000_000);
    expect(data.blobName).toBe('org-o1/doc-d1/123-manual.pdf');
    expect(created).toMatchObject({ id: 'f1' });
  });

  it('rechaza confirmar una clave de otra organización o documento', async () => {
    const { service, tx } = build({ presign: true });
    await expect(
      service.confirmDirectUpload('o1', user, 'd1', {
        key: 'org-otra/doc-d1/123-manual.pdf',
        filename: 'manual.pdf',
      }),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(tx.documentFile.create).not.toHaveBeenCalled();
  });

  it('no registra nada si el archivo no llegó al almacén', async () => {
    const { service, tx } = build({ presign: true, storedSize: 0 });
    await expect(
      service.confirmDirectUpload('o1', user, 'd1', {
        key: 'org-o1/doc-d1/123-manual.pdf',
        filename: 'manual.pdf',
      }),
    ).rejects.toBeInstanceOf(BadRequestException);
    expect(tx.documentFile.create).not.toHaveBeenCalled();
  });
});
