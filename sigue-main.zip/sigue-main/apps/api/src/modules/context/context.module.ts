import { Module } from '@nestjs/common';
import { ContextController } from './context.controller';
import { ContextService } from './context.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [TenancyModule, AuthSharedModule],
  controllers: [ContextController],
  providers: [ContextService],
})
export class ContextModule {}
