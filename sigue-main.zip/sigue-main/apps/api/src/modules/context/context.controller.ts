import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { ContextService } from './context.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { CreatePestelDto, UpdatePestelDto } from './dto/pestel.dto';
import { CreateSwotDto, UpdateSwotDto } from './dto/swot.dto';
import { CreateAnalysisDto, UpdateAnalysisDto } from './dto/analysis.dto';

@ApiTags('context')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/context', version: '1' })
export class ContextController {
  constructor(private readonly context: ContextService) {}

  @ApiEndpoint('Contexto de la organización (FODA, PESTEL, partes, procesos, legales)', { status: 200, tenant: true })
  @Get()
  get(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.context.getContext(orgId, user);
  }

  // --- FODA ---
  // Las rutas de análisis se declaran antes que las de elemento (`swot/:id`):
  // si fueran después, `PATCH swot/analyses/:id` no casaría por orden.
  @Audit('context.add_swot_analysis')
  @ApiEndpoint('Crea un FODA', { status: 201, tenant: true })
  @Post('swot/analyses')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  addSwotAnalysis(
    @Param('orgId') orgId: string,
    @Body() data: CreateAnalysisDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.addSwotAnalysis(orgId, user, data);
  }

  @Audit('context.update_swot_analysis')
  @ApiEndpoint('Actualiza los datos de un FODA', { status: 200, tenant: true })
  @Patch('swot/analyses/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateSwotAnalysis(
    @Param('orgId') orgId: string,
    @Param('id') id: string,
    @Body() data: UpdateAnalysisDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.updateSwotAnalysis(orgId, user, id, data);
  }

  @Audit('context.delete_swot_analysis')
  @ApiEndpoint('Elimina un FODA y sus elementos', { status: 200, tenant: true })
  @Delete('swot/analyses/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteSwotAnalysis(@Param('orgId') orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.context.deleteSwotAnalysis(orgId, user, id);
  }

  @Audit('context.add_swot')
  @ApiEndpoint('Agrega un elemento FODA', { status: 201, tenant: true })
  @Post('swot')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  addSwot(@Param('orgId') orgId: string, @Body() data: CreateSwotDto, @CurrentUser() user: AuthUser) {
    return this.context.addSwot(orgId, user, data.analysisId, data.type, data.text);
  }

  @Audit('context.update_swot')
  @ApiEndpoint('Actualiza un elemento FODA', { status: 200, tenant: true })
  @Patch('swot/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateSwot(@Param('orgId') orgId: string, @Param('id') id: string, @Body() data: UpdateSwotDto, @CurrentUser() user: AuthUser) {
    return this.context.updateSwot(orgId, user, id, data);
  }

  @Audit('context.delete_swot')
  @ApiEndpoint('Elimina un elemento FODA', { status: 200, tenant: true })
  @Delete('swot/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteSwot(@Param('orgId') orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.context.deleteSwot(orgId, user, id);
  }

  // --- PESTEL ---
  @Audit('context.add_pestel_analysis')
  @ApiEndpoint('Crea un análisis PESTEL', { status: 201, tenant: true })
  @Post('pestel/analyses')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  addPestelAnalysis(
    @Param('orgId') orgId: string,
    @Body() data: CreateAnalysisDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.addPestelAnalysis(orgId, user, data);
  }

  @Audit('context.update_pestel_analysis')
  @ApiEndpoint('Actualiza los datos de un análisis PESTEL', { status: 200, tenant: true })
  @Patch('pestel/analyses/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updatePestelAnalysis(
    @Param('orgId') orgId: string,
    @Param('id') id: string,
    @Body() data: UpdateAnalysisDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.updatePestelAnalysis(orgId, user, id, data);
  }

  @Audit('context.delete_pestel_analysis')
  @ApiEndpoint('Elimina un análisis PESTEL y sus factores', { status: 200, tenant: true })
  @Delete('pestel/analyses/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deletePestelAnalysis(@Param('orgId') orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.context.deletePestelAnalysis(orgId, user, id);
  }

  @Audit('context.add_pestel')
  @ApiEndpoint('Agrega un factor PESTEL', { status: 201, tenant: true })
  @Post('pestel')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  addPestel(
    @Param('orgId') orgId: string,
    @Body() data: CreatePestelDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.addPestel(orgId, user, data);
  }

  @Audit('context.update_pestel')
  @ApiEndpoint('Actualiza un factor PESTEL', { status: 200, tenant: true })
  @Patch('pestel/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updatePestel(
    @Param('orgId') orgId: string,
    @Param('id') id: string,
    @Body() data: UpdatePestelDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.updatePestel(orgId, user, id, data);
  }

  @Audit('context.delete_pestel')
  @ApiEndpoint('Elimina un factor PESTEL', { status: 200, tenant: true })
  @Delete('pestel/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deletePestel(@Param('orgId') orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.context.deletePestel(orgId, user, id);
  }

  // --- Partes interesadas ---
  @Audit('context.add_party')
  @ApiEndpoint('Registra una parte interesada', { status: 201, tenant: true })
  @Post('parties')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  addParty(
    @Param('orgId') orgId: string,
    @Body() data: { name: string; needs?: string; expectations?: string; relevance?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.addParty(orgId, user, data);
  }

  @Audit('context.update_party')
  @ApiEndpoint('Actualiza una parte interesada', { status: 200, tenant: true })
  @Patch('parties/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateParty(
    @Param('orgId') orgId: string,
    @Param('id') id: string,
    @Body() data: { name?: string; needs?: string | null; expectations?: string | null; relevance?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.updateParty(orgId, user, id, data);
  }

  @Audit('context.delete_party')
  @ApiEndpoint('Elimina una parte interesada', { status: 200, tenant: true })
  @Delete('parties/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteParty(@Param('orgId') orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.context.deleteParty(orgId, user, id);
  }

  // --- Cuestiones (4.1) ---
  @Audit('context.add_issue')
  @ApiEndpoint('Registra una cuestión interna o externa', { status: 201, tenant: true })
  @Post('issues')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  addIssue(@Param('orgId') orgId: string, @Body() data: { isInternal: boolean; text: string }, @CurrentUser() user: AuthUser) {
    return this.context.addIssue(orgId, user, data);
  }

  @Audit('context.update_issue')
  @ApiEndpoint('Actualiza una cuestión', { status: 200, tenant: true })
  @Patch('issues/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateIssue(@Param('orgId') orgId: string, @Param('id') id: string, @Body() data: { isInternal?: boolean; text?: string }, @CurrentUser() user: AuthUser) {
    return this.context.updateIssue(orgId, user, id, data);
  }

  @Audit('context.delete_issue')
  @ApiEndpoint('Elimina una cuestión', { status: 200, tenant: true })
  @Delete('issues/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteIssue(@Param('orgId') orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.context.deleteIssue(orgId, user, id);
  }

  // --- Requisitos legales ---
  @Audit('context.add_legal')
  @ApiEndpoint('Registra un requisito legal', { status: 201, tenant: true })
  @Post('legal')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addLegal(
    @Param('orgId') orgId: string,
    @Body() data: { source: string; reference: string; requirement: string; appliesTo?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.addLegal(orgId, user, data);
  }

  @Audit('context.update_legal')
  @ApiEndpoint('Actualiza un requisito legal', { status: 200, tenant: true })
  @Patch('legal/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateLegal(
    @Param('orgId') orgId: string,
    @Param('id') id: string,
    @Body() data: { source?: string; reference?: string; requirement?: string; appliesTo?: string | null; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.updateLegal(orgId, user, id, data);
  }

  @Audit('context.delete_legal')
  @ApiEndpoint('Elimina un requisito legal', { status: 200, tenant: true })
  @Delete('legal/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteLegal(@Param('orgId') orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.context.deleteLegal(orgId, user, id);
  }

  // --- Mapa de procesos ---
  @Audit('context.add_process')
  @ApiEndpoint('Registra un proceso', { status: 201, tenant: true })
  @Post('processes')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  addProcess(
    @Param('orgId') orgId: string,
    @Body() data: { name: string; inputs?: string; outputs?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.addProcess(orgId, user, data);
  }

  @Audit('context.update_process')
  @ApiEndpoint('Actualiza un proceso', { status: 200, tenant: true })
  @Patch('processes/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'admin_org')
  updateProcess(
    @Param('orgId') orgId: string,
    @Param('id') id: string,
    @Body() data: { name?: string; inputs?: string | null; outputs?: string | null; areaId?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.context.updateProcess(orgId, user, id, data);
  }

  @Audit('context.delete_process')
  @ApiEndpoint('Elimina un proceso', { status: 200, tenant: true })
  @Delete('processes/:id')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteProcess(@Param('orgId') orgId: string, @Param('id') id: string, @CurrentUser() user: AuthUser) {
    return this.context.deleteProcess(orgId, user, id);
  }
}
