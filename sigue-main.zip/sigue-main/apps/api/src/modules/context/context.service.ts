import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

@Injectable()
export class ContextService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Devuelve todo el contexto de la organización (FODA, PESTEL, partes, legales, procesos). */
  async getContext(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [swotAnalyses, pestelAnalyses, parties, issues, legal, processes] = await Promise.all([
        tx.contextSwotAnalysis.findMany({
          where: { orgId },
          orderBy: [{ createdAt: 'desc' }],
          include: { items: { orderBy: { createdAt: 'asc' } } },
        }),
        // PESTEL se muestra agrupado por dimensión: el orden estable evita que
        // las tarjetas cambien de sitio entre recargas.
        tx.contextPestelAnalysis.findMany({
          where: { orgId },
          orderBy: [{ createdAt: 'desc' }],
          include: { items: { orderBy: { createdAt: 'asc' } } },
        }),
        tx.contextParty.findMany({ where: { orgId } }),
        tx.contextIssue.findMany({ where: { orgId } }),
        tx.legalRequirement.findMany({ where: { orgId } }),
        tx.processMap.findMany({ where: { orgId } }),
      ]);
      return { swotAnalyses, pestelAnalyses, parties, issues, legal, processes };
    });
  }

  /** Comprueba que el análisis existe en la organización antes de colgarle elementos. */
  private async assertSwotAnalysis(tx: Prisma.TransactionClient, orgId: string, analysisId: string) {
    const analysis = await tx.contextSwotAnalysis.findUnique({ where: { id: analysisId } });
    if (!analysis || analysis.orgId !== orgId) {
      throw new NotFoundException('FODA no encontrado');
    }
    return analysis;
  }

  private async assertPestelAnalysis(tx: Prisma.TransactionClient, orgId: string, analysisId: string) {
    const analysis = await tx.contextPestelAnalysis.findUnique({ where: { id: analysisId } });
    if (!analysis || analysis.orgId !== orgId) {
      throw new NotFoundException('Análisis PESTEL no encontrado');
    }
    return analysis;
  }

  // --- FODA ---
  async addSwotAnalysis(
    orgId: string,
    user: AuthUser,
    data: { name: string; description?: string; period?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.contextSwotAnalysis.create({
        data: {
          orgId,
          name: data.name,
          description: data.description || null,
          period: data.period || null,
          ownerId: user.sub,
        },
        include: { items: true },
      });
    });
  }

  async updateSwotAnalysis(
    orgId: string,
    user: AuthUser,
    id: string,
    data: { name?: string; description?: string | null; period?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextSwotAnalysis.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('FODA no encontrado');
      return tx.contextSwotAnalysis.update({
        where: { id },
        data: {
          ...(data.name !== undefined ? { name: data.name } : {}),
          ...(data.description !== undefined ? { description: data.description || null } : {}),
          ...(data.period !== undefined ? { period: data.period || null } : {}),
        },
        include: { items: { orderBy: { createdAt: 'asc' } } },
      });
    });
  }

  async deleteSwotAnalysis(orgId: string, user: AuthUser, id: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextSwotAnalysis.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('FODA no encontrado');
      // Los elementos caen en cascada: la FK declara onDelete: Cascade.
      await tx.contextSwotAnalysis.delete({ where: { id } });
      return { ok: true, deleted: id };
    });
  }

  async addSwot(orgId: string, user: AuthUser, analysisId: string, type: string, text: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.assertSwotAnalysis(tx, orgId, analysisId);
      return tx.contextSwot.create({
        data: { orgId, analysisId, type, text, ownerId: user.sub },
      });
    });
  }

  async updateSwot(orgId: string, user: AuthUser, id: string, data: { type?: string; text?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextSwot.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Elemento FODA no encontrado');
      return tx.contextSwot.update({ where: { id }, data });
    });
  }

  async deleteSwot(orgId: string, user: AuthUser, id: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextSwot.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Elemento FODA no encontrado');
      await tx.contextSwot.delete({ where: { id } });
      return { ok: true, deleted: id };
    });
  }

  // --- PESTEL ---
  async addPestelAnalysis(
    orgId: string,
    user: AuthUser,
    data: { name: string; description?: string; period?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.contextPestelAnalysis.create({
        data: {
          orgId,
          name: data.name,
          description: data.description || null,
          period: data.period || null,
          ownerId: user.sub,
        },
        include: { items: true },
      });
    });
  }

  async updatePestelAnalysis(
    orgId: string,
    user: AuthUser,
    id: string,
    data: { name?: string; description?: string | null; period?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextPestelAnalysis.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Análisis PESTEL no encontrado');
      return tx.contextPestelAnalysis.update({
        where: { id },
        data: {
          ...(data.name !== undefined ? { name: data.name } : {}),
          ...(data.description !== undefined ? { description: data.description || null } : {}),
          ...(data.period !== undefined ? { period: data.period || null } : {}),
        },
        include: { items: { orderBy: { createdAt: 'asc' } } },
      });
    });
  }

  async deletePestelAnalysis(orgId: string, user: AuthUser, id: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextPestelAnalysis.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Análisis PESTEL no encontrado');
      // Los factores caen en cascada: la FK declara onDelete: Cascade.
      await tx.contextPestelAnalysis.delete({ where: { id } });
      return { ok: true, deleted: id };
    });
  }

  async addPestel(
    orgId: string,
    user: AuthUser,
    data: { analysisId: string; type: string; impact?: string; text: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      await this.assertPestelAnalysis(tx, orgId, data.analysisId);
      return tx.contextPestel.create({
        data: {
          orgId,
          analysisId: data.analysisId,
          type: data.type,
          impact: data.impact ?? 'NEUTRO',
          text: data.text,
          ownerId: user.sub,
        },
      });
    });
  }

  async updatePestel(
    orgId: string,
    user: AuthUser,
    id: string,
    data: { type?: string; impact?: string; text?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextPestel.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Factor PESTEL no encontrado');
      return tx.contextPestel.update({ where: { id }, data });
    });
  }

  async deletePestel(orgId: string, user: AuthUser, id: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextPestel.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Factor PESTEL no encontrado');
      await tx.contextPestel.delete({ where: { id } });
      return { ok: true, deleted: id };
    });
  }

  // --- Partes interesadas ---
  async addParty(
    orgId: string,
    user: AuthUser,
    data: { name: string; needs?: string; expectations?: string; relevance?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.contextParty.create({
        data: {
          orgId,
          name: data.name,
          needs: data.needs ? { text: data.needs } : undefined,
          expectations: data.expectations ? { text: data.expectations } : undefined,
          relevance: data.relevance ?? 'MEDIA',
        },
      });
    });
  }

  async updateParty(
    orgId: string,
    user: AuthUser,
    id: string,
    data: { name?: string; needs?: string | null; expectations?: string | null; relevance?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextParty.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Parte interesada no encontrada');
      return tx.contextParty.update({
        where: { id },
        data: {
          ...(data.name !== undefined ? { name: data.name } : {}),
          ...(data.needs !== undefined
            ? { needs: data.needs ? { text: data.needs } : Prisma.JsonNull }
            : {}),
          ...(data.expectations !== undefined
            ? { expectations: data.expectations ? { text: data.expectations } : Prisma.JsonNull }
            : {}),
          ...(data.relevance !== undefined ? { relevance: data.relevance } : {}),
        },
      });
    });
  }

  async deleteParty(orgId: string, user: AuthUser, id: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextParty.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Parte interesada no encontrada');
      await tx.contextParty.delete({ where: { id } });
      return { ok: true, deleted: id };
    });
  }

  // --- Cuestiones internas/externas (ISO 4.1) ---
  async addIssue(orgId: string, user: AuthUser, data: { isInternal: boolean; text: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.contextIssue.create({ data: { orgId, isInternal: data.isInternal, text: data.text } });
    });
  }

  async updateIssue(orgId: string, user: AuthUser, id: string, data: { isInternal?: boolean; text?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextIssue.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Cuestión no encontrada');
      return tx.contextIssue.update({ where: { id }, data });
    });
  }

  async deleteIssue(orgId: string, user: AuthUser, id: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.contextIssue.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Cuestión no encontrada');
      await tx.contextIssue.delete({ where: { id } });
      return { ok: true, deleted: id };
    });
  }

  // --- Requisitos legales ---
  async addLegal(orgId: string, user: AuthUser, data: { source: string; reference: string; requirement: string; appliesTo?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.legalRequirement.create({
        data: { orgId, source: data.source, reference: data.reference, requirement: data.requirement, appliesTo: data.appliesTo },
      });
    });
  }

  async updateLegal(
    orgId: string,
    user: AuthUser,
    id: string,
    data: { source?: string; reference?: string; requirement?: string; appliesTo?: string | null; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.legalRequirement.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Requisito legal no encontrado');
      return tx.legalRequirement.update({ where: { id }, data });
    });
  }

  async deleteLegal(orgId: string, user: AuthUser, id: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.legalRequirement.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Requisito legal no encontrado');
      await tx.legalRequirement.delete({ where: { id } });
      return { ok: true, deleted: id };
    });
  }

  // --- Mapa de procesos ---
  async addProcess(orgId: string, user: AuthUser, data: { name: string; inputs?: string; outputs?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.processMap.create({
        data: { orgId, name: data.name, inputs: data.inputs, outputs: data.outputs, ownerId: user.sub },
      });
    });
  }

  async updateProcess(
    orgId: string,
    user: AuthUser,
    id: string,
    data: { name?: string; inputs?: string | null; outputs?: string | null; areaId?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.processMap.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Proceso no encontrado');
      return tx.processMap.update({ where: { id }, data });
    });
  }

  async deleteProcess(orgId: string, user: AuthUser, id: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.processMap.findUnique({ where: { id } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Proceso no encontrado');
      await tx.processMap.delete({ where: { id } });
      return { ok: true, deleted: id };
    });
  }
}
