import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsIn, IsNotEmpty, IsOptional, IsString, Length } from 'class-validator';

/** Dimensiones del análisis PESTEL (ISO 4.1). */
export const PESTEL_TYPES = [
  'POLITICO',
  'ECONOMICO',
  'SOCIAL',
  'TECNOLOGICO',
  'ECOLOGICO',
  'LEGAL',
] as const;

export type PestelType = (typeof PESTEL_TYPES)[number];

export const PESTEL_IMPACTS = ['POSITIVO', 'NEGATIVO', 'NEUTRO'] as const;

export type PestelImpact = (typeof PESTEL_IMPACTS)[number];

/**
 * Factor PESTEL.
 *
 * A diferencia de los demás endpoints de contexto (que recibían un tipo inline
 * y por tanto aceptaban cualquier propiedad), este DTO queda sujeto al
 * `ValidationPipe` global con `forbidNonWhitelisted`, así que un `orgId` en el
 * cuerpo se rechaza en lugar de ignorarse en silencio.
 */
export class CreatePestelDto {
  @ApiProperty({ description: 'Análisis PESTEL al que pertenece el factor' })
  @IsString()
  @IsNotEmpty()
  analysisId!: string;

  @ApiProperty({ enum: PESTEL_TYPES, example: 'ECONOMICO' })
  @IsIn(PESTEL_TYPES)
  type!: PestelType;

  @ApiPropertyOptional({ enum: PESTEL_IMPACTS, default: 'NEUTRO' })
  @IsOptional()
  @IsIn(PESTEL_IMPACTS)
  impact?: PestelImpact;

  @ApiProperty({ example: 'Inflación en materias primas y costo logístico' })
  @IsString()
  @Length(1, 500)
  text!: string;
}

export class UpdatePestelDto {
  @ApiPropertyOptional({ enum: PESTEL_TYPES })
  @IsOptional()
  @IsIn(PESTEL_TYPES)
  type?: PestelType;

  @ApiPropertyOptional({ enum: PESTEL_IMPACTS })
  @IsOptional()
  @IsIn(PESTEL_IMPACTS)
  impact?: PestelImpact;

  @ApiPropertyOptional({ example: 'Inflación en materias primas y costo logístico' })
  @IsOptional()
  @IsString()
  @Length(1, 500)
  text?: string;
}
