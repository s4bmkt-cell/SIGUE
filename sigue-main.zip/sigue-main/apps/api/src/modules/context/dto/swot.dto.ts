import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsIn, IsNotEmpty, IsOptional, IsString, Length } from 'class-validator';

/** Cuadrantes del FODA (ISO 4.1). */
export const SWOT_TYPES = ['FORTALEZA', 'OPORTUNIDAD', 'DEBILIDAD', 'AMENAZA'] as const;

export type SwotType = (typeof SWOT_TYPES)[number];

/**
 * Elemento FODA.
 *
 * `analysisId` es obligatorio: un elemento suelto no tendría a qué FODA
 * pertenecer. También pasa por el `ValidationPipe` global con
 * `forbidNonWhitelisted`, así que un `orgId` en el cuerpo se rechaza en lugar
 * de ignorarse en silencio.
 */
export class CreateSwotDto {
  @ApiProperty({ description: 'FODA al que pertenece el elemento' })
  @IsString()
  @IsNotEmpty()
  analysisId!: string;

  @ApiProperty({ enum: SWOT_TYPES, example: 'FORTALEZA' })
  @IsIn(SWOT_TYPES)
  type!: SwotType;

  @ApiProperty({ example: 'Equipo de calidad experimentado y comprometido' })
  @IsString()
  @Length(1, 500)
  text!: string;
}

export class UpdateSwotDto {
  @ApiPropertyOptional({ enum: SWOT_TYPES })
  @IsOptional()
  @IsIn(SWOT_TYPES)
  type?: SwotType;

  @ApiPropertyOptional({ example: 'Equipo de calidad experimentado y comprometido' })
  @IsOptional()
  @IsString()
  @Length(1, 500)
  text?: string;
}
