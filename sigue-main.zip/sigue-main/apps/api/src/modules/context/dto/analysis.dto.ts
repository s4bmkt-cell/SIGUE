import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsString, Length } from 'class-validator';

/**
 * Metadatos de un análisis con nombre (FODA o PESTEL).
 *
 * La organización puede mantener varios —por año, sede, línea de negocio— así
 * que el nombre es lo que los distingue en la lista. El periodo es texto libre
 * a propósito: «2026», «Ene–Dic 2026» o «Q3 2026» son igual de válidos y no
 * conviene inventar una fecha que luego no case con cómo lo usa la organización.
 */
export class CreateAnalysisDto {
  @ApiProperty({ example: 'FODA 2026 · Planta Norte' })
  @IsString()
  @Length(1, 120)
  name!: string;

  @ApiPropertyOptional({ example: 'Análisis del ciclo 2026 para la operación de Monterrey.' })
  @IsOptional()
  @IsString()
  @Length(0, 500)
  description?: string;

  @ApiPropertyOptional({ example: '2026' })
  @IsOptional()
  @IsString()
  @Length(0, 60)
  period?: string;
}

export class UpdateAnalysisDto {
  @ApiPropertyOptional({ example: 'FODA 2026 · Planta Norte' })
  @IsOptional()
  @IsString()
  @Length(1, 120)
  name?: string;

  @ApiPropertyOptional({ example: 'Análisis del ciclo 2026 para la operación de Monterrey.' })
  @IsOptional()
  @IsString()
  @Length(0, 500)
  description?: string | null;

  @ApiPropertyOptional({ example: '2026' })
  @IsOptional()
  @IsString()
  @Length(0, 60)
  period?: string | null;
}
