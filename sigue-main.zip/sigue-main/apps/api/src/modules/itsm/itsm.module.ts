import { Module } from '@nestjs/common';
import { ItsmController } from './itsm.controller';
import { ItsmService } from './itsm.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [TenancyModule, AuthSharedModule],
  controllers: [ItsmController],
  providers: [ItsmService],
})
export class ItsmModule {}
