import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { ItsmService } from './itsm.service';

@ApiTags('itsm')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/itsm', version: '1' })
export class ItsmController {
  constructor(private readonly itsm: ItsmService) {}

  @ApiEndpoint('Panorama del SGS de TI: servicios, SLA y peticiones', { status: 200, tenant: true })
  @Get()
  overview(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.itsm.overview(orgId, user);
  }

  // ===== Portafolio de servicios (ISO/IEC 20000-1 · 8.2) =====
  @Audit('itsm.add_service')
  @ApiEndpoint('Registra un servicio en el catálogo', { status: 201, tenant: true, errors: ['conflict'] })
  @Post('services')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addService(
    @Param('orgId') orgId: string,
    @Body()
    data: { code: string; name: string; description?: string; category?: string; criticality?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.itsm.addService(orgId, user, data);
  }

  @Audit('itsm.update_service')
  @ApiEndpoint('Actualiza un servicio del catálogo', { status: 200, tenant: true, errors: ['notFound'] })
  @Patch('services/:serviceId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateService(
    @Param('orgId') orgId: string,
    @Param('serviceId') serviceId: string,
    @Body()
    data: { name?: string; description?: string | null; category?: string; criticality?: string; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.itsm.updateService(orgId, user, serviceId, data);
  }

  @Audit('itsm.delete_service')
  @ApiEndpoint('Retira un servicio del catálogo', { status: 200, tenant: true, errors: ['notFound'] })
  @Delete('services/:serviceId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteService(
    @Param('orgId') orgId: string,
    @Param('serviceId') serviceId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.itsm.deleteService(orgId, user, serviceId);
  }

  // ===== Acuerdos de nivel de servicio (ISO/IEC 20000-1 · 8.3) =====
  @Audit('itsm.add_sla')
  @ApiEndpoint('Registra un acuerdo de nivel de servicio', { status: 201, tenant: true, errors: ['notFound'] })
  @Post('slas')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addSla(
    @Param('orgId') orgId: string,
    @Body()
    data: { serviceCode: string; customer: string; responseHours?: number; resolutionHours?: number; availabilityPct?: number },
    @CurrentUser() user: AuthUser,
  ) {
    return this.itsm.addSla(orgId, user, data);
  }

  @Audit('itsm.update_sla')
  @ApiEndpoint('Actualiza un acuerdo de nivel de servicio', { status: 200, tenant: true, errors: ['notFound'] })
  @Patch('slas/:slaId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateSla(
    @Param('orgId') orgId: string,
    @Param('slaId') slaId: string,
    @Body()
    data: { customer?: string; responseHours?: number; resolutionHours?: number; availabilityPct?: number; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.itsm.updateSla(orgId, user, slaId, data);
  }

  @Audit('itsm.delete_sla')
  @ApiEndpoint('Elimina un acuerdo de nivel de servicio', { status: 200, tenant: true, errors: ['notFound'] })
  @Delete('slas/:slaId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteSla(@Param('orgId') orgId: string, @Param('slaId') slaId: string, @CurrentUser() user: AuthUser) {
    return this.itsm.deleteSla(orgId, user, slaId);
  }

  // ===== Incidentes y peticiones (ISO/IEC 20000-1 · 8.6) =====
  @Audit('itsm.add_request')
  @ApiEndpoint('Registra un incidente, petición, problema o cambio', { status: 201, tenant: true, errors: ['conflict'] })
  @Post('requests')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addRequest(
    @Param('orgId') orgId: string,
    @Body()
    data: { folio: string; serviceCode?: string; type?: string; title: string; description?: string; priority?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.itsm.addRequest(orgId, user, data);
  }

  @Audit('itsm.update_request')
  @ApiEndpoint('Actualiza el estado o asignación de una petición', { status: 200, tenant: true, errors: ['notFound'] })
  @Patch('requests/:requestId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateRequest(
    @Param('orgId') orgId: string,
    @Param('requestId') requestId: string,
    @Body()
    data: { title?: string; description?: string | null; type?: string; priority?: string; status?: string; assigneeId?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.itsm.updateRequest(orgId, user, requestId, data);
  }

  @Audit('itsm.delete_request')
  @ApiEndpoint('Elimina una petición de servicio', { status: 200, tenant: true, errors: ['notFound'] })
  @Delete('requests/:requestId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteRequest(
    @Param('orgId') orgId: string,
    @Param('requestId') requestId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.itsm.deleteRequest(orgId, user, requestId);
  }
}
