import { ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

/**
 * ISO/IEC 20000-1:2018 — Sistema de gestión de servicios.
 *
 * Cubre los procesos operativos de la cláusula 8 que el catálogo normativo
 * evalúa: portafolio de servicios (8.2), acuerdos de nivel de servicio (8.3)
 * y resolución de incidentes y peticiones (8.6).
 */
@Injectable()
export class ItsmService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Vista completa del SGS: servicios, SLA y peticiones. */
  async overview(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [services, slas, requests] = await Promise.all([
        tx.serviceCatalog.findMany({ where: { orgId }, orderBy: { code: 'asc' } }),
        tx.serviceLevelAgreement.findMany({ where: { orgId }, orderBy: { serviceCode: 'asc' } }),
        tx.serviceRequest.findMany({ where: { orgId }, orderBy: { createdAt: 'desc' } }),
      ]);
      const openRequests = requests.filter((r) => r.status === 'OPEN' || r.status === 'IN_PROGRESS').length;
      const incidents = requests.filter((r) => r.type === 'INCIDENT').length;
      const resolved = requests.filter((r) => r.status === 'RESOLVED' || r.status === 'CLOSED').length;
      return {
        services,
        slas,
        requests,
        summary: {
          services: services.filter((s) => s.status === 'ACTIVE').length,
          slas: slas.filter((s) => s.status === 'ACTIVE').length,
          openRequests,
          incidents,
          resolutionRate: requests.length ? Math.round((resolved / requests.length) * 100) : 0,
        },
      };
    });
  }

  // ===== Portafolio de servicios (8.2) =====
  async addService(
    orgId: string,
    user: AuthUser,
    data: { code: string; name: string; description?: string; category?: string; criticality?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const existing = await tx.serviceCatalog.findUnique({ where: { orgId_code: { orgId, code: data.code } } });
      if (existing) throw new ConflictException(`El servicio ${data.code} ya existe`);
      return tx.serviceCatalog.create({
        data: {
          orgId,
          code: data.code,
          name: data.name,
          description: data.description,
          category: data.category ?? 'SOPORTE',
          criticality: data.criticality ?? 'MEDIA',
          ownerId: user.sub,
        },
      });
    });
  }

  async updateService(
    orgId: string,
    user: AuthUser,
    serviceId: string,
    data: { name?: string; description?: string | null; category?: string; criticality?: string; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.serviceCatalog.findUnique({ where: { id: serviceId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Servicio no encontrado');
      return tx.serviceCatalog.update({
        where: { id: serviceId },
        data: {
          ...(data.name !== undefined ? { name: data.name } : {}),
          ...(data.description !== undefined ? { description: data.description } : {}),
          ...(data.category !== undefined ? { category: data.category } : {}),
          ...(data.criticality !== undefined ? { criticality: data.criticality } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
        },
      });
    });
  }

  async deleteService(orgId: string, user: AuthUser, serviceId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.serviceCatalog.findUnique({ where: { id: serviceId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Servicio no encontrado');
      await tx.serviceCatalog.delete({ where: { id: serviceId } });
      return { ok: true, deleted: serviceId };
    });
  }

  // ===== Acuerdos de nivel de servicio (8.3) =====
  async addSla(
    orgId: string,
    user: AuthUser,
    data: { serviceCode: string; customer: string; responseHours?: number; resolutionHours?: number; availabilityPct?: number },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const service = await tx.serviceCatalog.findUnique({ where: { orgId_code: { orgId, code: data.serviceCode } } });
      // Un SLA sin servicio en el catálogo no es verificable: se rechaza en vez
      // de dejar una fila huérfana que la auditoría no puede rastrear.
      if (!service) throw new NotFoundException(`El servicio ${data.serviceCode} no está en el catálogo`);
      return tx.serviceLevelAgreement.create({
        data: {
          orgId,
          serviceCode: data.serviceCode,
          customer: data.customer,
          responseHours: data.responseHours ?? 4,
          resolutionHours: data.resolutionHours ?? 24,
          availabilityPct: data.availabilityPct ?? 99.5,
        },
      });
    });
  }

  async updateSla(
    orgId: string,
    user: AuthUser,
    slaId: string,
    data: { customer?: string; responseHours?: number; resolutionHours?: number; availabilityPct?: number; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.serviceLevelAgreement.findUnique({ where: { id: slaId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Acuerdo de nivel de servicio no encontrado');
      return tx.serviceLevelAgreement.update({
        where: { id: slaId },
        data: {
          ...(data.customer !== undefined ? { customer: data.customer } : {}),
          ...(data.responseHours !== undefined ? { responseHours: data.responseHours } : {}),
          ...(data.resolutionHours !== undefined ? { resolutionHours: data.resolutionHours } : {}),
          ...(data.availabilityPct !== undefined ? { availabilityPct: data.availabilityPct } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
        },
      });
    });
  }

  async deleteSla(orgId: string, user: AuthUser, slaId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.serviceLevelAgreement.findUnique({ where: { id: slaId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Acuerdo de nivel de servicio no encontrado');
      await tx.serviceLevelAgreement.delete({ where: { id: slaId } });
      return { ok: true, deleted: slaId };
    });
  }

  // ===== Incidentes, peticiones, problemas y cambios (8.6 / 8.5) =====
  async addRequest(
    orgId: string,
    user: AuthUser,
    data: { folio: string; serviceCode?: string; type?: string; title: string; description?: string; priority?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const existing = await tx.serviceRequest.findUnique({ where: { orgId_folio: { orgId, folio: data.folio } } });
      if (existing) throw new ConflictException(`El folio ${data.folio} ya existe`);
      return tx.serviceRequest.create({
        data: {
          orgId,
          folio: data.folio,
          serviceCode: data.serviceCode,
          type: data.type ?? 'INCIDENT',
          title: data.title,
          description: data.description,
          priority: data.priority ?? 'MEDIA',
          reportedById: user.sub,
        },
      });
    });
  }

  /**
   * Actualiza la petición. Al pasar a `RESOLVED` o `CLOSED` se fija
   * `resolvedAt` una sola vez: es la marca que sostiene el cálculo del SLA.
   */
  async updateRequest(
    orgId: string,
    user: AuthUser,
    requestId: string,
    data: { title?: string; description?: string | null; type?: string; priority?: string; status?: string; assigneeId?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.serviceRequest.findUnique({ where: { id: requestId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Petición de servicio no encontrada');
      const closing = data.status === 'RESOLVED' || data.status === 'CLOSED';
      return tx.serviceRequest.update({
        where: { id: requestId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.description !== undefined ? { description: data.description } : {}),
          ...(data.type !== undefined ? { type: data.type } : {}),
          ...(data.priority !== undefined ? { priority: data.priority } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.assigneeId !== undefined ? { assigneeId: data.assigneeId } : {}),
          ...(closing && !row.resolvedAt ? { resolvedAt: new Date() } : {}),
        },
      });
    });
  }

  async deleteRequest(orgId: string, user: AuthUser, requestId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.serviceRequest.findUnique({ where: { id: requestId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Petición de servicio no encontrada');
      await tx.serviceRequest.delete({ where: { id: requestId } });
      return { ok: true, deleted: requestId };
    });
  }
}
