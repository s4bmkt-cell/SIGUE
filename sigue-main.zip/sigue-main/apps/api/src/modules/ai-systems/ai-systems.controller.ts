import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { AiSystemsService } from './ai-systems.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('ai-systems')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/ai-systems', version: '1' })
export class AiSystemsController {
  constructor(private readonly ai: AiSystemsService) {}

  @ApiEndpoint('Inventario de sistemas de IA, casos de uso y riesgos', { status: 200, tenant: true })
  @Get()
  overview(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.ai.overview(orgId, user);
  }

  // ===== Sistemas =====
  @Audit('ai_systems.add_system')
  @ApiEndpoint('Registra un sistema de IA', { status: 201, tenant: true })
  @Post()
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addSystem(@Param('orgId') orgId: string, @Body() data: { name: string; type?: string; vendor?: string; description?: string; dataClassification?: string }, @CurrentUser() user: AuthUser) {
    return this.ai.addSystem(orgId, user, data);
  }

  @Audit('ai_systems.update_system')
  @ApiEndpoint('Actualiza un sistema de IA', { status: 200, tenant: true })
  @Patch(':systemId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateSystem(
    @Param('orgId') orgId: string,
    @Param('systemId') systemId: string,
    @Body() data: { name?: string; type?: string; vendor?: string | null; description?: string | null; dataClassification?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.ai.updateSystem(orgId, user, systemId, data);
  }

  @Audit('ai_systems.delete_system')
  @ApiEndpoint('Elimina un sistema de IA', { status: 200, tenant: true })
  @Delete(':systemId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteSystem(@Param('orgId') orgId: string, @Param('systemId') systemId: string, @CurrentUser() user: AuthUser) {
    return this.ai.deleteSystem(orgId, user, systemId);
  }

  @Audit('ai_systems.update_lifecycle')
  @ApiEndpoint('Avanza la etapa del ciclo de vida del sistema', { status: 200, tenant: true })
  @Patch(':systemId/lifecycle')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateLifecycle(@Param('orgId') orgId: string, @Param('systemId') systemId: string, @Body() data: { stage: string; description?: string }, @CurrentUser() user: AuthUser) {
    return this.ai.updateLifecycle(orgId, user, systemId, data.stage, data.description);
  }

  // ===== Casos de uso =====
  @Audit('ai_systems.add_use_case')
  @ApiEndpoint('Registra un caso de uso de IA', { status: 201, tenant: true })
  @Post('use-cases')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addUseCase(@Param('orgId') orgId: string, @Body() data: { systemId: string; name: string; purpose?: string; supervision?: string }, @CurrentUser() user: AuthUser) {
    return this.ai.addUseCase(orgId, user, data);
  }

  @Audit('ai_systems.update_use_case')
  @ApiEndpoint('Actualiza un caso de uso', { status: 200, tenant: true })
  @Patch('use-cases/:useCaseId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateUseCase(
    @Param('orgId') orgId: string,
    @Param('useCaseId') useCaseId: string,
    @Body() data: { name?: string; purpose?: string | null; supervision?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.ai.updateUseCase(orgId, user, useCaseId, data);
  }

  @Audit('ai_systems.delete_use_case')
  @ApiEndpoint('Elimina un caso de uso', { status: 200, tenant: true })
  @Delete('use-cases/:useCaseId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteUseCase(@Param('orgId') orgId: string, @Param('useCaseId') useCaseId: string, @CurrentUser() user: AuthUser) {
    return this.ai.deleteUseCase(orgId, user, useCaseId);
  }

  // ===== Riesgos =====
  @Audit('ai_systems.add_risk')
  @ApiEndpoint('Registra un riesgo de sistema de IA', { status: 201, tenant: true })
  @Post('risks')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addRisk(@Param('orgId') orgId: string, @Body() data: { systemId: string; title: string; description?: string; likelihood?: number; impact?: number }, @CurrentUser() user: AuthUser) {
    return this.ai.addRisk(orgId, user, data);
  }

  @Audit('ai_systems.update_risk')
  @ApiEndpoint('Actualiza un riesgo de IA', { status: 200, tenant: true })
  @Patch('risks/:riskId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateRisk(
    @Param('orgId') orgId: string,
    @Param('riskId') riskId: string,
    @Body() data: { title?: string; description?: string | null; likelihood?: number; impact?: number },
    @CurrentUser() user: AuthUser,
  ) {
    return this.ai.updateRisk(orgId, user, riskId, data);
  }

  @Audit('ai_systems.delete_risk')
  @ApiEndpoint('Elimina un riesgo de IA', { status: 200, tenant: true })
  @Delete('risks/:riskId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteRisk(@Param('orgId') orgId: string, @Param('riskId') riskId: string, @CurrentUser() user: AuthUser) {
    return this.ai.deleteRisk(orgId, user, riskId);
  }

  // ===== Controles =====
  @Audit('ai_systems.add_control')
  @ApiEndpoint('Agrega un control a un riesgo de IA', { status: 201, tenant: true })
  @Post('risks/:riskId/controls')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addControl(@Param('orgId') orgId: string, @Param('riskId') riskId: string, @Body() data: { title: string; description?: string; source?: string }, @CurrentUser() user: AuthUser) {
    return this.ai.addControl(orgId, user, riskId, data);
  }

  @Audit('ai_systems.update_control')
  @ApiEndpoint('Actualiza un control de IA', { status: 200, tenant: true })
  @Patch('controls/:controlId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateControl(
    @Param('orgId') orgId: string,
    @Param('controlId') controlId: string,
    @Body() data: { title?: string; description?: string | null; source?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.ai.updateControl(orgId, user, controlId, data);
  }

  @Audit('ai_systems.delete_control')
  @ApiEndpoint('Elimina un control de IA', { status: 200, tenant: true })
  @Delete('controls/:controlId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteControl(@Param('orgId') orgId: string, @Param('controlId') controlId: string, @CurrentUser() user: AuthUser) {
    return this.ai.deleteControl(orgId, user, controlId);
  }
}
