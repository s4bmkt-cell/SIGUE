import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

@Injectable()
export class AiSystemsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Vista completa ISO 42001: sistemas, casos de uso, evaluaciones, riesgos, ciclo de vida. */
  async overview(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [systems, useCases, assessments, risks, events] = await Promise.all([
        tx.aiSystem.findMany({ where: { orgId }, orderBy: { createdAt: 'desc' } }),
        tx.aiOrgUseCase.findMany({ where: { orgId }, include: { system: { select: { name: true } } } }),
        tx.aiImpactAssessment.findMany({ where: { orgId }, include: { system: { select: { name: true } } } }),
        tx.aiSystemRisk.findMany({
          where: { orgId },
          include: { controls: true, system: { select: { name: true } } },
        }),
        tx.aiLifecycleEvent.findMany({ where: { orgId }, orderBy: { createdAt: 'desc' }, take: 20 }),
      ]);
      const deployed = systems.filter((s) => s.lifecycleStage === 'DEPLOYED').length;
      const highRisk = risks.filter((r) => r.score >= 10).length;
      const pendingAssess = assessments.filter((a) => a.status !== 'COMPLETED').length;
      return {
        systems,
        useCases,
        assessments,
        risks,
        events,
        summary: { total: systems.length, deployed, highRisk, pendingAssessments: pendingAssess },
      };
    });
  }

  /** Registra un sistema de IA (inventario). */
  async addSystem(orgId: string, user: AuthUser, data: { name: string; type?: string; vendor?: string; description?: string; dataClassification?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      return tx.aiSystem.create({
        data: { orgId, name: data.name, type: data.type ?? 'GENERATIVE', vendor: data.vendor, description: data.description, dataClassification: data.dataClassification ?? 'INTERNO', ownerId: user.sub },
      });
    });
  }

  /** Actualiza la etapa del ciclo de vida y registra el evento. */
  async updateLifecycle(orgId: string, user: AuthUser, systemId: string, stage: string, description?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const sys = await tx.aiSystem.findUnique({ where: { id: systemId } });
      if (!sys || sys.orgId !== orgId) throw new NotFoundException('Sistema de IA no encontrado');
      await tx.aiSystem.update({ where: { id: systemId }, data: { lifecycleStage: stage } });
      return tx.aiLifecycleEvent.create({
        data: { orgId, systemId, eventType: stage === 'DEPLOYED' ? 'DEPLOYED' : stage === 'RETIRED' ? 'RETIRED' : 'STATUS_CHANGE', description: description ?? `Transición a ${stage}` },
      });
    });
  }

  /** Registra un caso de uso de IA. */
  async addUseCase(orgId: string, user: AuthUser, data: { systemId: string; name: string; purpose?: string; supervision?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const sys = await tx.aiSystem.findUnique({ where: { id: data.systemId } });
      if (!sys || sys.orgId !== orgId) throw new NotFoundException('Sistema de IA no encontrado');
      return tx.aiOrgUseCase.create({
        data: { orgId, systemId: data.systemId, name: data.name, purpose: data.purpose, supervision: data.supervision ?? 'HUMAN_IN_LOOP' },
      });
    });
  }

  /** Registra un riesgo de IA con su score. */
  async addRisk(orgId: string, user: AuthUser, data: { systemId: string; title: string; description?: string; likelihood?: number; impact?: number }) {
    await this.assertMember(orgId, user);
    const likelihood = data.likelihood ?? 2;
    const impact = data.impact ?? 2;
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const sys = await tx.aiSystem.findUnique({ where: { id: data.systemId } });
      if (!sys || sys.orgId !== orgId) throw new NotFoundException('Sistema de IA no encontrado');
      return tx.aiSystemRisk.create({
        data: { orgId, systemId: data.systemId, title: data.title, description: data.description, likelihood, impact, score: likelihood * impact, ownerId: user.sub },
      });
    });
  }

  /** Agrega un control a un riesgo de IA. */
  async addControl(orgId: string, user: AuthUser, riskId: string, data: { title: string; description?: string; source?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const risk = await tx.aiSystemRisk.findUnique({ where: { id: riskId } });
      if (!risk || risk.orgId !== orgId) throw new NotFoundException('Riesgo de IA no encontrado');
      return tx.aiSystemControl.create({
        data: { orgId, riskId, title: data.title, description: data.description, source: data.source ?? 'ANEXO_A' },
      });
    });
  }

  // ===== Edición y baja =====
  async updateSystem(
    orgId: string,
    user: AuthUser,
    systemId: string,
    data: { name?: string; type?: string; vendor?: string | null; description?: string | null; dataClassification?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findSystem(tx, orgId, systemId);
      return tx.aiSystem.update({ where: { id: systemId }, data });
    });
  }

  async deleteSystem(orgId: string, user: AuthUser, systemId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findSystem(tx, orgId, systemId);
      await tx.aiSystem.delete({ where: { id: systemId } });
      return { ok: true, deleted: systemId };
    });
  }

  async updateUseCase(
    orgId: string,
    user: AuthUser,
    useCaseId: string,
    data: { name?: string; purpose?: string | null; supervision?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const row = await tx.aiOrgUseCase.findUnique({ where: { id: useCaseId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Caso de uso no encontrado');
      return tx.aiOrgUseCase.update({ where: { id: useCaseId }, data });
    });
  }

  async deleteUseCase(orgId: string, user: AuthUser, useCaseId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const row = await tx.aiOrgUseCase.findUnique({ where: { id: useCaseId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Caso de uso no encontrado');
      await tx.aiOrgUseCase.delete({ where: { id: useCaseId } });
      return { ok: true, deleted: useCaseId };
    });
  }

  /** Reevalúa el riesgo: recalcula el score a partir de probabilidad e impacto. */
  async updateRisk(
    orgId: string,
    user: AuthUser,
    riskId: string,
    data: { title?: string; description?: string | null; likelihood?: number; impact?: number },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const risk = await tx.aiSystemRisk.findUnique({ where: { id: riskId }, include: { controls: true } });
      if (!risk || risk.orgId !== orgId) throw new NotFoundException('Riesgo de IA no encontrado');
      const likelihood = data.likelihood ?? risk.likelihood;
      const impact = data.impact ?? risk.impact;
      return tx.aiSystemRisk.update({
        where: { id: riskId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.description !== undefined ? { description: data.description } : {}),
          ...(data.likelihood !== undefined ? { likelihood } : {}),
          ...(data.impact !== undefined ? { impact } : {}),
          ...(data.likelihood !== undefined || data.impact !== undefined
            ? { score: likelihood * impact }
            : {}),
        },
        include: { controls: true },
      });
    });
  }

  async deleteRisk(orgId: string, user: AuthUser, riskId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const risk = await tx.aiSystemRisk.findUnique({ where: { id: riskId } });
      if (!risk || risk.orgId !== orgId) throw new NotFoundException('Riesgo de IA no encontrado');
      await tx.aiSystemRisk.delete({ where: { id: riskId } });
      return { ok: true, deleted: riskId };
    });
  }

  async updateControl(
    orgId: string,
    user: AuthUser,
    controlId: string,
    data: { title?: string; description?: string | null; source?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const row = await tx.aiSystemControl.findUnique({ where: { id: controlId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Control no encontrado');
      return tx.aiSystemControl.update({ where: { id: controlId }, data });
    });
  }

  async deleteControl(orgId: string, user: AuthUser, controlId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const row = await tx.aiSystemControl.findUnique({ where: { id: controlId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Control no encontrado');
      await tx.aiSystemControl.delete({ where: { id: controlId } });
      return { ok: true, deleted: controlId };
    });
  }

  private async findSystem(
    tx: { aiSystem: { findUnique: (a: { where: { id: string } }) => Promise<{ orgId: string } | null> } },
    orgId: string,
    systemId: string,
  ) {
    const row = await tx.aiSystem.findUnique({ where: { id: systemId } });
    if (!row || row.orgId !== orgId) throw new NotFoundException('Sistema de IA no encontrado');
    return row;
  }
}
