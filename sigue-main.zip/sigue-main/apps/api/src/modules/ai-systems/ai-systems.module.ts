import { Module } from '@nestjs/common';
import { AiSystemsController } from './ai-systems.controller';
import { AiSystemsService } from './ai-systems.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [TenancyModule, AuthSharedModule],
  controllers: [AiSystemsController],
  providers: [AiSystemsService],
})
export class AiSystemsModule {}
