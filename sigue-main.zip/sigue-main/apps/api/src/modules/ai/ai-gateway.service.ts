import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';
import { MockAiProvider } from './mock-ai.provider';
import { AiProviderPort } from './ai-provider.port';
import { UsageService } from '../billing/usage.service';

/** Hash determinista de 32 dims (mock de embedding; prod: modelo de embedding + pgvector). */
function embed(text: string): number[] {
  const dim = 32;
  const v = new Array(dim).fill(0);
  for (let i = 0; i < text.length; i++) v[i % dim] += text.charCodeAt(i);
  const norm = Math.sqrt(v.reduce((a, b) => a + b * b, 0)) || 1;
  return v.map((x) => x / norm);
}

function cosine(a: number[], b: number[]): number {
  let dot = 0;
  for (let i = 0; i < Math.min(a.length, b.length); i++) dot += a[i] * b[i];
  return dot;
}

@Injectable()
export class AiGatewayService {
  /** Registro de proveedores: el mock está activo; los reales se añaden en producción. */
  private readonly providers = new Map<string, AiProviderPort>();

  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
    private readonly usage: UsageService,
  ) {
    this.providers.set('mock', new MockAiProvider());
  }

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Lista casos de uso de IA de la organización (estado, supervisión, cuota). */
  async listUseCases(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [useCases, consumption] = await Promise.all([
        tx.aiUseCase.findMany({ where: { orgId }, orderBy: { code: 'asc' } }),
        tx.aiConsumption.findUnique({ where: { orgId_period: { orgId, period: this.monthPeriod() } } }),
      ]);
      return useCases.map((uc) => {
        const spent = uc.monthlyQuota ? (consumption?.tokens ?? 0) : 0;
        return { ...uc, spentTokens: spent, quotaUsedPct: uc.monthlyQuota ? Math.min(100, Math.round((spent / uc.monthlyQuota) * 100)) : 0 };
      });
    });
  }

  /** Invoca un caso de uso: valida permisos + estado + cuota, hace RAG, genera, traza y consume. */
  async invoke(orgId: string, user: AuthUser, dto: { useCase: string; module?: string; context: Record<string, unknown>; entity?: string }) {
    await this.assertMember(orgId, user);

    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;

      const useCase = await tx.aiUseCase.findUnique({ where: { orgId_code: { orgId, code: dto.useCase } } });
      if (!useCase) throw new NotFoundException('Caso de uso no encontrado');
      if (useCase.status === 'DISABLED') {
        throw new ForbiddenException('Este caso de uso de IA está desactivado');
      }

      // Límite de consumo del mes: primero la bolsa del plan, después la del caso de uso
      const period = this.monthPeriod();
      await this.usage.assertAiTokensTx(tx, orgId);
      const consumption = await tx.aiConsumption.findUnique({ where: { orgId_period: { orgId, period } } });
      if (useCase.monthlyQuota && (consumption?.tokens ?? 0) >= useCase.monthlyQuota) {
        throw new ForbiddenException('Se alcanzó la cuota mensual de este caso de uso');
      }

      // Prompt versionado activo
      const prompt = await tx.aiPrompt.findFirst({
        where: { orgId, useCaseId: useCase.id, status: 'ACTIVE' },
        orderBy: { version: 'desc' },
      });

      // RAG aislado por organización: recupera los fragmentos más similares
      const query = String(dto.context.query ?? dto.entity ?? useCase.name);
      const queryEmbed = embed(query.toLowerCase());
      const allEmbeddings = await tx.aiDocumentEmbedding.findMany({ where: { orgId } });
      const ranked = allEmbeddings
        .map((e) => ({ e, sim: cosine(queryEmbed, e.embedding) }))
        .sort((a, b) => b.sim - a.sim)
        .slice(0, 3);
      const sources = ranked
        .filter((r) => r.sim > 0.05)
        .map((r) => ({ ref: r.e.title, title: r.e.content ?? r.e.sourceType }));

      // Modelo activo (mock en desarrollo)
      const model = await tx.aiModel.findFirst({ where: { status: 'ACTIVE' }, include: { provider: true } });

      // Proveedor registrado activo
      const providerName = model?.provider?.name ?? 'mock';
      const provider = this.providers.get(providerName) ?? this.providers.get('mock')!;

      // Generación (información mínima: solo metadatos de contexto, nunca contenido sensible completo)
      const result = await provider.generate({
        prompt: prompt?.content ?? `Caso de uso: ${useCase.code}`,
        context: { ...dto.context, useCase: useCase.code, label: dto.entity },
      });

      // Consumo acumulado
      const tokens = result.usage.tokens;
      const costUsd = result.usage.costUsd;
      await tx.aiConsumption.upsert({
        where: { orgId_period: { orgId, period } },
        update: { tokens: { increment: tokens }, costUsd: { increment: costUsd } },
        create: { orgId, period, tokens, costUsd },
      });

      // Trazabilidad completa (bitácora de interacción)
      await this.usage.addAiTokensTx(tx, orgId, tokens);

      const interaction = await tx.aiInteraction.create({
        data: {
          orgId,
          userId: user.sub,
          module: dto.module,
          useCaseId: useCase.id,
          modelId: model?.id ?? null,
          promptId: prompt?.id ?? null,
          inputMeta: { entity: dto.entity, fields: Object.keys(dto.context ?? {}) },
          sources,
          output: result.output,
          decision: 'PENDING',
          consumption: { tokens, costUsd, model: result.model },
          latencyMs: 350,
          status: 'DRAFT_READY',
        },
      });

      return {
        interactionId: interaction.id,
        status: 'DRAFT_READY',
        output: result.output,
        sources,
        model: result.model,
        promptVersion: prompt?.version ?? 1,
        decision: 'PENDING',
      };
    });
  }

  /** Supervisión humana: aceptar, modificar (se conserva el original), rechazar o reportar. */
  async decide(orgId: string, user: AuthUser, interactionId: string, dto: { decision: 'ACCEPTED' | 'MODIFIED' | 'REJECTED' | 'REPORTED'; modifiedOutput?: string; note?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const interaction = await tx.aiInteraction.findUnique({ where: { id: interactionId } });
      if (!interaction || interaction.orgId !== orgId) throw new NotFoundException('Interacción no encontrada');

      // Si reporta, registra un incidente de IA
      if (dto.decision === 'REPORTED') {
        await tx.aiIncident.create({
          data: { orgId, type: 'OTHER', severity: 'MEDIA', description: dto.note ?? 'Salida reportada por el usuario', reportedById: user.sub },
        });
      }

      return tx.aiInteraction.update({
        where: { id: interactionId },
        data: {
          decision: dto.decision,
          reviewerId: user.sub,
          approvedAt: new Date(),
          output: dto.decision === 'MODIFIED' && dto.modifiedOutput ? dto.modifiedOutput : interaction.output,
          status: 'DONE',
        },
      });
    });
  }

  /** Búsqueda semántica aislada por organización (RAG). */
  async search(orgId: string, user: AuthUser, query: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const qe = embed(query.toLowerCase());
      const all = await tx.aiDocumentEmbedding.findMany({ where: { orgId } });
      return all
        .map((e) => ({ id: e.id, title: e.title, content: e.content, sourceType: e.sourceType, similarity: Math.round(cosine(qe, e.embedding) * 100) / 100 }))
        .sort((a, b) => b.similarity - a.similarity)
        .slice(0, 5);
    });
  }

  /** Desactiva/activa un caso de uso (desactivación inmediata). */
  async setUseCaseStatus(orgId: string, user: AuthUser, useCaseId: string, status: 'ENABLED' | 'DISABLED') {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.aiUseCase.update({ where: { id: useCaseId }, data: { status } });
    });
  }

  /** Bitácora de interacciones de IA de la organización. */
  async listInteractions(orgId: string, user: AuthUser, limit = 30) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.aiInteraction.findMany({
        where: { orgId },
        orderBy: { createdAt: 'desc' },
        take: limit,
        include: { useCase: { select: { code: true, name: true } } },
      });
    });
  }

  /** Incidentes de IA de la organización. */
  async listIncidents(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.aiIncident.findMany({ where: { orgId }, orderBy: { createdAt: 'desc' } });
    });
  }

  private monthPeriod(): string {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  }
}
