import { Module } from '@nestjs/common';
import { AiController } from './ai.controller';
import { AiGatewayService } from './ai-gateway.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';
import { BillingModule } from '../billing/billing.module';

@Module({
  imports: [TenancyModule, AuthSharedModule, BillingModule],
  controllers: [AiController],
  providers: [AiGatewayService],
  exports: [AiGatewayService],
})
export class AiModule {}
