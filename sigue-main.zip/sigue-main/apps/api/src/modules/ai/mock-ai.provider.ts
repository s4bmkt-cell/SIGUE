import { Injectable } from '@nestjs/common';
import { AiProviderPort, AiGenerationRequest, AiGenerationResult } from './ai-provider.port';

/**
 * Proveedor simulado (desarrollo): genera respuestas deterministas por caso de uso
 * SIN llamar a ninguna API externa. Implementa la misma interfaz que los proveedores
 * reales (Azure OpenAI, OpenAI, Anthropic), que se activan en producción.
 *
 * Salidas diseñadas segun la especificacion de la capa de IA:
 *  - Siempre son borradores/recomendaciones (nunca decisiones).
 *  - Nunca inventan requisitos, fuentes ni evidencias.
 *  - Indican cuando no hay evidencia suficiente.
 */
@Injectable()
export class MockAiProvider implements AiProviderPort {
  readonly name = 'mock';

  async generate(req: AiGenerationRequest): Promise<AiGenerationResult> {
    // Simula latencia de una llamada real
    await new Promise((r) => setTimeout(r, 350));

    const ctx = req.context ?? {};
    const useCase = String(ctx.useCase ?? 'generic');
    const { output, sources } = this.responseFor(useCase, ctx);

    const tokens = Math.max(50, Math.round(output.length / 4));
    return {
      output,
      sources,
      usage: { tokens, costUsd: Math.round(tokens * 0.0015 * 100) / 100000 },
      model: 'sigue-sim-1',
    };
  }

  private responseFor(useCase: string, ctx: Record<string, unknown>): { output: string; sources: { ref: string; title: string }[] } {
    const label = ctx.label ? String(ctx.label) : '';
    const entity = ctx.entity ? String(ctx.entity) : '';

    switch (useCase) {
      case 'draft_document':
        return {
          output:
            'Borrador generado por IA para "' + (entity || 'el documento') + '":\n\n' +
            '- Objetivo: [definir].\n' +
            '- Alcance: [aplica a procesos y actividades].\n' +
            '- Responsabilidades: [asignar roles].\n' +
            '- Actividades: [describir pasos].\n' +
            '- Registros: [F-12 trazabilidad, PR-08].\n\n' +
            'Revisa y completa los campos entre corchetes antes de su uso. Este es un borrador, no un documento aprobado.',
          sources: [{ ref: 'PR-08', title: 'Procedimiento de referencia' }],
        };
      case 'summarize':
        return {
          output:
            'Resumen ejecutivo (borrador IA): el sistema de gestion presenta un nivel de cumplimiento global de ' +
            String(ctx.compliancePct ?? '--') +
            '%. Se recomienda priorizar las acciones criticas y atender los controles vencidos antes de la siguiente revision por la direccion.',
          sources: [{ ref: 'dashboard', title: 'Tablero de cumplimiento' }],
        };
      case 'suggest_risks':
        return {
          output:
            'Riesgos y oportunidades sugeridos (borrador IA) para ' + (entity || 'el proceso') + ':\n' +
            '- [Riesgo 1] con su tratamiento propuesto.\n' +
            '- [Riesgo 2] con su tratamiento propuesto.\n' +
            '- Oportunidad: [mejora sugerida].\n\n' +
            'Valida con el responsable antes de registrar.',
          sources: [{ ref: 'planning', title: 'Matriz de riesgos' }],
        };
      case 'detect_inconsistencies':
        return {
          output:
            'Inconsistencias detectadas (borrador IA):\n' +
            '- Se detectaron posibles desviaciones en ' + (label || 'la informacion revisada') + '.\n' +
            '- Verifica vencimientos y evidencias faltantes.\n\n' +
            'Sin acceso a datos completos, confirma cada hallazgo manualmente.',
          sources: [{ ref: 'documents', title: 'Inventario documental' }],
        };
      case 'root_cause':
        return {
          output:
            'Hipotesis de causa raiz (borrador IA) para "' + (entity || 'la NC') + '":\n' +
            '1. [Posible causa 1].\n' +
            '2. [Posible causa 2].\n' +
            '3. [Posible causa 3].\n\n' +
            'Aplica 5 porques con el responsable del proceso. Estas son hipotesis, no conclusiones.',
          sources: [{ ref: 'nc', title: 'No conformidad' }],
        };
      case 'classify_evidence':
        return {
          output:
            'Clasificacion sugerida (borrador IA) para "' + (entity || 'la evidencia') + '": ' +
            String(ctx.suggestedClass ?? 'INTERNO') +
            '.\n\nConfirma la clasificacion considerando la sensibilidad del contenido antes de aplicarla.',
          sources: [{ ref: 'evidence', title: 'Metadatos de evidencia' }],
        };
      case 'explain':
        return {
          output:
            'Explicacion (asistencia IA): ' + (label || 'Concepto de sistemas de gestion.') +
            '\n\nEsta es una explicacion general orientativa; consulta la documentacion de la norma para el detalle normativo.',
          sources: [{ ref: 'sig', title: 'Guia SIGUE' }],
        };
      default:
        return {
          output: 'Asistencia generada por IA para "' + useCase + '". Sin evidencia suficiente en el contexto para una recomendacion especifica.',
          sources: [],
        };
    }
  }
}
