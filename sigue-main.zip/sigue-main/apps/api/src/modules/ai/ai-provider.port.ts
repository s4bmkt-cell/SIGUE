// Interfaz de proveedor de IA (multi-proveedor).
// Implementaciones: MockAiProvider (sin API externa) y proveedores reales
// (Azure OpenAI, OpenAI, Anthropic) que se conectan vía clave en producción.

export interface AiGenerationRequest {
  prompt: string;
  context: Record<string, unknown>; // metadatos mínimos (nunca datos sensibles completos)
  maxTokens?: number;
}

export interface AiGenerationResult {
  output: string;
  sources: { ref: string; title: string }[];
  usage: { tokens: number; costUsd: number };
  model: string;
}

export interface AiProviderPort {
  readonly name: string;
  generate(req: AiGenerationRequest): Promise<AiGenerationResult>;
}
