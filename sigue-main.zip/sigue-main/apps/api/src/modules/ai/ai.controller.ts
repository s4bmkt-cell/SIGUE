import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { AiGatewayService } from './ai-gateway.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('ai')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/ai', version: '1' })
export class AiController {
  constructor(private readonly ai: AiGatewayService) {}

  @ApiEndpoint('Casos de uso de IA habilitados para la organización', { status: 200, tenant: true })
  @Get('use-cases')
  useCases(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.ai.listUseCases(orgId, user);
  }

  @Audit('ai.invoke')
  @ApiEndpoint('Invoca el copiloto y registra la interacción', { status: 201, tenant: true })
  @Post('interactions')
  invoke(
    @Param('orgId') orgId: string,
    @Body() data: { useCase: string; module?: string; context: Record<string, unknown>; entity?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.ai.invoke(orgId, user, data);
  }

  @Audit('ai.decide')
  @ApiEndpoint('Registra la decisión humana sobre una respuesta de IA', { status: 201, tenant: true })
  @Post('interactions/:interactionId/decision')
  decide(
    @Param('orgId') orgId: string,
    @Param('interactionId') interactionId: string,
    @Body() data: { decision: 'ACCEPTED' | 'MODIFIED' | 'REJECTED' | 'REPORTED'; modifiedOutput?: string; note?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.ai.decide(orgId, user, interactionId, data);
  }

  @ApiEndpoint('Historial de interacciones con el copiloto', { status: 200, tenant: true })
  @Get('interactions')
  interactions(@Param('orgId') orgId: string, @Query('limit') limit: string | undefined, @CurrentUser() user: AuthUser) {
    return this.ai.listInteractions(orgId, user, limit ? parseInt(limit, 10) : 30);
  }

  @ApiEndpoint('Búsqueda semántica sobre los datos de la organización', { status: 200, tenant: true })
  @Get('search')
  search(@Param('orgId') orgId: string, @Query('q') q: string, @CurrentUser() user: AuthUser) {
    return this.ai.search(orgId, user, q ?? '');
  }

  @Audit('ai.set_status')
  @ApiEndpoint('Habilita o deshabilita un caso de uso', { status: 200, tenant: true })
  @Patch('use-cases/:useCaseId/status')
  @RequireRoles('admin_org', 'resp_sgi')
  setStatus(@Param('orgId') orgId: string, @Param('useCaseId') useCaseId: string, @Body('status') status: 'ENABLED' | 'DISABLED', @CurrentUser() user: AuthUser) {
    return this.ai.setUseCaseStatus(orgId, user, useCaseId, status);
  }

  @ApiEndpoint('Incidentes de IA reportados', { status: 200, tenant: true })
  @Get('incidents')
  incidents(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.ai.listIncidents(orgId, user);
  }
}
