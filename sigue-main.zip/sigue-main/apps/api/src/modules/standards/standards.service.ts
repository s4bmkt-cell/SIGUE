import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';
import { UsageService } from '../billing/usage.service';
import { IsmsService } from '../isms/isms.service';

const LEVELS = ['NOT_IMPLEMENTED', 'PARTIAL', 'IMPLEMENTED', 'MATURE'] as const;
export type ComplianceLevel = (typeof LEVELS)[number];

/**
 * Normas con Anexo A, es decir, con controles que requieren declaración de
 * aplicabilidad. ISO 9001, 22301, 20000-1 y 37001 usan otros vehículos
 * (riesgos, BIA, catálogo de servicios, evaluación de soborno).
 */
const ANNEX_A_STANDARDS = ['ISO27001', 'ISO42001'] as const;

export interface ClauseCompliance {
  code: string;
  title: string;
  kind: string;
  level: string;
  pct: number;
  requirementCount: number;
  implementedCount: number;
}

@Injectable()
export class StandardsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
    private readonly usage: UsageService,
    private readonly isms: IsmsService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Catalogo de normas disponibles. */
  listStandards() {
    return this.prisma.standard.findMany({ orderBy: { code: 'asc' } });
  }

  /** Normas activas de la organización + catálogo. */
  async listOrgStandards(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    const { active, catalog } = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const active = await tx.orgStandard.findMany({ include: { standard: true } });
      const catalog = await tx.standard.findMany();
      return { active, catalog };
    });
    return { active, catalog };
  }

  /** Activa una norma para la organización. */
  async activate(orgId: string, standardId: string, user: AuthUser, scopeText?: string) {
    await this.assertMember(orgId, user);
    const standard = await this.prisma.standard.findUnique({ where: { id: standardId } });
    if (!standard) throw new NotFoundException('Norma no encontrada');

    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const current = await tx.orgStandard.findUnique({
        where: { orgId_standardId: { orgId, standardId } },
        select: { status: true },
      });
      // Reactivar una norma ya activa no consume cupo; activar una nueva sí.
      if (current?.status !== 'ACTIVE') {
        await this.usage.assertStandardsTx(tx, orgId, 1);
      }
      const activated = await tx.orgStandard.upsert({
        where: { orgId_standardId: { orgId, standardId } },
        // `scopeText` solo se pisa si viene: reactivar una norma no debe borrar
        // el alcance ya declarado.
        update: { status: 'ACTIVE', ...(scopeText ? { scopeText } : {}) },
        create: { orgId, standardId, status: 'ACTIVE', scopeText },
      });

      // Normas con Anexo A: la Declaración de Aplicabilidad se crea con la
      // activación, no con el seed. Es idempotente, así que reactivar no
      // duplica ni borra lo ya declarado.
      if ((ANNEX_A_STANDARDS as readonly string[]).includes(standard.code)) {
        await this.isms.ensureSoaForStandard(tx, orgId, standardId, standard.code);
      }
      return activated;
    });
  }

  /** Actualiza el alcance declarado de una norma ya activa. */
  async updateScope(orgId: string, standardId: string, user: AuthUser, scopeText: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const current = await tx.orgStandard.findUnique({
        where: { orgId_standardId: { orgId, standardId } },
        select: { id: true },
      });
      if (!current) throw new NotFoundException('La norma no está activa en esta organización');
      return tx.orgStandard.update({
        where: { orgId_standardId: { orgId, standardId } },
        data: { scopeText },
      });
    });
  }

  /** Árbol de cláusulas/requisitos de una norma. */
  async getClauses(standardId: string) {
    return this.prisma.standardClause.findMany({
      where: { standardId },
      orderBy: { sortOrder: 'asc' },
    });
  }

  /** Requisitos de una norma con el nivel de cumplimiento de la organización. */
  async getRequirementsWithStatus(orgId: string, standardId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const clauses = await tx.standardClause.findMany({
        where: { standardId },
        orderBy: { sortOrder: 'asc' },
      });
      const statuses = await tx.requirementStatus.findMany({
        where: { orgId, clause: { standardId } },
      });
      const statusMap = new Map(statuses.map((s) => [s.clauseId, s.level]));
      return clauses.map((c) => ({ ...c, level: statusMap.get(c.id) ?? 'NOT_IMPLEMENTED' }));
    });
  }

  /** Actualiza el nivel de cumplimiento de un requisito. */
  async setRequirementLevel(orgId: string, clauseId: string, level: string, user: AuthUser) {
    if (!LEVELS.includes(level as ComplianceLevel)) {
      throw new NotFoundException('Nivel inválido');
    }
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const clause = await tx.standardClause.findUnique({ where: { id: clauseId } });
      if (!clause) throw new NotFoundException('Requisito no encontrado');
      return tx.requirementStatus.upsert({
        where: { orgId_clauseId: { orgId, clauseId } },
        update: { level, updatedById: user.sub, updatedAt: new Date() },
        create: { orgId, clauseId, level, updatedById: user.sub },
      });
    });
  }

  /** Resumen de cumplimiento por cláusula (para tableros y card). */
  async complianceSummary(orgId: string, standardId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const clauses = await tx.standardClause.findMany({
        where: { standardId },
        orderBy: { sortOrder: 'asc' },
      });
      const statuses = await tx.requirementStatus.findMany({
        where: { orgId, clause: { standardId } },
      });
      const statusMap = new Map(statuses.map((s) => [s.clauseId, s.level]));

      const perClause: ClauseCompliance[] = clauses
        .filter((c) => c.kind === 'requirement')
        .map((c) => {
          const level = statusMap.get(c.id) ?? 'NOT_IMPLEMENTED';
          const pctMap: Record<string, number> = {
            NOT_IMPLEMENTED: 0,
            PARTIAL: 50,
            IMPLEMENTED: 100,
            MATURE: 100,
          };
          return {
            code: c.code,
            title: c.title,
            kind: c.kind,
            level,
            pct: pctMap[level] ?? 0,
            requirementCount: 1,
            implementedCount: level === 'IMPLEMENTED' || level === 'MATURE' ? 1 : 0,
          };
        });

      const total = perClause.length;
      const implemented = perClause.filter((c) => c.pct === 100).length;
      const pct = total ? Math.round((implemented / total) * 100) : 0;
      const pending = total - implemented;

      return {
        standardId,
        total,
        implemented,
        pending,
        pct,
        byClause: perClause,
      };
    });
  }
}
