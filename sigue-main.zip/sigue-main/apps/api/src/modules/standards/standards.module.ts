import { Module } from '@nestjs/common';
import { StandardsController } from './standards.controller';
import { StandardsService } from './standards.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';
import { BillingModule } from '../billing/billing.module';
import { IsmsModule } from '../isms/isms.module';

@Module({
  imports: [TenancyModule, AuthSharedModule, BillingModule, IsmsModule],
  controllers: [StandardsController],
  providers: [StandardsService],
})
export class StandardsModule {}
