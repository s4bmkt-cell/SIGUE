import { Body, Controller, Get, Param, Patch, Post, Put, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { StandardsService } from './standards.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('standards')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/standards', version: '1' })
export class StandardsController {
  constructor(private readonly standards: StandardsService) {}

  @ApiEndpoint('Normas activas y catálogo disponible', { status: 200, tenant: true })
  @Get()
  list(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.standards.listOrgStandards(orgId, user);
  }

  @Audit('standards.activate')
  @ApiEndpoint('Activa una norma en la organización', { status: 201, tenant: true })
  @Post(':standardId/activate')
  @RequireRoles('admin_org', 'resp_sgi', 'resp_norma')
  activate(
    @Param('orgId') orgId: string,
    @Param('standardId') standardId: string,
    @Body('scopeText') scopeText: string | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    return this.standards.activate(orgId, standardId, user, scopeText);
  }

  @Audit('standards.update_scope')
  @ApiEndpoint('Actualiza el alcance declarado de una norma activa', { status: 200, tenant: true })
  @Patch(':standardId/scope')
  @RequireRoles('admin_org', 'resp_sgi', 'resp_norma')
  updateScope(
    @Param('orgId') orgId: string,
    @Param('standardId') standardId: string,
    @Body('scopeText') scopeText: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.standards.updateScope(orgId, standardId, user, scopeText);
  }

  @ApiEndpoint('Requisitos de la norma con su nivel de cumplimiento', { status: 200, tenant: true })
  @Get(':standardId/requirements')
  requirements(
    @Param('orgId') orgId: string,
    @Param('standardId') standardId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.standards.getRequirementsWithStatus(orgId, standardId, user);
  }

  @Audit('standards.set_level')
  @ApiEndpoint('Actualiza el nivel de un requisito', { status: 200, tenant: true })
  @Put(':standardId/requirements/:clauseId/level')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'resp_riesgos', 'controlador_doc', 'admin_org')
  setLevel(
    @Param('orgId') orgId: string,
    @Param('clauseId') clauseId: string,
    @Body('level') level: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.standards.setRequirementLevel(orgId, clauseId, level, user);
  }

  @ApiEndpoint('Resumen de cumplimiento de una norma', { status: 200, tenant: true })
  @Get(':standardId/compliance')
  compliance(
    @Param('orgId') orgId: string,
    @Param('standardId') standardId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.standards.complianceSummary(orgId, standardId, user);
  }
}
