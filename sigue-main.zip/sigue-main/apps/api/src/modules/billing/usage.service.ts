import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { withTenant } from '../../tenancy/with-tenant';
import { BYTES_PER_GB, PlanLimits, currentPeriod, limitsFor } from './plan-limits';

export interface UsageSnapshot {
  planCode: string;
  limits: PlanLimits;
  seats: number;
  pendingInvitations: number;
  standards: number;
  storageGb: number;
  aiTokens: number;
  period: string;
}

type TxClient = Prisma.TransactionClient;

/**
 * Cuotas del plan.
 *
 * `OrgUsage` es una **caché** de consumo (la leen los tableros y la exportación),
 * pero las decisiones de negocio se toman con datos reales dentro de la misma
 * transacción: así un cambio hecho por fuera de los flujos normales no deja la
 * cuota desactualizada y nadie puede pasarse del límite por una fila vieja.
 */
@Injectable()
export class UsageService {
  constructor(private readonly prisma: PrismaService) {}

  /** Plan vigente: la suscripción manda; la organización es el respaldo. */
  async planCode(orgId: string): Promise<string> {
    return withTenant(this.prisma, { orgId }, (tx) => this.planCodeTx(tx, orgId));
  }

  async planCodeTx(tx: TxClient, orgId: string): Promise<string> {
    const sub = await tx.subscription.findUnique({ where: { orgId }, select: { planCode: true } });
    if (sub) return sub.planCode;
    const org = await tx.organization.findUnique({ where: { id: orgId }, select: { planCode: true } });
    if (!org) throw new NotFoundException('Organización no encontrada');
    return org.planCode;
  }

  async limits(orgId: string): Promise<PlanLimits> {
    return limitsFor(await this.planCode(orgId));
  }

  /** Consumo real, sin escribir nada. */
  async snapshot(orgId: string): Promise<UsageSnapshot> {
    return withTenant(this.prisma, { orgId }, (tx) => this.snapshotTx(tx, orgId));
  }

  async snapshotTx(tx: TxClient, orgId: string): Promise<UsageSnapshot> {
    const planCode = await this.planCodeTx(tx, orgId);
    const period = currentPeriod();
    const [seats, pendingInvitations, standards, files, ai] = await Promise.all([
      tx.orgMember.count({ where: { orgId, status: 'ACTIVE' } }),
      tx.invitation.count({
        where: { orgId, status: 'PENDING', expiresAt: { gt: new Date() } },
      }),
      tx.orgStandard.count({ where: { orgId, status: 'ACTIVE' } }),
      tx.evidenceFile.aggregate({ where: { orgId }, _sum: { size: true } }),
      tx.aiConsumption.findUnique({ where: { orgId_period: { orgId, period } } }),
    ]);

    const bytes = Number(files._sum.size ?? 0);
    return {
      planCode,
      limits: limitsFor(planCode),
      seats,
      pendingInvitations,
      standards,
      storageGb: Number((bytes / BYTES_PER_GB).toFixed(4)),
      aiTokens: ai?.tokens ?? 0,
      period,
    };
  }

  /** Recalcula y guarda el consumo en `OrgUsage`. Devuelve la foto usada. */
  async sync(orgId: string): Promise<UsageSnapshot> {
    return withTenant(this.prisma, { orgId }, (tx) => this.syncTx(tx, orgId));
  }

  async syncTx(tx: TxClient, orgId: string): Promise<UsageSnapshot> {
    const snap = await this.snapshotTx(tx, orgId);
    const total = 'TOTAL';

    await this.writeQuota(tx, orgId, 'users', total, snap.seats + snap.pendingInvitations, snap.limits.users);
    await this.writeQuota(tx, orgId, 'storage_gb', total, snap.storageGb, snap.limits.storageGb);
    await this.writeQuota(tx, orgId, 'standards', total, snap.standards, snap.limits.standards);
    await this.writeQuota(tx, orgId, 'ai_tokens', snap.period, snap.aiTokens, snap.limits.aiTokens);

    return snap;
  }

  /** Rechaza si no hay lugar para más miembros (activos + invitaciones pendientes). */
  async assertUsers(orgId: string, additional = 1): Promise<void> {
    await withTenant(this.prisma, { orgId }, (tx) => this.assertUsersTx(tx, orgId, additional));
  }

  async assertUsersTx(tx: TxClient, orgId: string, additional = 1): Promise<void> {
    const snap = await this.snapshotTx(tx, orgId);
    const reserved = snap.seats + snap.pendingInvitations;
    if (reserved + additional > snap.limits.users) {
      throw new ForbiddenException(
        `La cuota de ${snap.limits.users} usuarios del plan ${snap.limits.name} está llena ` +
          `(${snap.seats} activos y ${snap.pendingInvitations} invitaciones pendientes).`,
      );
    }
  }

  /**
   * Lugares ocupados al canjear una invitación: la invitación pendiente ya
   * reservaba su lugar, así que solo se cuentan las membresías activas.
   */
  async assertSeatTx(tx: TxClient, orgId: string): Promise<void> {
    const snap = await this.snapshotTx(tx, orgId);
    if (snap.seats + 1 > snap.limits.users) {
      throw new ForbiddenException(
        `La cuota de ${snap.limits.users} usuarios del plan ${snap.limits.name} está llena.`,
      );
    }
  }

  /** Rechaza activar más normas de las incluidas en el plan. */
  async assertStandards(orgId: string, additional = 1): Promise<void> {
    await withTenant(this.prisma, { orgId }, (tx) => this.assertStandardsTx(tx, orgId, additional));
  }

  async assertStandardsTx(tx: TxClient, orgId: string, additional = 1): Promise<void> {
    const snap = await this.snapshotTx(tx, orgId);
    if (snap.standards + additional > snap.limits.standards) {
      throw new ForbiddenException(
        `El plan ${snap.limits.name} incluye ${snap.limits.standards} norma(s) activa(s) ` +
          `y ya hay ${snap.standards}. Desactiva una o cambia de plan.`,
      );
    }
  }

  /** Rechaza consumir tokens de IA por encima de la bolsa mensual del plan. */
  async assertAiTokens(orgId: string, additional = 0): Promise<void> {
    await withTenant(this.prisma, { orgId }, (tx) => this.assertAiTokensTx(tx, orgId, additional));
  }

  async assertAiTokensTx(tx: TxClient, orgId: string, additional = 0): Promise<void> {
    const snap = await this.snapshotTx(tx, orgId);
    if (snap.aiTokens + additional >= snap.limits.aiTokens) {
      throw new ForbiddenException(
        `La bolsa mensual de IA del plan ${snap.limits.name} se agotó ` +
          `(${snap.aiTokens} de ${snap.limits.aiTokens} tokens en ${snap.period}).`,
      );
    }
  }

  /** Suma tokens consumidos y deja la caché de cuota al día. */
  async addAiTokens(orgId: string, tokens: number): Promise<void> {
    await withTenant(this.prisma, { orgId }, (tx) => this.addAiTokensTx(tx, orgId, tokens));
  }

  async addAiTokensTx(tx: TxClient, orgId: string, tokens: number): Promise<void> {
    if (tokens <= 0) return;
    const snap = await this.snapshotTx(tx, orgId);
    await this.writeQuota(
      tx,
      orgId,
      'ai_tokens',
      snap.period,
      snap.aiTokens + tokens,
      snap.limits.aiTokens,
    );
  }

  /** Rechaza una carga si el plan no tiene espacio de almacenamiento. */
  async assertStorage(orgId: string, bytes: number): Promise<void> {
    await withTenant(this.prisma, { orgId }, (tx) => this.assertStorageTx(tx, orgId, bytes));
  }

  async assertStorageTx(tx: TxClient, orgId: string, bytes: number): Promise<void> {
    const snap = await this.snapshotTx(tx, orgId);
    if (snap.storageGb + bytes / BYTES_PER_GB > snap.limits.storageGb) {
      throw new ForbiddenException(
        `La cuota de almacenamiento del plan ${snap.limits.name} está agotada ` +
          `(${snap.storageGb.toFixed(2)} de ${snap.limits.storageGb} GB).`,
      );
    }
  }

  /** Escribe la fila de cuota (upsert por organización + recurso + periodo). */
  async writeQuota(
    tx: TxClient,
    orgId: string,
    resource: string,
    period: string,
    used: number,
    quota: number,
  ): Promise<void> {
    await tx.orgUsage.upsert({
      where: { orgId_resource_period: { orgId, resource, period } },
      update: { used, quota },
      create: { orgId, resource, period, used, quota },
    });
  }
}
