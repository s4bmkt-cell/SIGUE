import { Module } from '@nestjs/common';
import { BillingController, BillingWebhookController } from './billing.controller';
import { BillingService } from './billing.service';
import { UsageService } from './usage.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';
import { AuditModule } from '../audit/audit.module';

@Module({
  imports: [TenancyModule, AuthSharedModule, AuditModule],
  controllers: [BillingController, BillingWebhookController],
  providers: [BillingService, UsageService],
  // `UsageService` es el guardián de cuotas: lo usan usuarios y normas.
  exports: [UsageService],
})
export class BillingModule {}
