import { BadRequestException, Controller, Get, Headers, Param, Post, RawBodyRequest, Req, UseGuards, Body } from '@nestjs/common';
import { ApiBearerAuth, ApiExcludeEndpoint, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import type { Request } from 'express';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { BillingService } from './billing.service';
import { UsageService } from './usage.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { Public } from '../../common/decorators/public.decorator';

@ApiTags('billing')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/billing', version: '1' })
export class BillingController {
  constructor(
    private readonly billing: BillingService,
    private readonly usage: UsageService,
  ) {}

  @ApiEndpoint('Suscripción y cuotas de la organización', { status: 200, tenant: true })
  @Get('subscription')
  @RequireRoles('admin_org', 'alta_direccion', 'admin_global')
  subscription(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.billing.getSubscription(orgId, user);
  }

  @ApiEndpoint('Planes disponibles', { status: 200, tenant: true })
  @Get('plans')
  plans() {
    return this.billing.listPlans();
  }

  /** Consumo real por recurso, sin depender de la caché de cuotas. */
  @ApiEndpoint('Consumo actual frente a los límites del plan', { status: 200, tenant: true })
  @Get('usage')
  async currentUsage(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    await this.billing.assertMember(orgId, user);
    return this.usage.snapshot(orgId);
  }

  @Audit('billing.change_plan')
  @ApiEndpoint('Solicita un cambio de plan', { status: 201, tenant: true })
  @Post('plan')
  @RequireRoles('admin_org', 'admin_global')
  changePlan(
    @Param('orgId') orgId: string,
    @Body('planCode') planCode: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.billing.changePlan(orgId, user, planCode);
  }
}

/**
 * Webhook del proveedor de cobros.
 *
 * Vive en su propio controlador porque es **público**: lo invoca Stripe (o el
 * proveedor que se configure), no un usuario. La autenticidad se valida con la
 * firma del cuerpo crudo, no con la sesión.
 */
@ApiTags('billing')
@Controller({ path: 'billing', version: '1' })
export class BillingWebhookController {
  constructor(private readonly billing: BillingService) {}

  @Public()
  @ApiExcludeEndpoint()
  @ApiEndpoint('Webhook del proveedor de pagos (firmado)', { status: 201, tenant: false, auth: false })
  @Post('webhook')
  webhook(
    @Req() req: RawBodyRequest<Request>,
    @Headers('stripe-signature') stripeSignature: string | undefined,
    @Headers('x-sigue-signature') localSignature: string | undefined,
  ) {
    const raw = req.rawBody;
    if (!raw) {
      throw new BadRequestException(
        'El webhook requiere el cuerpo crudo; verifica la configuración del servidor',
      );
    }
    return this.billing.handleWebhook(raw, stripeSignature ?? localSignature);
  }
}
