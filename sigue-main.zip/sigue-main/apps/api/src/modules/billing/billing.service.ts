import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';
import { withTenant } from '../../tenancy/with-tenant';
import { AuditService } from '../audit/audit.service';
import { PAYMENT_PROVIDER, PaymentProviderPort } from '../../common/payments/payment-provider.port';
import { PlanLimits, PLAN_LIMITS, limitsFor } from './plan-limits';
import { UsageService } from './usage.service';

export { PLAN_LIMITS } from './plan-limits';

/**
 * Suscripción y cambios de plan.
 *
 * El plan se aplica aquí, pero los límites se hacen cumplir donde se consume el
 * recurso (`UsageService`): así el enforcement no depende de que un módulo
 * recuerde llamar al billing. Un cambio de plan a uno más pequeño se rechaza si
 * el consumo actual ya no cabría, y no se "recorta" nada en silencio.
 */
@Injectable()
export class BillingService {
  private readonly logger = new Logger('Billing');

  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
    private readonly usage: UsageService,
    private readonly audit: AuditService,
    private readonly config: ConfigService,
    @Inject(PAYMENT_PROVIDER) private readonly payments: PaymentProviderPort,
  ) {}

  /** Membresía de la organización (la usa también el controlador). */
  async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Resumen de suscripción + uso de cuotas del plan (recálculo real). */
  async getSubscription(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    const updated = await this.usage.sync(orgId);
    return this.readSubscription(orgId, updated);
  }

  /** Catálogo de planes disponibles (para upgrade/downgrade). */
  listPlans() {
    return Object.entries(PLAN_LIMITS).map(([code, p]) => ({ code, ...p }));
  }

  /**
   * Inicia el cambio de plan.
   *
   * Con un proveedor de cobros real devuelve la URL del checkout y **no** toca
   * el plan hasta que llegue el webhook. Con el adaptador local aplica el cambio
   * de inmediato y devuelve `applied: true` (no hay cobro que esperar).
   */
  async changePlan(orgId: string, user: AuthUser, planCode: string) {
    const plan = PLAN_LIMITS[planCode];
    if (!plan) throw new NotFoundException('Plan no válido');
    await this.assertMember(orgId, user);

    const sub = await withTenant(this.prisma, { orgId }, (tx) =>
      tx.subscription.findUnique({ where: { orgId } }),
    );
    if (!sub) throw new NotFoundException('Suscripción no encontrada');
    if (sub.status === 'CANCELLED') {
      throw new BadRequestException('La suscripción está cancelada; contacta a soporte');
    }

    const snap = await this.usage.snapshot(orgId);
    if (sub.planCode === planCode) {
      return {
        applied: true,
        checkout: null,
        planCode,
        usage: await this.readSubscription(orgId, snap),
        message: 'La organización ya tiene este plan',
      };
    }

    // Bajar de plan exige que lo ya consumido quepa en el nuevo cupo. Cortar
    // datos del cliente por un downgrade sería peor que rechazarlo.
    if (plan.monthlyUsd < limitsFor(sub.planCode).monthlyUsd) {
      this.assertDowngradeFits(planCode, plan, snap);
    }

    const origin = this.webOrigin();
    const checkout = await this.payments.createCheckout({
      orgId,
      planCode,
      amountUsd: plan.monthlyUsd,
      customerEmail: user.email,
      successUrl: `${origin}/subscription?plan=${planCode}`,
      cancelUrl: `${origin}/subscription?plan=cancelled`,
    });

    if (checkout.mode === 'live') {
      return {
        applied: false,
        checkout,
        planCode: sub.planCode,
        message: 'Completa el pago para activar el nuevo plan',
      };
    }

    const applied = await this.applyPlan(orgId, planCode, user.sub, {
      provider: this.payments.name,
      ref: checkout.ref,
    });

    return {
      applied: true,
      checkout,
      planCode,
      usage: applied,
      message: `Plan ${plan.name} activado (modo local: sin cobro)`,
    };
  }

  /**
   * Aplica un plan y recalcula cuotas.
   *
   * Se usa desde el cambio directo y desde el webhook, así que es idempotente:
   * aplicar dos veces el mismo plan solo reescribe las mismas filas.
   */
  async applyPlan(
    orgId: string,
    planCode: string,
    actorId: string | null,
    meta: { provider?: string; ref?: string; status?: string } = {},
  ) {
    const plan = PLAN_LIMITS[planCode];
    if (!plan) throw new NotFoundException('Plan no válido');

    const snap = await withTenant(this.prisma, { orgId }, async (tx) => {
      const sub = await tx.subscription.findUnique({ where: { orgId } });
      if (!sub) throw new NotFoundException('Suscripción no encontrada');

      // El webhook también puede aplicar un plan más pequeño: la misma regla
      // del cambio directo vale aquí, para no dejar a la organización por
      // encima de su cupo sin aviso.
      if (plan.monthlyUsd < limitsFor(sub.planCode).monthlyUsd) {
        this.assertDowngradeFits(planCode, plan, await this.usage.snapshotTx(tx, orgId));
      }

      await tx.subscription.update({
        where: { orgId },
        data: {
          planCode,
          status: meta.status ?? (sub.status === 'TRIAL' ? 'TRIAL' : 'ACTIVE'),
          stripeSubId: sub.stripeSubId ?? meta.ref ?? null,
        },
      });
      // La ficha de la organización también refleja el plan: hay flujos que solo
      // leen `Organization.planCode`.
      await tx.organization.update({ where: { id: orgId }, data: { planCode } });

      return this.usage.syncTx(tx, orgId);
    });

    await this.audit.record({
      orgId,
      actorId,
      action: 'billing.plan_applied',
      entity: 'subscription',
      entityId: orgId,
      after: { planCode, provider: meta.provider ?? null, ref: meta.ref ?? null },
    });

    this.logger.log(`Plan ${planCode} aplicado a ${orgId} (${meta.provider ?? 'manual'})`);
    return this.readSubscription(orgId, snap);
  }

  /** Cambia el estado de la suscripción (p. ej. suspensión por impago). */
  async setStatus(orgId: string, status: string, actorId: string | null, ref?: string) {
    const allowed = ['ACTIVE', 'TRIAL', 'SUSPENDED', 'CANCELLED'];
    if (!allowed.includes(status)) throw new BadRequestException('Estado de suscripción no válido');

    await withTenant(this.prisma, { orgId }, async (tx) => {
      const sub = await tx.subscription.findUnique({ where: { orgId } });
      if (!sub) throw new NotFoundException('Suscripción no encontrada');
      await tx.subscription.update({ where: { orgId }, data: { status } });
    });

    await this.audit.record({
      orgId,
      actorId,
      action: 'billing.status_changed',
      entity: 'subscription',
      entityId: orgId,
      after: { status, ref: ref ?? null },
    });
    return { ok: true, status };
  }

  /**
   * Webhook del proveedor de cobros.
   *
   * Es público (lo llama el proveedor, no un usuario), así que la autenticidad
   * la da la firma: sin `PAYMENTS_WEBHOOK_SECRET` no se acepta nada.
   */
  async handleWebhook(rawBody: Buffer, signature: string | undefined) {
    const event = this.payments.parseWebhook(rawBody, signature);

    if (!event.orgId) {
      // Sin organización no hay nada que aplicar; se confirma para que el
      // proveedor no reintente un evento que nunca podremos procesar.
      this.logger.warn(`Webhook ${event.id} (${event.type}) sin orgId: ignorado`);
      return { received: true, applied: false };
    }

    const known = await withTenant(this.prisma, { orgId: event.orgId }, (tx) =>
      tx.subscription.findUnique({ where: { orgId: event.orgId } }),
    );
    if (!known) throw new NotFoundException('Organización del evento no encontrada');

    switch (event.type) {
      case 'checkout.session.completed':
      case 'customer.subscription.updated':
        if (event.planCode) {
          await this.applyPlan(event.orgId, event.planCode, null, {
            provider: this.payments.name,
            ref: event.subscriptionRef ?? event.id,
            status: event.status,
          });
        }
        break;
      case 'customer.subscription.deleted':
        await this.setStatus(event.orgId, 'CANCELLED', null, event.id);
        break;
      default:
        this.logger.log(`Webhook ${event.id}: tipo ${event.type} sin efecto`);
    }

    return { received: true, applied: true, type: event.type };
  }

  /** Comprobaciones de downgrade contra el consumo real. */
  private assertDowngradeFits(
    planCode: string,
    plan: PlanLimits,
    snap: Awaited<ReturnType<UsageService['snapshot']>>,
  ) {
    const problems: string[] = [];
    if (snap.seats > plan.users) {
      problems.push(`${snap.seats} usuarios activos (máximo ${plan.users})`);
    }
    if (snap.standards > plan.standards) {
      problems.push(`${snap.standards} normas activas (máximo ${plan.standards})`);
    }
    if (snap.storageGb > plan.storageGb) {
      problems.push(`${snap.storageGb.toFixed(2)} GB usados (máximo ${plan.storageGb})`);
    }
    if (problems.length) {
      throw new ConflictException(
        `No se puede bajar al plan ${plan.name}: ${problems.join(', ')}. ` +
          'Libera recursos o conserva el plan actual.',
      );
    }
    // El plan existe en el catálogo y la suscripción también: esto es solo una
    // salvaguarda por si algún día el catálogo cambia a mitad de vuelo.
    if (!PLAN_LIMITS[planCode]) throw new NotFoundException('Plan no válido');
  }

  private async readSubscription(orgId: string, snap: Awaited<ReturnType<UsageService['snapshot']>>) {
    const sub = await withTenant(this.prisma, { orgId }, (tx) =>
      tx.subscription.findUnique({ where: { orgId } }),
    );
    if (!sub) throw new NotFoundException('Suscripción no encontrada');

    const limits = limitsFor(sub.planCode);
    const pct = (used: number, quota: number) =>
      quota ? Math.min(100, Math.round((used / quota) * 100)) : 0;

    return {
      subscription: {
        planCode: sub.planCode,
        planName: limits.name,
        status: sub.status,
        periodStart: sub.periodStart,
        periodEnd: sub.periodEnd,
        cfdiRef: sub.cfdiRef,
        monthlyUsd: limits.monthlyUsd,
        paymentProvider: this.payments.name,
        livePayments: this.payments.live,
      },
      quotas: {
        users: {
          used: snap.seats + snap.pendingInvitations,
          active: snap.seats,
          pending: snap.pendingInvitations,
          quota: limits.users,
          pct: pct(snap.seats + snap.pendingInvitations, limits.users),
        },
        storageGb: {
          used: snap.storageGb,
          quota: limits.storageGb,
          pct: pct(snap.storageGb, limits.storageGb),
        },
        standards: {
          used: snap.standards,
          quota: limits.standards,
          pct: pct(snap.standards, limits.standards),
        },
        aiTokens: {
          used: snap.aiTokens,
          quota: limits.aiTokens,
          pct: pct(snap.aiTokens, limits.aiTokens),
          period: snap.period,
        },
      },
    };
  }

  private webOrigin(): string {
    const raw = this.config.get<string>('WEB_APP_URL') ?? 'http://localhost:3000';
    return raw.split(',')[0].trim().replace(/\/+$/, '');
  }
}
