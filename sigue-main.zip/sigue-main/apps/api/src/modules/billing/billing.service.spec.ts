import { BadRequestException, ConflictException, NotFoundException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { BillingService } from './billing.service';
import { UsageService } from './usage.service';
import { PrismaService } from '../../prisma/prisma.service';
import { TenancyService } from '../../tenancy/tenancy.service';
import { AuditService } from '../audit/audit.service';
import { PaymentProviderPort } from '../../common/payments/payment-provider.port';
import { LocalPaymentProviderAdapter } from '../../common/payments/local-payment.adapter';
import { AuthUser } from '../../common/decorators/current-user.decorator';

const user: AuthUser = {
  sub: 'u1',
  email: 'admin@org.mx',
  name: 'Admin',
  roles: ['admin_org'],
  orgId: 'o1',
};

function usageSnapshot(overrides: Partial<Record<string, unknown>> = {}) {
  return {
    planCode: 'PROFESSIONAL',
    limits: { name: 'Profesional', users: 50, storageGb: 2000, standards: 3, aiTokens: 5000, monthlyUsd: 249 },
    seats: 10,
    pendingInvitations: 0,
    standards: 2,
    storageGb: 1,
    aiTokens: 0,
    period: '2026-10',
    ...overrides,
  };
}

function build(opts: {
  planCode?: string;
  status?: string;
  snap?: Record<string, unknown>;
  provider?: PaymentProviderPort;
} = {}) {
  const sub = {
    orgId: 'o1',
    planCode: opts.planCode ?? 'PROFESSIONAL',
    status: opts.status ?? 'ACTIVE',
    stripeSubId: null,
  };

  const tx = {
    $executeRaw: jest.fn().mockResolvedValue(undefined),
    subscription: {
      findUnique: jest.fn().mockResolvedValue(sub),
      update: jest.fn().mockResolvedValue({ ...sub, planCode: 'ESSENTIAL' }),
    },
    organization: { update: jest.fn().mockResolvedValue({}) },
  };

  const prisma = {
    $transaction: jest.fn(async (fn: (client: typeof tx) => Promise<unknown>) => fn(tx)),
  } as unknown as PrismaService;

  const tenancy = { isMember: jest.fn().mockResolvedValue(true) } as unknown as TenancyService;

  const snapshot = opts.snap ?? usageSnapshot();
  const usage = {
    snapshot: jest.fn().mockResolvedValue(snapshot),
    snapshotTx: jest.fn().mockResolvedValue(snapshot),
    sync: jest.fn().mockResolvedValue(snapshot),
    syncTx: jest.fn().mockResolvedValue(snapshot),
  } as unknown as UsageService;

  const audit = { record: jest.fn().mockResolvedValue(null) } as unknown as AuditService;

  const config = {
    get: jest.fn().mockReturnValue('http://localhost:3000'),
  } as unknown as ConfigService;

  const provider = opts.provider ?? new LocalPaymentProviderAdapter();

  const service = new BillingService(prisma, tenancy, usage, audit, config, provider);
  return { service, prisma, tx, usage, audit, provider };
}

describe('BillingService — lectura', () => {
  it('recalcula el consumo con datos reales al consultar la suscripción', async () => {
    const { service, usage } = build();
    const result = await service.getSubscription('o1', user);

    expect(usage.sync).toHaveBeenCalledWith('o1');
    expect(result.quotas.users).toMatchObject({ used: 10, quota: 50, pct: 20 });
  });

  it('expone el proveedor de cobros y si cobra de verdad', async () => {
    const { service } = build();
    const result = await service.getSubscription('o1', user);
    expect(result.subscription.paymentProvider).toBe('local');
    expect(result.subscription.livePayments).toBe(false);
  });

  it('rechaza a quien no pertenece a la organización', async () => {
    const { service } = build();
    (service as unknown as { tenancy: { isMember: jest.Mock } }).tenancy.isMember.mockResolvedValue(
      false,
    );
    await expect(service.getSubscription('o1', user)).rejects.toThrow(
      'No perteneces a esta organización',
    );
  });
});

describe('BillingService — cambio de plan', () => {
  it('aplica el plan de inmediato con el proveedor local', async () => {
    const { service, usage, tx } = build({ planCode: 'ESSENTIAL' });
    const result = await service.changePlan('o1', user, 'PROFESSIONAL');

    expect(result.applied).toBe(true);
    expect(result.checkout?.mode).toBe('local');
    expect(tx.subscription.update).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ planCode: 'PROFESSIONAL' }) }),
    );
    expect(tx.organization.update).toHaveBeenCalledWith({
      where: { id: 'o1' },
      data: { planCode: 'PROFESSIONAL' },
    });
    expect(usage.syncTx).toHaveBeenCalled();
  });

  it('no cambia nada si el plan pedido es el actual', async () => {
    const { service, tx } = build({ planCode: 'PROFESSIONAL' });
    const result = await service.changePlan('o1', user, 'PROFESSIONAL');
    expect(result.applied).toBe(true);
    expect(result.message).toContain('ya tiene este plan');
    expect(tx.subscription.update).not.toHaveBeenCalled();
  });

  it('rechaza un plan inexistente', async () => {
    const { service } = build();
    await expect(service.changePlan('o1', user, 'PLATINUM')).rejects.toBeInstanceOf(
      NotFoundException,
    );
  });

  it('rechaza bajar de plan si los usuarios activos no caben', async () => {
    const { service } = build({
      planCode: 'PROFESSIONAL',
      snap: usageSnapshot({ seats: 40 }),
    });
    await expect(service.changePlan('o1', user, 'ESSENTIAL')).rejects.toBeInstanceOf(
      ConflictException,
    );
  });

  it('rechaza bajar de plan si las normas activas no caben', async () => {
    const { service } = build({
      planCode: 'PROFESSIONAL',
      snap: usageSnapshot({ standards: 3 }),
    });
    await expect(service.changePlan('o1', user, 'ESSENTIAL')).rejects.toBeInstanceOf(
      ConflictException,
    );
  });

  it('rechaza bajar de plan si el almacenamiento usado no cabe', async () => {
    const { service } = build({
      planCode: 'PROFESSIONAL',
      snap: usageSnapshot({ storageGb: 900 }),
    });
    await expect(service.changePlan('o1', user, 'ESSENTIAL')).rejects.toBeInstanceOf(
      ConflictException,
    );
  });

  it('permite subir de plan sin revisar consumos', async () => {
    const { service } = build({
      planCode: 'ESSENTIAL',
      snap: usageSnapshot({ seats: 20, standards: 1, storageGb: 400 }),
    });
    await expect(service.changePlan('o1', user, 'BUSINESS')).resolves.toMatchObject({
      applied: true,
    });
  });

  it('con un proveedor real devuelve el checkout y no aplica el plan', async () => {
    const provider: PaymentProviderPort = {
      name: 'stripe',
      live: true,
      createCheckout: jest.fn().mockResolvedValue({
        mode: 'live',
        ref: 'cs_test',
        url: 'https://checkout.stripe.com/cs_test',
        amountUsd: 249,
      }),
      parseWebhook: jest.fn(),
    };
    const { service, tx } = build({ planCode: 'ESSENTIAL', provider });
    const result = await service.changePlan('o1', user, 'PROFESSIONAL');

    expect(result.applied).toBe(false);
    expect(result.checkout?.url).toContain('stripe.com');
    expect(tx.subscription.update).not.toHaveBeenCalled();
  });

  it('no permite cambiar el plan de una suscripción cancelada', async () => {
    const { service } = build({ status: 'CANCELLED' });
    await expect(service.changePlan('o1', user, 'BUSINESS')).rejects.toBeInstanceOf(
      BadRequestException,
    );
  });
});

describe('BillingService — webhook', () => {
  const SECRET = 'test-secret';
  const body = Buffer.from(
    JSON.stringify({
      id: 'evt_1',
      type: 'checkout.session.completed',
      orgId: 'o1',
      planCode: 'BUSINESS',
      subscriptionRef: 'sub_9',
    }),
  );

  /** Proveedor local con el secreto ya fijado en el entorno. */
  function localProvider() {
    process.env.PAYMENTS_WEBHOOK_SECRET = SECRET;
    const adapter = new LocalPaymentProviderAdapter();
    return {
      name: 'local',
      live: false,
      createCheckout: jest.fn(),
      parseWebhook: (raw: Buffer | string, signature: string | undefined) =>
        adapter.parseWebhook(raw, signature),
    } satisfies PaymentProviderPort;
  }

  const sign = async (payload: Buffer) => {
    const { createHmac } = await import('crypto');
    return createHmac('sha256', SECRET).update(payload).digest('hex');
  };

  const original = process.env.PAYMENTS_WEBHOOK_SECRET;
  afterAll(() => {
    if (original === undefined) delete process.env.PAYMENTS_WEBHOOK_SECRET;
    else process.env.PAYMENTS_WEBHOOK_SECRET = original;
  });

  it('aplica el plan cuando la firma es válida', async () => {
    const provider = localProvider();
    const { service, tx, audit } = build({ planCode: 'ESSENTIAL', provider });
    const result = await service.handleWebhook(body, `sha256=${await sign(body)}`);

    expect(result).toMatchObject({ received: true, applied: true });
    expect(tx.subscription.update).toHaveBeenCalledWith(
      expect.objectContaining({ data: expect.objectContaining({ planCode: 'BUSINESS' }) }),
    );
    expect(audit.record).toHaveBeenCalledWith(
      expect.objectContaining({ action: 'billing.plan_applied' }),
    );
  });

  it('rechaza firmas inválidas', async () => {
    const { service } = build({ provider: localProvider() });
    await expect(service.handleWebhook(body, 'sha256=deadbeef')).rejects.toBeInstanceOf(
      BadRequestException,
    );
  });

  it('cancela la suscripción cuando el proveedor notifica la baja', async () => {
    const cancelled = Buffer.from(
      JSON.stringify({ id: 'evt_2', type: 'customer.subscription.deleted', orgId: 'o1' }),
    );
    const { service, tx } = build({ provider: localProvider() });
    await service.handleWebhook(cancelled, `sha256=${await sign(cancelled)}`);

    expect(tx.subscription.update).toHaveBeenCalledWith({
      where: { orgId: 'o1' },
      data: { status: 'CANCELLED' },
    });
  });

  it('exige firma cuando no hay secreto configurado', async () => {
    delete process.env.PAYMENTS_WEBHOOK_SECRET;
    const adapter = new LocalPaymentProviderAdapter();
    const provider: PaymentProviderPort = {
      name: 'local',
      live: false,
      createCheckout: jest.fn(),
      parseWebhook: (raw, signature) => adapter.parseWebhook(raw, signature),
    };
    const { service } = build({ provider });

    await expect(service.handleWebhook(body, 'sha256=x')).rejects.toThrow(/no configurado/);
  });
});
