/**
 * Catálogo de planes y sus límites.
 *
 * Vive en su propio archivo (y no en `billing.service`) para que los servicios
 * que sólo necesitan consultar cuotas no importen el servicio completo.
 */
export interface PlanLimits {
  name: string;
  users: number;
  storageGb: number;
  standards: number;
  aiTokens: number;
  monthlyUsd: number;
}

export const PLAN_LIMITS: Record<string, PlanLimits> = {
  ESSENTIAL: { name: 'Esencial', users: 25, storageGb: 500, standards: 1, aiTokens: 2000, monthlyUsd: 99 },
  PROFESSIONAL: { name: 'Profesional', users: 50, storageGb: 2000, standards: 3, aiTokens: 5000, monthlyUsd: 249 },
  BUSINESS: { name: 'Empresarial', users: 200, storageGb: 10000, standards: 6, aiTokens: 20000, monthlyUsd: 799 },
  CONSULTANT: { name: 'Consultor', users: 100, storageGb: 5000, standards: 6, aiTokens: 10000, monthlyUsd: 599 },
};

export const DEFAULT_PLAN = 'ESSENTIAL';

export function limitsFor(planCode: string | null | undefined): PlanLimits {
  return PLAN_LIMITS[planCode ?? DEFAULT_PLAN] ?? PLAN_LIMITS[DEFAULT_PLAN];
}

/** Periodo mensual de las cuotas variables (`YYYY-MM`). */
export function currentPeriod(date = new Date()): string {
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
}

export const BYTES_PER_GB = 1024 ** 3;
