import { ForbiddenException, NotFoundException } from '@nestjs/common';
import { UsageService } from './usage.service';
import { PrismaService } from '../../prisma/prisma.service';
import { BYTES_PER_GB, currentPeriod } from './plan-limits';

const PERIOD = currentPeriod();

function build(opts: {
  planCode?: string;
  orgPlanCode?: string;
  seats?: number;
  pending?: number;
  standards?: number;
  storageBytes?: number;
  aiTokens?: number;
} = {}) {
  const tx = {
    $executeRaw: jest.fn().mockResolvedValue(undefined),
    subscription: {
      findUnique: jest.fn().mockResolvedValue(
        opts.planCode === undefined ? null : { planCode: opts.planCode },
      ),
    },
    organization: {
      findUnique: jest.fn().mockResolvedValue({
        planCode: opts.orgPlanCode ?? 'ESSENTIAL',
      }),
    },
    orgMember: { count: jest.fn().mockResolvedValue(opts.seats ?? 0) },
    invitation: { count: jest.fn().mockResolvedValue(opts.pending ?? 0) },
    orgStandard: { count: jest.fn().mockResolvedValue(opts.standards ?? 0) },
    evidenceFile: {
      aggregate: jest.fn().mockResolvedValue({ _sum: { size: opts.storageBytes ?? 0 } }),
    },
    aiConsumption: {
      findUnique: jest.fn().mockResolvedValue(
        opts.aiTokens === undefined ? null : { tokens: opts.aiTokens },
      ),
    },
    orgUsage: { upsert: jest.fn().mockResolvedValue({}) },
  };

  const prisma = {
    $transaction: jest.fn(async (fn: (client: typeof tx) => Promise<unknown>) => fn(tx)),
  } as unknown as PrismaService;

  return { service: new UsageService(prisma), prisma, tx };
}

describe('UsageService — plan vigente', () => {
  it('prefiere el plan de la suscripción sobre el de la organización', async () => {
    const { service } = build({ planCode: 'BUSINESS', orgPlanCode: 'ESSENTIAL' });
    await expect(service.planCode('o1')).resolves.toBe('BUSINESS');
  });

  it('usa el plan de la organización cuando no hay suscripción', async () => {
    const { service } = build({ orgPlanCode: 'PROFESSIONAL' });
    await expect(service.planCode('o1')).resolves.toBe('PROFESSIONAL');
  });

  it('falla si la organización no existe', async () => {
    const { service, tx } = build();
    tx.organization.findUnique.mockResolvedValue(null);
    await expect(service.planCode('o1')).rejects.toBeInstanceOf(NotFoundException);
  });
});

describe('UsageService — foto de consumo', () => {
  it('suma usuarios activos e invitaciones pendientes como lugares ocupados', async () => {
    const { service } = build({ planCode: 'ESSENTIAL', seats: 3, pending: 2 });
    const snap = await service.snapshot('o1');
    expect(snap.seats).toBe(3);
    expect(snap.pendingInvitations).toBe(2);
    expect(snap.limits.users).toBe(25);
  });

  it('convierte los bytes a GB con cuatro decimales', async () => {
    const { service } = build({ planCode: 'ESSENTIAL', storageBytes: BYTES_PER_GB / 2 });
    const snap = await service.snapshot('o1');
    expect(snap.storageGb).toBe(0.5);
  });

  it('lee los tokens del periodo en curso', async () => {
    const { service } = build({ planCode: 'ESSENTIAL', aiTokens: 750 });
    const snap = await service.snapshot('o1');
    expect(snap.aiTokens).toBe(750);
    expect(snap.period).toBe(PERIOD);
  });
});

describe('UsageService — límite de usuarios', () => {
  it('rechaza cuando activos + pendientes ya llenaron el plan', async () => {
    const { service } = build({ planCode: 'ESSENTIAL', seats: 21, pending: 4 });
    await expect(service.assertUsers('o1')).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('permite el último lugar disponible', async () => {
    const { service } = build({ planCode: 'ESSENTIAL', seats: 20, pending: 4 });
    await expect(service.assertUsers('o1', 1)).resolves.toBeUndefined();
  });

  it('al canjear una invitación solo cuenta las membresías activas', async () => {
    const { service, tx } = build({ planCode: 'ESSENTIAL', seats: 24, pending: 1 });
    await expect(service.assertSeatTx(tx as never, 'o1')).resolves.toBeUndefined();
  });

  it('al canjear rechaza si las membresías ya llenaron el plan', async () => {
    const { service, tx } = build({ planCode: 'ESSENTIAL', seats: 25, pending: 0 });
    await expect(service.assertSeatTx(tx as never, 'o1')).rejects.toBeInstanceOf(
      ForbiddenException,
    );
  });
});

describe('UsageService — límite de normas', () => {
  it('rechaza activar una cuarta norma en el plan Esencial', async () => {
    const { service } = build({ planCode: 'ESSENTIAL', standards: 1 });
    await expect(service.assertStandards('o1')).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('permite activar mientras quede cupo', async () => {
    const { service } = build({ planCode: 'PROFESSIONAL', standards: 2 });
    await expect(service.assertStandards('o1')).resolves.toBeUndefined();
  });
});

describe('UsageService — almacenamiento y tokens', () => {
  it('rechaza una carga que no cabe en el espacio restante', async () => {
    const { service } = build({
      planCode: 'ESSENTIAL',
      storageBytes: 499 * BYTES_PER_GB,
    });
    await expect(service.assertStorage('o1', 2 * BYTES_PER_GB)).rejects.toBeInstanceOf(
      ForbiddenException,
    );
  });

  it('permite una carga que cabe exactamente', async () => {
    const { service } = build({
      planCode: 'ESSENTIAL',
      storageBytes: 499 * BYTES_PER_GB,
    });
    await expect(service.assertStorage('o1', BYTES_PER_GB)).resolves.toBeUndefined();
  });

  it('rechaza invocar IA cuando la bolsa mensual está agotada', async () => {
    const { service } = build({ planCode: 'ESSENTIAL', aiTokens: 2000 });
    await expect(service.assertAiTokens('o1')).rejects.toBeInstanceOf(ForbiddenException);
  });

  it('registra los tokens consumidos en la cuota del periodo', async () => {
    const { service, tx } = build({ planCode: 'ESSENTIAL', aiTokens: 100 });
    await service.addAiTokens('o1', 50);
    expect(tx.orgUsage.upsert).toHaveBeenCalledWith({
      where: { orgId_resource_period: { orgId: 'o1', resource: 'ai_tokens', period: PERIOD } },
      update: { used: 150, quota: 2000 },
      create: { orgId: 'o1', resource: 'ai_tokens', period: PERIOD, used: 150, quota: 2000 },
    });
  });
});

describe('UsageService — sincronización de cuotas', () => {
  it('escribe las cuatro cuotas con sus límites reales', async () => {
    const { service, tx } = build({
      planCode: 'PROFESSIONAL',
      seats: 10,
      pending: 1,
      standards: 2,
      storageBytes: BYTES_PER_GB,
      aiTokens: 300,
    });

    const snap = await service.sync('o1');
    expect(snap.planCode).toBe('PROFESSIONAL');

    const writes = tx.orgUsage.upsert.mock.calls.map(
      ([arg]: [{ where: { orgId_resource_period: { resource: string } } }]) =>
        arg.where.orgId_resource_period.resource,
    );
    expect(writes.sort()).toEqual(['ai_tokens', 'standards', 'storage_gb', 'users']);
    expect(tx.orgUsage.upsert).toHaveBeenCalledWith({
      where: { orgId_resource_period: { orgId: 'o1', resource: 'users', period: 'TOTAL' } },
      update: { used: 11, quota: 50 },
      create: { orgId: 'o1', resource: 'users', period: 'TOTAL', used: 11, quota: 50 },
    });
  });
});
