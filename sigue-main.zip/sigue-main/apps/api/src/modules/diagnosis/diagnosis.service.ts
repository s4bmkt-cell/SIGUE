import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

export interface DiagnosisResult {
  standardId: string;
  maturity: number; // 0..5
  gap: number; // % de brecha
  evaluated: number;
  total: number;
  levels: Record<string, number>;
  recommendations: { clause: string; title: string; level: string; recommendation: string }[];
  plan: { id: string; title: string; tasks: { title: string; priority: string }[] };
}

@Injectable()
export class DiagnosisService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /**
   * Ejecuta el diagnóstico: calcula madurez, brecha y genera plan automático.
   * `generatePlan = false` permite consultar el estado sin escribir nada.
   */
  async run(
    orgId: string,
    standardId: string,
    user: AuthUser,
    generatePlan = true,
  ): Promise<DiagnosisResult> {
    await this.assertMember(orgId, user);

    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;

      const clauses = await tx.standardClause.findMany({
        where: { standardId, kind: 'requirement' },
        orderBy: { sortOrder: 'asc' },
      });
      const statuses = await tx.requirementStatus.findMany({ where: { orgId } });
      const statusMap = new Map(statuses.map((s) => [s.clauseId, s.level]));

      // Madurez: promedio de niveles (NOT=0, PARTIAL=1, IMPL=2, MATURE=3) → escala 0..5
      const levelScore: Record<string, number> = {
        NOT_IMPLEMENTED: 0,
        PARTIAL: 1,
        IMPLEMENTED: 2,
        MATURE: 3,
      };
      const total = clauses.length;
      const scores = clauses.map((c) => levelScore[statusMap.get(c.id) ?? 'NOT_IMPLEMENTED'] ?? 0);
      const avg = total ? scores.reduce((a, b) => a + b, 0) / total : 0;
      const maturity = Math.round((avg / 3) * 5 * 10) / 10; // 0..5
      const gapPct = Math.round(((total - scores.filter((s) => s >= 2).length) / Math.max(total, 1)) * 100);

      const levels: Record<string, number> = {};
      for (const c of clauses) {
        const lvl = statusMap.get(c.id) ?? 'NOT_IMPLEMENTED';
        levels[lvl] = (levels[lvl] ?? 0) + 1;
      }

      // Recomendaciones para requisitos no implementados/parciales
      const recommendations = clauses
        .filter((c) => {
          const lvl = statusMap.get(c.id) ?? 'NOT_IMPLEMENTED';
          return lvl === 'NOT_IMPLEMENTED' || lvl === 'PARTIAL';
        })
        .slice(0, 6)
        .map((c) => {
          const lvl = statusMap.get(c.id) ?? 'NOT_IMPLEMENTED';
          return {
            clause: c.code,
            title: c.title,
            level: lvl,
            recommendation:
              lvl === 'NOT_IMPLEMENTED'
                ? `Implementar ${c.code} ${c.title} y documentar la evidencia.`
                : `Completar ${c.code}: revisar la implementación parcial y cerrar evidencias faltantes.`,
          };
        });

      // Generar (o reutilizar) el plan automático de esta norma. El título
      // incluye la norma porque la organización puede diagnosticar varias.
      const standard = await tx.standard.findUnique({
        where: { id: standardId },
        select: { code: true },
      });
      const planTitle = `Plan de implementación ${standard?.code ?? standardId} (diagnóstico)`;
      let plan = await tx.workPlan.findFirst({
        where: { orgId, standardId, title: planTitle },
      });

      if (generatePlan) {
        if (!plan) {
          plan = await tx.workPlan.create({
            data: {
              orgId,
              title: planTitle,
              standardId,
              startDate: new Date(),
              endDate: new Date(Date.now() + 180 * 86400000),
              status: 'ACTIVE',
            },
          });
        }

        // Tareas del plan según requisitos pendientes
        const pending = clauses.filter((c) => {
          const lvl = statusMap.get(c.id) ?? 'NOT_IMPLEMENTED';
          return lvl !== 'IMPLEMENTED' && lvl !== 'MATURE';
        });
        const existing = await tx.planTask.count({ where: { planId: plan.id } });
        if (existing === 0 && pending.length > 0) {
          await tx.planTask.createMany({
            data: pending.slice(0, 12).map((c, i) => ({
              orgId,
              planId: plan!.id,
              title: `${c.code} · ${c.title}`,
              priority: c.weight >= 3 ? 'HIGH' : 'MEDIUM',
              status: 'PENDING',
              sortOrder: i + 1,
            })),
          });
        }
      }

      const tasks = plan
        ? await tx.planTask.findMany({
            where: { planId: plan.id },
            orderBy: { sortOrder: 'asc' },
          })
        : [];

      return {
        standardId,
        maturity,
        gap: gapPct,
        evaluated: total,
        total,
        levels,
        recommendations,
        plan: {
          id: plan?.id ?? '',
          title: plan?.title ?? planTitle,
          tasks: tasks.map((t) => ({ title: t.title, priority: t.priority })),
        },
      };
    });
  }

  /** Devuelve el diagnóstico actual sin escribir nada en la base. */
  async get(orgId: string, standardId: string, user: AuthUser): Promise<DiagnosisResult> {
    return this.run(orgId, standardId, user, false);
  }
}
