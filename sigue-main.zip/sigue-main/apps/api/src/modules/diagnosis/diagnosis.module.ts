import { Module } from '@nestjs/common';
import { DiagnosisController } from './diagnosis.controller';
import { DiagnosisService } from './diagnosis.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [TenancyModule, AuthSharedModule],
  controllers: [DiagnosisController],
  providers: [DiagnosisService],
})
export class DiagnosisModule {}
