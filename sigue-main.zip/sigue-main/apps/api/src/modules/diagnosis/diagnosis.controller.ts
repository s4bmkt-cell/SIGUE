import { Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { DiagnosisService } from './diagnosis.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('diagnosis')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/diagnosis', version: '1' })
export class DiagnosisController {
  constructor(private readonly diagnosis: DiagnosisService) {}

  @Audit('diagnosis.run')
  @ApiEndpoint('Ejecuta el diagnóstico de madurez y genera el plan', { status: 201, tenant: true })
  @Post(':standardId/run')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_proceso', 'resp_riesgos', 'admin_org')
  run(
    @Param('orgId') orgId: string,
    @Param('standardId') standardId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.diagnosis.run(orgId, standardId, user);
  }

  @ApiEndpoint('Último diagnóstico calculado para la norma', { status: 200, tenant: true })
  @Get(':standardId')
  get(
    @Param('orgId') orgId: string,
    @Param('standardId') standardId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.diagnosis.get(orgId, standardId, user);
  }
}
