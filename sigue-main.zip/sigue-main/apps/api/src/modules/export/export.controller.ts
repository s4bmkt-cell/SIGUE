import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { ExportService } from './export.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';

@ApiTags('export')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/export', version: '1' })
export class ExportController {
  constructor(private readonly exportService: ExportService) {}

  @ApiEndpoint('Exporta toda la información de la organización', { status: 200, tenant: true })
  @Get('all')
  @RequireRoles('admin_org', 'admin_global')
  exportAll(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.exportService.exportAll(orgId, user);
  }
}
