import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

/**
 * Exportación completa de la información de un inquilino (derecho de portabilidad).
 * Recopila TODAS las tablas de la organización en un JSON descargable.
 */
@Injectable()
export class ExportService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  async exportAll(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    const data: Record<string, unknown> = { exportedAt: new Date().toISOString(), orgId };

    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;

      // Núcleo
      data.organization = await tx.organization.findUnique({ where: { id: orgId } });
      data.members = await tx.orgMember.findMany({ where: { orgId } });
      data.branches = await tx.orgBranch.findMany({ where: { orgId } });
      data.areas = await tx.orgArea.findMany({ where: { orgId } });

      // Normas y cumplimiento
      data.orgStandards = await tx.orgStandard.findMany({ where: { orgId } });
      data.requirementStatuses = await tx.requirementStatus.findMany({ where: { orgId } });

      // Contexto y planificación
      data.context = {
        // Los FODA/PESTEL viajan con sus elementos: la portabilidad debe
        // conservar la agrupación, no una lista plana imposible de recomponer.
        swotAnalyses: await tx.contextSwotAnalysis.findMany({
          where: { orgId },
          include: { items: true },
        }),
        pestelAnalyses: await tx.contextPestelAnalysis.findMany({
          where: { orgId },
          include: { items: true },
        }),
        parties: await tx.contextParty.findMany({ where: { orgId } }),
        issues: await tx.contextIssue.findMany({ where: { orgId } }),
        legal: await tx.legalRequirement.findMany({ where: { orgId } }),
        processes: await tx.processMap.findMany({ where: { orgId } }),
      };
      data.risks = await tx.risk.findMany({ where: { orgId } });
      data.riskAssessments = await tx.riskAssessment.findMany({ where: { orgId } });
      data.riskTreatments = await tx.riskTreatment.findMany({ where: { orgId } });
      data.controls = await tx.control.findMany({ where: { orgId } });
      data.objectives = await tx.objective.findMany({ where: { orgId } });
      data.objectiveKpis = await tx.objectiveKpi.findMany({ where: { orgId } });
      data.workPlans = await tx.workPlan.findMany({ where: { orgId } });
      data.planTasks = await tx.planTask.findMany({ where: { orgId } });

      // Documental y evidencias
      data.documents = await tx.document.findMany({ where: { orgId } });
      data.documentVersions = await tx.documentVersion.findMany({ where: { orgId } });
      data.evidences = await tx.evidence.findMany({ where: { orgId } });
      data.evidenceFiles = await tx.evidenceFile.findMany({ where: { orgId } });
      data.evidenceRequirements = await tx.evidenceRequirement.findMany({ where: { orgId } });

      // Verificar y mejorar
      data.audits = await tx.audit.findMany({ where: { orgId } });
      data.findings = await tx.finding.findMany({ where: { orgId } });
      data.nc = await tx.nc.findMany({ where: { orgId } });
      data.ncCorrections = await tx.ncCorrection.findMany({ where: { orgId } });
      data.rootCauses = await tx.rootCause.findMany({ where: { orgId } });
      data.correctiveActions = await tx.correctiveAction.findMany({ where: { orgId } });
      data.mgmtReviews = await tx.mgmtReview.findMany({ where: { orgId } });
      data.reviewAgreements = await tx.reviewAgreement.findMany({ where: { orgId } });

      // Normas especializadas
      data.isms = {
        assets: await tx.securityAsset.findMany({ where: { orgId } }),
        soa: await tx.statementOfApplicability.findMany({ where: { orgId } }),
        incidents: await tx.securityIncident.findMany({ where: { orgId } }),
      };
      data.bcms = {
        bias: await tx.bia.findMany({ where: { orgId } }),
        plans: await tx.continuityPlan.findMany({ where: { orgId } }),
        exercises: await tx.continuityExercise.findMany({ where: { orgId } }),
      };
      data.aiSystems = await tx.aiSystem.findMany({ where: { orgId } });
      data.aiUseCases = await tx.aiOrgUseCase.findMany({ where: { orgId } });
      data.aiSystemRisks = await tx.aiSystemRisk.findMany({ where: { orgId } });

      // IA
      data.ai = {
        useCases: await tx.aiUseCase.findMany({ where: { orgId } }),
        interactions: await tx.aiInteraction.findMany({ where: { orgId } }),
        incidents: await tx.aiIncident.findMany({ where: { orgId } }),
      };

      // Suscripción
      data.subscription = await tx.subscription.findUnique({ where: { orgId } });
      data.usage = await tx.orgUsage.findMany({ where: { orgId } });

      // Registra el job de exportación
      const job = await tx.exportJob.create({
        data: { orgId, status: 'COMPLETED', format: 'JSON', requestedById: user.sub, completedAt: new Date() },
      });

      return { exportId: job.id, exportedAt: data.exportedAt, size: JSON.stringify(data).length, data };
    });
  }
}
