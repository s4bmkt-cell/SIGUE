import {
  BadRequestException,
  ForbiddenException,
  Inject,
  Injectable,
  Logger,
  NotFoundException,
} from '@nestjs/common';
import { createHash } from 'crypto';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';
import { STORAGE, StoragePort } from '../../common/storage/storage.port';
import { AuditService } from '../audit/audit.service';
import { UsageService } from '../billing/usage.service';

/** Límite duro por archivo; la cuota del plan se valida además por organización. */
const MAX_UPLOAD_BYTES = Number(process.env.MAX_UPLOAD_MB ?? 25) * 1024 * 1024;

export interface UploadedFile {
  originalname: string;
  buffer: Buffer;
  size: number;
  mimetype: string;
}

@Injectable()
export class EvidencesService {
  private readonly logger = new Logger('Evidences');

  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
    @Inject(STORAGE) private readonly storage: StoragePort,
    private readonly audit: AuditService,
    private readonly usage: UsageService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Lista evidencias de la organización. */
  async list(orgId: string, user: AuthUser, clauseId?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.evidence.findMany({
        where: { orgId, status: 'ACTIVE', ...(clauseId ? { requirements: { some: { clauseId } } } : {}) },
        include: { files: { orderBy: { createdAt: 'desc' } }, requirements: { include: { clause: true } } },
        orderBy: { createdAt: 'desc' },
      });
    });
  }

  /** Crea una evidencia (metadata; los archivos se agregan aparte). */
  async create(
    orgId: string,
    user: AuthUser,
    data: {
      title: string;
      type?: string;
      classification?: string;
      validityUntil?: string;
      reviewDate?: string;
      restrictionFlags?: { noDownload?: boolean; noAiSend?: boolean; mask?: boolean };
    },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      return tx.evidence.create({
        data: {
          orgId,
          title: data.title,
          type: data.type ?? 'FILE',
          classification: data.classification ?? 'INTERNO',
          ownerId: user.sub,
          validityUntil: data.validityUntil ? new Date(data.validityUntil) : null,
          reviewDate: data.reviewDate ? new Date(data.reviewDate) : null,
          restrictionFlags: data.restrictionFlags ?? { noAiSend: false, noDownload: false },
        },
        include: { files: true, requirements: { include: { clause: true } } },
      });
    });
  }

  /** Actualiza metadata de la evidencia (título, clasificación, fechas, restricciones). */
  async update(
    orgId: string,
    user: AuthUser,
    evidenceId: string,
    data: {
      title?: string;
      type?: string;
      classification?: string;
      validityUntil?: string | null;
      reviewDate?: string | null;
      restrictionFlags?: { noDownload?: boolean; noAiSend?: boolean; mask?: boolean };
    },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const ev = await tx.evidence.findUnique({ where: { id: evidenceId } });
      if (!ev || ev.orgId !== orgId) throw new NotFoundException('Evidencia no encontrada');
      return tx.evidence.update({
        where: { id: evidenceId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.type !== undefined ? { type: data.type } : {}),
          ...(data.classification !== undefined ? { classification: data.classification } : {}),
          ...(data.validityUntil !== undefined
            ? { validityUntil: data.validityUntil ? new Date(data.validityUntil) : null }
            : {}),
          ...(data.reviewDate !== undefined
            ? { reviewDate: data.reviewDate ? new Date(data.reviewDate) : null }
            : {}),
          ...(data.restrictionFlags !== undefined ? { restrictionFlags: data.restrictionFlags } : {}),
        },
        include: { files: { orderBy: { createdAt: 'desc' } }, requirements: { include: { clause: true } } },
      });
    });
  }

  /**
   * Sube un archivo real a la evidencia.
   *
   * El binario se escribe primero en el almacenamiento y luego se registra la
   * fila: si la transacción falla, se borra el objeto para no dejar huérfanos.
   */
  async addFile(orgId: string, user: AuthUser, evidenceId: string, file: UploadedFile) {
    await this.assertMember(orgId, user);
    if (!file?.buffer?.length) throw new BadRequestException('El archivo está vacío');
    if (file.size > MAX_UPLOAD_BYTES) {
      throw new BadRequestException(
        `El archivo supera el límite de ${Math.round(MAX_UPLOAD_BYTES / 1024 / 1024)} MB`,
      );
    }

    const evidence = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.evidence.findUnique({ where: { id: evidenceId } });
    });
    if (!evidence || evidence.orgId !== orgId) throw new NotFoundException('Evidencia no encontrada');

    await this.assertQuota(orgId, file.size);

    const filename = safeFilename(file.originalname);
    const version = await this.nextVersion(orgId, evidenceId);
    const key = `org-${orgId}/ev-${evidenceId}/v${version}-${filename}`;
    const stored = await this.storage.put(key, file.buffer, file.mimetype);

    try {
      return await this.prisma.$transaction(async (tx) => {
        await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
        // Revalida la evidencia dentro de la transacción de escritura.
        const ev = await tx.evidence.findUnique({ where: { id: evidenceId } });
        if (!ev || ev.orgId !== orgId) throw new NotFoundException('Evidencia no encontrada');
        const created = await tx.evidenceFile.create({
          data: {
            orgId,
            evidenceId,
            blobName: stored.key,
            size: stored.size,
            sha256: stored.sha256,
            mime: stored.mime,
            version,
          },
        });
        await this.usage.syncTx(tx, orgId);
        return created;
      });
    } catch (error) {
      await this.storage.remove(key).catch(() => undefined);
      throw error;
    }
  }

  /** Descarga: valida clasificación, integridad (sha256) y audita el acceso. */
  async readFile(orgId: string, user: AuthUser, fileId: string) {
    await this.assertMember(orgId, user);
    const { file, evidence } = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.evidenceFile.findUnique({
        where: { id: fileId },
        include: { evidence: true },
      });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Archivo no encontrado');
      return { file: row, evidence: row.evidence };
    });

    const flags = (evidence.restrictionFlags ?? {}) as { noDownload?: boolean };
    if (flags.noDownload) {
      await this.audit.record({
        orgId,
        actorId: user.sub,
        action: 'evidences.download_denied',
        entity: 'evidences',
        entityId: file.id,
        after: { reason: 'noDownload', classification: evidence.classification },
      });
      throw new ForbiddenException('La descarga de esta evidencia está restringida');
    }

    const buffer = await this.storage.get(file.blobName);
    if (!buffer) {
      await this.audit.record({
        orgId,
        actorId: user.sub,
        action: 'evidences.download_missing',
        entity: 'evidences',
        entityId: file.id,
        after: { blobName: file.blobName },
      });
      throw new NotFoundException('El archivo ya no está disponible en el almacenamiento');
    }

    const digest = createHash('sha256').update(buffer).digest('hex');
    const integrityOk = !file.sha256 || digest === file.sha256;
    await this.audit.record({
      orgId,
      actorId: user.sub,
      action: integrityOk ? 'evidences.download' : 'evidences.download_corrupted',
      entity: 'evidences',
      entityId: file.id,
      after: {
        evidenceId: evidence.id,
        size: buffer.byteLength,
        sha256: digest,
        expectedSha256: file.sha256,
        integrityOk,
      },
    });
    if (!integrityOk) {
      this.logger.error(`Integridad rota en archivo ${file.id}: ${digest} ≠ ${file.sha256}`);
      throw new ForbiddenException(
        'El archivo no superó la verificación de integridad; solicita una nueva carga',
      );
    }

    return {
      buffer,
      filename: file.blobName.split('/').pop() ?? 'archivo',
      mime: file.mime ?? 'application/octet-stream',
      size: buffer.byteLength,
    };
  }

  /** Borra un archivo: primero la fila, después el objeto (y devuelve la cuota). */
  async deleteFile(orgId: string, user: AuthUser, fileId: string) {
    await this.assertMember(orgId, user);
    const file = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const row = await tx.evidenceFile.findUnique({ where: { id: fileId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Archivo no encontrado');
      await tx.evidenceFile.delete({ where: { id: fileId } });
      await this.usage.syncTx(tx, orgId);
      return row;
    });

    await this.storage.remove(file.blobName).catch((error: Error) => {
      this.logger.warn(`No se pudo borrar ${file.blobName}: ${error.message}`);
    });
    return { ok: true, deleted: file.id };
  }

  /** Elimina la evidencia completa (archivos en disco incluidos). */
  async remove(orgId: string, user: AuthUser, evidenceId: string) {
    await this.assertMember(orgId, user);
    const { files, freed } = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const ev = await tx.evidence.findUnique({ where: { id: evidenceId }, include: { files: true } });
      if (!ev || ev.orgId !== orgId) throw new NotFoundException('Evidencia no encontrada');
      const total = ev.files.reduce((sum, f) => sum + f.size, 0);
      await tx.evidence.delete({ where: { id: evidenceId } });
      await this.usage.syncTx(tx, orgId);
      return { files: ev.files, freed: total };
    });

    for (const file of files) {
      await this.storage.remove(file.blobName).catch((error: Error) => {
        this.logger.warn(`No se pudo borrar ${file.blobName}: ${error.message}`);
      });
    }
    return { ok: true, deleted: evidenceId, freedBytes: freed };
  }

  /** Vincula una evidencia a uno o varios requisitos (N:N). */
  async linkToRequirements(orgId: string, user: AuthUser, evidenceId: string, clauseIds: string[]) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const ev = await tx.evidence.findUnique({ where: { id: evidenceId } });
      if (!ev || ev.orgId !== orgId) throw new NotFoundException('Evidencia no encontrada');
      await tx.evidenceRequirement.deleteMany({ where: { evidenceId } });
      for (const clauseId of clauseIds) {
        await tx.evidenceRequirement.create({ data: { orgId, evidenceId, clauseId } });
      }
      return { ok: true, linked: clauseIds.length };
    });
  }

  /** Desvincula la evidencia de un requisito. */
  async unlinkRequirement(orgId: string, user: AuthUser, evidenceId: string, clauseId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const ev = await tx.evidence.findUnique({ where: { id: evidenceId } });
      if (!ev || ev.orgId !== orgId) throw new NotFoundException('Evidencia no encontrada');
      const result = await tx.evidenceRequirement.deleteMany({ where: { evidenceId, clauseId } });
      return { ok: true, unlinked: result.count };
    });
  }

  /** Expediente de un requisito: evidencia vinculada. */
  async getRequirementEvidence(orgId: string, user: AuthUser, clauseId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const links = await tx.evidenceRequirement.findMany({
        where: { orgId, clauseId },
        include: { evidence: { include: { files: true } } },
      });
      return links.map((l) => l.evidence);
    });
  }

  /** Guarda un archivo y devuelve sus metadatos (endpoint heredado de solo lectura). */
  async getFile(orgId: string, user: AuthUser, fileId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const file = await tx.evidenceFile.findUnique({
        where: { id: fileId },
        include: { evidence: true },
      });
      if (!file || file.orgId !== orgId) throw new NotFoundException('Archivo no encontrado');
      const flags = (file.evidence.restrictionFlags ?? {}) as { noDownload?: boolean };
      return {
        file: {
          id: file.id,
          blobName: file.blobName,
          size: file.size,
          sha256: file.sha256,
          mime: file.mime,
          version: file.version,
        },
        downloadable: !flags.noDownload,
      };
    });
  }

  /** Número de versión siguiente dentro de la evidencia. */
  private async nextVersion(orgId: string, evidenceId: string) {
    const last = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.evidenceFile.findFirst({
        where: { evidenceId },
        orderBy: { version: 'desc' },
        select: { version: true },
      });
    });
    return (last?.version ?? 0) + 1;
  }

  /** Rechaza la carga si el plan no tiene espacio (se mide con datos reales). */
  private async assertQuota(orgId: string, bytes: number) {
    await this.usage.assertStorage(orgId, bytes);
  }
}

/** Nombre de archivo sin rutas ni caracteres problemáticos. */
function safeFilename(name: string): string {
  const base = (name.split(/[/\\]/).pop() ?? 'archivo').replace(/[^\w.\- ]+/g, '_').trim();
  return base.slice(-120) || 'archivo';
}
