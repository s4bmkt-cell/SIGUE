import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Res,
  StreamableFile,
  UploadedFiles,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { FileFieldsInterceptor } from '@nestjs/platform-express';
import { ApiBearerAuth, ApiConsumes, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { Response } from 'express';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { EvidencesService } from './evidences.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

const MAX_UPLOAD_MB = Number(process.env.MAX_UPLOAD_MB ?? 25);

/** Acepta `file` (uno) o `files` (hasta 10). El límite también se valida en el servicio. */
const uploadOptions = {
  limits: { fileSize: MAX_UPLOAD_MB * 1024 * 1024, files: 10 },
};

@ApiTags('evidences')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/evidences', version: '1' })
export class EvidencesController {
  constructor(private readonly evidences: EvidencesService) {}

  @ApiEndpoint('Evidencias de la organización', { status: 200, tenant: true })
  @Get()
  list(
    @Param('orgId') orgId: string,
    @Query('clauseId') clauseId: string | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    return this.evidences.list(orgId, user, clauseId);
  }

  @Audit('evidences.create')
  @ApiEndpoint('Registra una evidencia', { status: 201, tenant: true })
  @Post()
  @RequireRoles('colaborador', 'resp_proceso', 'resp_sgi', 'resp_norma', 'admin_org')
  create(
    @Param('orgId') orgId: string,
    @Body()
    data: {
      title: string;
      type?: string;
      classification?: string;
      validityUntil?: string;
      reviewDate?: string;
      restrictionFlags?: { noDownload?: boolean; noAiSend?: boolean; mask?: boolean };
    },
    @CurrentUser() user: AuthUser,
  ) {
    return this.evidences.create(orgId, user, data);
  }

  @Audit('evidences.update')
  @ApiEndpoint('Actualiza una evidencia', { status: 200, tenant: true })
  @Patch(':evidenceId')
  @RequireRoles('colaborador', 'resp_proceso', 'resp_sgi', 'resp_norma', 'admin_org')
  update(
    @Param('orgId') orgId: string,
    @Param('evidenceId') evidenceId: string,
    @Body()
    data: {
      title?: string;
      type?: string;
      classification?: string;
      validityUntil?: string | null;
      reviewDate?: string | null;
      restrictionFlags?: { noDownload?: boolean; noAiSend?: boolean; mask?: boolean };
    },
    @CurrentUser() user: AuthUser,
  ) {
    return this.evidences.update(orgId, user, evidenceId, data);
  }

  @Audit('evidences.delete')
  @ApiEndpoint('Elimina una evidencia y sus archivos', { status: 200, tenant: true })
  @Delete(':evidenceId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  remove(
    @Param('orgId') orgId: string,
    @Param('evidenceId') evidenceId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.evidences.remove(orgId, user, evidenceId);
  }

  /** Subida multipart real: campo `file` (uno) o `files` (varios). */
  @Audit('evidences.add_file')
  @ApiEndpoint('Sube archivos a una evidencia', { status: 201, tenant: true })
  @Post(':evidenceId/files')
  @ApiConsumes('multipart/form-data')
  @UseInterceptors(
    FileFieldsInterceptor(
      [
        { name: 'file', maxCount: 1 },
        { name: 'files', maxCount: 10 },
      ],
      uploadOptions,
    ),
  )
  @RequireRoles('colaborador', 'resp_proceso', 'resp_sgi', 'resp_norma', 'admin_org')
  async addFile(
    @Param('orgId') orgId: string,
    @Param('evidenceId') evidenceId: string,
    @UploadedFiles() uploaded: Record<string, Express.Multer.File[] | undefined> | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    const list = [...(uploaded?.file ?? []), ...(uploaded?.files ?? [])];
    if (list.length === 0) throw new BadRequestException('Adjunta al menos un archivo');

    const created = [];
    for (const file of list) {
      created.push(await this.evidences.addFile(orgId, user, evidenceId, file));
    }
    return created.length === 1 ? created[0] : { files: created };
  }

  @Audit('evidences.link')
  @ApiEndpoint('Vincula la evidencia a requisitos', { status: 201, tenant: true })
  @Post(':evidenceId/requirements')
  @RequireRoles('resp_proceso', 'resp_sgi', 'resp_norma', 'admin_org')
  link(
    @Param('orgId') orgId: string,
    @Param('evidenceId') evidenceId: string,
    @Body('clauseIds') clauseIds: string[],
    @CurrentUser() user: AuthUser,
  ) {
    return this.evidences.linkToRequirements(orgId, user, evidenceId, clauseIds ?? []);
  }

  @Audit('evidences.unlink')
  @ApiEndpoint('Desvincula la evidencia de un requisito', { status: 200, tenant: true })
  @Delete(':evidenceId/requirements/:clauseId')
  @RequireRoles('resp_proceso', 'resp_sgi', 'resp_norma', 'admin_org')
  unlink(
    @Param('orgId') orgId: string,
    @Param('evidenceId') evidenceId: string,
    @Param('clauseId') clauseId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.evidences.unlinkRequirement(orgId, user, evidenceId, clauseId);
  }

  @ApiEndpoint('Evidencias vinculadas a un requisito', { status: 200, tenant: true })
  @Get('requirement/:clauseId')
  requirementEvidence(
    @Param('orgId') orgId: string,
    @Param('clauseId') clauseId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.evidences.getRequirementEvidence(orgId, user, clauseId);
  }

  @ApiEndpoint('Metadatos de un archivo de evidencia', { status: 200, tenant: true })
  @Get('files/:fileId')
  file(
    @Param('orgId') orgId: string,
    @Param('fileId') fileId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.evidences.getFile(orgId, user, fileId);
  }

  /** Descarga del binario real con verificación de integridad y auditoría. */
  @ApiEndpoint('Descarga un archivo verificando su hash', { status: 200, tenant: true })
  @Get('files/:fileId/download')
  async download(
    @Param('orgId') orgId: string,
    @Param('fileId') fileId: string,
    @CurrentUser() user: AuthUser,
    @Res({ passthrough: true }) res: Response,
  ) {
    const file = await this.evidences.readFile(orgId, user, fileId);
    const ascii = file.filename.replace(/[^\x20-\x7E]+/g, '_').replace(/"/g, '');
    res.setHeader('Content-Type', file.mime);
    res.setHeader('Content-Length', String(file.size));
    res.setHeader(
      'Content-Disposition',
      `attachment; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(file.filename)}`,
    );
    res.setHeader('Cache-Control', 'private, no-store');
    return new StreamableFile(file.buffer);
  }

  @Audit('evidences.delete_file')
  @ApiEndpoint('Elimina un archivo de evidencia', { status: 200, tenant: true })
  @Delete('files/:fileId')
  @RequireRoles('resp_sgi', 'resp_norma', 'colaborador', 'resp_proceso', 'admin_org')
  deleteFile(
    @Param('orgId') orgId: string,
    @Param('fileId') fileId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.evidences.deleteFile(orgId, user, fileId);
  }
}
