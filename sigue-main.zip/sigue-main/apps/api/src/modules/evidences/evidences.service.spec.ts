import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { createHash } from 'crypto';
import { EvidencesService } from './evidences.service';
import { PrismaService } from '../../prisma/prisma.service';
import { TenancyService } from '../../tenancy/tenancy.service';
import { StoragePort, StoredObject } from '../../common/storage/storage.port';
import { AuditService } from '../audit/audit.service';
import { UsageService } from '../billing/usage.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';

const user: AuthUser = {
  sub: 'u1',
  email: 'persona@org.mx',
  name: 'Persona',
  roles: ['colaborador'],
  orgId: 'o1',
};

const evidence = {
  id: 'ev1',
  orgId: 'o1',
  title: 'Contrato',
  classification: 'INTERNO',
  restrictionFlags: { noDownload: false },
};

function build(opts: { file?: Record<string, unknown> | null; quotaFull?: boolean } = {}) {
  const tx = {
    $executeRaw: jest.fn().mockResolvedValue(undefined),
    evidence: {
      findUnique: jest.fn().mockResolvedValue(evidence),
      delete: jest.fn().mockResolvedValue(evidence),
    },
    evidenceFile: {
      findFirst: jest.fn().mockResolvedValue(null),
      findUnique: jest.fn().mockResolvedValue(opts.file ?? null),
      create: jest.fn().mockImplementation(({ data }) => Promise.resolve({ id: 'f1', ...data })),
      delete: jest.fn().mockResolvedValue({}),
    },
  };

  const prisma = {
    $transaction: jest.fn().mockImplementation((fn: (t: typeof tx) => unknown) => fn(tx)),
  } as unknown as PrismaService;

  const tenancy = { isMember: jest.fn().mockResolvedValue(true) } as unknown as TenancyService;

  const storage = {
    put: jest.fn().mockImplementation((key: string, data: Buffer) =>
      Promise.resolve<StoredObject>({
        key,
        size: data.byteLength,
        sha256: createHash('sha256').update(data).digest('hex'),
        mime: 'text/plain',
      }),
    ),
    get: jest.fn().mockResolvedValue(Buffer.from('hola')),
    remove: jest.fn().mockResolvedValue(undefined),
    exists: jest.fn().mockResolvedValue(true),
  } as unknown as StoragePort;

  const audit = { record: jest.fn().mockResolvedValue(null) } as unknown as AuditService;

  const usage = {
    assertStorage: opts.quotaFull
      ? jest.fn().mockRejectedValue(
          new ForbiddenException('La cuota de almacenamiento del plan Esencial está agotada'),
        )
      : jest.fn().mockResolvedValue(undefined),
    syncTx: jest.fn().mockResolvedValue({}),
  } as unknown as UsageService;

  const service = new EvidencesService(prisma, tenancy, storage, audit, usage);
  return { service, prisma, tx, tenancy, storage, audit, usage };
}

const upload = (content = 'hola') => ({
  originalname: 'contrato.pdf',
  buffer: Buffer.from(content),
  size: Buffer.byteLength(content),
  mimetype: 'application/pdf',
});

describe('EvidencesService — archivos', () => {
  it('guarda el binario, registra hash y versión, y recalcula la cuota', async () => {
    const { service, storage, tx, usage } = build();
    const created = await service.addFile('o1', user, 'ev1', upload());

    expect(storage.put).toHaveBeenCalledWith(
      'org-o1/ev-ev1/v1-contrato.pdf',
      expect.any(Buffer),
      'application/pdf',
    );
    expect(tx.evidenceFile.create).toHaveBeenCalledWith({
      data: expect.objectContaining({
        orgId: 'o1',
        evidenceId: 'ev1',
        size: 4,
        sha256: createHash('sha256').update('hola').digest('hex'),
        version: 1,
      }),
    });
    expect(created).toMatchObject({ id: 'f1', version: 1 });
    // La cuota guardada se recalcula con datos reales, no se incrementa a ciegas.
    expect(usage.syncTx).toHaveBeenCalledWith(tx, 'o1');
  });

  it('incrementa la versión respecto a los archivos previos', async () => {
    const { service, storage, tx } = build();
    tx.evidenceFile.findFirst.mockResolvedValue({ version: 3 });

    await service.addFile('o1', user, 'ev1', upload());

    expect(storage.put).toHaveBeenCalledWith('org-o1/ev-ev1/v4-contrato.pdf', expect.any(Buffer), expect.any(String));
  });

  it('limpia el nombre de archivo para evitar rutas', async () => {
    const { service, storage } = build();
    await service.addFile('o1', user, 'ev1', {
      ...upload(),
      originalname: '../../etc/passwd',
    });
    expect(storage.put).toHaveBeenCalledWith('org-o1/ev-ev1/v1-passwd', expect.any(Buffer), expect.any(String));
  });

  it('rechaza un archivo vacío', async () => {
    const { service } = build();
    await expect(
      service.addFile('o1', user, 'ev1', {
        originalname: 'x.txt',
        buffer: Buffer.alloc(0),
        size: 0,
        mimetype: 'text/plain',
      }),
    ).rejects.toBeInstanceOf(BadRequestException);
  });

  it('rechaza la carga cuando la cuota del plan está agotada', async () => {
    const { service, storage } = build({ quotaFull: true });
    await expect(service.addFile('o1', user, 'ev1', upload())).rejects.toBeInstanceOf(
      ForbiddenException,
    );
    expect(storage.put).not.toHaveBeenCalled();
  });

  it('rechaza la carga si la evidencia no existe', async () => {
    const { service, tx } = build();
    tx.evidence.findUnique.mockResolvedValue(null);
    await expect(service.addFile('o1', user, 'ev1', upload())).rejects.toBeInstanceOf(
      NotFoundException,
    );
  });

  it('borra el objeto del almacenamiento si falla el registro en base', async () => {
    const { service, storage, tx } = build();
    tx.evidenceFile.create.mockRejectedValue(new Error('db caída'));

    await expect(service.addFile('o1', user, 'ev1', upload())).rejects.toThrow('db caída');
    expect(storage.remove).toHaveBeenCalledWith('org-o1/ev-ev1/v1-contrato.pdf');
  });
});

describe('EvidencesService — descarga', () => {
  const fileRow = {
    id: 'f1',
    orgId: 'o1',
    blobName: 'org-o1/ev-ev1/v1-contrato.pdf',
    size: 4,
    sha256: createHash('sha256').update('hola').digest('hex'),
    mime: 'text/plain',
    version: 1,
    evidence: { id: 'ev1', restrictionFlags: { noDownload: false }, classification: 'INTERNO' },
  };

  it('devuelve el binario verificado y audita la descarga', async () => {
    const { service, audit } = build({ file: fileRow });
    const result = await service.readFile('o1', user, 'f1');

    expect(result.buffer.toString()).toBe('hola');
    expect(result.filename).toBe('v1-contrato.pdf');
    expect(audit.record).toHaveBeenCalledWith(
      expect.objectContaining({ action: 'evidences.download', entityId: 'f1' }),
    );
  });

  it('bloquea la descarga cuando la evidencia está restringida', async () => {
    const { service, audit, storage } = build({
      file: { ...fileRow, evidence: { ...fileRow.evidence, restrictionFlags: { noDownload: true } } },
    });

    await expect(service.readFile('o1', user, 'f1')).rejects.toBeInstanceOf(ForbiddenException);
    expect(storage.get).not.toHaveBeenCalled();
    expect(audit.record).toHaveBeenCalledWith(
      expect.objectContaining({ action: 'evidences.download_denied' }),
    );
  });

  it('detecta un archivo corrupto comparando el sha256', async () => {
    const { service, audit } = build({ file: { ...fileRow, sha256: 'no-coincide' } });
    await expect(service.readFile('o1', user, 'f1')).rejects.toBeInstanceOf(ForbiddenException);
    expect(audit.record).toHaveBeenCalledWith(
      expect.objectContaining({ action: 'evidences.download_corrupted' }),
    );
  });

  it('informa cuando el objeto ya no está en el almacenamiento', async () => {
    const { service, storage } = build({ file: fileRow });
    (storage.get as jest.Mock).mockResolvedValue(null);
    await expect(service.readFile('o1', user, 'f1')).rejects.toBeInstanceOf(NotFoundException);
  });

  it('rechaza archivos de otra organización', async () => {
    const { service } = build({ file: { ...fileRow, orgId: 'o2' } });
    await expect(service.readFile('o1', user, 'f1')).rejects.toBeInstanceOf(NotFoundException);
  });
});

describe('EvidencesService — borrado', () => {
  it('elimina el archivo y devuelve la cuota', async () => {
    const { service, storage, tx } = build();
    tx.evidenceFile.findUnique.mockResolvedValue({
      id: 'f1',
      orgId: 'o1',
      blobName: 'org-o1/ev-ev1/v1-c.pdf',
      size: 1024,
    });

    const result = await service.deleteFile('o1', user, 'f1');

    expect(result).toEqual({ ok: true, deleted: 'f1' });
    expect(tx.evidenceFile.delete).toHaveBeenCalledWith({ where: { id: 'f1' } });
    expect(storage.remove).toHaveBeenCalledWith('org-o1/ev-ev1/v1-c.pdf');
  });

  it('borra todos los objetos al eliminar la evidencia', async () => {
    const { service, storage, tx } = build();
    tx.evidence.findUnique.mockResolvedValue({
      ...evidence,
      files: [
        { blobName: 'org-o1/ev-ev1/a.pdf', size: 10 },
        { blobName: 'org-o1/ev-ev1/b.pdf', size: 20 },
      ],
    });

    const result = await service.remove('o1', user, 'ev1');

    expect(result.freedBytes).toBe(30);
    expect(storage.remove).toHaveBeenCalledTimes(2);
    expect(tx.evidence.delete).toHaveBeenCalledWith({ where: { id: 'ev1' } });
  });
});
