import { Module } from '@nestjs/common';
import { EvidencesController } from './evidences.controller';
import { EvidencesService } from './evidences.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';
import { AuditModule } from '../audit/audit.module';
import { BillingModule } from '../billing/billing.module';

@Module({
  imports: [TenancyModule, AuthSharedModule, AuditModule, BillingModule],
  controllers: [EvidencesController],
  providers: [EvidencesService],
})
export class EvidencesModule {}
