import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

@Injectable()
export class NotificationsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Notificaciones del usuario en la organización (no leídas primero). */
  async list(orgId: string, user: AuthUser, unreadOnly = false) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const where = { orgId, ...(unreadOnly ? { readAt: null } : {}) };
      const items = await tx.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        take: 50,
      });
      const unread = await tx.notification.count({ where: { orgId, readAt: null } });
      return { items, unread };
    });
  }

  /** Crea una notificación (para tareas, aprobaciones, alertas). */
  async create(orgId: string, user: AuthUser, data: { type: string; title: string; body?: string; userId?: string; entity?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      return tx.notification.create({
        data: { orgId, userId: data.userId ?? user.sub, type: data.type, title: data.title, body: data.body, entity: data.entity },
      });
    });
  }

  /** Marca una notificación como leída. */
  async markRead(orgId: string, user: AuthUser, notificationId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      // Solo el destinatario (o una notificación sin destinatario) se marca.
      const result = await tx.notification.updateMany({
        where: { id: notificationId, orgId, OR: [{ userId: user.sub }, { userId: null }] },
        data: { readAt: new Date() },
      });
      return { updated: result.count };
    });
  }

  /** Deshace la lectura: el usuario puede volver a marcar algo como pendiente. */
  async markUnread(orgId: string, user: AuthUser, notificationId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const result = await tx.notification.updateMany({
        where: { id: notificationId, orgId, OR: [{ userId: user.sub }, { userId: null }] },
        data: { readAt: null },
      });
      return { updated: result.count };
    });
  }

  /** Marca todas como leídas. */
  async markAllRead(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      // Incluye las notificaciones sin destinatario, que son de toda la organización.
      const result = await tx.notification.updateMany({
        where: {
          orgId,
          readAt: null,
          OR: [{ userId: user.sub }, { userId: null }],
        },
        data: { readAt: new Date() },
      });
      return { updated: result.count };
    });
  }

  /** Elimina una notificación propia. */
  async remove(orgId: string, user: AuthUser, notificationId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const result = await tx.notification.deleteMany({
        where: { id: notificationId, orgId, OR: [{ userId: user.sub }, { userId: null }] },
      });
      return { deleted: result.count };
    });
  }

  /** Elimina todas las notificaciones leídas del usuario. */
  async clearRead(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const result = await tx.notification.deleteMany({
        where: { orgId, userId: user.sub, readAt: { not: null } },
      });
      return { deleted: result.count };
    });
  }
}
