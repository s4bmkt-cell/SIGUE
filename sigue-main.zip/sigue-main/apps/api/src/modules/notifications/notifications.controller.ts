import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { NotificationsService } from './notifications.service';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('notifications')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/notifications', version: '1' })
export class NotificationsController {
  constructor(private readonly notifications: NotificationsService) {}

  @ApiEndpoint('Notificaciones del usuario en la organización', { status: 200, tenant: true })
  @Get()
  list(@Param('orgId') orgId: string, @Query('unread') unread: string | undefined, @CurrentUser() user: AuthUser) {
    return this.notifications.list(orgId, user, unread === 'true');
  }

  @Audit('notifications.create')
  @ApiEndpoint('Crea una notificación', { status: 201, tenant: true })
  @Post()
  create(@Param('orgId') orgId: string, @Body() data: { type: string; title: string; body?: string; userId?: string; entity?: string }, @CurrentUser() user: AuthUser) {
    return this.notifications.create(orgId, user, data);
  }

  @Audit('notifications.mark_read')
  @ApiEndpoint('Marca una notificación como leída', { status: 200, tenant: true })
  @Patch(':notificationId/read')
  markRead(@Param('orgId') orgId: string, @Param('notificationId') notificationId: string, @CurrentUser() user: AuthUser) {
    return this.notifications.markRead(orgId, user, notificationId);
  }

  @Audit('notifications.mark_unread')
  @ApiEndpoint('Marca una notificación como no leída', { status: 200, tenant: true })
  @Patch(':notificationId/unread')
  markUnread(@Param('orgId') orgId: string, @Param('notificationId') notificationId: string, @CurrentUser() user: AuthUser) {
    return this.notifications.markUnread(orgId, user, notificationId);
  }

  @Audit('notifications.mark_all_read')
  @ApiEndpoint('Marca todas las notificaciones como leídas', { status: 200, tenant: true })
  @Patch('read-all')
  markAllRead(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.notifications.markAllRead(orgId, user);
  }

  @Audit('notifications.delete')
  @ApiEndpoint('Elimina una notificación', { status: 200, tenant: true })
  @Delete(':notificationId')
  remove(@Param('orgId') orgId: string, @Param('notificationId') notificationId: string, @CurrentUser() user: AuthUser) {
    return this.notifications.remove(orgId, user, notificationId);
  }

  @Audit('notifications.clear_read')
  @ApiEndpoint('Elimina las notificaciones leídas', { status: 200, tenant: true })
  @Delete()
  clearRead(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.notifications.clearRead(orgId, user);
  }
}
