import {
  IsArray,
  IsEmail,
  IsIn,
  IsOptional,
  IsString,
  Length,
  MaxLength,
} from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { PLAN_LIMITS } from '../billing/plan-limits';

const PLAN_CODES = Object.keys(PLAN_LIMITS);
const ORG_STATUS = ['ACTIVE', 'SUSPENDED'];

export class CreateOrgDto {
  @ApiProperty({ example: 'Acme, S.A. de C.V.' })
  @IsString()
  @Length(2, 160)
  name!: string;

  @ApiPropertyOptional({ example: 'Acme Servicios Industriales, S.A. de C.V.' })
  @IsOptional()
  @IsString()
  @MaxLength(200)
  legalName?: string;

  @ApiProperty({ enum: PLAN_CODES, example: 'ESSENTIAL' })
  @IsIn(PLAN_CODES)
  plan!: string;

  @ApiPropertyOptional({
    enum: ['ISO9001', 'ISO27001', 'ISO22301', 'ISO20000', 'ISO37001', 'ISO42001'],
    isArray: true,
    description: 'Normas a activar al crear la organización',
  })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  standards?: string[];

  @ApiProperty({ example: 'Ana Ruiz' })
  @IsString()
  @Length(2, 120)
  adminName!: string;

  @ApiProperty({ example: 'ana.ruiz@acme.mx' })
  @IsEmail()
  adminEmail!: string;
}

export class UpdateOrgStatusDto {
  @ApiProperty({ enum: ORG_STATUS, example: 'SUSPENDED' })
  @IsIn(ORG_STATUS)
  status!: string;
}
