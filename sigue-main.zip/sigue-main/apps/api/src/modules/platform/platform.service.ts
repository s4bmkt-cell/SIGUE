import {
  BadRequestException,
  ConflictException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { randomBytes } from 'crypto';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { withTenant } from '../../tenancy/with-tenant';
import { AuditService } from '../audit/audit.service';
import { PLAN_LIMITS } from '../billing/plan-limits';
import { provisionOrganization } from './org-provisioning';

/** Estados que el panel puede aplicar. Dar de baja es suspender, no borrar. */
const ALLOWED_STATUS = ['ACTIVE', 'SUSPENDED'] as const;

export interface PlatformOrgRow {
  id: string;
  name: string;
  legalName: string | null;
  plan: string;
  status: string;
  users: number;
  standards: number;
  storageGb: number;
  createdAt: Date;
}

export interface PlatformOrgDetail extends PlatformOrgRow {
  country: string;
  currency: string;
  admins: { id: string; name: string; email: string; lastLoginAt: Date | null }[];
  subscription: { planCode: string; status: string; periodEnd: Date | null } | null;
}

/**
 * Administración de la plataforma: catálogo de organizaciones y su ciclo de vida.
 *
 * Todo pasa por `withTenant({ platform: true })`, que fija el GUC `app.platform`
 * y activa las políticas RLS `platform_*`. Esas políticas solo leen: las
 * escrituras de datos de negocio de una organización **no** se abren nunca desde
 * aquí. Lo único que se escribe es `Organization` (alta y estado), más las filas
 * iniciales que crea el aprovisionamiento dentro de su propio `app.org_id`.
 *
 * Consecuencia deliberada: el panel ve plan, estado, personas y consumo, pero
 * **no** el contenido del SGI de un cliente (FODA, documentos, no
 * conformidades). El aislamiento entre inquilinos no tiene excepciones.
 */
@Injectable()
export class PlatformService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly audit: AuditService,
  ) {}

  /** Catálogo completo de organizaciones con sus conteos reales. */
  async listOrgs(query?: string): Promise<PlatformOrgRow[]> {
    const term = query?.trim();
    return withTenant(this.prisma, { platform: true }, async (tx) => {
      const orgs = await tx.organization.findMany({
        where: term
          ? {
              OR: [
                { name: { contains: term, mode: 'insensitive' } },
                { legalName: { contains: term, mode: 'insensitive' } },
              ],
            }
          : undefined,
        orderBy: { createdAt: 'desc' },
        select: {
          id: true,
          name: true,
          legalName: true,
          planCode: true,
          status: true,
          createdAt: true,
        },
      });

      // Los conteos se agregan en tres consultas, no una por organización: el
      // panel lista todas las empresas y fila a fila el coste crecería con el
      // número de clientes.
      const ids = orgs.map((o) => o.id);
      if (!ids.length) return [];

      const [members, standards, storage] = await Promise.all([
        tx.orgMember.groupBy({
          by: ['orgId'],
          where: { orgId: { in: ids }, status: 'ACTIVE' },
          _count: { _all: true },
        }),
        tx.orgStandard.groupBy({
          by: ['orgId'],
          where: { orgId: { in: ids }, status: 'ACTIVE' },
          _count: { _all: true },
        }),
        tx.evidenceFile.groupBy({
          by: ['orgId'],
          where: { orgId: { in: ids } },
          _sum: { size: true },
        }),
      ]);

      const countOf = <T extends { orgId: string }>(rows: T[]) =>
        new Map(rows.map((r) => [r.orgId, r]));
      const memberMap = countOf(members);
      const standardMap = countOf(standards);
      const storageMap = countOf(storage);

      return orgs.map((o) => ({
        id: o.id,
        name: o.name,
        legalName: o.legalName,
        plan: o.planCode,
        status: o.status,
        users: memberMap.get(o.id)?._count._all ?? 0,
        standards: standardMap.get(o.id)?._count._all ?? 0,
        storageGb: Number(
          (Number(storageMap.get(o.id)?._sum.size ?? 0) / 1024 ** 3).toFixed(2),
        ),
        createdAt: o.createdAt,
      }));
    });
  }

  /** Detalle de una organización, con sus administradores y su suscripción. */
  async getOrg(id: string): Promise<PlatformOrgDetail> {
    return withTenant(this.prisma, { platform: true }, async (tx) => {
      const org = await tx.organization.findUnique({
        where: { id },
        select: {
          id: true,
          name: true,
          legalName: true,
          planCode: true,
          status: true,
          country: true,
          currency: true,
          createdAt: true,
        },
      });
      if (!org) throw new NotFoundException('Organización no encontrada');

      const [members, standards, storageSum, admins, subscription] = await Promise.all([
        tx.orgMember.count({ where: { orgId: id, status: 'ACTIVE' } }),
        tx.orgStandard.count({ where: { orgId: id, status: 'ACTIVE' } }),
        tx.evidenceFile.aggregate({ where: { orgId: id }, _sum: { size: true } }),
        // `User` no lleva RLS, así que este join solo devuelve las personas de
        // esta organización porque `OrgMember` ya está acotado por `orgId`.
        tx.$queryRaw<{ id: string; name: string; email: string; lastLoginAt: Date | null }[]>`
          SELECT u."id", u."name", u."email", u."lastLoginAt"
          FROM "OrgMember" m JOIN "User" u ON u."id" = m."userId"
          WHERE m."orgId" = ${id} AND m."status" = 'ACTIVE'
            AND m."roles" && ARRAY['admin_org']::text[]
          ORDER BY u."name"
        `,
        tx.subscription.findUnique({
          where: { orgId: id },
          select: { planCode: true, status: true, periodEnd: true },
        }),
      ]);

      return {
        id: org.id,
        name: org.name,
        legalName: org.legalName,
        plan: org.planCode,
        status: org.status,
        country: org.country,
        currency: org.currency,
        users: members,
        standards,
        storageGb: Number((Number(storageSum._sum.size ?? 0) / 1024 ** 3).toFixed(2)),
        createdAt: org.createdAt,
        admins,
        subscription: subscription ?? null,
      };
    });
  }

  /**
   * Alta de una organización desde el panel.
   *
   * Genera una contraseña temporal y la devuelve **una sola vez**. Si el correo
   * ya pertenece a una cuenta, no se toca su contraseña: se reutiliza el usuario
   * y se le añade la membresía de administrador (misma regla que `db:provision`).
   */
  async createOrg(
    actor: AuthUser,
    input: {
      name: string;
      legalName?: string;
      plan: string;
      standards?: string[];
      adminName: string;
      adminEmail: string;
    },
  ) {
    if (!PLAN_LIMITS[input.plan]) {
      throw new BadRequestException(
        `Plan inválido: ${input.plan}. Válidos: ${Object.keys(PLAN_LIMITS).join(', ')}`,
      );
    }
    const email = input.adminEmail.trim().toLowerCase();
    const wanted = input.standards ?? [];

    // Las normas se validan contra el catálogo de la base: `Standard` es la
    // fuente de verdad y no lleva RLS (solo lectura para el rol de app).
    if (wanted.length) {
      const known = await this.prisma.standard.findMany({
        where: { code: { in: wanted } },
        select: { code: true },
      });
      const missing = wanted.filter((code) => !known.some((s) => s.code === code));
      if (missing.length) {
        throw new BadRequestException(`Norma desconocida: ${missing.join(', ')}`);
      }
    }

    // 18 bytes → 24 caracteres base64url. No se guarda en claro en ningún sitio
    // ni se registra en la bitácora: se muestra una vez y se pierde.
    const temporaryPassword = randomBytes(18).toString('base64url');

    const result = await withTenant(this.prisma, { platform: true }, (tx) =>
      provisionOrganization(tx, {
        orgName: input.name.trim(),
        legalName: input.legalName?.trim() || undefined,
        plan: input.plan,
        adminEmail: email,
        adminName: input.adminName.trim(),
        adminPassword: temporaryPassword,
        standards: wanted,
      }),
    );

    await this.audit.record({
      orgId: null,
      actorId: actor.sub,
      action: 'platform.org_create',
      entity: 'organization',
      entityId: result.orgId,
      // Se registra el correo, nunca la contraseña: `sanitize` la redactaría de
      // todos modos, pero no se envía siquiera.
      after: {
        name: input.name,
        plan: input.plan,
        standards: wanted,
        adminEmail: email,
        userCreated: result.userCreated,
      },
    });

    return {
      orgId: result.orgId,
      adminEmail: email,
      // Solo se devuelve si la cuenta es nueva: si el usuario ya existía, su
      // contraseña no se ha modificado y esta clave no serviría para nada.
      temporaryPassword: result.userCreated ? temporaryPassword : null,
      templates: result.templates,
    };
  }

  /**
   * Cambia el estado de una organización.
   *
   * Suspenderla corta el acceso de todos sus miembros de inmediato:
   * `OrgMembershipGuard` consulta el estado en cada petición con `:orgId`.
   */
  async setStatus(actor: AuthUser, id: string, status: string) {
    if (!(ALLOWED_STATUS as readonly string[]).includes(status)) {
      throw new BadRequestException(
        `Estado inválido: ${status}. Válidos: ${ALLOWED_STATUS.join(', ')}`,
      );
    }

    const updated = await withTenant(this.prisma, { platform: true }, async (tx) => {
      const org = await tx.organization.findUnique({
        where: { id },
        select: { id: true, status: true },
      });
      if (!org) throw new NotFoundException('Organización no encontrada');
      if (org.status === status) {
        throw new ConflictException(`La organización ya está en estado ${status}`);
      }
      return tx.organization.update({ where: { id }, data: { status } });
    });

    await this.audit.record({
      orgId: null,
      actorId: actor.sub,
      action: 'platform.org_status',
      entity: 'organization',
      entityId: id,
      after: { status },
    });

    return { id: updated.id, name: updated.name, status: updated.status };
  }

  /** Planes disponibles, para que la web no duplique el catálogo. */
  listPlans() {
    return Object.entries(PLAN_LIMITS).map(([code, limits]) => ({ code, ...limits }));
  }

  /** Normas del catálogo, para el selector del alta. */
  listStandards() {
    return this.prisma.standard.findMany({
      select: { code: true, title: true, edition: true },
      orderBy: { code: 'asc' },
    });
  }
}
