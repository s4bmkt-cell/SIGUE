import { Module } from '@nestjs/common';
import { PlatformController } from './platform.controller';
import { PlatformService } from './platform.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';
import { AuditModule } from '../audit/audit.module';

/**
 * Panel de plataforma. No importa `BillingModule`: el catálogo de planes llega
 * desde `PLAN_LIMITS`, que es un módulo de datos sin dependencias de Nest.
 */
@Module({
  imports: [TenancyModule, AuthSharedModule, AuditModule],
  controllers: [PlatformController],
  providers: [PlatformService],
})
export class PlatformModule {}
