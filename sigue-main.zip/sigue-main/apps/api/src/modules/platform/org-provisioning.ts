import type { Prisma } from '@prisma/client';
import * as bcrypt from 'bcryptjs';
import { seedTemplates } from '../../common/templates/seed-templates';

type TxClient = Prisma.TransactionClient;

/** Normas con Anexo A: al activarlas se crea su Declaración de Aplicabilidad. */
const ANNEX_A_STANDARDS = ['ISO27001', 'ISO42001'] as const;

export interface ProvisionOptions {
  orgName: string;
  legalName?: string;
  plan: string;
  /** Correo del administrador; se normaliza a minúsculas. */
  adminEmail: string;
  adminName: string;
  /**
   * Contraseña inicial. Solo se usa si el usuario **no existía**: una cuenta real
   * no se sobrescribe por accidente.
   */
  adminPassword?: string;
  /** Roles de la membresía. Por defecto `admin_org`. */
  roles?: string[];
  /** Códigos de norma a activar (`ISO9001`, `ISO27001`, …). */
  standards?: string[];
  /**
   * Id fijo para la organización. Lo usa el CLI (`--org-id`) para ser
   * idempotente con identificadores estables; el panel no lo fija.
   */
  orgId?: string;
}

export interface ProvisionResult {
  orgId: string;
  userId: string;
  /** `true` si el usuario administrador se creó en esta llamada. */
  userCreated: boolean;
  /** Plantillas propietarias sembradas. */
  templates: number;
}

/**
 * Crea (o completa) una organización con su suscripción, su administrador y sus
 * normas activas.
 *
 * Vive en `src` y recibe el cliente de transacción de quien llama, para que lo
 * usen los dos caminos sin duplicar la lógica: el CLI `db:provision` (rol dueño,
 * sin RLS) y el panel de plataforma (rol de aplicación, con `app.platform`).
 *
 * **Debe ejecutarse dentro de una transacción ya abierta.** Al final fija
 * `app.org_id` al identificador recién creado, porque las tablas de inquilino
 * (`OrgStandard`, `StatementOfApplicability`, `Template`) exigen ese contexto
 * incluso cuando quien las escribe es un administrador de plataforma: el panel
 * puede crearlas, no leerlas después.
 *
 * Es idempotente por nombre (o por `orgId`): repetir la llamada actualiza en
 * lugar de duplicar.
 */
export async function provisionOrganization(
  tx: TxClient,
  opts: ProvisionOptions,
): Promise<ProvisionResult> {
  const roles = opts.roles?.length ? opts.roles : ['admin_org'];
  const standards = opts.standards ?? [];

  // 1. Organización. La clave para ser idempotente es el nombre (o `orgId`): sin
  //    eso, cada ejecución crearía una organización nueva con otro uuid y el
  //    administrador acabaría repartido entre duplicados.
  let org;
  if (opts.orgId) {
    org = await tx.organization.upsert({
      where: { id: opts.orgId },
      update: {
        name: opts.orgName,
        planCode: opts.plan,
        ...(opts.legalName ? { legalName: opts.legalName } : {}),
      },
      create: {
        id: opts.orgId,
        name: opts.orgName,
        legalName: opts.legalName ?? opts.orgName,
        planCode: opts.plan,
      },
    });
  } else {
    const found = await tx.organization.findMany({ where: { name: opts.orgName } });
    if (found.length > 1) {
      throw new Error(
        `Hay ${found.length} organizaciones llamadas "${opts.orgName}". ` +
          'Usa --org-id para elegir una y no duplicar datos.',
      );
    }
    org =
      found.length > 0
        ? await tx.organization.update({
            where: { id: found[0].id },
            data: {
              planCode: opts.plan,
              ...(opts.legalName ? { legalName: opts.legalName } : {}),
            },
          })
        : await tx.organization.create({
            data: {
              name: opts.orgName,
              legalName: opts.legalName ?? opts.orgName,
              planCode: opts.plan,
            },
          });
  }

  // A partir de aquí se escribe en tablas de inquilino: se fija el contexto de la
  // organización recién creada (o encontrada). En el CLI es inocuo —conecta con
  // el rol dueño—; en el panel es lo que permite activar normas y sembrar
  // plantillas sin abrir escrituras de plataforma sobre datos de negocio.
  await tx.$executeRaw`SELECT set_config('app.org_id', ${org.id}, true)`;

  // 2. Suscripción: `GET /billing/subscription` la exige y responde 404 si falta.
  await tx.subscription.upsert({
    where: { orgId: org.id },
    update: { planCode: opts.plan },
    create: { orgId: org.id, planCode: opts.plan, status: 'ACTIVE' },
  });

  // 3. Usuario administrador. Si ya existe no se le cambia la contraseña: es una
  //    cuenta real y sobrescribirla por accidente la dejaría fuera de servicio.
  const existing = await tx.user.findUnique({ where: { email: opts.adminEmail } });
  let userId: string;
  let userCreated = false;
  if (existing) {
    userId = existing.id;
  } else {
    if (!opts.adminPassword) {
      throw new Error(
        'El usuario no existe y falta la contraseña inicial para el administrador.',
      );
    }
    const created = await tx.user.create({
      data: {
        email: opts.adminEmail,
        name: opts.adminName,
        passwordHash: await bcrypt.hash(opts.adminPassword, 10),
      },
    });
    userId = created.id;
    userCreated = true;
  }

  // 4. Membresía.
  await tx.orgMember.upsert({
    where: { orgId_userId: { orgId: org.id, userId } },
    update: { roles, status: 'ACTIVE' },
    create: { orgId: org.id, userId, roles, status: 'ACTIVE' },
  });

  // 5. Normas activadas y su Declaración de Aplicabilidad.
  for (const code of standards) {
    const standard = await tx.standard.findUnique({ where: { code } });
    if (!standard) {
      throw new Error(
        `La norma ${code} no está en la base: carga el catálogo primero (npm run db:catalog).`,
      );
    }
    await tx.orgStandard.upsert({
      where: { orgId_standardId: { orgId: org.id, standardId: standard.id } },
      update: { status: 'ACTIVE' },
      create: { orgId: org.id, standardId: standard.id, status: 'ACTIVE' },
    });

    if ((ANNEX_A_STANDARDS as readonly string[]).includes(code)) {
      await ensureSoa(tx, org.id, standard.id);
    }
  }

  // 6. Plantillas propietarias. Van al final porque cuelgan de la organización y
  //    son idempotentes, así que repetir el alta no las duplica.
  const templates = await seedTemplates(tx, org.id);

  return { orgId: org.id, userId, userCreated, templates };
}

/**
 * Declaración de Aplicabilidad de una norma con Anexo A.
 *
 * Replica `IsmsService.ensureSoaForStandard` sobre el cliente de transacción
 * recibido: aquí no hay inyección de dependencias, y duplicar el servicio
 * completo solo para esto no aporta. Idempotente: solo inserta los controles
 * que faltan, sin tocar los ya declarados.
 */
async function ensureSoa(tx: TxClient, orgId: string, standardId: string): Promise<number> {
  const clauses = await tx.standardClause.findMany({
    where: { standardId, kind: 'requirement', code: { startsWith: 'A.' } },
    orderBy: { sortOrder: 'asc' },
  });
  if (!clauses.length) return 0;

  const existing = await tx.statementOfApplicability.findMany({
    where: { orgId, standardId },
    select: { controlCode: true },
  });
  const known = new Set(existing.map((e) => e.controlCode));
  const pending = clauses.filter((c) => !known.has(c.code));
  if (pending.length) {
    await tx.statementOfApplicability.createMany({
      data: pending.map((c) => ({
        orgId,
        standardId,
        controlCode: c.code,
        controlName: c.title,
        applicable: true,
        implementationStatus: 'NOT_IMPLEMENTED',
      })),
    });
  }
  return pending.length;
}
