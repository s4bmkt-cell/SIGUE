import { BadRequestException, ConflictException, NotFoundException } from '@nestjs/common';
import { PlatformService } from './platform.service';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService } from '../audit/audit.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { provisionOrganization } from './org-provisioning';

// El aprovisionamiento real escribe en seis tablas; aquí interesa el contrato
// del servicio (validaciones, contraseña y auditoría), no volver a probarlo.
jest.mock('./org-provisioning', () => ({
  provisionOrganization: jest.fn(),
}));

const provisionMock = provisionOrganization as jest.MockedFunction<typeof provisionOrganization>;

const actor: AuthUser = {
  sub: 'admin-plataforma',
  email: 'admin@sign.mx',
  name: 'Admin',
  roles: [],
  orgId: null,
  platform: true,
};

/** Cliente de transacción mínimo: el servicio solo lo pasa a `provisionOrganization`. */
function build(opts: { standards?: { code: string }[]; status?: string } = {}) {
  const tx = { $executeRaw: jest.fn().mockResolvedValue(undefined) };

  const prisma = {
    $transaction: jest.fn(async (fn: (client: typeof tx) => Promise<unknown>) => fn(tx)),
    standard: {
      findMany: jest.fn().mockResolvedValue(opts.standards ?? [{ code: 'ISO9001' }]),
    },
  } as unknown as PrismaService;

  const audit = { record: jest.fn().mockResolvedValue(null) } as unknown as AuditService;

  return { service: new PlatformService(prisma, audit), audit, tx };
}

describe('PlatformService', () => {
  beforeEach(() => {
    provisionMock.mockReset();
  });

  describe('createOrg', () => {
    const input = {
      name: 'Acme, S.A. de C.V.',
      plan: 'BUSINESS',
      adminName: 'Ana Ruiz',
      adminEmail: 'Ana.Ruiz@Acme.mx',
    };

    it('rechaza un plan que no está en el catálogo', async () => {
      const { service } = build();
      await expect(
        service.createOrg(actor, { ...input, plan: 'ENTERPRISE' }),
      ).rejects.toBeInstanceOf(BadRequestException);
      expect(provisionMock).not.toHaveBeenCalled();
    });

    it('rechaza una norma que no existe en el catálogo', async () => {
      const { service } = build({ standards: [{ code: 'ISO9001' }] });
      await expect(
        service.createOrg(actor, { ...input, standards: ['ISO9001', 'ISO9999'] }),
      ).rejects.toBeInstanceOf(BadRequestException);
      expect(provisionMock).not.toHaveBeenCalled();
    });

    it('devuelve la contraseña temporal cuando la cuenta es nueva', async () => {
      const { service } = build();
      provisionMock.mockResolvedValue({
        orgId: 'org-nueva',
        userId: 'u-nueva',
        userCreated: true,
        templates: 12,
      });

      const result = await service.createOrg(actor, input);

      expect(result).toMatchObject({
        orgId: 'org-nueva',
        adminEmail: 'ana.ruiz@acme.mx',
        templates: 12,
      });
      // 18 bytes en base64url son 24 caracteres sin relleno.
      expect(result.temporaryPassword).toMatch(/^[A-Za-z0-9_-]{24}$/);

      // El correo se normaliza antes de llegar al aprovisionamiento.
      expect(provisionMock).toHaveBeenCalledWith(
        expect.anything(),
        expect.objectContaining({ adminEmail: 'ana.ruiz@acme.mx', plan: 'BUSINESS' }),
      );
    });

    it('no devuelve contraseña si el usuario ya existía', async () => {
      const { service } = build();
      provisionMock.mockResolvedValue({
        orgId: 'org-nueva',
        userId: 'u-existente',
        userCreated: false,
        templates: 12,
      });

      const result = await service.createOrg(actor, input);
      expect(result.temporaryPassword).toBeNull();
    });

    it('audita el alta sin incluir la contraseña', async () => {
      const { service, audit } = build();
      provisionMock.mockResolvedValue({
        orgId: 'org-nueva',
        userId: 'u-nueva',
        userCreated: true,
        templates: 12,
      });

      await service.createOrg(actor, input);

      const [event] = (audit.record as jest.Mock).mock.calls[0];
      expect(event).toMatchObject({
        orgId: null,
        actorId: actor.sub,
        action: 'platform.org_create',
        entityId: 'org-nueva',
      });
      expect(JSON.stringify(event.after)).not.toMatch(/temporaryPassword|passwordHash/i);
    });
  });

  describe('setStatus', () => {
    it('rechaza un estado fuera de ACTIVE | SUSPENDED', async () => {
      const { service } = build();
      await expect(service.setStatus(actor, 'org-1', 'DELETED')).rejects.toBeInstanceOf(
        BadRequestException,
      );
    });

    it('responde 404 si la organización no existe', async () => {
      const { service, tx } = build();
      Object.assign(tx, { organization: { findUnique: jest.fn().mockResolvedValue(null) } });
      await expect(service.setStatus(actor, 'org-x', 'SUSPENDED')).rejects.toBeInstanceOf(
        NotFoundException,
      );
    });

    it('responde 409 si ya está en ese estado y audita el cambio', async () => {
      const { service, tx, audit } = build();
      Object.assign(tx, {
        organization: {
          findUnique: jest.fn().mockResolvedValue({ id: 'org-1', status: 'SUSPENDED' }),
          update: jest.fn(),
        },
      });

      await expect(service.setStatus(actor, 'org-1', 'SUSPENDED')).rejects.toBeInstanceOf(
        ConflictException,
      );
      expect((audit.record as jest.Mock)).not.toHaveBeenCalled();

      (tx as unknown as { organization: { findUnique: jest.Mock } }).organization.findUnique.mockResolvedValue(
        { id: 'org-1', status: 'ACTIVE' },
      );
      (tx as unknown as { organization: { update: jest.Mock } }).organization.update.mockResolvedValue({
        id: 'org-1',
        name: 'Acme',
        status: 'SUSPENDED',
      });

      const result = await service.setStatus(actor, 'org-1', 'SUSPENDED');
      expect(result).toEqual({ id: 'org-1', name: 'Acme', status: 'SUSPENDED' });
      expect((audit.record as jest.Mock).mock.calls[0][0]).toMatchObject({
        orgId: null,
        action: 'platform.org_status',
        entityId: 'org-1',
        after: { status: 'SUSPENDED' },
      });
    });
  });

  it('listPlans expone el catálogo sin duplicarlo en la web', () => {
    const { service } = build();
    const plans = service.listPlans();
    expect(plans.map((p) => p.code).sort()).toEqual([
      'BUSINESS',
      'CONSULTANT',
      'ESSENTIAL',
      'PROFESSIONAL',
    ]);
    expect(plans.find((p) => p.code === 'BUSINESS')).toMatchObject({ monthlyUsd: 799 });
  });
});
