import { Body, Controller, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { PlatformService } from './platform.service';
import { CreateOrgDto, UpdateOrgStatusDto } from './platform.dto';

/**
 * Panel de plataforma: catálogo de empresas y su ciclo de vida.
 *
 * Todas las rutas usan `:id`, **nunca** `:orgId`: el guard global de tenancy
 * exige membresía en cuanto aparece un parámetro con ese nombre exacto, y aquí
 * la gracia es precisamente no ser miembro de la organización administrada.
 *
 * `@RequireRoles('admin_global')` es el contrato visible; quien lo satisface de
 * verdad es `User.isPlatformAdmin` (ver `RolesGuard`). El nombre del rol se
 * mantiene porque ya estaba declarado en billing, audit, export y consultant:
 * cambiarlo habría dejado esas rutas con un rol que nadie puede ostentar.
 */
@ApiTags('platform')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'platform', version: '1' })
export class PlatformController {
  constructor(private readonly platform: PlatformService) {}

  @ApiEndpoint('Organizaciones de la plataforma', { status: 200, tenant: false })
  @Get('orgs')
  @RequireRoles('admin_global')
  listOrgs(@Query('q') q?: string) {
    return this.platform.listOrgs(q);
  }

  @ApiEndpoint('Detalle de una organización', { status: 200, tenant: false, errors: ['notFound'] })
  @Get('orgs/:id')
  @RequireRoles('admin_global')
  getOrg(@Param('id') id: string) {
    return this.platform.getOrg(id);
  }

  @ApiEndpoint('Crea una organización con su administrador', {
    status: 201,
    tenant: false,
    errors: ['badRequest', 'conflict'],
  })
  @Post('orgs')
  @RequireRoles('admin_global')
  createOrg(@Body() dto: CreateOrgDto, @CurrentUser() user: AuthUser) {
    return this.platform.createOrg(user, dto);
  }

  @ApiEndpoint('Suspende o reactiva una organización', {
    status: 200,
    tenant: false,
    errors: ['badRequest', 'notFound', 'conflict'],
  })
  @Patch('orgs/:id/status')
  @RequireRoles('admin_global')
  setStatus(
    @Param('id') id: string,
    @Body() dto: UpdateOrgStatusDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.platform.setStatus(user, id, dto.status);
  }

  @ApiEndpoint('Planes disponibles', { status: 200, tenant: false })
  @Get('plans')
  @RequireRoles('admin_global')
  plans() {
    return this.platform.listPlans();
  }

  @ApiEndpoint('Normas del catálogo', { status: 200, tenant: false })
  @Get('standards')
  @RequireRoles('admin_global')
  standards() {
    return this.platform.listStandards();
  }
}
