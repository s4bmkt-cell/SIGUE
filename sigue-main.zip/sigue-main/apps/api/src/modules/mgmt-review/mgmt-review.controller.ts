import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { MgmtReviewService } from './mgmt-review.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('mgmt-review')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/mgmt-reviews', version: '1' })
export class MgmtReviewController {
  constructor(private readonly svc: MgmtReviewService) {}

  @ApiEndpoint('Revisiones por la dirección', { status: 200, tenant: true })
  @Get()
  list(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.svc.list(orgId, user);
  }

  @Audit('mgmt_reviews.create')
  @ApiEndpoint('Crea una revisión por la dirección', { status: 201, tenant: true })
  @Post()
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  create(@Param('orgId') orgId: string, @Body() data: { code: string; period: string }, @CurrentUser() user: AuthUser) {
    return this.svc.create(orgId, user, data);
  }

  @Audit('mgmt_reviews.add_agreement')
  @ApiEndpoint('Agrega un acuerdo de la revisión', { status: 201, tenant: true })
  @Post(':reviewId/agreements')
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  addAgreement(@Param('orgId') orgId: string, @Param('reviewId') reviewId: string, @Body() data: { decision: string; dueDate?: string }, @CurrentUser() user: AuthUser) {
    return this.svc.addAgreement(orgId, user, reviewId, data);
  }

  @Audit('mgmt_reviews.update_agreement')
  @ApiEndpoint('Actualiza un acuerdo', { status: 200, tenant: true })
  @Patch('agreements/:agreementId')
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  updateAgreement(
    @Param('orgId') orgId: string,
    @Param('agreementId') agreementId: string,
    @Body() data: { decision?: string; assigneeId?: string | null; dueDate?: string | null; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.svc.updateAgreement(orgId, user, agreementId, data);
  }

  @Audit('mgmt_reviews.complete_agreement')
  @ApiEndpoint('Marca un acuerdo como cumplido', { status: 200, tenant: true })
  @Patch('agreements/:agreementId/complete')
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  complete(@Param('orgId') orgId: string, @Param('agreementId') agreementId: string, @CurrentUser() user: AuthUser) {
    return this.svc.completeAgreement(orgId, user, agreementId);
  }

  @Audit('mgmt_reviews.delete_agreement')
  @ApiEndpoint('Elimina un acuerdo', { status: 200, tenant: true })
  @Delete('agreements/:agreementId')
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  deleteAgreement(@Param('orgId') orgId: string, @Param('agreementId') agreementId: string, @CurrentUser() user: AuthUser) {
    return this.svc.deleteAgreement(orgId, user, agreementId);
  }

  @Audit('mgmt_reviews.add_entry')
  @ApiEndpoint('Agrega una entrada (entrada/salida) a la revisión', { status: 201, tenant: true })
  @Post(':reviewId/entries')
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  addEntry(
    @Param('orgId') orgId: string,
    @Param('reviewId') reviewId: string,
    @Body() data: { entryType: string; source?: string; content?: unknown },
    @CurrentUser() user: AuthUser,
  ) {
    return this.svc.addEntry(orgId, user, reviewId, data);
  }

  @Audit('mgmt_reviews.delete_entry')
  @ApiEndpoint('Elimina una entrada de la revisión', { status: 200, tenant: true })
  @Delete('entries/:entryId')
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  deleteEntry(@Param('orgId') orgId: string, @Param('entryId') entryId: string, @CurrentUser() user: AuthUser) {
    return this.svc.deleteEntry(orgId, user, entryId);
  }

  @Audit('mgmt_reviews.status')
  @ApiEndpoint('Cambia el estado de la revisión', { status: 200, tenant: true })
  @Patch(':reviewId/status')
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  status(@Param('orgId') orgId: string, @Param('reviewId') reviewId: string, @Body('status') status: string, @CurrentUser() user: AuthUser) {
    return this.svc.updateStatus(orgId, user, reviewId, status);
  }

  @Audit('mgmt_reviews.close')
  @ApiEndpoint('Cierra la revisión por la dirección', { status: 201, tenant: true })
  @Post(':reviewId/close')
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  close(@Param('orgId') orgId: string, @Param('reviewId') reviewId: string, @CurrentUser() user: AuthUser) {
    return this.svc.close(orgId, user, reviewId);
  }

  @Audit('mgmt_reviews.delete')
  @ApiEndpoint('Elimina una revisión', { status: 200, tenant: true })
  @Delete(':reviewId')
  @RequireRoles('resp_sgi', 'alta_direccion', 'admin_org')
  remove(@Param('orgId') orgId: string, @Param('reviewId') reviewId: string, @CurrentUser() user: AuthUser) {
    return this.svc.remove(orgId, user, reviewId);
  }
}
