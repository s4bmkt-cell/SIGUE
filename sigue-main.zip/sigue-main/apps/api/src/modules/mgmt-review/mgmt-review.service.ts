import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

@Injectable()
export class MgmtReviewService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Lista las revisiones por la dirección. */
  async list(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.mgmtReview.findMany({
        where: { orgId },
        include: { entries: true, agreements: true },
        orderBy: { date: 'desc' },
      });
    });
  }

  /** Crea una revisión y genera automáticamente las 6 entradas requeridas. */
  async create(orgId: string, user: AuthUser, data: { code: string; period: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;

      // Entradas automáticas desde el estado del sistema
      const [compliance, audits, risks, nc, objectives, processes] = await Promise.all([
        tx.requirementStatus.count({ where: { orgId, level: { in: ['IMPLEMENTED', 'MATURE'] } } }),
        tx.audit.count({ where: { orgId } }),
        tx.risk.count({ where: { orgId } }),
        tx.nc.count({ where: { orgId, status: { not: 'CLOSED' } } }),
        tx.objective.count({ where: { orgId } }),
        tx.processMap.count({ where: { orgId } }),
      ]);
      const totalReq = await tx.standardClause.count({ where: { kind: 'requirement' } });

      const review = await tx.mgmtReview.create({
        data: { orgId, code: data.code, period: data.period, preparedById: user.sub },
      });
      await tx.reviewEntry.createMany({
        data: [
          { orgId, reviewId: review.id, entryType: 'COMPLIANCE', source: `Cumplimiento global ${totalReq ? Math.round((compliance / totalReq) * 100) : 0}%`, auto: true },
          { orgId, reviewId: review.id, entryType: 'AUDITS', source: `Auditorías realizadas: ${audits}`, auto: true },
          { orgId, reviewId: review.id, entryType: 'RISKS', source: `Riesgos registrados: ${risks}`, auto: true },
          { orgId, reviewId: review.id, entryType: 'NC', source: `NC abiertas: ${nc}`, auto: true },
          { orgId, reviewId: review.id, entryType: 'OBJECTIVES', source: `Objetivos: ${objectives}`, auto: true },
          { orgId, reviewId: review.id, entryType: 'PROCESS_PERFORMANCE', source: `Procesos: ${processes}`, auto: true },
        ],
      });
      return review;
    });
  }

  /** Agrega un acuerdo a la revisión (con responsable y fecha). */
  async addAgreement(orgId: string, user: AuthUser, reviewId: string, data: { decision: string; dueDate?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const review = await tx.mgmtReview.findUnique({ where: { id: reviewId } });
      if (!review || review.orgId !== orgId) throw new NotFoundException('Revisión no encontrada');
      return tx.reviewAgreement.create({
        data: { orgId, reviewId, decision: data.decision, assigneeId: user.sub, dueDate: data.dueDate ? new Date(data.dueDate) : null },
      });
    });
  }

  /** Marca un acuerdo como cumplido. */
  async completeAgreement(orgId: string, user: AuthUser, agreementId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const a = await tx.reviewAgreement.findUnique({ where: { id: agreementId } });
      if (!a || a.orgId !== orgId) throw new NotFoundException('Acuerdo no encontrado');
      return tx.reviewAgreement.update({ where: { id: agreementId }, data: { status: 'DONE' } });
    });
  }

  /** Actualiza un acuerdo (decisión, responsable, fecha, estado). */
  async updateAgreement(
    orgId: string,
    user: AuthUser,
    agreementId: string,
    data: { decision?: string; assigneeId?: string | null; dueDate?: string | null; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const a = await tx.reviewAgreement.findUnique({ where: { id: agreementId } });
      if (!a || a.orgId !== orgId) throw new NotFoundException('Acuerdo no encontrado');
      return tx.reviewAgreement.update({
        where: { id: agreementId },
        data: {
          ...(data.decision !== undefined ? { decision: data.decision } : {}),
          ...(data.assigneeId !== undefined ? { assigneeId: data.assigneeId } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.dueDate !== undefined
            ? { dueDate: data.dueDate ? new Date(data.dueDate) : null }
            : {}),
        },
      });
    });
  }

  async deleteAgreement(orgId: string, user: AuthUser, agreementId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const a = await tx.reviewAgreement.findUnique({ where: { id: agreementId } });
      if (!a || a.orgId !== orgId) throw new NotFoundException('Acuerdo no encontrado');
      await tx.reviewAgreement.delete({ where: { id: agreementId } });
      return { ok: true, deleted: agreementId };
    });
  }

  /** Elimina una entrada de la revisión (corrige una captura equivocada). */
  async deleteEntry(orgId: string, user: AuthUser, entryId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const entry = await tx.reviewEntry.findUnique({ where: { id: entryId } });
      if (!entry || entry.orgId !== orgId) throw new NotFoundException('Entrada no encontrada');
      await tx.reviewEntry.delete({ where: { id: entryId } });
      return { ok: true, deleted: entryId };
    });
  }

  /** Registra una entrada manual de la revisión (p. ej. resultados de proceso). */
  async addEntry(
    orgId: string,
    user: AuthUser,
    reviewId: string,
    data: { entryType: string; source?: string; content?: unknown },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const review = await tx.mgmtReview.findUnique({ where: { id: reviewId } });
      if (!review || review.orgId !== orgId) throw new NotFoundException('Revisión no encontrada');
      return tx.reviewEntry.create({
        data: {
          orgId,
          reviewId,
          entryType: data.entryType,
          source: data.source,
          content: data.content === undefined ? undefined : (data.content as object),
          auto: false,
        },
      });
    });
  }

  /** Actualiza el estado de la revisión (iniciar / cerrar). */
  async updateStatus(orgId: string, user: AuthUser, reviewId: string, status: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const review = await tx.mgmtReview.findUnique({ where: { id: reviewId } });
      if (!review || review.orgId !== orgId) throw new NotFoundException('Revisión no encontrada');
      return tx.mgmtReview.update({ where: { id: reviewId }, data: { status } });
    });
  }

  /**
   * Cierra la revisión. No se permite con acuerdos pendientes: los compromisos
   * de la dirección deben quedar con dueño y fecha antes de archivar la sesión.
   */
  async close(orgId: string, user: AuthUser, reviewId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const review = await tx.mgmtReview.findUnique({
        where: { id: reviewId },
        include: { agreements: true },
      });
      if (!review || review.orgId !== orgId) throw new NotFoundException('Revisión no encontrada');

      const open = review.agreements.filter((a) => a.status !== 'DONE').length;
      if (open > 0) {
        throw new BadRequestException(`Hay ${open} acuerdo(s) sin cumplir; ciérralos antes`);
      }
      return tx.mgmtReview.update({
        where: { id: reviewId },
        data: { status: 'COMPLETED' },
        include: { entries: true, agreements: true },
      });
    });
  }

  async remove(orgId: string, user: AuthUser, reviewId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const review = await tx.mgmtReview.findUnique({ where: { id: reviewId } });
      if (!review || review.orgId !== orgId) throw new NotFoundException('Revisión no encontrada');
      await tx.mgmtReview.delete({ where: { id: reviewId } });
      return { ok: true, deleted: reviewId };
    });
  }
}
