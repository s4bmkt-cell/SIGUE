import { Module } from '@nestjs/common';
import { MgmtReviewController } from './mgmt-review.controller';
import { MgmtReviewService } from './mgmt-review.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [TenancyModule, AuthSharedModule],
  controllers: [MgmtReviewController],
  providers: [MgmtReviewService],
})
export class MgmtReviewModule {}
