import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { IsmsService } from './isms.service';
import { UpdateSoaDto } from './dto/soa.dto';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('isms')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/isms', version: '1' })
export class IsmsController {
  constructor(private readonly isms: IsmsService) {}

  @ApiEndpoint('Panorama del SGSI: activos, SOA e incidentes', { status: 200, tenant: true })
  @Get()
  overview(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.isms.overview(orgId, user);
  }

  // ===== Activos =====
  @Audit('isms.add_asset')
  @ApiEndpoint('Registra un activo de información', { status: 201, tenant: true })
  @Post('assets')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addAsset(@Param('orgId') orgId: string, @Body() data: { name: string; type?: string; classification?: string; location?: string }, @CurrentUser() user: AuthUser) {
    return this.isms.addAsset(orgId, user, data);
  }

  @Audit('isms.update_asset')
  @ApiEndpoint('Actualiza un activo', { status: 200, tenant: true })
  @Patch('assets/:assetId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateAsset(
    @Param('orgId') orgId: string,
    @Param('assetId') assetId: string,
    @Body() data: { name?: string; type?: string; classification?: string; location?: string | null; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.isms.updateAsset(orgId, user, assetId, data);
  }

  @Audit('isms.delete_asset')
  @ApiEndpoint('Elimina un activo', { status: 200, tenant: true })
  @Delete('assets/:assetId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteAsset(@Param('orgId') orgId: string, @Param('assetId') assetId: string, @CurrentUser() user: AuthUser) {
    return this.isms.deleteAsset(orgId, user, assetId);
  }

  // ===== Declaración de aplicabilidad =====
  @ApiEndpoint('Declaración de aplicabilidad', { status: 200, tenant: true })
  @Get('soa')
  listSoa(
    @Param('orgId') orgId: string,
    @Query('applicable') applicable: string | undefined,
    @Query('status') status: string | undefined,
    @Query('standardId') standardId: string | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    return this.isms.listSoa(orgId, user, {
      applicable: applicable === undefined ? undefined : applicable === 'true',
      status,
      standardId,
    });
  }

  /**
   * SOA de todas las normas con Anexo A (27001 y 42001), agrupada por norma.
   * La sección «SoA» de Contexto usa este endpoint para alternar entre ambas.
   */
  @ApiEndpoint('Declaración de aplicabilidad de las normas con Anexo A', {
    status: 200,
    tenant: true,
  })
  @Get('soa/by-standard')
  listSoaByStandard(
    @Param('orgId') orgId: string,
    @Query('standardId') standardId: string | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    return this.isms.listSoaByStandard(orgId, user, standardId);
  }

  @Audit('isms.update_soa')
  @ApiEndpoint('Actualiza un control de la SOA', { status: 200, tenant: true })
  @Patch('soa/:controlId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateSoa(
    @Param('orgId') orgId: string,
    @Param('controlId') controlId: string,
    @Body() data: UpdateSoaDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.isms.updateSoa(orgId, user, controlId, data);
  }

  // ===== Incidentes =====
  @Audit('isms.add_incident')
  @ApiEndpoint('Registra un incidente de seguridad', { status: 201, tenant: true })
  @Post('incidents')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addIncident(@Param('orgId') orgId: string, @Body() data: { title: string; description?: string; severity?: string }, @CurrentUser() user: AuthUser) {
    return this.isms.addIncident(orgId, user, data);
  }

  @Audit('isms.update_incident')
  @ApiEndpoint('Actualiza un incidente de seguridad', { status: 200, tenant: true })
  @Patch('incidents/:incidentId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateIncident(
    @Param('orgId') orgId: string,
    @Param('incidentId') incidentId: string,
    @Body() data: { status?: string; severity?: string; description?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.isms.updateIncident(orgId, user, incidentId, data);
  }

  @Audit('isms.delete_incident')
  @ApiEndpoint('Elimina un incidente de seguridad', { status: 200, tenant: true })
  @Delete('incidents/:incidentId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteIncident(@Param('orgId') orgId: string, @Param('incidentId') incidentId: string, @CurrentUser() user: AuthUser) {
    return this.isms.deleteIncident(orgId, user, incidentId);
  }
}
