import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

/**
 * Orden natural de códigos de control: `A.2` antes que `A.10`.
 *
 * Prisma ordena como texto, y en el Anexo A de ISO/IEC 42001 (donde los códigos
 * llevan un solo dígito) eso dejaba `A.10` al principio, que se lee mal en la
 * tabla.
 */
const compareControlCode = (a: string, b: string) =>
  a.localeCompare(b, 'es', { numeric: true });

@Injectable()
export class IsmsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /**
   * Panorama del SGSI.
   *
   * `soa` se mantiene acotada a ISO/IEC 27001 porque esta vista es la de
   * seguridad de la información; `soaByStandard` resume todas las
   * declaraciones de aplicabilidad de la organización (27001 y 42001).
   */
  async overview(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [assets, allSoa, incidents] = await Promise.all([
        tx.securityAsset.findMany({ where: { orgId } }),
        tx.statementOfApplicability.findMany({
          where: { orgId },
          include: { standard: { select: { code: true, edition: true } } },
          orderBy: [{ standardId: 'asc' }, { controlCode: 'asc' }],
        }),
        tx.securityIncident.findMany({ where: { orgId }, orderBy: { detectedAt: 'desc' } }),
      ]);

      const soa = allSoa.filter((s) => s.standard.code === 'ISO27001');
      const applicable = soa.filter((s) => s.applicable).length;
      const implemented = soa.filter(
        (s) => s.applicable && s.implementationStatus === 'IMPLEMENTED',
      ).length;

      // Resumen por norma: la SOA existe para cada norma con Anexo A. La clave
      // es `standardId` y no el código: son dos ámbitos distintos y así el
      // selector del front puede pedir directamente la declaración elegida.
      const byStandard = new Map<
        string,
        {
          id: string;
          code: string;
          edition: string;
          total: number;
          applicable: number;
          implemented: number;
        }
      >();
      for (const row of allSoa) {
        const entry = byStandard.get(row.standardId) ?? {
          id: row.standardId,
          code: row.standard.code,
          edition: row.standard.edition,
          total: 0,
          applicable: 0,
          implemented: 0,
        };
        entry.total += 1;
        if (row.applicable) entry.applicable += 1;
        if (row.applicable && row.implementationStatus === 'IMPLEMENTED') entry.implemented += 1;
        byStandard.set(row.standardId, entry);
      }
      const soaByStandard = [...byStandard.values()]
        .sort((a, b) => a.code.localeCompare(b.code))
        .map((e) => ({
          ...e,
          progress: e.applicable ? Math.round((e.implemented / e.applicable) * 100) : 0,
        }));

      return {
        assets,
        soa: soa.map(({ standard: _standard, ...row }) => row),
        incidents,
        summary: {
          total: soa.length,
          applicable,
          implemented,
          soaProgress: applicable ? Math.round((implemented / applicable) * 100) : 0,
        },
        soaByStandard,
      };
    });
  }

  async addAsset(orgId: string, user: AuthUser, data: { name: string; type?: string; classification?: string; location?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      return tx.securityAsset.create({
        data: { orgId, name: data.name, type: data.type ?? 'INFORMATION', classification: data.classification ?? 'INTERNO', location: data.location, ownerId: user.sub },
      });
    });
  }

  /** Actualiza la SOA: aplicabilidad + estado de implementación. */
  async updateSoa(
    orgId: string,
    user: AuthUser,
    controlId: string,
    data: { applicable?: boolean; justification?: string; implementationStatus?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const c = await tx.statementOfApplicability.findUnique({ where: { id: controlId } });
      if (!c || c.orgId !== orgId) throw new NotFoundException('Control no encontrado');
      return tx.statementOfApplicability.update({
        where: { id: controlId },
        data: { applicable: data.applicable ?? c.applicable, justification: data.justification ?? c.justification, implementationStatus: data.implementationStatus ?? c.implementationStatus },
      });
    });
  }

  /**
   * Declaraciones de aplicabilidad de la organización, opcionalmente por norma.
   *
   * Es el mismo dato que `overview` pero sin activos ni incidentes: lo consume
   * la sección SoA de Contexto, que necesita alternar entre 27001 y 42001.
   */
  async listSoaByStandard(orgId: string, user: AuthUser, standardId?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const rows = await tx.statementOfApplicability.findMany({
        where: { orgId, ...(standardId ? { standardId } : {}) },
        include: { standard: { select: { code: true, edition: true, title: true } } },
      });
      // El orden se calcula aquí, no en SQL: Prisma ordena texto y dejaría
      // `A.10` antes que `A.2`.
      rows.sort(
        (a, b) =>
          a.standard.code.localeCompare(b.standard.code) ||
          compareControlCode(a.controlCode, b.controlCode),
      );
      return rows.map(({ standard, ...row }) => ({ ...row, standard }));
    });
  }

  /**
   * Crea las filas de SOA de una norma a partir de sus controles de Anexo A.
   *
   * Se llama al activar la norma: antes la declaración solo existía si el seed
   * la había sembrado, así que una organización nueva activaba ISO 27001 y veía
   * una pantalla vacía que prometía controles generados. Es idempotente: no
   * toca las filas que ya existen (nadie pierde su justificación).
   */
  async ensureSoaForStandard(
    tx: Prisma.TransactionClient,
    orgId: string,
    standardId: string,
    standardCode: string,
  ) {
    const clauses = await tx.standardClause.findMany({
      where: { standardId, kind: 'requirement', code: { startsWith: 'A.' } },
      orderBy: { sortOrder: 'asc' },
    });
    if (!clauses.length) return { created: 0, code: standardCode };

    // Solo se insertan las que faltan: `createMany` con `skipDuplicates` no
    // devuelve cuántas entraron, así que se consulta antes lo existente.
    const existing = await tx.statementOfApplicability.findMany({
      where: { orgId, standardId },
      select: { controlCode: true },
    });
    const known = new Set(existing.map((e) => e.controlCode));
    const pending = clauses.filter((c) => !known.has(c.code));
    if (pending.length) {
      await tx.statementOfApplicability.createMany({
        data: pending.map((c) => ({
          orgId,
          standardId,
          controlCode: c.code,
          controlName: c.title,
          applicable: true,
          implementationStatus: 'NOT_IMPLEMENTED',
        })),
      });
    }
    return { created: pending.length, code: standardCode };
  }

  async addIncident(orgId: string, user: AuthUser, data: { title: string; description?: string; severity?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      return tx.securityIncident.create({
        data: { orgId, title: data.title, description: data.description, severity: data.severity ?? 'MEDIA', reportedById: user.sub },
      });
    });
  }

  async updateAsset(
    orgId: string,
    user: AuthUser,
    assetId: string,
    data: { name?: string; type?: string; classification?: string; location?: string | null; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const asset = await tx.securityAsset.findUnique({ where: { id: assetId } });
      if (!asset || asset.orgId !== orgId) throw new NotFoundException('Activo no encontrado');
      return tx.securityAsset.update({ where: { id: assetId }, data });
    });
  }

  async deleteAsset(orgId: string, user: AuthUser, assetId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const asset = await tx.securityAsset.findUnique({ where: { id: assetId } });
      if (!asset || asset.orgId !== orgId) throw new NotFoundException('Activo no encontrado');
      await tx.securityAsset.delete({ where: { id: assetId } });
      return { ok: true, deleted: assetId };
    });
  }

  /** Lista la SOA filtrable (aplicables, no implementados) para trabajo diario. */
  async listSoa(
    orgId: string,
    user: AuthUser,
    filter?: { applicable?: boolean; status?: string; standardId?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.statementOfApplicability.findMany({
        where: {
          orgId,
          ...(filter?.standardId ? { standardId: filter.standardId } : {}),
          ...(filter?.applicable !== undefined ? { applicable: filter.applicable } : {}),
          ...(filter?.status ? { implementationStatus: filter.status } : {}),
        },
        include: { standard: { select: { code: true, edition: true } } },
        orderBy: [{ standardId: 'asc' }, { controlCode: 'asc' }],
      });
    });
  }

  /**
   * Cambia el estado de un incidente. Al resolver, fija `resolvedAt`; al reabrir,
   * lo limpia, de modo que el tiempo de resolución sea siempre consistente.
   */
  async updateIncident(
    orgId: string,
    user: AuthUser,
    incidentId: string,
    data: { status?: string; severity?: string; description?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const incident = await tx.securityIncident.findUnique({ where: { id: incidentId } });
      if (!incident || incident.orgId !== orgId) throw new NotFoundException('Incidente no encontrado');

      const closed = data.status === 'RESOLVED' || data.status === 'CLOSED';
      const reopened = data.status === 'OPEN' || data.status === 'IN_PROGRESS';
      return tx.securityIncident.update({
        where: { id: incidentId },
        data: {
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.severity !== undefined ? { severity: data.severity } : {}),
          ...(data.description !== undefined ? { description: data.description } : {}),
          ...(closed ? { resolvedAt: incident.resolvedAt ?? new Date() } : {}),
          ...(reopened ? { resolvedAt: null } : {}),
        },
      });
    });
  }

  async deleteIncident(orgId: string, user: AuthUser, incidentId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const incident = await tx.securityIncident.findUnique({ where: { id: incidentId } });
      if (!incident || incident.orgId !== orgId) throw new NotFoundException('Incidente no encontrado');
      await tx.securityIncident.delete({ where: { id: incidentId } });
      return { ok: true, deleted: incidentId };
    });
  }
}
