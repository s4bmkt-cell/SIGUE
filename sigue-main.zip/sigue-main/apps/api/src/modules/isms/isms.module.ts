import { Module } from '@nestjs/common';
import { IsmsController } from './isms.controller';
import { IsmsService } from './isms.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [TenancyModule, AuthSharedModule],
  controllers: [IsmsController],
  providers: [IsmsService],
  // `standards` lo usa al activar una norma para generar su SOA.
  exports: [IsmsService],
})
export class IsmsModule {}
