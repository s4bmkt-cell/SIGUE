import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsBoolean, IsIn, IsOptional, IsString, Length } from 'class-validator';

/** Estados de implementación admitidos en la Declaración de Aplicabilidad. */
export const SOA_STATUSES = ['NOT_IMPLEMENTED', 'PLANNED', 'IMPLEMENTED'] as const;

export type SoaStatus = (typeof SOA_STATUSES)[number];

/**
 * Actualización de una fila de la SOA.
 *
 * Como el resto de DTOs con clase, queda sujeto al `ValidationPipe` global con
 * `forbidNonWhitelisted`: un `orgId` o un `standardId` en el cuerpo se rechaza
 * en lugar de ignorarse, porque la norma del registro no se cambia desde aquí.
 */
export class UpdateSoaDto {
  @ApiPropertyOptional({ description: 'Si el control aplica a la organización' })
  @IsOptional()
  @IsBoolean()
  applicable?: boolean;

  @ApiPropertyOptional({ description: 'Por qué aplica o por qué se excluye' })
  @IsOptional()
  @IsString()
  @Length(0, 1000)
  justification?: string;

  @ApiPropertyOptional({ enum: SOA_STATUSES })
  @IsOptional()
  @IsIn(SOA_STATUSES)
  implementationStatus?: SoaStatus;
}
