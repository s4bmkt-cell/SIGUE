import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { AuditsService } from './audits.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('audits')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/audits', version: '1' })
export class AuditsController {
  constructor(private readonly audits: AuditsService) {}

  @ApiEndpoint('Auditorías internas de la organización', { status: 200, tenant: true })
  @Get()
  list(@Param('orgId') orgId: string, @Query('year') year: string | undefined, @CurrentUser() user: AuthUser) {
    return this.audits.list(orgId, user, year ? parseInt(year, 10) : undefined);
  }

  @Audit('audits.create')
  @ApiEndpoint('Programa una auditoría interna', { status: 201, tenant: true })
  @Post()
  @RequireRoles('auditor_interno', 'resp_sgi', 'resp_norma', 'admin_org')
  create(
    @Param('orgId') orgId: string,
    @Body()
    data: {
      title: string;
      scope?: string;
      standardId?: string;
      startDate?: string;
      endDate?: string;
      year?: number;
      checklist?: { clauseId: string; question: string }[];
    },
    @CurrentUser() user: AuthUser,
  ) {
    return this.audits.create(orgId, user, data);
  }

  @Audit('audits.update')
  @ApiEndpoint('Actualiza una auditoría', { status: 200, tenant: true })
  @Patch(':auditId')
  @RequireRoles('auditor_interno', 'resp_sgi', 'resp_norma', 'admin_org')
  update(
    @Param('orgId') orgId: string,
    @Param('auditId') auditId: string,
    @Body()
    data: { title?: string; scope?: string | null; startDate?: string | null; endDate?: string | null; status?: string; standardId?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.audits.update(orgId, user, auditId, data);
  }

  @Audit('audits.delete')
  @ApiEndpoint('Elimina una auditoría', { status: 200, tenant: true })
  @Delete(':auditId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  remove(@Param('orgId') orgId: string, @Param('auditId') auditId: string, @CurrentUser() user: AuthUser) {
    return this.audits.remove(orgId, user, auditId);
  }

  /** Genera el checklist desde los requisitos de la norma. */
  @Audit('audits.generate_checklist')
  @ApiEndpoint('Genera la lista de verificación de la auditoría', { status: 201, tenant: true })
  @Post(':auditId/checklist')
  @RequireRoles('auditor_interno', 'resp_sgi', 'resp_norma', 'admin_org')
  generateChecklist(@Param('orgId') orgId: string, @Param('auditId') auditId: string, @CurrentUser() user: AuthUser) {
    return this.audits.generateChecklist(orgId, user, auditId);
  }

  @Audit('audits.set_result')
  @ApiEndpoint('Registra el resultado de un punto de la lista', { status: 201, tenant: true })
  @Post('checklist/:itemId/result')
  @RequireRoles('auditor_interno', 'resp_sgi', 'admin_org')
  setResult(
    @Param('orgId') orgId: string,
    @Param('itemId') itemId: string,
    @Body() data: { result: string; comment?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.audits.setChecklistItemResult(orgId, user, itemId, data.result, data.comment);
  }

  @Audit('audits.add_finding')
  @ApiEndpoint('Registra un hallazgo de auditoría', { status: 201, tenant: true })
  @Post(':auditId/findings')
  @RequireRoles('auditor_interno', 'resp_sgi', 'admin_org')
  addFinding(
    @Param('orgId') orgId: string,
    @Param('auditId') auditId: string,
    @Body() data: { type: string; description: string; clauseId?: string; classification?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.audits.addFinding(orgId, user, auditId, data);
  }

  @Audit('audits.update_finding')
  @ApiEndpoint('Actualiza un hallazgo', { status: 200, tenant: true })
  @Patch('findings/:findingId')
  @RequireRoles('auditor_interno', 'resp_sgi', 'resp_norma', 'admin_org')
  updateFinding(
    @Param('orgId') orgId: string,
    @Param('findingId') findingId: string,
    @Body() data: { status?: string; description?: string; classification?: string; type?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.audits.updateFinding(orgId, user, findingId, data);
  }

  @Audit('audits.delete_finding')
  @ApiEndpoint('Elimina un hallazgo', { status: 200, tenant: true })
  @Delete('findings/:findingId')
  @RequireRoles('auditor_interno', 'resp_sgi', 'resp_norma', 'admin_org')
  deleteFinding(@Param('orgId') orgId: string, @Param('findingId') findingId: string, @CurrentUser() user: AuthUser) {
    return this.audits.deleteFinding(orgId, user, findingId);
  }

  @Audit('audits.close')
  @ApiEndpoint('Cierra la auditoría', { status: 201, tenant: true })
  @Post(':auditId/close')
  @RequireRoles('auditor_interno', 'resp_sgi', 'resp_norma', 'admin_org')
  close(@Param('orgId') orgId: string, @Param('auditId') auditId: string, @CurrentUser() user: AuthUser) {
    return this.audits.close(orgId, user, auditId);
  }

  @ApiEndpoint('Informe consolidado de la auditoría', { status: 200, tenant: true })
  @Get(':auditId/report')
  report(@Param('orgId') orgId: string, @Param('auditId') auditId: string, @CurrentUser() user: AuthUser) {
    return this.audits.report(orgId, user, auditId);
  }
}
