import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

@Injectable()
export class AuditsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Lista auditorías de la organización (con hallazgos y checklist). */
  async list(orgId: string, user: AuthUser, year?: number) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.audit.findMany({
        where: { orgId, ...(year ? { program: { year } } : {}) },
        include: {
          program: true,
          findings: true,
          checklists: { include: { items: true } },
        },
        orderBy: { startDate: 'desc' },
      });
    });
  }

  /** Crea una auditoría con su checklist inicial. */
  async create(
    orgId: string,
    user: AuthUser,
    data: { title: string; scope?: string; standardId?: string; startDate?: string; endDate?: string; year?: number; checklist?: { clauseId: string; question: string }[] },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const year = data.year ?? new Date().getFullYear();
      let program = await tx.auditProgram.findFirst({ where: { orgId, year } });
      if (!program) program = await tx.auditProgram.create({ data: { orgId, year } });

      const audit = await tx.audit.create({
        data: {
          orgId,
          programId: program.id,
          standardId: data.standardId,
          title: data.title,
          scope: data.scope,
          startDate: data.startDate ? new Date(data.startDate) : null,
          endDate: data.endDate ? new Date(data.endDate) : null,
          status: 'PLANNED',
          leadAuditorId: user.sub,
        },
      });

      if (data.checklist?.length) {
        const checklist = await tx.auditChecklist.create({
          data: { orgId, auditId: audit.id, title: `Checklist ${audit.title}` },
        });
        await tx.checklistItem.createMany({
          data: data.checklist.map((c) => ({ orgId, checklistId: checklist.id, clauseId: c.clauseId, question: c.question })),
        });
      }
      return audit;
    });
  }

  /** Registra el resultado de un ítem del checklist. */
  async setChecklistItemResult(orgId: string, user: AuthUser, itemId: string, result: string, comment?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const item = await tx.checklistItem.findUnique({ where: { id: itemId } });
      if (!item || item.orgId !== orgId) throw new NotFoundException('Ítem no encontrado');
      return tx.checklistItem.update({ where: { id: itemId }, data: { result, comment } });
    });
  }

  /** Registra un hallazgo en la auditoría. */
  async addFinding(
    orgId: string,
    user: AuthUser,
    auditId: string,
    data: { type: string; description: string; clauseId?: string; classification?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const audit = await tx.audit.findUnique({ where: { id: auditId } });
      if (!audit || audit.orgId !== orgId) throw new NotFoundException('Auditoría no encontrada');
      return tx.finding.create({
        data: {
          orgId,
          auditId,
          clauseId: data.clauseId,
          type: data.type,
          description: data.description,
          classification: data.classification ?? 'MENOR',
          assigneeId: user.sub,
        },
      });
    });
  }

  /** Actualiza datos de la auditoría (alcance, fechas, estado). */
  async update(
    orgId: string,
    user: AuthUser,
    auditId: string,
    data: { title?: string; scope?: string | null; startDate?: string | null; endDate?: string | null; status?: string; standardId?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findAudit(tx, orgId, auditId);
      return tx.audit.update({
        where: { id: auditId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.scope !== undefined ? { scope: data.scope } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.standardId !== undefined ? { standardId: data.standardId } : {}),
          ...(data.startDate !== undefined
            ? { startDate: data.startDate ? new Date(data.startDate) : null }
            : {}),
          ...(data.endDate !== undefined
            ? { endDate: data.endDate ? new Date(data.endDate) : null }
            : {}),
        },
      });
    });
  }

  /**
   * Genera la lista de verificación a partir de los requisitos de la norma de la
   * auditoría (o de la primera norma activa si no se indicó).
   */
  async generateChecklist(orgId: string, user: AuthUser, auditId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const audit = await this.findAudit(tx, orgId, auditId);

      // Se prefiere la norma de la auditoría; si no la tiene o no tiene
      // requisitos cargados, se usa la primera norma activa con contenido.
      // El orden por `createdAt` es deliberado: sin él PostgreSQL devuelve las
      // filas en orden no garantizado y, con seis normas activas, la misma
      // auditoría podía generar 40 ítems o 120 según la ejecución.
      const active = await tx.orgStandard.findMany({
        where: { orgId, status: 'ACTIVE' },
        orderBy: { createdAt: 'asc' },
        select: { standardId: true },
      });
      const candidates = [
        ...(audit.standardId ? [audit.standardId] : []),
        ...active.map((s) => s.standardId),
      ];
      let clauses: { id: string; code: string; title: string }[] = [];
      let usedStandard: string | null = null;
      for (const standardId of new Set(candidates)) {
        const found = await tx.standardClause.findMany({
          where: { standardId, kind: 'requirement' },
          orderBy: { code: 'asc' },
          take: 120,
          select: { id: true, code: true, title: true },
        });
        if (found.length) {
          clauses = found;
          usedStandard = standardId;
          break;
        }
      }
      if (!clauses.length) {
        throw new NotFoundException('Ninguna norma activa tiene requisitos cargados');
      }
      if (!audit.standardId && usedStandard) {
        await tx.audit.update({ where: { id: auditId }, data: { standardId: usedStandard } });
      }

      const existing = await tx.auditChecklist.findFirst({ where: { orgId, auditId } });
      const checklist =
        existing ??
        (await tx.auditChecklist.create({
          data: { orgId, auditId, title: `Checklist ${audit.title}` },
        }));

      // Solo se agregan los requisitos que aún no tienen pregunta en esta lista.
      const current = await tx.checklistItem.findMany({
        where: { checklistId: checklist.id },
        select: { clauseId: true },
      });
      const already = new Set(current.map((c) => c.clauseId));
      const missing = clauses.filter((c) => !already.has(c.id));
      if (missing.length) {
        await tx.checklistItem.createMany({
          data: missing.map((c) => ({
            orgId,
            checklistId: checklist.id,
            clauseId: c.id,
            question: `¿Se cumple ${c.code}${c.title ? ` — ${c.title}` : ''}?`,
          })),
        });
      }
      return tx.auditChecklist.findUnique({
        where: { id: checklist.id },
        include: { items: { include: { clause: true }, orderBy: { createdAt: 'asc' } } },
      });
    });
  }

  /** Cierra la auditoría (COMPLETED) validando que el checklist esté contestado. */
  async close(orgId: string, user: AuthUser, auditId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const audit = await tx.audit.findUnique({
        where: { id: auditId },
        include: { checklists: { include: { items: true } } },
      });
      if (!audit || audit.orgId !== orgId) throw new NotFoundException('Auditoría no encontrada');

      const items = audit.checklists.flatMap((c) => c.items);
      const pending = items.filter((i) => !i.result).length;
      if (pending > 0) {
        throw new BadRequestException(
          `Faltan ${pending} ítem(s) de la lista de verificación sin resultado`,
        );
      }
      await tx.auditChecklist.updateMany({
        where: { orgId, auditId },
        data: { status: 'COMPLETED' },
      });
      return tx.audit.update({
        where: { id: auditId },
        data: { status: 'COMPLETED', endDate: audit.endDate ?? new Date() },
        include: { findings: true, checklists: { include: { items: true } } },
      });
    });
  }

  /** Actualiza un hallazgo (atención / cierre). */
  async updateFinding(
    orgId: string,
    user: AuthUser,
    findingId: string,
    data: { status?: string; description?: string; classification?: string; type?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const finding = await tx.finding.findUnique({ where: { id: findingId } });
      if (!finding || finding.orgId !== orgId) throw new NotFoundException('Hallazgo no encontrado');
      return tx.finding.update({ where: { id: findingId }, data });
    });
  }

  async deleteFinding(orgId: string, user: AuthUser, findingId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const finding = await tx.finding.findUnique({ where: { id: findingId } });
      if (!finding || finding.orgId !== orgId) throw new NotFoundException('Hallazgo no encontrado');
      await tx.finding.delete({ where: { id: findingId } });
      return { ok: true, deleted: findingId };
    });
  }

  /** Elimina la auditoría completa (checklist y hallazgos incluidos). */
  async remove(orgId: string, user: AuthUser, auditId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findAudit(tx, orgId, auditId);
      await tx.audit.delete({ where: { id: auditId } });
      return { ok: true, deleted: auditId };
    });
  }

  /** Genera el informe de la auditoría (resumen agregado). */
  async report(orgId: string, user: AuthUser, auditId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const audit = await tx.audit.findUnique({
        where: { id: auditId },
        include: { findings: true, checklists: { include: { items: true } } },
      });
      if (!audit || audit.orgId !== orgId) throw new NotFoundException('Auditoría no encontrada');
      const byType: Record<string, number> = {};
      for (const f of audit.findings) byType[f.type] = (byType[f.type] ?? 0) + 1;
      const checklistDone = audit.checklists.flatMap((c) => c.items).filter((i) => i.result).length;
      const checklistTotal = audit.checklists.flatMap((c) => c.items).length;
      return {
        audit: { id: audit.id, title: audit.title, status: audit.status, dates: [audit.startDate, audit.endDate] },
        findings: audit.findings,
        byType,
        checklistProgress: checklistTotal ? Math.round((checklistDone / checklistTotal) * 100) : 0,
      };
    });
  }

  private async findAudit(
    tx: { audit: { findUnique: (a: { where: { id: string } }) => Promise<{ orgId: string; standardId: string | null; title: string; endDate: Date | null } | null> } },
    orgId: string,
    auditId: string,
  ) {
    const row = await tx.audit.findUnique({ where: { id: auditId } });
    if (!row || row.orgId !== orgId) throw new NotFoundException('Auditoría no encontrada');
    return row;
  }
}
