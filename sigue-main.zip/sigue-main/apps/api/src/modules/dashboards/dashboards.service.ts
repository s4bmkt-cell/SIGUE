import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';
import { aggregateCompliance } from './compliance';

@Injectable()
export class DashboardsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Resumen ejecutivo del sistema de gestión (para tableros y card). */
  async summary(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;

      // El cumplimiento se mide solo sobre las normas activas de la
      // organización: sumar el catálogo global inflaría el denominador con
      // normas que el cliente no ha adoptado.
      const active = await tx.orgStandard.findMany({
        where: { orgId, status: 'ACTIVE' },
        select: { standardId: true },
      });
      const standardIds = active.map((a) => a.standardId);

      const [totalReq, implementedReq, ncOpen, ncCritical, auditsUpcoming, plansActive, objectives] = await Promise.all([
        tx.standardClause.count({ where: { kind: 'requirement', standardId: { in: standardIds } } }),
        tx.requirementStatus.count({
          where: {
            orgId,
            level: { in: ['IMPLEMENTED', 'MATURE'] },
            clause: { standardId: { in: standardIds } },
          },
        }),
        tx.nc.count({ where: { orgId, status: { not: 'CLOSED' } } }),
        tx.nc.count({ where: { orgId, priority: 'ALTA', status: { not: 'CLOSED' } } }),
        tx.audit.count({ where: { orgId, status: { in: ['PLANNED', 'IN_PROGRESS'] } } }),
        tx.workPlan.count({ where: { orgId, status: 'ACTIVE' } }),
        tx.objective.count({ where: { orgId } }),
      ]);

      const compliancePct = totalReq ? Math.round((implementedReq / totalReq) * 100) : 0;
      const tasks = await tx.planTask.count({ where: { orgId, status: { not: 'DONE' } } });

      return {
        compliance: { pct: compliancePct, implemented: implementedReq, pending: totalReq - implementedReq, total: totalReq },
        nc: { open: ncOpen, critical: ncCritical },
        audits: { upcoming: auditsUpcoming },
        plans: { active: plansActive, pendingTasks: tasks },
        objectives: { total: objectives },
      };
    });
  }

  /**
   * Cumplimiento por cláusula (para el tablero de barras).
   *
   * Devuelve una fila por norma y cláusula: con cuatro normas activas, códigos
   * como "4.1" existen en ISO 9001, 27001 y 42001, y agregarlos por código
   * mezclaría requisitos de estándares distintos en una sola barra.
   */
  async complianceByClause(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const active = await tx.orgStandard.findMany({
        where: { orgId, status: 'ACTIVE' },
        select: { standard: { select: { code: true } } },
      });
      const activeCodes = active.map((a) => a.standard.code);
      const clauses = await tx.standardClause.findMany({
        where: { kind: 'requirement', standard: { code: { in: activeCodes } } },
        orderBy: [{ sortOrder: 'asc' }],
        select: { id: true, code: true, standard: { select: { code: true } } },
      });
      const statuses = await tx.requirementStatus.findMany({ where: { orgId } });
      const statusByClause = new Map(statuses.map((s) => [s.clauseId, s.level]));

      return aggregateCompliance(
        clauses.map((c) => ({ id: c.id, code: c.code, standardCode: c.standard.code })),
        statusByClause,
      );
    });
  }
}
