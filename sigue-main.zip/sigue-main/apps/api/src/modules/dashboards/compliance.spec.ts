import { aggregateCompliance, type ComplianceClause } from './compliance';

function clause(id: string, code: string, standardCode: string): ComplianceClause {
  return { id, code, standardCode };
}

describe('aggregateCompliance — cálculo de cumplimiento por norma y cláusula', () => {
  it('separa el mismo código de cláusula en normas distintas', () => {
    const clauses = [clause('c1', '4.1', 'ISO9001'), clause('c2', '4.1', 'ISO27001')];
    const rows = aggregateCompliance(clauses, new Map([['c1', 'IMPLEMENTED']]));

    expect(rows).toHaveLength(2);
    expect(rows[0]).toMatchObject({ standard: 'ISO9001', code: '4.1', count: 1, implemented: 1, pct: 100 });
    expect(rows[1]).toMatchObject({ standard: 'ISO27001', code: '4.1', count: 1, implemented: 0, pct: 0 });
  });

  it('solo IMPLEMENTED y MATURE cuentan como implementados', () => {
    const clauses = [
      clause('c1', '5.2', 'ISO9001'),
      clause('c2', '5.2', 'ISO9001'),
      clause('c3', '5.2', 'ISO9001'),
      clause('c4', '5.2', 'ISO9001'),
    ];
    const levels = new Map([
      ['c1', 'NOT_IMPLEMENTED'],
      ['c2', 'PARTIAL'],
      ['c3', 'IMPLEMENTED'],
      ['c4', 'MATURE'],
    ]);

    const [row] = aggregateCompliance(clauses, levels);
    expect(row).toMatchObject({ count: 4, implemented: 2, pct: 50 });
  });

  it('redondea el porcentaje al entero más cercano', () => {
    const clauses = [
      clause('c1', '6.1', 'ISO22301'),
      clause('c2', '6.1', 'ISO22301'),
      clause('c3', '6.1', 'ISO22301'),
    ];
    const rows = aggregateCompliance(clauses, new Map([['c1', 'IMPLEMENTED']]));

    expect(rows[0].pct).toBe(33);
  });

  it('deja en 0% una cláusula sin estados registrados', () => {
    const rows = aggregateCompliance([clause('c1', '7.5', 'ISO42001')], new Map());

    expect(rows[0]).toMatchObject({ count: 1, implemented: 0, pct: 0 });
  });

  it('ordena las normas según el catálogo y las cláusulas de forma numérica', () => {
    const clauses = [
      clause('a', '4.10', 'ISO42001'),
      clause('b', '4.2', 'ISO42001'),
      clause('c', '10.1', 'ISO22301'),
      clause('d', '4.1', 'ISO27001'),
      clause('e', '4.1', 'ISO9001'),
    ];

    const rows = aggregateCompliance(clauses, new Map());

    expect(rows.map((r) => `${r.standard} ${r.code}`)).toEqual([
      'ISO9001 4.1',
      'ISO27001 4.1',
      'ISO22301 10.1',
      'ISO42001 4.2',
      'ISO42001 4.10',
    ]);
  });
});
