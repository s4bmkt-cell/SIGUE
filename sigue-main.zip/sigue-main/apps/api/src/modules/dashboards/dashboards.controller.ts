import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { DashboardsService } from './dashboards.service';

@ApiTags('dashboards')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/dashboard', version: '1' })
export class DashboardsController {
  constructor(private readonly dashboards: DashboardsService) {}

  @ApiEndpoint('Indicadores del tablero de inicio', { status: 200, tenant: true })
  @Get('summary')
  summary(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.dashboards.summary(orgId, user);
  }

  @ApiEndpoint('Avance por cláusula y norma', { status: 200, tenant: true })
  @Get('compliance')
  compliance(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.dashboards.complianceByClause(orgId, user);
  }
}
