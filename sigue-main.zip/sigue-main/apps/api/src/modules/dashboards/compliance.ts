/** Fila de cumplimiento por norma y cláusula. */
export interface ComplianceRow {
  standard: string;
  code: string;
  count: number;
  implemented: number;
  pct: number;
}

/** Cláusula mínima para agregar el cumplimiento (sin dependencias de Prisma). */
export interface ComplianceClause {
  id: string;
  code: string;
  standardCode: string;
}

/** Peso de cada nivel; solo los niveles completos cuentan como implementados. */
const COMPLETE_LEVELS = new Set(['IMPLEMENTED', 'MATURE']);

/** Las normas se ordenan como el catálogo, no alfabéticamente. */
const STANDARD_ORDER = ['ISO9001', 'ISO27001', 'ISO22301', 'ISO20000', 'ISO37001', 'ISO42001'];

/**
 * Agrega los requisitos por norma + código de cláusula.
 *
 * Con varias normas activas el mismo código ("4.1") existe en ISO 9001, 27001
 * y 42001: agrupar solo por código mezclaría requisitos de estándares distintos
 * en una sola barra, así que la clave es la pareja norma + cláusula.
 */
export function aggregateCompliance(
  clauses: ComplianceClause[],
  levelByClauseId: ReadonlyMap<string, string>,
): ComplianceRow[] {
  const rows: ComplianceRow[] = [];
  const index = new Map<string, ComplianceRow>();

  for (const clause of clauses) {
    const key = `${clause.standardCode}|${clause.code}`;
    let row = index.get(key);
    if (!row) {
      row = { standard: clause.standardCode, code: clause.code, count: 0, implemented: 0, pct: 0 };
      index.set(key, row);
      rows.push(row);
    }
    row.count += 1;
    if (COMPLETE_LEVELS.has(levelByClauseId.get(clause.id) ?? '')) row.implemented += 1;
  }

  for (const row of rows) {
    row.pct = row.count ? Math.round((row.implemented / row.count) * 100) : 0;
  }

  return rows.sort(
    (a, b) =>
      orderOf(a.standard) - orderOf(b.standard) ||
      a.code.localeCompare(b.code, undefined, { numeric: true }),
  );
}

function orderOf(standard: string) {
  const index = STANDARD_ORDER.indexOf(standard);
  return index === -1 ? STANDARD_ORDER.length : index;
}
