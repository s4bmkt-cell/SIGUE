import { Controller, Get } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { Public } from '../../common/decorators/public.decorator';

@ApiTags('health')
@Public()
@Controller({
  path: 'health',
  version: '1',
})
export class HealthController {
  @ApiEndpoint('Estado de la API', { status: 200, tenant: false, auth: false })
  @Get()
  check() {
    return {
      status: 'ok',
      service: 'sigue-api',
      time: new Date().toISOString(),
    };
  }
}
