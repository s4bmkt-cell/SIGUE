import { Module } from '@nestjs/common';
import { AbmsController } from './abms.controller';
import { AbmsService } from './abms.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [TenancyModule, AuthSharedModule],
  controllers: [AbmsController],
  providers: [AbmsService],
})
export class AbmsModule {}
