import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import { AbmsService } from './abms.service';

@ApiTags('abms')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/abms', version: '1' })
export class AbmsController {
  constructor(private readonly abms: AbmsService) {}

  @ApiEndpoint('Panorama del SGAS: riesgos, controles e incidentes', { status: 200, tenant: true })
  @Get()
  overview(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.abms.overview(orgId, user);
  }

  // ===== Riesgo de soborno (ISO 37001 · 4.5 y 6.1) =====
  @Audit('abms.add_risk')
  @ApiEndpoint('Registra una evaluación de riesgo de soborno', { status: 201, tenant: true })
  @Post('risks')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addRisk(
    @Param('orgId') orgId: string,
    @Body() data: { area: string; activity: string; likelihood: number; impact: number; mitigation?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.abms.addRisk(orgId, user, data);
  }

  @Audit('abms.update_risk')
  @ApiEndpoint('Actualiza una evaluación de riesgo de soborno', { status: 200, tenant: true, errors: ['notFound'] })
  @Patch('risks/:riskId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateRisk(
    @Param('orgId') orgId: string,
    @Param('riskId') riskId: string,
    @Body()
    data: { area?: string; activity?: string; likelihood?: number; impact?: number; mitigation?: string | null; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.abms.updateRisk(orgId, user, riskId, data);
  }

  @Audit('abms.delete_risk')
  @ApiEndpoint('Elimina una evaluación de riesgo de soborno', { status: 200, tenant: true, errors: ['notFound'] })
  @Delete('risks/:riskId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteRisk(@Param('orgId') orgId: string, @Param('riskId') riskId: string, @CurrentUser() user: AuthUser) {
    return this.abms.deleteRisk(orgId, user, riskId);
  }

  // ===== Controles antisoborno (ISO 37001 · cláusula 8) =====
  @Audit('abms.upsert_control')
  @ApiEndpoint('Registra o actualiza un control antisoborno', { status: 201, tenant: true })
  @Post('controls')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  upsertControl(
    @Param('orgId') orgId: string,
    @Body() data: { code: string; title: string; description?: string; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.abms.upsertControl(orgId, user, data);
  }

  @Audit('abms.update_control')
  @ApiEndpoint('Cambia el estado de un control antisoborno', { status: 200, tenant: true, errors: ['notFound'] })
  @Patch('controls/:controlId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateControl(
    @Param('orgId') orgId: string,
    @Param('controlId') controlId: string,
    @Body() data: { status?: string; description?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.abms.updateControl(orgId, user, controlId, data);
  }

  @Audit('abms.delete_control')
  @ApiEndpoint('Elimina un control antisoborno', { status: 200, tenant: true, errors: ['notFound'] })
  @Delete('controls/:controlId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteControl(@Param('orgId') orgId: string, @Param('controlId') controlId: string, @CurrentUser() user: AuthUser) {
    return this.abms.deleteControl(orgId, user, controlId);
  }

  // ===== Incidentes e investigaciones (ISO 37001 · 8.9 y 8.10) =====
  @Audit('abms.add_incident')
  @ApiEndpoint('Registra una sospecha o incidente de soborno', { status: 201, tenant: true })
  @Post('incidents')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addIncident(
    @Param('orgId') orgId: string,
    @Body() data: { title: string; description?: string; severity?: string; detectedAt?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.abms.addIncident(orgId, user, data);
  }

  @Audit('abms.update_incident')
  @ApiEndpoint('Actualiza la investigación de un incidente', { status: 200, tenant: true, errors: ['notFound', 'conflict'] })
  @Patch('incidents/:incidentId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateIncident(
    @Param('orgId') orgId: string,
    @Param('incidentId') incidentId: string,
    @Body()
    data: { title?: string; description?: string | null; severity?: string; status?: string; resolution?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.abms.updateIncident(orgId, user, incidentId, data);
  }

  @Audit('abms.delete_incident')
  @ApiEndpoint('Elimina un incidente de soborno', { status: 200, tenant: true, errors: ['notFound'] })
  @Delete('incidents/:incidentId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteIncident(
    @Param('orgId') orgId: string,
    @Param('incidentId') incidentId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.abms.deleteIncident(orgId, user, incidentId);
  }
}
