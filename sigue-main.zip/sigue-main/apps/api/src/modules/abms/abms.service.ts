import { ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

/**
 * ISO 37001:2025 — Sistema de gestión antisoborno.
 *
 * Cubre la evaluación del riesgo de soborno (4.5 y 6.1), los controles
 * operativos de la cláusula 8 (diligencia debida, controles financieros y no
 * financieros, regalos, canal de denuncias) y la investigación de incidentes
 * (8.10).
 */
@Injectable()
export class AbmsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Vista completa del SGAS: riesgos, controles e incidentes. */
  async overview(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [risks, controls, incidents] = await Promise.all([
        tx.briberyRiskAssessment.findMany({ where: { orgId }, orderBy: { score: 'desc' } }),
        tx.briberyControl.findMany({ where: { orgId }, orderBy: { code: 'asc' } }),
        tx.briberyIncident.findMany({ where: { orgId }, orderBy: { detectedAt: 'desc' } }),
      ]);
      const highRisks = risks.filter((r) => r.score >= 15).length;
      const implemented = controls.filter((c) => c.status === 'IMPLEMENTED').length;
      const applicable = controls.filter((c) => c.status !== 'NOT_APPLICABLE').length;
      const openIncidents = incidents.filter((i) => i.status !== 'CLOSED').length;
      return {
        risks,
        controls,
        incidents,
        summary: {
          risks: risks.length,
          highRisks,
          controls: applicable,
          implemented,
          controlProgress: applicable ? Math.round((implemented / applicable) * 100) : 0,
          openIncidents,
        },
      };
    });
  }

  // ===== Evaluación del riesgo de soborno (4.5 / 6.1) =====
  async addRisk(
    orgId: string,
    user: AuthUser,
    data: { area: string; activity: string; likelihood: number; impact: number; mitigation?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.briberyRiskAssessment.create({
        data: {
          orgId,
          area: data.area,
          activity: data.activity,
          likelihood: data.likelihood,
          impact: data.impact,
          // El puntaje se deriva de probabilidad × impacto: así no hay dos
          // fuentes de verdad y la matriz de calor coincide con el registro.
          score: data.likelihood * data.impact,
          mitigation: data.mitigation,
        },
      });
    });
  }

  async updateRisk(
    orgId: string,
    user: AuthUser,
    riskId: string,
    data: { area?: string; activity?: string; likelihood?: number; impact?: number; mitigation?: string | null; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.briberyRiskAssessment.findUnique({ where: { id: riskId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Riesgo de soborno no encontrado');
      const likelihood = data.likelihood ?? row.likelihood;
      const impact = data.impact ?? row.impact;
      return tx.briberyRiskAssessment.update({
        where: { id: riskId },
        data: {
          ...(data.area !== undefined ? { area: data.area } : {}),
          ...(data.activity !== undefined ? { activity: data.activity } : {}),
          ...(data.likelihood !== undefined ? { likelihood: data.likelihood } : {}),
          ...(data.impact !== undefined ? { impact: data.impact } : {}),
          ...(data.likelihood !== undefined || data.impact !== undefined ? { score: likelihood * impact } : {}),
          ...(data.mitigation !== undefined ? { mitigation: data.mitigation } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
        },
      });
    });
  }

  async deleteRisk(orgId: string, user: AuthUser, riskId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.briberyRiskAssessment.findUnique({ where: { id: riskId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Riesgo de soborno no encontrado');
      await tx.briberyRiskAssessment.delete({ where: { id: riskId } });
      return { ok: true, deleted: riskId };
    });
  }

  // ===== Controles operativos (cláusula 8) =====
  async upsertControl(
    orgId: string,
    user: AuthUser,
    data: { code: string; title: string; description?: string; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.briberyControl.upsert({
        where: { orgId_code: { orgId, code: data.code } },
        update: {
          title: data.title,
          ...(data.description !== undefined ? { description: data.description } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
        },
        create: {
          orgId,
          code: data.code,
          title: data.title,
          description: data.description,
          status: data.status ?? 'PLANNED',
        },
      });
    });
  }

  /** Cambia el estado de un control: el avance del SGAS se calcula con esto. */
  async updateControl(orgId: string, user: AuthUser, controlId: string, data: { status?: string; description?: string | null }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.briberyControl.findUnique({ where: { id: controlId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Control antisoborno no encontrado');
      return tx.briberyControl.update({
        where: { id: controlId },
        data: {
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.description !== undefined ? { description: data.description } : {}),
        },
      });
    });
  }

  async deleteControl(orgId: string, user: AuthUser, controlId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.briberyControl.findUnique({ where: { id: controlId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Control antisoborno no encontrado');
      await tx.briberyControl.delete({ where: { id: controlId } });
      return { ok: true, deleted: controlId };
    });
  }

  // ===== Incidentes e investigaciones (8.9 / 8.10) =====
  async addIncident(
    orgId: string,
    user: AuthUser,
    data: { title: string; description?: string; severity?: string; detectedAt?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      return tx.briberyIncident.create({
        data: {
          orgId,
          title: data.title,
          description: data.description,
          severity: data.severity ?? 'MEDIA',
          detectedAt: data.detectedAt ? new Date(data.detectedAt) : new Date(),
          reportedById: user.sub,
        },
      });
    });
  }

  /**
   * Avanza la investigación. Cerrar exige resolución escrita: un incidente
   * cerrado sin conclusión no sirve como evidencia de la cláusula 8.10.
   */
  async updateIncident(
    orgId: string,
    user: AuthUser,
    incidentId: string,
    data: { title?: string; description?: string | null; severity?: string; status?: string; resolution?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.briberyIncident.findUnique({ where: { id: incidentId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Incidente de soborno no encontrado');
      const resolution = data.resolution !== undefined ? data.resolution : row.resolution;
      if (data.status === 'CLOSED' && !resolution?.trim()) {
        throw new ConflictException('Para cerrar el incidente se requiere una resolución');
      }
      return tx.briberyIncident.update({
        where: { id: incidentId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.description !== undefined ? { description: data.description } : {}),
          ...(data.severity !== undefined ? { severity: data.severity } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.resolution !== undefined ? { resolution: data.resolution } : {}),
        },
      });
    });
  }

  async deleteIncident(orgId: string, user: AuthUser, incidentId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.briberyIncident.findUnique({ where: { id: incidentId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Incidente de soborno no encontrado');
      await tx.briberyIncident.delete({ where: { id: incidentId } });
      return { ok: true, deleted: incidentId };
    });
  }
}
