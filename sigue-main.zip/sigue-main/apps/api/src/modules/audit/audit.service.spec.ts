import { Prisma, PrismaClient } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { AuditService, sanitize } from './audit.service';
import {
  GENESIS_HASH,
  canonicalJson,
  chainKeyFor,
  eventPayload,
  verifyChain,
} from './audit-hash';
import { createHash } from 'crypto';

describe('Auditoría — serialización canónica', () => {
  it('el orden de las claves no cambia el hash', () => {
    expect(canonicalJson({ b: 1, a: 2 })).toBe(canonicalJson({ a: 2, b: 1 }));
  });

  it('normaliza objetos anidados y arreglos', () => {
    expect(canonicalJson({ z: [{ y: 1, x: 2 }] })).toBe('{"z":[{"x":2,"y":1}]}');
  });

  it('trata null y undefined como el mismo valor nulo', () => {
    expect(canonicalJson(null)).toBe(canonicalJson(undefined));
  });

  it('redacta credenciales antes de persistirlas', () => {
    expect(sanitize({ email: 'a@b.mx', password: 'secreto', nested: { refreshToken: 'x' } })).toEqual({
      email: 'a@b.mx',
      password: '[redactado]',
      nested: { refreshToken: '[redactado]' },
    });
  });

  it('guarda los Decimal como número y no como objeto con constructor', () => {
    // Un `Decimal` de Prisma expone un `constructor` propio al recorrer sus
    // propiedades: si se serializara por reflexión, el hash dejaría de poder
    // recalcularse al leer el evento desde la base.
    const result = sanitize({ kpi: { target: new Prisma.Decimal(95) } });
    expect(result).toEqual({ kpi: { target: 95 } });
    expect(canonicalJson(result)).not.toContain('constructor');
  });

  it('los valores no serializables no se cuelan en el hash', () => {
    class Monto {
      constructor(readonly valor: number) {}
    }
    expect(sanitize({ monto: new Monto(10), fn: () => 1 })).toEqual({
      monto: { valor: 10 },
      fn: '[función]',
    });
  });

  it('asigna una cadena por organización y otra por usuario', () => {
    expect(chainKeyFor('org-a', 'u1')).toBe('org:org-a');
    expect(chainKeyFor(null, 'u1')).toBe('user:u1');
    expect(chainKeyFor(null, null)).toBe('anonymous');
  });
});

describe('Auditoría — verificación de cadena', () => {
  const hashOf = (event: Parameters<typeof eventPayload>[0], prevHash: string) =>
    createHash('sha256').update(prevHash + canonicalJson(eventPayload(event))).digest('hex');

  const base = {
    chainKey: 'org:a',
    orgId: 'a',
    actorId: 'u1',
    action: 'nc.create',
    entity: 'nc',
    entityId: 'nc-1',
    before: null,
    after: { id: 'nc-1' },
    ip: '127.0.0.1',
    userAgent: 'jest',
    at: '2026-01-01T00:00:00.000Z',
  };

  function chain(length: number) {
    const events = [];
    let prevHash = GENESIS_HASH;
    for (let seq = 1; seq <= length; seq += 1) {
      const partial = { ...base, id: `e${seq}`, seq };
      const hash = hashOf(partial, prevHash);
      events.push({ ...partial, prevHash, hash });
      prevHash = hash;
    }
    return events;
  }

  const verify = (e: (ReturnType<typeof chain>[number])) => hashOf(e, e.prevHash);

  it('acepta una cadena intacta', async () => {
    await expect(verifyChain(chain(3), verify)).resolves.toEqual({ intact: true, count: 3 });
  });

  it('detecta un evento eliminado', async () => {
    const events = chain(3);
    events.splice(1, 1);
    const verdict = await verifyChain(events, verify);
    expect(verdict.intact).toBe(false);
    expect(verdict.brokenAt).toBe(2);
  });

  it('detecta contenido alterado', async () => {
    const events = chain(2);
    events[1].action = 'nc.delete';
    const verdict = await verifyChain(events, verify);
    expect(verdict.intact).toBe(false);
    expect(verdict.brokenAt).toBe(2);
  });
});

/**
 * Pruebas contra PostgreSQL real: escritura concurrente, numeración de la cadena
 * y bloqueo de modificación. Se omiten si no hay `TEST_DATABASE_URL`.
 */
const url = process.env.TEST_DATABASE_URL;
const describeDb = url ? describe : describe.skip;

describeDb('Auditoría — persistencia (PostgreSQL)', () => {
  let prisma: PrismaService;
  let svc: AuditService;
  // Cadena propia: las pruebas no deben contaminar la bitácora de una
  // organización real. El aislamiento solo exige que `app.org_id` coincida con
  // el `orgId` del evento, no que la organización exista.
  const orgId = 'org-audit-test';
  const actorId = 'u-audit-test';

  beforeAll(async () => {
    prisma = new PrismaClient({ datasourceUrl: url }) as unknown as PrismaService;
    await prisma.$connect();
    svc = new AuditService(prisma);
  });

  afterAll(async () => {
    await prisma.$disconnect();
  });

  it('numera la cadena por organización y verifica su integridad', async () => {
    const first = await svc.recordOrThrow({
      orgId,
      actorId,
      action: 'test.audit.first',
      entity: 'test',
      after: { n: 1 },
    });
    const second = await svc.recordOrThrow({
      orgId,
      actorId,
      action: 'test.audit.second',
      entity: 'test',
      after: { n: 2 },
    });

    expect(second.seq).toBe(first.seq + 1);
    expect(second.prevHash).toBe(first.hash);
    expect(second.chainKey).toBe(`org:${orgId}`);

    await expect(svc.verify(orgId)).resolves.toMatchObject({ intact: true });
  });

  it('serializa escrituras concurrentes sin romper la cadena', async () => {
    await Promise.all(
      Array.from({ length: 8 }, (_, i) =>
        svc.recordOrThrow({
          orgId,
          actorId,
          action: `test.audit.concurrent.${i}`,
          entity: 'test',
        }),
      ),
    );

    const rows = await prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.auditLog.findMany({
        where: { chainKey: `org:${orgId}` },
        orderBy: { seq: 'asc' },
        select: { seq: true },
      });
    });

    // Sin huecos ni duplicados: cada posición aparece exactamente una vez.
    expect(rows.map((r) => r.seq)).toEqual(Array.from({ length: rows.length }, (_, i) => i + 1));
    await expect(svc.verify(orgId)).resolves.toMatchObject({ intact: true });
  });

  it('la bitácora rechaza modificaciones directas', async () => {
    const event = await svc.recordOrThrow({
      orgId,
      actorId,
      action: 'test.audit.immutable',
      entity: 'test',
    });

    // Dos capas: el rol de aplicación no tiene UPDATE sobre AuditLog y, aun con
    // permiso (rol dueño), el trigger append-only lo impide. El mensaje del
    // servidor llega en el idioma con el que se inicializó el clúster, así que
    // se comprueban ambos: el local (español) y el de CI (inglés).
    await expect(
      prisma.$executeRawUnsafe(
        `UPDATE "AuditLog" SET "action" = 'alterado' WHERE "id" = '${event.id}'`,
      ),
    ).rejects.toThrow(/permiso denegado|permission denied|append-only/);

    const owner = new PrismaClient({
      datasourceUrl: process.env.DIRECT_URL ?? process.env.DATABASE_URL,
    });
    try {
      await expect(
        owner.$executeRawUnsafe(
          `UPDATE "AuditLog" SET "action" = 'alterado' WHERE "id" = '${event.id}'`,
        ),
      ).rejects.toThrow(/append-only/);
    } finally {
      await owner.$disconnect();
    }
  });

  it('no expone eventos de otra organización', async () => {
    const page = await svc.list({ orgId, pageSize: 200 });
    expect(page.items.every((e) => e.orgId === orgId)).toBe(true);
  });
});
