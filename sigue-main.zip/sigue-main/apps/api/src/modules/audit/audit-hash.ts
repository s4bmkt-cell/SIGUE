/**
 * Primitivas de integridad de la bitácora.
 *
 * Cada evento se encadena con el hash del anterior **dentro de su cadena**
 * (una por organización, una por usuario para los eventos de identidad).
 * La serialización es canónica: las claves se ordenan, de modo que el mismo
 * contenido produce siempre el mismo hash sin depender del orden de las
 * propiedades en JavaScript.
 */

export const GENESIS_HASH = 'GENESIS';

export interface ChainableEvent {
  id: string;
  chainKey: string;
  seq: number;
  orgId: string | null;
  actorId: string | null;
  action: string;
  entity: string | null;
  entityId: string | null;
  before: unknown;
  after: unknown;
  ip: string | null;
  userAgent: string | null;
  at: string;
  prevHash: string;
  hash: string;
}

/** JSON con claves ordenadas recursivamente. */
export function canonicalJson(value: unknown): string {
  if (value === null || value === undefined) return 'null';
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  if (typeof value === 'string') return JSON.stringify(value);
  if (value instanceof Date) return JSON.stringify(value.toISOString());
  if (Array.isArray(value)) return `[${value.map(canonicalJson).join(',')}]`;
  if (typeof value === 'object') {
    const entries = Object.entries(value as Record<string, unknown>)
      .filter(([, v]) => v !== undefined)
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0))
      .map(([k, v]) => `${JSON.stringify(k)}:${canonicalJson(v)}`);
    return `{${entries.join(',')}}`;
  }
  return JSON.stringify(String(value));
}

/** Campo del evento que se firma: todo lo auditable, sin el hash ni su predecesor. */
export function eventPayload(event: Omit<ChainableEvent, 'prevHash' | 'hash'>) {
  return {
    id: event.id,
    chainKey: event.chainKey,
    seq: event.seq,
    orgId: event.orgId,
    actorId: event.actorId,
    action: event.action,
    entity: event.entity,
    entityId: event.entityId,
    before: event.before ?? null,
    after: event.after ?? null,
    ip: event.ip,
    userAgent: event.userAgent,
    at: event.at,
  };
}

/** Cadena de integridad a la que pertenece un evento. */
export function chainKeyFor(orgId: string | null | undefined, actorId: string | null | undefined): string {
  if (orgId) return `org:${orgId}`;
  if (actorId) return `user:${actorId}`;
  return 'anonymous';
}

export interface ChainVerdict {
  intact: boolean;
  count: number;
  /** Posición del primer evento inválido (1-based), si la cadena está rota. */
  brokenAt?: number;
  reason?: string;
}

/**
 * Verifica una cadena completa: continuidad de `prevHash`, numeración de `seq`
 * y correspondencia del hash recalculado con el almacenado.
 */
export async function verifyChain(
  events: ChainableEvent[],
  verify: (event: ChainableEvent) => Promise<string> | string,
): Promise<ChainVerdict> {
  let prev = GENESIS_HASH;
  let expectedSeq = 1;

  for (const event of events) {
    if (event.prevHash !== prev) {
      return { intact: false, count: events.length, brokenAt: expectedSeq, reason: 'prevHash no coincide con el evento anterior' };
    }
    if (event.seq !== expectedSeq) {
      return { intact: false, count: events.length, brokenAt: expectedSeq, reason: `falta el evento ${expectedSeq}` };
    }
    const expected = await verify(event);
    if (expected !== event.hash) {
      return { intact: false, count: events.length, brokenAt: event.seq, reason: 'el contenido no coincide con el hash almacenado' };
    }
    prev = event.hash;
    expectedSeq += 1;
  }
  return { intact: true, count: events.length };
}
