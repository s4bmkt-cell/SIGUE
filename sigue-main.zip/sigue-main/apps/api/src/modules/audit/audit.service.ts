import { createHash, randomUUID } from 'crypto';
import { Injectable, Logger } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { withTenant } from '../../tenancy/with-tenant';
import {
  ChainableEvent,
  ChainVerdict,
  GENESIS_HASH,
  canonicalJson,
  chainKeyFor,
  eventPayload,
  verifyChain,
} from './audit-hash';

export interface AuditInput {
  orgId?: string | null;
  actorId?: string | null;
  action: string;
  entity?: string | null;
  entityId?: string | null;
  before?: unknown;
  after?: unknown;
  ip?: string | null;
  userAgent?: string | null;
}

export interface AuditRecord {
  id: string;
  orgId: string | null;
  actorId: string | null;
  action: string;
  entity: string | null;
  entityId: string | null;
  before: unknown;
  after: unknown;
  ip: string | null;
  userAgent: string | null;
  chainKey: string;
  seq: number;
  prevHash: string;
  hash: string;
  createdAt: string;
}

export interface AuditQuery {
  orgId: string;
  actorId?: string;
  action?: string;
  entity?: string;
  entityId?: string;
  from?: Date;
  to?: Date;
  page?: number;
  pageSize?: number;
}

/** Campos que nunca deben quedar escritos en la bitácora. */
const REDACTED = /password|secret|token|authorization|code|otp/i;

/**
 * Bitácora de auditoría persistida en PostgreSQL.
 *
 * Cada escritura ocurre en una transacción que:
 *  1. toma `pg_advisory_xact_lock` sobre la cadena, serializando las escrituras
 *     concurrentes de la misma organización;
 *  2. lee la cabeza de la cadena (`AuditChain`) y avanza `seq`;
 *  3. calcula `hash = sha256(prevHash + canon(evento))`;
 *  4. inserta el evento y actualiza la cabeza.
 *
 * Si el evento no pertenece a ninguna organización (login, recuperación), la
 * cadena es la del usuario. La tabla `AuditLog` tiene un trigger que impide
 * `UPDATE` y `DELETE`: corregir un evento exige romper la cadena, que es
 * precisamente lo que `verify()` detecta.
 */
@Injectable()
export class AuditService {
  private readonly logger = new Logger('Audit');

  constructor(private readonly prisma: PrismaService) {}

  /**
   * Escribe un evento. Un fallo de auditoría **no** debe tumbar la operación de
   * negocio que lo produjo: se registra el error y se devuelve `null`. Para los
   * flujos donde la bitácora es parte del contrato (verificación de integridad)
   * existe `recordOrThrow`.
   */
  async record(input: AuditInput): Promise<AuditRecord | null> {
    try {
      return await this.recordOrThrow(input);
    } catch (error) {
      this.logger.error(
        `No se pudo escribir la auditoría "${input.action}": ${(error as Error).message}`,
      );
      return null;
    }
  }

  async recordOrThrow(input: AuditInput): Promise<AuditRecord> {
    const orgId = input.orgId ?? null;
    const actorId = input.actorId ?? null;
    const chainKey = chainKeyFor(orgId, actorId);
    const id = randomUUID();
    const at = new Date();

    const event = await withTenant(this.prisma, { orgId, userId: actorId }, async (tx) => {
      // Serializa las escrituras de esta cadena. El bloqueo se libera al
      // confirmar/abortar la transacción.
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${chainKey})::bigint)`;

      const headRows = await tx.$queryRaw<{ lastHash: string; lastSeq: number }[]>`
        INSERT INTO "AuditChain" ("chainKey", "lastHash", "lastSeq", "updatedAt")
        VALUES (${chainKey}, ${GENESIS_HASH}, 0, now())
        ON CONFLICT ("chainKey") DO UPDATE
          SET "lastSeq" = "AuditChain"."lastSeq"
        RETURNING "lastHash", "lastSeq"
      `;
      const head = headRows[0];

      const seq = head.lastSeq + 1;
      const payload = eventPayload({
        id,
        chainKey,
        seq,
        orgId,
        actorId,
        action: input.action,
        entity: input.entity ?? null,
        entityId: input.entityId ?? null,
        before: sanitize(input.before),
        after: sanitize(input.after),
        ip: input.ip ?? null,
        userAgent: input.userAgent ?? null,
        at: at.toISOString(),
      });
      const prevHash = head.lastHash;
      const hash = createHash('sha256').update(prevHash + canonicalJson(payload)).digest('hex');

      const before = sanitize(input.before);
      const after = sanitize(input.after);
      const ip = input.ip ?? null;
      const userAgent = input.userAgent ?? null;

      // `INSERT ... RETURNING` devuelve el registro recién creado, y eso exige
      // que la política de lectura lo permita. Un evento anónimo (login fallido
      // con correo inexistente) no es legible por diseño, así que se inserta
      // sin RETURNING y el resultado se arma en memoria.
      await tx.$executeRaw`
        INSERT INTO "AuditLog"
          ("id", "orgId", "actorId", "action", "entity", "entityId", "before", "after",
           "ip", "userAgent", "chainKey", "seq", "prevHash", "hash", "createdAt")
        VALUES (
          ${id}, ${orgId}, ${actorId}, ${input.action}, ${input.entity ?? null},
          ${input.entityId ?? null}, ${jsonParam(before)}, ${jsonParam(after)},
          ${ip}, ${userAgent}, ${chainKey}, ${seq}, ${prevHash}, ${hash}, ${at}
        )
      `;

      await tx.auditChain.update({
        where: { chainKey },
        data: { lastHash: hash, lastSeq: seq },
      });

      return {
        id,
        orgId,
        actorId,
        action: input.action,
        entity: input.entity ?? null,
        entityId: input.entityId ?? null,
        before,
        after,
        ip,
        userAgent,
        chainKey,
        seq,
        prevHash,
        hash,
        createdAt: at.toISOString(),
      } satisfies AuditRecord;
    });

    return event;
  }

  /** Página de eventos de una organización, más recientes primero. */
  async list(query: AuditQuery) {
    const page = Math.max(1, query.page ?? 1);
    const pageSize = Math.min(200, Math.max(1, query.pageSize ?? 50));

    const where: Prisma.AuditLogWhereInput = {
      // La política RLS ya limita al tenant activo; el filtro explícito evita
      // depender solo de ella.
      orgId: query.orgId,
      ...(query.actorId ? { actorId: query.actorId } : {}),
      ...(query.action ? { action: { startsWith: query.action } } : {}),
      ...(query.entity ? { entity: query.entity } : {}),
      ...(query.entityId ? { entityId: query.entityId } : {}),
      ...(query.from || query.to
        ? {
            createdAt: {
              ...(query.from ? { gte: query.from } : {}),
              ...(query.to ? { lte: query.to } : {}),
            },
          }
        : {}),
    };

    const [items, total] = await withTenant(
      this.prisma,
      { orgId: query.orgId },
      (tx) =>
        Promise.all([
          tx.auditLog.findMany({
            where,
            orderBy: { createdAt: 'desc' },
            skip: (page - 1) * pageSize,
            take: pageSize,
          }),
          tx.auditLog.count({ where }),
        ]),
    );

    return {
      items: items.map(toRecord),
      page,
      pageSize,
      total,
      pages: Math.ceil(total / pageSize),
    };
  }

  /**
   * Verifica la cadena de la organización recorriéndola completa, en orden de
   * `seq`. Devuelve la posición exacta del primer evento manipulado.
   */
  async verify(orgId: string): Promise<ChainVerdict> {
    const events = await withTenant(this.prisma, { orgId }, (tx) =>
      tx.auditLog.findMany({
        where: { chainKey: `org:${orgId}` },
        orderBy: { seq: 'asc' },
      }),
    );

    return verifyChain(events.map(toChainable), (event) =>
      createHash('sha256')
        .update(
          event.prevHash +
            canonicalJson(
              eventPayload({
                id: event.id,
                chainKey: event.chainKey,
                seq: event.seq,
                orgId: event.orgId,
                actorId: event.actorId,
                action: event.action,
                entity: event.entity,
                entityId: event.entityId,
                before: event.before,
                after: event.after,
                ip: event.ip,
                userAgent: event.userAgent,
                at: event.at,
              }),
            ),
        )
        .digest('hex'),
    );
  }
}

function toChainable(row: Prisma.AuditLogGetPayload<object>): ChainableEvent {
  return {
    id: row.id,
    chainKey: row.chainKey,
    seq: row.seq,
    orgId: row.orgId,
    actorId: row.actorId,
    action: row.action,
    entity: row.entity,
    entityId: row.entityId,
    before: row.before,
    after: row.after,
    ip: row.ip,
    userAgent: row.userAgent,
    at: row.createdAt.toISOString(),
    prevHash: row.prevHash,
    hash: row.hash,
  };
}

function toRecord(row: Prisma.AuditLogGetPayload<object>): AuditRecord {
  return {
    id: row.id,
    orgId: row.orgId,
    actorId: row.actorId,
    action: row.action,
    entity: row.entity,
    entityId: row.entityId,
    before: row.before,
    after: row.after,
    ip: row.ip,
    userAgent: row.userAgent,
    chainKey: row.chainKey,
    seq: row.seq,
    prevHash: row.prevHash,
    hash: row.hash,
    createdAt: row.createdAt.toISOString(),
  };
}

/** Valor JSON para un parámetro SQL: `null` se envía como JSON `null`, no como SQL NULL. */
function jsonParam(value: unknown): Prisma.JsonValue {
  return (value === undefined ? null : value) as Prisma.JsonValue;
}

/** Deja el valor apto para JSON y borra credenciales antes de persistirlo. */
export function sanitize(value: unknown, depth = 0): unknown {
  if (value === undefined || value === null) return null;
  if (depth > 6) return '[profundidad máxima]';
  if (value instanceof Date) return value.toISOString();
  // Los `Decimal` de Prisma son objetos con un `constructor` propio: si se
  // serializan por reflexión, el hash incluye el código de esa función y deja
  // de poder recalcularse al leer el evento desde la base. Se guardan como
  // número, que es lo que representan.
  if (Prisma.Decimal.isDecimal(value)) return Number(value.toString());
  // Un binario (p. ej. un archivo de una evidencia) no aporta y es enorme.
  if (Buffer.isBuffer(value)) return `[binario ${value.byteLength} bytes]`;
  if (typeof value === 'function') return '[función]';
  if (Array.isArray(value)) {
    // Un listado completo no cabe (ni aporta) en la bitácora.
    const items = value.slice(0, 50).map((v) => sanitize(v, depth + 1));
    return value.length > 50 ? [...items, `[…${value.length - 50} más]`] : items;
  }
  if (typeof value === 'object') {
    // Solo se recorren las propiedades propias: los prototipos (Decimal, clases
    // de Prisma) no forman parte del dato.
    const out: Record<string, unknown> = {};
    for (const [key, v] of Object.entries(value as Record<string, unknown>)) {
      out[key] = REDACTED.test(key) ? '[redactado]' : sanitize(v, depth + 1);
    }
    return out;
  }
  if (typeof value === 'string' && value.length > 2000) return `${value.slice(0, 2000)}…`;
  return value;
}
