import { Controller, Get, Param, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { AuditService } from './audit.service';

@ApiTags('audit')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({
  path: 'orgs/:orgId/audit',
  version: '1',
})
export class AuditController {
  constructor(private readonly audit: AuditService) {}

  /**
   * La organización va en la ruta (no en un query param) para que el
   * `OrgMembershipGuard` global valide la membresía antes de llegar aquí: con
   * `?orgId=` el guard no tendría `:orgId` que comprobar.
   */
  @ApiEndpoint('Bitácora de auditoría paginada', { status: 200, tenant: true })
  @Get()
  @RequireRoles('admin_org', 'admin_global', 'auditor_interno', 'auditor_externo')
  list(
    @Param('orgId') orgId: string,
    @Query('actorId') actorId?: string,
    @Query('action') action?: string,
    @Query('entity') entity?: string,
    @Query('entityId') entityId?: string,
    @Query('from') from?: string,
    @Query('to') to?: string,
    @Query('page') page?: string,
    @Query('pageSize') pageSize?: string,
  ) {
    return this.audit.list({
      orgId,
      actorId,
      action,
      entity,
      entityId,
      from: from ? new Date(from) : undefined,
      to: to ? new Date(to) : undefined,
      page: page ? Number(page) : undefined,
      pageSize: pageSize ? Number(pageSize) : undefined,
    });
  }

  @ApiEndpoint('Verifica la integridad de la cadena de hashes', { status: 200, tenant: true })
  @Get('integrity')
  @RequireRoles('admin_org', 'admin_global', 'auditor_interno')
  integrity(@Param('orgId') orgId: string) {
    return this.audit.verify(orgId);
  }
}
