import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { NcService } from './nc.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('nc')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/nc', version: '1' })
export class NcController {
  constructor(private readonly nc: NcService) {}

  @ApiEndpoint('No conformidades de la organización', { status: 200, tenant: true })
  @Get()
  list(@Param('orgId') orgId: string, @Query('status') status: string | undefined, @CurrentUser() user: AuthUser) {
    return this.nc.list(orgId, user, status);
  }

  @Audit('nc.register')
  @ApiEndpoint('Registra una no conformidad con folio automático', { status: 201, tenant: true })
  @Post()
  @RequireRoles('colaborador', 'resp_proceso', 'resp_sgi', 'resp_norma', 'auditor_interno', 'admin_org')
  register(
    @Param('orgId') orgId: string,
    @Body() data: { title: string; description?: string; priority?: string; standardId?: string; clauseId?: string; classification?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.nc.register(orgId, user, data);
  }

  @Audit('nc.update')
  @ApiEndpoint('Actualiza una no conformidad', { status: 200, tenant: true })
  @Patch(':ncId')
  @RequireRoles('resp_proceso', 'resp_sgi', 'resp_norma', 'admin_org')
  update(
    @Param('orgId') orgId: string,
    @Param('ncId') ncId: string,
    @Body() data: { title?: string; description?: string | null; priority?: string; classification?: string; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.nc.update(orgId, user, ncId, data);
  }

  @Audit('nc.correction')
  @ApiEndpoint('Agrega una corrección inmediata', { status: 201, tenant: true })
  @Post(':ncId/corrections')
  @RequireRoles('resp_proceso', 'resp_accion', 'resp_sgi', 'resp_norma', 'admin_org')
  correction(@Param('orgId') orgId: string, @Param('ncId') ncId: string, @Body('description') description: string, @CurrentUser() user: AuthUser) {
    return this.nc.addCorrection(orgId, user, ncId, description);
  }

  @Audit('nc.root_cause')
  @ApiEndpoint('Registra el análisis de causa raíz', { status: 201, tenant: true })
  @Post(':ncId/root-causes')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_riesgos', 'admin_org')
  rootCause(@Param('orgId') orgId: string, @Param('ncId') ncId: string, @Body() data: { method?: string; causes?: string[]; analysis?: string }, @CurrentUser() user: AuthUser) {
    return this.nc.addRootCause(orgId, user, ncId, data);
  }

  @Audit('nc.action')
  @ApiEndpoint('Agrega una acción correctiva', { status: 201, tenant: true })
  @Post(':ncId/corrective-actions')
  @RequireRoles('resp_proceso', 'resp_accion', 'resp_sgi', 'resp_norma', 'admin_org')
  action(@Param('orgId') orgId: string, @Param('ncId') ncId: string, @Body() data: { title: string; dueDate?: string }, @CurrentUser() user: AuthUser) {
    return this.nc.addCorrectiveAction(orgId, user, ncId, data);
  }

  @Audit('nc.verify')
  @ApiEndpoint('Verifica la eficacia de una acción correctiva', { status: 201, tenant: true })
  @Post('corrective-actions/:actionId/verify')
  @RequireRoles('resp_sgi', 'resp_norma', 'resp_riesgos', 'admin_org')
  verify(
    @Param('orgId') orgId: string,
    @Param('actionId') actionId: string,
    @Body() data: { result: 'EFFECTIVE' | 'NOT_EFFECTIVE'; evidenceId?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.nc.verifyEffectiveness(orgId, user, actionId, data.result, data.evidenceId);
  }

  @Audit('nc.lesson')
  @ApiEndpoint('Registra una lección aprendida', { status: 201, tenant: true })
  @Post(':ncId/lessons')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  lesson(@Param('orgId') orgId: string, @Param('ncId') ncId: string, @Body('lesson') lesson: string, @CurrentUser() user: AuthUser) {
    return this.nc.addLesson(orgId, user, ncId, lesson);
  }

  @Audit('nc.close')
  @ApiEndpoint('Cierra la no conformidad', { status: 201, tenant: true })
  @Post(':ncId/close')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  close(
    @Param('orgId') orgId: string,
    @Param('ncId') ncId: string,
    @Body('note') note: string | undefined,
    @CurrentUser() user: AuthUser,
  ) {
    return this.nc.close(orgId, user, ncId, note);
  }

  @Audit('nc.reopen')
  @ApiEndpoint('Reabre una no conformidad cerrada', { status: 201, tenant: true })
  @Post(':ncId/reopen')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  reopen(
    @Param('orgId') orgId: string,
    @Param('ncId') ncId: string,
    @Body('reason') reason: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.nc.reopen(orgId, user, ncId, reason);
  }

  @Audit('nc.action.delete')
  @ApiEndpoint('Elimina una acción correctiva', { status: 200, tenant: true })
  @Delete(':ncId/corrective-actions/:actionId')
  @RequireRoles('resp_proceso', 'resp_accion', 'resp_sgi', 'resp_norma', 'admin_org')
  removeAction(
    @Param('orgId') orgId: string,
    @Param('ncId') ncId: string,
    @Param('actionId') actionId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.nc.removeCorrectiveAction(orgId, user, ncId, actionId);
  }

  @Audit('nc.delete')
  @ApiEndpoint('Elimina una no conformidad', { status: 200, tenant: true })
  @Delete(':ncId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  remove(@Param('orgId') orgId: string, @Param('ncId') ncId: string, @CurrentUser() user: AuthUser) {
    return this.nc.remove(orgId, user, ncId);
  }
}
