import { Module } from '@nestjs/common';
import { NcController } from './nc.controller';
import { NcService } from './nc.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [TenancyModule, AuthSharedModule],
  controllers: [NcController],
  providers: [NcService],
})
export class NcModule {}
