import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { nextSequentialCode } from '../../common/next-code';
import { TenancyService } from '../../tenancy/tenancy.service';

const NC_STATUS = {
  REGISTERED: 'REGISTERED',
  IN_ANALYSIS: 'IN_ANALYSIS',
  IN_CORRECTIVE_ACTION: 'IN_CORRECTIVE_ACTION',
  VERIFYING: 'VERIFYING',
  CLOSED: 'CLOSED',
} as const;

@Injectable()
export class NcService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Lista NC de la organización con su expediente. */
  async list(orgId: string, user: AuthUser, status?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.nc.findMany({
        where: { orgId, ...(status ? { status } : {}) },
        include: { corrections: true, rootCauses: true, actions: { include: { verifications: true } }, lessons: true },
        orderBy: { reportedAt: 'desc' },
      });
    });
  }

  /** Registra una NC con folio auto-generado (NC-2026-NNN). */
  async register(
    orgId: string,
    user: AuthUser,
    data: { title: string; description?: string; priority?: string; standardId?: string; clauseId?: string; classification?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      // El folio sale del mayor consecutivo existente, no del número de filas:
      // al borrar una NC o al sembrar folios salteados (011, 014) contar filas
      // repite un folio ya usado y la inserción falla por la clave única.
      const prefix = `NC-${new Date().getFullYear()}-`;
      const existing = await tx.nc.findMany({
        where: { orgId, folio: { startsWith: prefix } },
        select: { folio: true },
      });
      const folio = nextSequentialCode(prefix, existing.map((row) => row.folio));
      return tx.nc.create({
        data: {
          orgId,
          folio,
          title: data.title,
          description: data.description,
          priority: data.priority ?? 'MEDIA',
          classification: data.classification ?? 'NON_CONFORMITY',
          standardId: data.standardId,
          clauseId: data.clauseId,
          reportedById: user.sub,
        },
      });
    });
  }

  /** Corrección inmediata (paso 1). */
  async addCorrection(orgId: string, user: AuthUser, ncId: string, description: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findNc(tx, orgId, ncId);
      await tx.nc.update({ where: { id: ncId }, data: { status: NC_STATUS.IN_ANALYSIS } });
      return tx.ncCorrection.create({ data: { orgId, ncId, description } });
    });
  }

  /** Análisis de causa raíz (paso 2). */
  async addRootCause(orgId: string, user: AuthUser, ncId: string, data: { method?: string; causes?: string[]; analysis?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findNc(tx, orgId, ncId);
      await tx.nc.update({ where: { id: ncId }, data: { status: NC_STATUS.IN_CORRECTIVE_ACTION } });
      return tx.rootCause.create({
        data: { orgId, ncId, method: data.method ?? '5_WHYS', causes: data.causes ?? [], analysis: data.analysis },
      });
    });
  }

  /** Acción correctiva (paso 3). */
  async addCorrectiveAction(orgId: string, user: AuthUser, ncId: string, data: { title: string; dueDate?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findNc(tx, orgId, ncId);
      const action = await tx.correctiveAction.create({
        data: { orgId, ncId, title: data.title, assigneeId: user.sub, dueDate: data.dueDate ? new Date(data.dueDate) : null, status: 'IN_PROGRESS', approvedById: user.sub, approvedAt: new Date() },
      });
      await tx.nc.update({ where: { id: ncId }, data: { status: NC_STATUS.IN_CORRECTIVE_ACTION } });
      return action;
    });
  }

  /** Verificación de eficacia (paso 4): efectiva → cierra NC. */
  async verifyEffectiveness(orgId: string, user: AuthUser, actionId: string, result: 'EFFECTIVE' | 'NOT_EFFECTIVE', evidenceId?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const action = await tx.correctiveAction.findUnique({ where: { id: actionId }, include: { nc: true } });
      if (!action || action.orgId !== orgId) throw new NotFoundException('Acción correctiva no encontrada');

      await tx.effectivenessVerification.create({
        data: { orgId, actionId, result, evidenceId, verifiedById: user.sub },
      });
      if (result === 'EFFECTIVE') {
        await tx.correctiveAction.update({ where: { id: actionId }, data: { status: 'VERIFIED' } });
        await tx.nc.update({ where: { id: action.ncId }, data: { status: NC_STATUS.CLOSED } });
      }
      return { result, ncStatus: result === 'EFFECTIVE' ? 'CLOSED' : action.nc.status };
    });
  }

  /** Lección aprendida (cierre). */
  async addLesson(orgId: string, user: AuthUser, ncId: string, lesson: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findNc(tx, orgId, ncId);
      return tx.lessonLearned.create({ data: { orgId, ncId, lesson } });
    });
  }

  /** Actualiza los datos generales de la NC. */
  async update(
    orgId: string,
    user: AuthUser,
    ncId: string,
    data: { title?: string; description?: string | null; priority?: string; classification?: string; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findNc(tx, orgId, ncId);
      return tx.nc.update({ where: { id: ncId }, data });
    });
  }

  /**
   * Cierre manual de la NC. Exige al menos una acción correctiva verificada
   * como efectiva: cerrar sin eficacia comprobada vacía el ciclo de mejora.
   */
  async close(orgId: string, user: AuthUser, ncId: string, note?: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const nc = await tx.nc.findUnique({
        where: { id: ncId },
        include: { actions: { include: { verifications: true } } },
      });
      if (!nc || nc.orgId !== orgId) throw new NotFoundException('NC no encontrada');
      if (nc.status === NC_STATUS.CLOSED) return nc;

      const effective = nc.actions.some((a) =>
        a.verifications.some((v) => v.result === 'EFFECTIVE'),
      );
      if (!effective) {
        throw new BadRequestException(
          'No se puede cerrar: ninguna acción correctiva tiene verificación de eficacia',
        );
      }
      if (note) {
        await tx.lessonLearned.create({ data: { orgId, ncId, lesson: note } });
      }
      return tx.nc.update({ where: { id: ncId }, data: { status: NC_STATUS.CLOSED } });
    });
  }

  /** Reabre una NC cerrada (regresión detectada). */
  async reopen(orgId: string, user: AuthUser, ncId: string, reason: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const nc = await this.findNc(tx, orgId, ncId);
      if (nc.status !== NC_STATUS.CLOSED) {
        throw new BadRequestException('Solo se reabren NC cerradas');
      }
      await tx.lessonLearned.create({ data: { orgId, ncId, lesson: `Reapertura: ${reason}` } });
      return tx.nc.update({ where: { id: ncId }, data: { status: NC_STATUS.IN_CORRECTIVE_ACTION } });
    });
  }

  /**
   * Elimina una NC y su expediente. Solo se permite si nunca llegó a cerrarse:
   * un registro cerrado forma parte de la evidencia del sistema.
   */
  async remove(orgId: string, user: AuthUser, ncId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      const nc = await this.findNc(tx, orgId, ncId);
      if (nc.status === NC_STATUS.CLOSED) {
        throw new BadRequestException(
          'Una NC cerrada no se elimina: conserva la trazabilidad del sistema',
        );
      }
      await tx.nc.delete({ where: { id: ncId } });
      return { ok: true, deleted: ncId };
    });
  }

  /** Elimina una acción correctiva todavía no verificada (corrige un alta equivocada). */
  async removeCorrectiveAction(orgId: string, user: AuthUser, ncId: string, actionId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      await this.findNc(tx, orgId, ncId);
      const action = await tx.correctiveAction.findUnique({ where: { id: actionId } });
      if (!action || action.orgId !== orgId || action.ncId !== ncId) {
        throw new NotFoundException('Acción correctiva no encontrada');
      }
      if (action.status === 'VERIFIED') {
        throw new BadRequestException(
          'Una acción verificada no se elimina: es evidencia de la eficacia',
        );
      }
      await tx.correctiveAction.delete({ where: { id: actionId } });
      const remaining = await tx.correctiveAction.count({ where: { ncId } });
      if (remaining === 0) {
        await tx.nc.update({ where: { id: ncId }, data: { status: NC_STATUS.IN_ANALYSIS } });
      }
      return { ok: true, deleted: actionId, remaining };
    });
  }

  private async findNc(
    tx: { nc: { findUnique: (a: { where: { id: string } }) => Promise<{ orgId: string; status: string } | null> } },
    orgId: string,
    ncId: string,
  ) {
    const nc = await tx.nc.findUnique({ where: { id: ncId } });
    if (!nc || nc.orgId !== orgId) throw new NotFoundException('NC no encontrada');
    return nc;
  }
}
