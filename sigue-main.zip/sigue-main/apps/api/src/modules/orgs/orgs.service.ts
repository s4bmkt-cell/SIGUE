import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { ADMIN_ROLES } from '../../common/roles';
import { PrismaService } from '../../prisma/prisma.service';
import { TenancyService } from '../../tenancy/tenancy.service';
import { withTenant } from '../../tenancy/with-tenant';
import { limitsFor } from '../billing/plan-limits';

export interface OrgSummary {
  id: string;
  name: string;
  plan: string;
  /** Roles del usuario en esa organización (permite elegir dónde administra). */
  roles: string[];
  users: number;
  quotaUsers: number;
  storage: { usedGb: number; quotaGb: number };
  aiConsumption: { pct: number; used: string; quota: string };
}

export interface OrgProfile extends OrgSummary {
  legalName: string | null;
  country: string;
  lang: string;
  timezone: string;
  currency: string;
  status: string;
  createdAt: Date;
}

/**
 * Módulo de organizaciones (persistencia PostgreSQL).
 *
 * Toda consulta fija `app.org_id`/`app.user_id` en la misma transacción que usa
 * los datos: las políticas RLS exigen ese contexto y, además, cada método valida
 * la membresía explícitamente (defensa en profundidad).
 */
@Injectable()
export class OrgsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  /** Resumen de la organización SOLO si el usuario es miembro activo. */
  async getSummary(orgId: string, user: AuthUser): Promise<OrgSummary> {
    const profile = await this.getProfile(orgId, user);
    return {
      id: profile.id,
      name: profile.name,
      plan: profile.plan,
      roles: user.roles ?? [],
      users: profile.users,
      quotaUsers: profile.quotaUsers,
      storage: profile.storage,
      aiConsumption: profile.aiConsumption,
    };
  }

  /** Ficha completa: datos comerciales, uso de cuotas y datos de configuración. */
  async getProfile(orgId: string, user: AuthUser): Promise<OrgProfile> {
    const { membership, org, counts } = await withTenant(
      this.prisma,
      { orgId, userId: user.sub },
      async (tx) => {
        const membership = await tx.$queryRaw<{ orgId: string; roles: string[] }[]>`
          SELECT m."orgId", m."roles" FROM "OrgMember" m
          WHERE m."orgId" = ${orgId} AND m."userId" = ${user.sub} AND m."status" = 'ACTIVE'
            AND (m."accessEnd" IS NULL OR m."accessEnd" > now())
          LIMIT 1
        `;
        const org = await tx.organization.findUnique({ where: { id: orgId } });
        const counts = await tx.$queryRaw<{ users: number; storage: number; standards: number }[]>`
          SELECT
            (SELECT count(*)::int FROM "OrgMember" WHERE "orgId" = ${orgId} AND "status" = 'ACTIVE') AS users,
            (SELECT COALESCE(sum("size"), 0)::bigint FROM "EvidenceFile" WHERE "orgId" = ${orgId}) AS storage,
            (SELECT count(*)::int FROM "OrgStandard" WHERE "orgId" = ${orgId} AND "status" = 'ACTIVE') AS standards
        `;
        return { membership, org, counts: counts[0] };
      },
    );

    if (!membership.length) throw new ForbiddenException('No perteneces a esta organización');
    if (!org) throw new NotFoundException('Organización no encontrada');

    const limits = limitsFor(org.planCode);
    const usedGb = Number(counts?.storage ?? 0) / 1024 ** 3;
    const aiTokens = await this.aiUsage(orgId);

    return {
      id: org.id,
      name: org.name,
      plan: org.planCode,
      // Roles vigentes en esta organización, no los del token: pueden haber
      // cambiado sin que la sesión se haya renovado.
      roles: membership[0]?.roles ?? [],
      users: counts?.users ?? 0,
      quotaUsers: limits.users,
      storage: { usedGb: Number(usedGb.toFixed(2)), quotaGb: limits.storageGb },
      aiConsumption: {
        pct: limits.aiTokens ? Math.min(100, Math.round((aiTokens / limits.aiTokens) * 100)) : 0,
        used: String(aiTokens),
        quota: String(limits.aiTokens),
      },
      legalName: org.legalName,
      country: org.country,
      lang: org.lang,
      timezone: org.timezone,
      currency: org.currency,
      status: org.status,
      createdAt: org.createdAt,
    };
  }

  /** Lista las organizaciones a las que el usuario pertenece (membresías activas). */
  async listForUser(user: AuthUser): Promise<OrgSummary[]> {
    const memberships = await withTenant(this.prisma, { userId: user.sub }, (tx) =>
      tx.$queryRaw<{ orgId: string; name: string; planCode: string; roles: string[] }[]>`
        SELECT m."orgId", o."name", o."planCode", m."roles"
        FROM "OrgMember" m
        JOIN "Organization" o ON o.id = m."orgId"
        WHERE m."userId" = ${user.sub} AND m."status" = 'ACTIVE' AND o."status" = 'ACTIVE'
          AND (m."accessEnd" IS NULL OR m."accessEnd" > now())
        ORDER BY o."name"
      `,
    );

    // Los conteos se hacen organización por organización: la política de
    // `OrgMember` solo deja ver las membresías propias cuando no hay
    // `app.org_id`, así que agregarlos en la consulta anterior daría 1 siempre.
    return Promise.all(
      memberships.map(async (m) => {
        const counts = await withTenant(this.prisma, { orgId: m.orgId }, (tx) =>
          tx.$queryRaw<{ users: number; storage: bigint }[]>`
            SELECT
              (SELECT count(*)::int FROM "OrgMember" WHERE "orgId" = ${m.orgId} AND "status" = 'ACTIVE') AS users,
              (SELECT COALESCE(sum("size"), 0)::bigint FROM "EvidenceFile" WHERE "orgId" = ${m.orgId}) AS storage
          `,
        );
        const limits = limitsFor(m.planCode);
        return {
          id: m.orgId,
          name: m.name,
          plan: m.planCode,
          roles: m.roles,
          users: counts[0]?.users ?? 0,
          quotaUsers: limits.users,
          storage: {
            usedGb: Number((Number(counts[0]?.storage ?? 0) / 1024 ** 3).toFixed(2)),
            quotaGb: limits.storageGb,
          },
          aiConsumption: { pct: 0, used: '0', quota: String(limits.aiTokens) },
        };
      }),
    );
  }

  /** Edita los datos de la organización. Solo administradores. */
  async update(
    orgId: string,
    user: AuthUser,
    input: { name?: string; legalName?: string; country?: string; lang?: string; timezone?: string },
  ) {
    await this.assertAdmin(orgId, user);

    const data: Record<string, string> = {};
    for (const key of ['name', 'legalName', 'country', 'lang', 'timezone'] as const) {
      const value = input[key];
      if (value !== undefined) data[key] = value;
    }
    if (!Object.keys(data).length) throw new BadRequestException('No hay cambios que aplicar');

    // `Organization` tiene RLS: sin `app.org_id` la escritura no alcanza ninguna
    // fila (y, con un id ajeno, la política `WITH CHECK` la rechaza).
    const updated = await withTenant(this.prisma, { orgId, userId: user.sub }, (tx) =>
      tx.organization.update({ where: { id: orgId }, data }),
    );
    return {
      id: updated.id,
      name: updated.name,
      legalName: updated.legalName,
      country: updated.country,
      lang: updated.lang,
      timezone: updated.timezone,
      currency: updated.currency,
    };
  }

  // ===== Sucursales =====

  async listBranches(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return withTenant(this.prisma, { orgId }, (tx) =>
      tx.orgBranch.findMany({ where: { orgId }, orderBy: { name: 'asc' } }),
    );
  }

  async createBranch(
    orgId: string,
    user: AuthUser,
    input: { name: string; country?: string; state?: string; city?: string },
  ) {
    await this.assertAdmin(orgId, user);
    return withTenant(this.prisma, { orgId, userId: user.sub }, async (tx) => {
      const duplicate = await tx.orgBranch.findFirst({ where: { orgId, name: input.name } });
      if (duplicate) throw new ConflictException('Ya existe una sucursal con ese nombre');
      return tx.orgBranch.create({ data: { orgId, ...input } });
    });
  }

  async updateBranch(
    orgId: string,
    user: AuthUser,
    branchId: string,
    input: { name: string; country?: string; state?: string; city?: string },
  ) {
    await this.assertAdmin(orgId, user);
    return withTenant(this.prisma, { orgId, userId: user.sub }, async (tx) => {
      const branch = await tx.orgBranch.findFirst({ where: { id: branchId, orgId } });
      if (!branch) throw new NotFoundException('Sucursal no encontrada');
      return tx.orgBranch.update({ where: { id: branchId }, data: input });
    });
  }

  async deleteBranch(orgId: string, user: AuthUser, branchId: string) {
    await this.assertAdmin(orgId, user);
    return withTenant(this.prisma, { orgId, userId: user.sub }, async (tx) => {
      const branch = await tx.orgBranch.findFirst({ where: { id: branchId, orgId } });
      if (!branch) throw new NotFoundException('Sucursal no encontrada');
      const areas = await tx.orgArea.count({ where: { orgId, branchId } });
      if (areas) {
        throw new ConflictException(
          'La sucursal tiene áreas asociadas; reasígnalas o elimínalas primero',
        );
      }
      await tx.orgBranch.delete({ where: { id: branchId } });
      return { ok: true };
    });
  }

  // ===== Áreas =====

  async listAreas(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return withTenant(this.prisma, { orgId }, (tx) =>
      tx.orgArea.findMany({ where: { orgId }, orderBy: { name: 'asc' } }),
    );
  }

  async createArea(
    orgId: string,
    user: AuthUser,
    input: { name: string; branchId?: string; parentId?: string },
  ) {
    await this.assertAdmin(orgId, user);
    return withTenant(this.prisma, { orgId, userId: user.sub }, async (tx) => {
      if (input.branchId) {
        const branch = await tx.orgBranch.findFirst({ where: { id: input.branchId, orgId } });
        if (!branch) throw new BadRequestException('La sucursal indicada no pertenece a la organización');
      }
      if (input.parentId) {
        const parent = await tx.orgArea.findFirst({ where: { id: input.parentId, orgId } });
        if (!parent) throw new BadRequestException('El área padre no pertenece a la organización');
      }
      const duplicate = await tx.orgArea.findFirst({ where: { orgId, name: input.name } });
      if (duplicate) throw new ConflictException('Ya existe un área con ese nombre');
      return tx.orgArea.create({ data: { orgId, ...input } });
    });
  }

  async updateArea(
    orgId: string,
    user: AuthUser,
    areaId: string,
    input: { name: string; branchId?: string; parentId?: string },
  ) {
    await this.assertAdmin(orgId, user);
    return withTenant(this.prisma, { orgId, userId: user.sub }, async (tx) => {
      const area = await tx.orgArea.findFirst({ where: { id: areaId, orgId } });
      if (!area) throw new NotFoundException('Área no encontrada');
      if (input.parentId === areaId) {
        throw new BadRequestException('Un área no puede ser su propio padre');
      }
      if (input.branchId) {
        const branch = await tx.orgBranch.findFirst({ where: { id: input.branchId, orgId } });
        if (!branch) throw new BadRequestException('La sucursal indicada no pertenece a la organización');
      }
      return tx.orgArea.update({ where: { id: areaId }, data: input });
    });
  }

  async deleteArea(orgId: string, user: AuthUser, areaId: string) {
    await this.assertAdmin(orgId, user);
    return withTenant(this.prisma, { orgId, userId: user.sub }, async (tx) => {
      const area = await tx.orgArea.findFirst({ where: { id: areaId, orgId } });
      if (!area) throw new NotFoundException('Área no encontrada');
      const children = await tx.orgArea.count({ where: { orgId, parentId: areaId } });
      if (children) {
        throw new ConflictException('El área tiene subáreas; elimínalas o reasígnalas primero');
      }
      await tx.orgArea.delete({ where: { id: areaId } });
      return { ok: true };
    });
  }

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  private async assertAdmin(orgId: string, user: AuthUser) {
    const roles = await this.tenancy.rolesIn(orgId, user.sub);
    if (!roles.some((r) => ADMIN_ROLES.includes(r as never))) {
      throw new ForbiddenException('Requiere el rol de administrador de la organización');
    }
  }

  /** Consumo de IA del periodo en curso (tokens). */
  private async aiUsage(orgId: string): Promise<number> {
    const period = new Date().toISOString().slice(0, 7);
    const rows = await withTenant(this.prisma, { orgId }, (tx) =>
      tx.orgUsage.findFirst({ where: { orgId, resource: 'ai_tokens', period } }),
    );
    return Number(rows?.used ?? 0);
  }
}
