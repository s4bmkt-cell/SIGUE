import {
  Body,
  Controller,
  Delete,
  Get,
  HttpCode,
  HttpStatus,
  Param,
  Patch,
  Post,
  UseGuards,
} from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { OrgsService } from './orgs.service';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { Audit } from '../../common/decorators/audit.decorator';
import {
  CreateAreaDto,
  CreateBranchDto,
  UpdateAreaDto,
  UpdateBranchDto,
  UpdateOrgDto,
} from '../users/dto/users.dto';

/**
 * Organización, sucursales y áreas.
 *
 * Las rutas con `:orgId` pasan por el guard global de tenancy, que exige
 * membresía activa; los cambios, además, exigen rol de administrador en el
 * servicio. `GET /orgs` (sin `:orgId`) lista solo las membresías propias.
 */
@ApiTags('orgs')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs', version: '1' })
export class OrgsController {
  constructor(private readonly orgs: OrgsService) {}

  @ApiEndpoint('Organizaciones en las que participa el usuario', { status: 200, tenant: false })
  @Get()
  async mine(@CurrentUser() user: AuthUser) {
    return { organizations: await this.orgs.listForUser(user) };
  }

  @ApiEndpoint('Resumen de la organización con cuotas de uso', { status: 200, tenant: true })
  @Get(':orgId')
  async summary(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.orgs.getSummary(orgId, user);
  }

  @ApiEndpoint('Ficha completa de la organización', { status: 200, tenant: true })
  @Get(':orgId/profile')
  profile(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.orgs.getProfile(orgId, user);
  }

  @Audit('org.update')
  @ApiEndpoint('Actualiza los datos generales de la organización', { status: 200, tenant: true })
  @Patch(':orgId')
  update(
    @Param('orgId') orgId: string,
    @Body() dto: UpdateOrgDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.orgs.update(orgId, user, dto);
  }

  // ===== Sucursales =====

  @ApiEndpoint('Sucursales de la organización', { status: 200, tenant: true })
  @Get(':orgId/branches')
  branches(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.orgs.listBranches(orgId, user);
  }

  @Audit('org.branch_create')
  @ApiEndpoint('Crea una sucursal', { status: 201, tenant: true })
  @Post(':orgId/branches')
  createBranch(
    @Param('orgId') orgId: string,
    @Body() dto: CreateBranchDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.orgs.createBranch(orgId, user, dto);
  }

  @Audit('org.branch_update')
  @ApiEndpoint('Actualiza una sucursal', { status: 200, tenant: true })
  @Patch(':orgId/branches/:branchId')
  updateBranch(
    @Param('orgId') orgId: string,
    @Param('branchId') branchId: string,
    @Body() dto: UpdateBranchDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.orgs.updateBranch(orgId, user, branchId, dto);
  }

  @Audit('org.branch_delete')
  @ApiEndpoint('Elimina una sucursal', { status: 200, tenant: true })
  @Delete(':orgId/branches/:branchId')
  @HttpCode(HttpStatus.OK)
  deleteBranch(
    @Param('orgId') orgId: string,
    @Param('branchId') branchId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.orgs.deleteBranch(orgId, user, branchId);
  }

  // ===== Áreas =====

  @ApiEndpoint('Áreas de la organización', { status: 200, tenant: true })
  @Get(':orgId/areas')
  areas(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.orgs.listAreas(orgId, user);
  }

  @Audit('org.area_create')
  @ApiEndpoint('Crea un área', { status: 201, tenant: true })
  @Post(':orgId/areas')
  createArea(
    @Param('orgId') orgId: string,
    @Body() dto: CreateAreaDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.orgs.createArea(orgId, user, dto);
  }

  @Audit('org.area_update')
  @ApiEndpoint('Actualiza un área', { status: 200, tenant: true })
  @Patch(':orgId/areas/:areaId')
  updateArea(
    @Param('orgId') orgId: string,
    @Param('areaId') areaId: string,
    @Body() dto: UpdateAreaDto,
    @CurrentUser() user: AuthUser,
  ) {
    return this.orgs.updateArea(orgId, user, areaId, dto);
  }

  @Audit('org.area_delete')
  @ApiEndpoint('Elimina un área', { status: 200, tenant: true })
  @Delete(':orgId/areas/:areaId')
  @HttpCode(HttpStatus.OK)
  deleteArea(
    @Param('orgId') orgId: string,
    @Param('areaId') areaId: string,
    @CurrentUser() user: AuthUser,
  ) {
    return this.orgs.deleteArea(orgId, user, areaId);
  }
}
