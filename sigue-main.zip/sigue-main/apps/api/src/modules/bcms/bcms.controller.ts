import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { BcmsService } from './bcms.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';
import { Audit } from '../../common/decorators/audit.decorator';

@ApiTags('bcms')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'orgs/:orgId/bcms', version: '1' })
export class BcmsController {
  constructor(private readonly bcms: BcmsService) {}

  @ApiEndpoint('Panorama del SGCN: BIA, planes y ejercicios', { status: 200, tenant: true })
  @Get()
  overview(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.bcms.overview(orgId, user);
  }

  // ===== BIA =====
  @Audit('bcms.add_bia')
  @ApiEndpoint('Registra un análisis de impacto al negocio', { status: 201, tenant: true })
  @Post('bia')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addBia(@Param('orgId') orgId: string, @Body() data: { processName: string; criticality?: string; rtoHours?: number; rpoHours?: number }, @CurrentUser() user: AuthUser) {
    return this.bcms.addBia(orgId, user, data);
  }

  @Audit('bcms.update_bia')
  @ApiEndpoint('Actualiza un BIA', { status: 200, tenant: true })
  @Patch('bia/:biaId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updateBia(
    @Param('orgId') orgId: string,
    @Param('biaId') biaId: string,
    @Body() data: { processName?: string; criticality?: string; rtoHours?: number | null; rpoHours?: number | null; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.bcms.updateBia(orgId, user, biaId, data);
  }

  @Audit('bcms.delete_bia')
  @ApiEndpoint('Elimina un BIA', { status: 200, tenant: true })
  @Delete('bia/:biaId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteBia(@Param('orgId') orgId: string, @Param('biaId') biaId: string, @CurrentUser() user: AuthUser) {
    return this.bcms.deleteBia(orgId, user, biaId);
  }

  // ===== Planes =====
  @Audit('bcms.add_plan')
  @ApiEndpoint('Crea un plan de continuidad', { status: 201, tenant: true })
  @Post('plans')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addPlan(@Param('orgId') orgId: string, @Body() data: { title: string; strategy?: string; content?: string }, @CurrentUser() user: AuthUser) {
    return this.bcms.addPlan(orgId, user, data);
  }

  @Audit('bcms.update_plan')
  @ApiEndpoint('Actualiza un plan de continuidad', { status: 200, tenant: true })
  @Patch('plans/:planId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  updatePlan(
    @Param('orgId') orgId: string,
    @Param('planId') planId: string,
    @Body() data: { title?: string; strategy?: string | null; content?: string | null; status?: string },
    @CurrentUser() user: AuthUser,
  ) {
    return this.bcms.updatePlan(orgId, user, planId, data);
  }

  @Audit('bcms.delete_plan')
  @ApiEndpoint('Elimina un plan de continuidad', { status: 200, tenant: true })
  @Delete('plans/:planId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deletePlan(@Param('orgId') orgId: string, @Param('planId') planId: string, @CurrentUser() user: AuthUser) {
    return this.bcms.deletePlan(orgId, user, planId);
  }

  // ===== Ejercicios =====
  @Audit('bcms.add_exercise')
  @ApiEndpoint('Programa un ejercicio de continuidad', { status: 201, tenant: true })
  @Post('exercises')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  addExercise(@Param('orgId') orgId: string, @Body() data: { title: string; type?: string; scheduledAt?: string }, @CurrentUser() user: AuthUser) {
    return this.bcms.addExercise(orgId, user, data);
  }

  @Audit('bcms.record_exercise')
  @ApiEndpoint('Registra el resultado de un ejercicio', { status: 200, tenant: true })
  @Patch('exercises/:exerciseId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  recordExercise(
    @Param('orgId') orgId: string,
    @Param('exerciseId') exerciseId: string,
    @Body() data: { result: string; status?: string; planId?: string | null },
    @CurrentUser() user: AuthUser,
  ) {
    return this.bcms.recordExercise(orgId, user, exerciseId, data);
  }

  @Audit('bcms.delete_exercise')
  @ApiEndpoint('Elimina un ejercicio', { status: 200, tenant: true })
  @Delete('exercises/:exerciseId')
  @RequireRoles('resp_sgi', 'resp_norma', 'admin_org')
  deleteExercise(@Param('orgId') orgId: string, @Param('exerciseId') exerciseId: string, @CurrentUser() user: AuthUser) {
    return this.bcms.deleteExercise(orgId, user, exerciseId);
  }
}
