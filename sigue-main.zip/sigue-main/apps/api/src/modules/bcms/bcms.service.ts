import { ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

@Injectable()
export class BcmsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertMember(orgId: string, user: AuthUser) {
    if (!(await this.tenancy.isMember(orgId, user.sub))) {
      throw new ForbiddenException('No perteneces a esta organización');
    }
  }

  /** Vista completa ISO 22301: BIA, planes, ejercicios. */
  async overview(orgId: string, user: AuthUser) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const [bias, plans, exercises] = await Promise.all([
        tx.bia.findMany({ where: { orgId }, orderBy: { criticality: 'desc' } }),
        tx.continuityPlan.findMany({ where: { orgId } }),
        tx.continuityExercise.findMany({ where: { orgId }, orderBy: { scheduledAt: 'desc' } }),
      ]);
      const critical = bias.filter((b) => b.criticality === 'CRITICA' || b.criticality === 'ALTA').length;
      const activePlans = plans.filter((p) => p.status === 'ACTIVE').length;
      return { bias, plans, exercises, summary: { processes: bias.length, critical, activePlans } };
    });
  }

  async addBia(orgId: string, user: AuthUser, data: { processName: string; criticality?: string; rtoHours?: number; rpoHours?: number }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.bia.create({
        data: { orgId, processName: data.processName, criticality: data.criticality ?? 'MEDIA', rtoHours: data.rtoHours ?? null, rpoHours: data.rpoHours ?? null },
      });
    });
  }

  async addPlan(orgId: string, user: AuthUser, data: { title: string; strategy?: string; content?: string; biaId?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;
      return tx.continuityPlan.create({
        data: { orgId, title: data.title, strategy: data.strategy, content: data.content, biaId: data.biaId ?? null },
      });
    });
  }

  async addExercise(orgId: string, user: AuthUser, data: { title: string; type?: string; scheduledAt?: string }) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      return tx.continuityExercise.create({
        data: { orgId, title: data.title, type: data.type ?? 'TABLE_TOP', scheduledAt: data.scheduledAt ? new Date(data.scheduledAt) : null },
      });
    });
  }

  // ===== Actualización =====
  async updateBia(
    orgId: string,
    user: AuthUser,
    biaId: string,
    data: { processName?: string; criticality?: string; rtoHours?: number | null; rpoHours?: number | null; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.bia.findUnique({ where: { id: biaId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Análisis de impacto no encontrado');
      return tx.bia.update({ where: { id: biaId }, data });
    });
  }

  async deleteBia(orgId: string, user: AuthUser, biaId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.bia.findUnique({ where: { id: biaId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Análisis de impacto no encontrado');
      await tx.bia.delete({ where: { id: biaId } });
      return { ok: true, deleted: biaId };
    });
  }

  /**
   * Actualiza el plan. Al marcarlo `TESTED` se fija `lastTestedAt`: la evidencia
   * del ejercicio es la fecha, no una etiqueta sin sustento.
   */
  async updatePlan(
    orgId: string,
    user: AuthUser,
    planId: string,
    data: { title?: string; strategy?: string | null; content?: string | null; status?: string },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.continuityPlan.findUnique({ where: { id: planId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Plan de continuidad no encontrado');
      return tx.continuityPlan.update({
        where: { id: planId },
        data: {
          ...(data.title !== undefined ? { title: data.title } : {}),
          ...(data.strategy !== undefined ? { strategy: data.strategy } : {}),
          ...(data.content !== undefined ? { content: data.content } : {}),
          ...(data.status !== undefined ? { status: data.status } : {}),
          ...(data.status === 'TESTED' ? { lastTestedAt: new Date() } : {}),
        },
      });
    });
  }

  async deletePlan(orgId: string, user: AuthUser, planId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.continuityPlan.findUnique({ where: { id: planId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Plan de continuidad no encontrado');
      await tx.continuityPlan.delete({ where: { id: planId } });
      return { ok: true, deleted: planId };
    });
  }

  /** Registra el resultado de un ejercicio (completado o no). */
  async recordExercise(
    orgId: string,
    user: AuthUser,
    exerciseId: string,
    data: { result: string; status?: string; planId?: string | null },
  ) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.continuityExercise.findUnique({ where: { id: exerciseId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Ejercicio no encontrado');
      return tx.continuityExercise.update({
        where: { id: exerciseId },
        data: {
          result: data.result,
          status: data.status ?? 'COMPLETED',
          ...(data.planId !== undefined ? { planId: data.planId } : {}),
        },
      });
    });
  }

  async deleteExercise(orgId: string, user: AuthUser, exerciseId: string) {
    await this.assertMember(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true)`;
      const row = await tx.continuityExercise.findUnique({ where: { id: exerciseId } });
      if (!row || row.orgId !== orgId) throw new NotFoundException('Ejercicio no encontrado');
      await tx.continuityExercise.delete({ where: { id: exerciseId } });
      return { ok: true, deleted: exerciseId };
    });
  }
}
