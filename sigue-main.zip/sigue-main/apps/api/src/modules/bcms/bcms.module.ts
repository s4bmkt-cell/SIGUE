import { Module } from '@nestjs/common';
import { BcmsController } from './bcms.controller';
import { BcmsService } from './bcms.service';
import { TenancyModule } from '../../tenancy/tenancy.module';
import { AuthSharedModule } from '../../common/auth-shared.module';

@Module({
  imports: [TenancyModule, AuthSharedModule],
  controllers: [BcmsController],
  providers: [BcmsService],
})
export class BcmsModule {}
