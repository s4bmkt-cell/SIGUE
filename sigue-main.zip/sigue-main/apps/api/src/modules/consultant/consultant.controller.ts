import { Controller, Get, Param, UseGuards } from '@nestjs/common';
import { ApiBearerAuth, ApiTags } from '@nestjs/swagger';
import { ApiEndpoint } from '../../common/swagger/api-endpoint.decorator';
import { JwtAuthGuard } from '../../common/guards/jwt-auth.guard';
import { RolesGuard } from '../../common/guards/roles.guard';
import { CurrentUser, AuthUser } from '../../common/decorators/current-user.decorator';
import { ConsultantService } from './consultant.service';
import { RequireRoles } from '../../common/decorators/roles.decorator';

@ApiTags('consultant')
@ApiBearerAuth()
@UseGuards(JwtAuthGuard, RolesGuard)
@Controller({ path: 'consultant', version: '1' })
export class ConsultantController {
  constructor(private readonly consultant: ConsultantService) {}

  @ApiEndpoint('Clientes del consultor con su salud', { status: 200, tenant: false })
  @Get('clients')
  @RequireRoles('consultor_externo', 'admin_org', 'admin_global')
  myClients(@CurrentUser() user: AuthUser) {
    return this.consultant.myClients(user);
  }

  @ApiEndpoint('Consolidado de todos los clientes', { status: 200, tenant: false })
  @Get('consolidated')
  @RequireRoles('consultor_externo', 'admin_org', 'admin_global')
  consolidated(@CurrentUser() user: AuthUser) {
    return this.consultant.consolidated(user);
  }

  @ApiEndpoint('Resumen de un cliente concreto', { status: 200, tenant: true })
  @Get('clients/:orgId/summary')
  @RequireRoles('consultor_externo', 'admin_org')
  clientSummary(@Param('orgId') orgId: string, @CurrentUser() user: AuthUser) {
    return this.consultant.clientSummary(orgId, user);
  }
}
