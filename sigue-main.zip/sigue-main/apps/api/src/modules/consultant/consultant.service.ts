import { ForbiddenException, Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AuthUser } from '../../common/decorators/current-user.decorator';
import { TenancyService } from '../../tenancy/tenancy.service';

/**
 * Consola Consultor multicliente: un consultor administra varios clientes,
 * cambia de organización y supervisa avances consolidados.
 */
@Injectable()
export class ConsultantService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly tenancy: TenancyService,
  ) {}

  private async assertConsultant(orgId: string, user: AuthUser) {
    const m = await this.tenancy.isMember(orgId, user.sub);
    if (!m) throw new ForbiddenException('No tienes acceso a esta organización');
  }

  /** Organizaciones cliente asignadas al consultor (membresías consultor_externo). */
  async myClients(user: AuthUser) {
    const rows = await this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.user_id', ${user.sub}, true)`;
      return tx.$queryRaw`
        SELECT m."orgId", o."name", o."planCode", o."status" AS org_status, m."roles", m."accessEnd"
        FROM "OrgMember" m JOIN "Organization" o ON o.id = m."orgId"
        WHERE m."userId" = ${user.sub} AND m."status" = 'ACTIVE'
          AND (m."roles" && ARRAY['consultor_externo','admin_org']::text[])
        ORDER BY o."name"
      ` as unknown as { orgId: string; name: string; planCode: string; org_status: string; roles: string[]; accessEnd: Date | null }[];
    });

    // Vista consolidada por cliente
    const clients = [];
    for (const c of rows) {
      const summary = await this.clientSummary(c.orgId, user);
      clients.push({ orgId: c.orgId, name: c.name, planCode: c.planCode, roles: c.roles, accessEnd: c.accessEnd, summary });
    }
    return { clients };
  }

  /** Consolidado de avance de un cliente (cumplimiento, NC, auditorías, tareas, riesgos). */
  async clientSummary(orgId: string, user: AuthUser) {
    await this.assertConsultant(orgId, user);
    return this.prisma.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT set_config('app.org_id', ${orgId}, true), set_config('app.user_id', ${user.sub}, true)`;

      const [totalReq, implementedReq, ncOpen, audits, pendingTasks, risksOpen, objectives] = await Promise.all([
        tx.standardClause.count({ where: { kind: 'requirement' } }),
        tx.requirementStatus.count({ where: { orgId, level: { in: ['IMPLEMENTED', 'MATURE'] } } }),
        tx.nc.count({ where: { orgId, status: { not: 'CLOSED' } } }),
        tx.audit.count({ where: { orgId, status: { in: ['PLANNED', 'IN_PROGRESS'] } } }),
        tx.planTask.count({ where: { orgId, status: { not: 'DONE' } } }),
        tx.risk.count({ where: { orgId, status: 'OPEN' } }),
        tx.objective.count({ where: { orgId } }),
      ]);

      const compliancePct = totalReq ? Math.round((implementedReq / totalReq) * 100) : 0;
      return {
        compliancePct,
        implemented: implementedReq,
        totalRequirements: totalReq,
        ncOpen,
        upcomingAudits: audits,
        pendingTasks,
        openRisks: risksOpen,
        objectives: objectives,
        health: compliancePct >= 75 ? 'GOOD' : compliancePct >= 40 ? 'WATCH' : 'CRITICAL',
      };
    });
  }

  /** Resumen consolidado de TODOS los clientes (para la vista global del consultor). */
  async consolidated(user: AuthUser) {
    const { clients } = await this.myClients(user);
    const total = clients.length;
    const avgCompliance = total ? Math.round(clients.reduce((a, c) => a + c.summary.compliancePct, 0) / total) : 0;
    const totalNC = clients.reduce((a, c) => a + c.summary.ncOpen, 0);
    const totalTasks = clients.reduce((a, c) => a + c.summary.pendingTasks, 0);
    const good = clients.filter((c) => c.summary.health === 'GOOD').length;
    return {
      totalClients: total,
      avgCompliance,
      totalNC,
      totalPendingTasks: totalTasks,
      clientsOnTrack: good,
      clients,
    };
  }
}
