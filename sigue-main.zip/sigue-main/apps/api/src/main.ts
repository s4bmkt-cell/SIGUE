import { NestFactory } from '@nestjs/core';
import { Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { SwaggerModule } from '@nestjs/swagger';
import { AppModule } from './app.module';
import { buildOpenApiDocument, configureApp } from './app.setup';

async function bootstrap() {
  // `rawBody`: el webhook de pagos verifica la firma sobre los bytes exactos
  // recibidos, no sobre el JSON reserializado.
  const app = await NestFactory.create(AppModule, { rawBody: true });

  configureApp(app);

  // OpenAPI (Swagger)
  SwaggerModule.setup('docs', app, buildOpenApiDocument(app));

  const config = app.get(ConfigService);
  const port = config.get<number>('PORT') ?? 3001;
  await app.listen(port);
  Logger.log(`SIGUE API escuchando en http://localhost:${port}/api/v1 (docs: /docs)`, 'Bootstrap');
}

bootstrap();
