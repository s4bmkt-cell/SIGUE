/** @type {import('tailwindcss').Config} */
export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}', './lib/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        // Tokens del sistema de diseño SIGN (dirección visual "El Faro")
        navy: {
          DEFAULT: '#001743',
          light: '#0a2a52',
          lighter: '#123563',
        },
        primary: {
          DEFAULT: '#2f66eb',
          strong: '#1e56ef',
          soft: '#5381ec',
        },
        page: '#f9fafd',
        ink: {
          DEFAULT: '#16233d',
          soft: '#54627d',
          muted: '#8296ab',
        },
        line: {
          DEFAULT: '#e3e8f0',
          strong: '#d3dbe7',
        },
        success: { DEFAULT: '#16794c', bg: '#e2f1e6' },
        warning: { DEFAULT: '#b26a00', bg: '#fcf2e2' },
        danger: { DEFAULT: '#ed2932', bg: '#fce2db' },
        info: { DEFAULT: '#2563eb', bg: '#ebf3ff' },
      },
      borderRadius: {
        card: '14px',
        btn: '8px',
      },
      boxShadow: {
        card: '0 1px 3px rgba(16,35,67,.06), 0 4px 14px rgba(16,35,67,.05)',
      },
      fontFamily: {
        sans: ['"Segoe UI"', '-apple-system', 'BlinkMacSystemFont', 'Roboto', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
