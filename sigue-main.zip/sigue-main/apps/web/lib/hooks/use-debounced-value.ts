'use client';

import { useEffect, useState } from 'react';

/**
 * Retrasa la propagación de un valor que cambia con cada tecla. La búsqueda del
 * inventario se resuelve en la API: enviar una petición por pulsación castiga al
 * servidor sin mejorar la respuesta.
 */
export function useDebouncedValue<T>(value: T, delayMs = 300): T {
  const [debounced, setDebounced] = useState(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebounced(value), delayMs);
    return () => clearTimeout(timer);
  }, [value, delayMs]);

  return debounced;
}
