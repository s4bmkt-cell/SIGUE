'use client';

import { createContext, useCallback, useContext, useMemo, useSyncExternalStore } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { api, mayHaveSession, subscribeSessionHint, type OrgSummary } from '@/lib/api/client';

const STORAGE_KEY = 'sigue.activeOrgId';

// `localStorage` es un sistema externo: se lee con `useSyncExternalStore` para
// que la preferencia llegue sin llamar a setState desde un efecto y sin romper
// la hidratación (en el servidor la instantánea es null).
const orgListeners = new Set<() => void>();

function subscribeOrgStored(callback: () => void) {
  orgListeners.add(callback);
  const onStorage = (e: StorageEvent) => {
    if (e.key === STORAGE_KEY) callback();
  };
  window.addEventListener('storage', onStorage);
  return () => {
    orgListeners.delete(callback);
    window.removeEventListener('storage', onStorage);
  };
}

function readStoredOrgId() {
  return localStorage.getItem(STORAGE_KEY);
}

function writeStoredOrgId(orgId: string) {
  localStorage.setItem(STORAGE_KEY, orgId);
  orgListeners.forEach((listener) => listener());
}

export interface ActiveOrgState {
  org: OrgSummary | undefined;
  orgId: string | null;
  organizations: OrgSummary[];
  loading: boolean;
  error: Error | null;
  /** Cambia la organización activa (persiste la elección para la próxima visita). */
  setOrgId: (orgId: string) => void;
}

const ActiveOrgContext = createContext<ActiveOrgState | null>(null);

/**
 * Organización activa del usuario.
 *
 * La elección se guarda en localStorage y se comparte por contexto: antes cada
 * componente consultaba `organizations[0]` por su cuenta y el consultor no podía
 * entrar a sus clientes. Al cambiar de organización se limpia la caché de
 * TanStack Query en lugar de recargar la página, así que cada vista vuelve a
 * pedir sus datos con el nuevo contexto y sin arrastrar los del anterior.
 */
export function ActiveOrgProvider({ children }: { children: React.ReactNode }) {
  const qc = useQueryClient();
  // El provider vive en el layout raíz y sobrevive a la navegación: al entrar
  // desde /login tiene que reevaluar si ya hay sesión, así que la pista se
  // consume como sistema externo en lugar de leerse una sola vez al montar.
  const signedIn = useSyncExternalStore(subscribeSessionHint, mayHaveSession, () => false);
  const query = useQuery({
    queryKey: ['orgs'],
    queryFn: () => api.myOrgs(),
    // Sin sesión (login, invitación) no hay organizaciones que pedir. La pista
    // viene de una cookie legible por JS; los tokens siguen siendo httpOnly.
    enabled: signedIn,
  });

  const organizations = useMemo(() => query.data?.organizations ?? [], [query.data]);

  // La preferencia vive en localStorage: se lee como sistema externo y se
  // notifica al resto de pestañas vía el evento `storage`.
  const saved = useSyncExternalStore(subscribeOrgStored, readStoredOrgId, () => null);

  const orgId = useMemo(() => {
    if (!organizations.length) return null;
    return organizations.some((o) => o.id === saved) ? saved! : organizations[0].id;
  }, [organizations, saved]);

  const org = useMemo(
    () => organizations.find((o) => o.id === orgId),
    [organizations, orgId],
  );

  const setOrgId = useCallback(
    (next: string) => {
      writeStoredOrgId(next);
      // Los datos de la organización anterior no deben reaparecer al volver.
      qc.clear();
    },
    [qc],
  );

  const value = useMemo<ActiveOrgState>(
    () => ({
      org,
      orgId,
      organizations,
      loading: query.isLoading,
      error: query.error as Error | null,
      setOrgId,
    }),
    [org, orgId, organizations, query.isLoading, query.error, setOrgId],
  );

  return <ActiveOrgContext.Provider value={value}>{children}</ActiveOrgContext.Provider>;
}

export function useActiveOrg(): ActiveOrgState {
  const ctx = useContext(ActiveOrgContext);
  if (!ctx) {
    throw new Error('useActiveOrg debe usarse dentro de ActiveOrgProvider');
  }
  return ctx;
}
