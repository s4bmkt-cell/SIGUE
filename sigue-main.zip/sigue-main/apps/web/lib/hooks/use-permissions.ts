'use client';

import { useMemo } from 'react';
import { useAuth } from '@/components/providers/auth-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';

/**
 * Códigos de rol de organización. Deben coincidir con `ORG_ROLES` del API
 * (`apps/api/src/common/roles.ts`): una discrepancia aquí desactiva el gating
 * del frontend sin que el servidor se entere.
 */
export type Role =
  | 'admin_org'
  | 'resp_sgi'
  | 'resp_norma'
  | 'resp_proceso'
  | 'resp_riesgos'
  | 'controlador_doc'
  | 'auditor_interno'
  | 'resp_accion'
  | 'alta_direccion'
  | 'colaborador'
  | 'consultor_externo'
  | 'auditor_externo'
  | 'solo_lectura';

/** Roles con permiso de escritura en los módulos del sistema de gestión. */
const WRITERS: Role[] = [
  'admin_org',
  'resp_sgi',
  'resp_norma',
  'resp_proceso',
  'resp_riesgos',
  'controlador_doc',
  'auditor_interno',
  'resp_accion',
  'alta_direccion',
  'colaborador',
  'consultor_externo',
];

/** Roles que administran personas y la configuración de la organización. */
const ADMINS: Role[] = ['admin_org'];

/** Roles que pueden leer la bitácora de auditoría y los consolidados. */
const AUDITORS: Role[] = ['admin_org', 'auditor_interno', 'auditor_externo', 'consultor_externo'];

export interface Permissions {
  /** Roles efectivos en la organización activa. */
  roles: Role[];
  /** Puede crear/editar registros del SGI. */
  canWrite: boolean;
  /** Puede administrar miembros, invitaciones y la organización. */
  isAdmin: boolean;
  /**
   * Administrador de plataforma: su rol vive en el token, no en la
   * organización, y la API lo acepta en las rutas de administración.
   */
  isGlobalAdmin: boolean;
  /** Puede leer la bitácora de auditoría. */
  canAudit: boolean;
  /** Solo lectura: no debe ver acciones de escritura. */
  readOnly: boolean;
  has: (role: Role | Role[]) => boolean;
}

/**
 * Permisos del usuario en la organización activa.
 *
 * Se prefieren los roles de la organización (`useActiveOrg`) sobre los del token:
 * un consultor tiene rol `consultor_externo` en su propia organización pero
 * `admin_org` en la del cliente, y el token solo guarda los del hogar.
 */
export function usePermissions(): Permissions {
  const { user } = useAuth();
  const { org, organizations, orgId } = useActiveOrg();

  const roles = useMemo<Role[]>(() => {
    const active = organizations.find((o) => o.id === orgId);
    const source = active?.roles?.length ? active.roles : (org?.roles ?? user?.roles ?? []);
    return source as Role[];
  }, [organizations, orgId, org?.roles, user?.roles]);

  const has = useMemo(
    () => (role: Role | Role[]) => {
      const wanted = Array.isArray(role) ? role : [role];
      return wanted.some((r) => roles.includes(r));
    },
    [roles],
  );

  // El administrador de plataforma se reconoce por la marca del token
  // (`platform`), no por un rol: su autoridad no proviene de ninguna
  // organización. Se mantiene además `admin_global` porque es el nombre que usan
  // los `@RequireRoles` de la API y algún token antiguo todavía lo lleva.
  const isGlobalAdmin = user?.platform === true || !!user?.roles.includes('admin_global');

  // El objeto se memoiza: los consumidores lo usan en dependencias de efectos.
  return useMemo(
    () => ({
      roles,
      canWrite: has(WRITERS) || isGlobalAdmin,
      isAdmin: has(ADMINS) || isGlobalAdmin,
      isGlobalAdmin,
      canAudit: has(AUDITORS) || isGlobalAdmin,
      // Sin roles reconocidos se asume lectura: es el lado seguro.
      readOnly:
        !isGlobalAdmin &&
        (roles.length === 0 || roles.every((r) => r === 'solo_lectura')),
      has,
    }),
    [roles, has, isGlobalAdmin],
  );
}
