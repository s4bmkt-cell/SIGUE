import { api, ApiError, type DocumentFileItem } from '@/lib/api/client';
import { MAX_PROXY_FILE_MB } from '@/components/views/documents/document-meta';

/**
 * Sube el archivo de un documento eligiendo el camino disponible.
 *
 * Con almacenamiento en la nube el servidor firma una URL y el binario va del
 * navegador al almacén, sin cruzar el proxy `/api/*`: así se supera el límite
 * de 4,5 MB de las funciones de Vercel. Con almacenamiento en disco no hay URL
 * firmada y se usa la subida multipart clásica, limitada por ese mismo proxy.
 *
 * La confirmación es obligatoria en el camino directo: subir al almacén no crea
 * la fila, y sin ella el archivo quedaría sin registrar.
 */
export async function uploadDocumentFile(
  orgId: string,
  documentId: string,
  file: File,
): Promise<DocumentFileItem> {
  const ticket = await api.documentUploadTicket(orgId, documentId, {
    filename: file.name,
    mime: file.type || undefined,
    size: file.size,
  });

  if (!ticket) {
    // Sin subida directa el archivo cruza el proxy, que corta en 4,5 MB. Se
    // avisa aquí en lugar de dejar que Vercel devuelva un 413 sin explicación.
    if (file.size > MAX_PROXY_FILE_MB * 1024 * 1024) {
      throw new ApiError(
        413,
        `Este entorno no admite subidas directas: el archivo debe ser menor a ${MAX_PROXY_FILE_MB} MB`,
      );
    }
    return api.uploadDocumentFile(orgId, documentId, file);
  }

  await api.putToSignedUrl(ticket, file);
  return api.confirmDocumentUpload(orgId, documentId, {
    key: ticket.key,
    filename: ticket.filename,
    mime: file.type || undefined,
  });
}
