import { describe, expect, it } from 'vitest';
import { findMissingTranslations, messages } from './i18n';

describe('i18n', () => {
  it('es-MX y en-US están completos (sin claves faltantes)', () => {
    const missing = findMissingTranslations();
    expect(missing).toEqual([]);
  });

  it('tiene los dos idiomas de lanzamiento', () => {
    expect(Object.keys(messages)).toEqual(expect.arrayContaining(['es-MX', 'en-US']));
  });
});
