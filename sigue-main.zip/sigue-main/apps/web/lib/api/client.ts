// Cliente HTTP de SIGN.
// Consume la API local vía el proxy de Next (rewrites en next.config.mjs), por lo
// que la sesión viaja en cookies httpOnly del mismo origen: JavaScript nunca ve
// los tokens. `credentials: 'include'` es obligatorio para que las cookies fluyan.

const BASE = '/api/v1';
const TIMEOUT_MS = 20_000;

/**
 * Query string con solo los valores utilizables. Un filtro vacío en la URL
 * (`?status=`) cambia el comportamiento de la API: se omite en lugar de viajar.
 */
function queryString(params: object): string {
  const qs = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v !== undefined && v !== null && v !== '') qs.set(k, String(v));
  }
  const s = qs.toString();
  return s ? `?${s}` : '';
}

export class ApiError extends Error {
  constructor(
    public status: number,
    message: string,
    public code?: string,
  ) {
    super(message);
  }
}

/** Se dispara cuando la sesión ya no se puede renovar: la UI debe volver al login. */
export class SessionExpiredError extends ApiError {
  constructor() {
    super(401, 'Tu sesión expiró. Inicia sesión de nuevo.', 'session_expired');
  }
}

let onSessionExpired: (() => void) | null = null;
/** Registra el manejador que se invoca cuando el refresh falla definitivamente. */
export function setSessionExpiredHandler(handler: (() => void) | null) {
  onSessionExpired = handler;
}

/**
 * ¿Hay pista de sesión? Las cookies de token son `httpOnly`, así que JS no puede
 * leerlas; la API emite además `sigue_session=1` —sin secretos— para que las
 * pantallas públicas no pidan `/auth/me` ni un refresh condenado a 401 cuando el
 * visitante claramente no tiene sesión.
 */
function hasSessionHint(): boolean {
  if (typeof document === 'undefined') return false;
  return document.cookie.split('; ').some((c) => c.startsWith('sigue_session='));
}

/** ¿El navegador cree tener sesión? Útil para no consultar `/auth/me` sin motivo. */
export function mayHaveSession(): boolean {
  return hasSessionHint();
}

// La pista cambia cuando el servidor emite o borra las cookies de sesión. React
// no se entera por sí sola (las cookies httpOnly no disparan eventos), así que
// login y logout avisan a los suscriptores.
const sessionHintListeners = new Set<() => void>();

export function subscribeSessionHint(callback: () => void): () => void {
  sessionHintListeners.add(callback);
  return () => {
    sessionHintListeners.delete(callback);
  };
}

/** Notifica que la sesión se abrió o se cerró (tras login, MFA o logout). */
export function notifySessionChange(): void {
  sessionHintListeners.forEach((listener) => listener());
}

// Un único refresh en vuelo: si diez peticiones reciben 401 a la vez, comparten
// la misma promesa en lugar de rotar el refresh token diez veces (lo que
// dispararía la detección de reutilización y cerraría la sesión).
let refreshInFlight: Promise<boolean> | null = null;

async function refreshSession(): Promise<boolean> {
  // Aquí sí se intenta siempre: solo se llega tras un 401, así que una sesión
  // antigua sin pista de sesión (p. ej. desplegada antes de esta versión) debe
  // poder renovarse en lugar de perder la sesión.
  if (!refreshInFlight) {
    refreshInFlight = fetch(`${BASE}/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: '{}',
      credentials: 'include',
      cache: 'no-store',
    })
      .then((res) => res.ok)
      .catch(() => false)
      .finally(() => {
        refreshInFlight = null;
      });
  }
  return refreshInFlight;
}

interface RequestOptions extends RequestInit {
  /** Petición interna que no debe intentar refrescar (p. ej. el propio refresh). */
  skipRefresh?: boolean;
}

/**
 * Envía la petición con la sesión al día y devuelve la respuesta sin
 * interpretarla. La comparten las llamadas JSON y las descargas de texto.
 */
async function requestResponse(path: string, options: RequestOptions = {}): Promise<Response> {
  const { skipRefresh, ...init } = options;

  const send = async (): Promise<Response> => {
    const headers: Record<string, string> = { ...(init.headers as Record<string, string>) };
    // Solo se añade Content-Type si hay cuerpo: en GET es innecesario y en
    // multipart (FormData) el navegador debe fijar el boundary.
    if (init.body && !(init.body instanceof FormData)) {
      headers['Content-Type'] = 'application/json';
    }
    return fetch(`${BASE}${path}`, {
      ...init,
      headers,
      credentials: 'include',
      cache: 'no-store',
      signal: init.signal ?? AbortSignal.timeout(TIMEOUT_MS),
    });
  };

  let res = await send();

  // Access token vencido (10 min): se renueva y se reintenta una sola vez.
  if (res.status === 401 && !skipRefresh) {
    const renewed = await refreshSession();
    if (!renewed) {
      onSessionExpired?.();
      throw new SessionExpiredError();
    }
    res = await send();
    if (res.status === 401) {
      onSessionExpired?.();
      throw new SessionExpiredError();
    }
  }

  if (!res.ok) {
    let message = `Error ${res.status}`;
    let code: string | undefined;
    try {
      const body = await res.json();
      message = body.message ?? body.error?.message ?? message;
      code = body.code ?? body.error?.code;
      if (Array.isArray(message)) message = message.join('. ');
    } catch {
      /* cuerpo no JSON */
    }
    throw new ApiError(res.status, message, code);
  }

  return res;
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const res = await requestResponse(path, options);
  if (res.status === 204) return undefined as T;

  const text = await res.text();
  if (!text) return undefined as T;
  return JSON.parse(text) as T;
}

/**
 * Descarga de texto (CSV). Se pide con `fetch` en lugar de un `<a download>`
 * porque una respuesta de error del servidor no se puede mostrar: el navegador
 * abandonaría la aplicación para enseñar el JSON del fallo.
 */
async function requestText(path: string, options: RequestOptions = {}): Promise<string> {
  const res = await requestResponse(path, options);
  return res.text();
}


// ============ Tipos ============
export interface AuthUser {
  sub: string;
  email: string;
  name: string;
  roles: string[];
  orgId: string | null;
  /**
   * Administrador de plataforma (`User.isPlatformAdmin`). No es un rol de
   * organización: vive en el token y da acceso al catálogo de empresas.
   */
  platform?: boolean;
  /** Estado real del segundo factor; el token no lo lleva. */
  mfaEnabled?: boolean;
}

export interface TokensResponse {
  accessToken: string;
  refreshToken: string;
}

/** Datos para registrar un autenticador TOTP. */
export interface MfaEnrollment {
  secret: string;
  otpauthUrl: string;
  /** QR en `data:image/png;base64,...` generado por la API. */
  qrDataUrl: string;
  message: string;
}

export interface OrgSummary {
  id: string;
  name: string;
  plan: string;
  /** Roles del usuario en esa organización. */
  roles: string[];
  users: number;
  quotaUsers: number;
  storage: { usedGb: number; quotaGb: number };
  aiConsumption: { pct: number; used: string; quota: string };
}

export interface OrgProfile extends OrgSummary {
  legalName: string | null;
  country: string;
  lang: string;
  timezone: string;
  currency: string;
  status: string;
  createdAt: string;
}

export interface OrgBranch {
  id: string;
  orgId: string;
  name: string;
  country: string;
  state: string | null;
  city: string | null;
}

export interface OrgArea {
  id: string;
  orgId: string;
  branchId: string | null;
  parentId: string | null;
  name: string;
}

export interface MemberItem {
  id: string;
  userId: string;
  name: string;
  email: string;
  roles: string[];
  status: string;
  areaId: string | null;
  accessStart: string | null;
  accessEnd: string | null;
  createdAt: string;
  lastLoginAt: string | null;
}

export interface InvitationItem {
  id: string;
  email: string;
  role: string;
  status: string;
  expiresAt: string;
  accessEnd: string | null;
  createdAt: string;
}

export interface PendingInvitation {
  id: string;
  orgId: string;
  orgName: string;
  role: string;
  expiresAt: string;
  accessEnd: string | null;
  createdAt: string;
}

export interface RoleDefinition {
  code: string;
  labelKey: string;
  admin: boolean;
  readOnly: boolean;
}

// ============ Iteración 1: Normas, Diagnóstico, Contexto, Planificación ============
export interface Standard {
  id: string;
  code: string;
  title: string;
  edition: string;
  year: number;
  active: boolean;
}

export interface OrgStandard {
  id: string;
  standardId: string;
  status: string;
  scopeText: string | null;
  standard: Standard;
}

export interface RequirementWithStatus {
  id: string;
  code: string;
  title: string;
  kind: string;
  requirementText: string | null;
  level: string;
  weight: number;
}

export interface ComplianceSummary {
  standardId: string;
  total: number;
  implemented: number;
  pending: number;
  pct: number;
  byClause: { code: string; title: string; level: string; pct: number }[];
}

export interface DiagnosisResult {
  standardId: string;
  maturity: number;
  gap: number;
  evaluated: number;
  total: number;
  levels: Record<string, number>;
  recommendations: { clause: string; title: string; level: string; recommendation: string }[];
  plan: { id: string; title: string; tasks: { title: string; priority: string }[] };
}

export interface SwotItem {
  id: string;
  type: string;
  text: string;
}

export interface PestelItem {
  id: string;
  type: string;
  impact: string;
  text: string;
}

/** Metadatos comunes de un FODA o un PESTEL. */
interface AnalysisMeta {
  id: string;
  name: string;
  description: string | null;
  period: string | null;
  createdAt: string;
}

export interface SwotAnalysis extends AnalysisMeta {
  items: SwotItem[];
}

export interface PestelAnalysis extends AnalysisMeta {
  items: PestelItem[];
}

export interface ContextData {
  swotAnalyses: SwotAnalysis[];
  pestelAnalyses: PestelAnalysis[];
  parties: { id: string; name: string; needs: unknown; expectations: unknown; relevance: string }[];
  issues: { id: string; isInternal: boolean; text: string }[];
  legal: { id: string; source: string; reference: string; requirement: string }[];
  processes: { id: string; name: string; inputs: string | null; outputs: string | null }[];
}

export interface AnalysisInput {
  name: string;
  description?: string;
  period?: string;
}

export interface PlanningData {
  risks: {
    id: string;
    title: string;
    description: string | null;
    category: string | null;
    status: string;
    assessments: { id: string; score: number }[];
    treatments: { id: string; type: string; plan: string | null; status: string }[];
  }[];
  objectives: {
    id: string;
    title: string;
    status: string;
    kpis: { id: string; name: string; target: number | null; unit: string | null }[];
  }[];
  plans: {
    id: string;
    title: string;
    status: string;
    tasks: {
      id: string;
      title: string;
      priority: string;
      status: string;
      assigneeId?: string | null;
      dueDate?: string | null;
    }[];
  }[];
}

// ============ Auth ============
export interface LoginResult {
  mfaRequired: boolean;
  challengeId?: string;
  // El backend devuelve los tokens en el nivel superior (issueTokens), no anidados.
  accessToken?: string;
  refreshToken?: string;
}

export const api = {
  login: (email: string, password: string) =>
    request<LoginResult>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ email, password }),
      skipRefresh: true,
    }),

  verifyMfa: (challengeId: string, code: string) =>
    request<TokensResponse>('/auth/mfa/verify', {
      method: 'POST',
      body: JSON.stringify({ challengeId, code }),
      skipRefresh: true,
    }),

  refresh: () => request<TokensResponse>('/auth/refresh', { method: 'POST', body: '{}', skipRefresh: true }),

  logout: () => request<{ ok: boolean }>('/auth/logout', { method: 'POST', skipRefresh: true }),

  logoutAll: () => request<{ ok: boolean }>('/auth/logout-all', { method: 'POST' }),

  forgotPassword: (email: string) =>
    request<{ ok: boolean; message: string }>('/auth/password/forgot', {
      method: 'POST',
      body: JSON.stringify({ email }),
      skipRefresh: true,
    }),

  resetPassword: (token: string, password: string) =>
    request<{ ok: boolean; message: string }>('/auth/password/reset', {
      method: 'POST',
      body: JSON.stringify({ token, password }),
      skipRefresh: true,
    }),

  me: () => request<AuthUser>('/auth/me'),

  /** Genera (y persiste) la semilla TOTP pendiente, con su QR. */
  mfaSetup: () =>
    request<MfaEnrollment>('/auth/mfa/setup'),

  /** Confirma el código del autenticador y activa el MFA. */
  mfaConfirm: (code: string) =>
    request<{ ok: boolean; mfaEnabled: boolean; message: string }>('/auth/mfa/setup', {
      method: 'POST',
      body: JSON.stringify({ code }),
    }),

  /** Desactiva el MFA; exige un código vigente. */
  mfaDisable: (code: string) =>
    request<{ ok: boolean; mfaEnabled: boolean; message: string }>('/auth/mfa', {
      method: 'DELETE',
      body: JSON.stringify({ code }),
    }),

  myOrgs: () => request<{ organizations: OrgSummary[] }>('/orgs'),

  orgSummary: (orgId: string) =>
    request<OrgSummary>(`/orgs/${orgId}`),

  // ===== Organización, sucursales y áreas =====
  orgProfile: (orgId: string) => request<OrgProfile>(`/orgs/${orgId}/profile`),

  updateOrg: (orgId: string, data: Partial<Pick<OrgProfile, 'name' | 'legalName' | 'country' | 'lang' | 'timezone'>>) =>
    request<
      Pick<OrgProfile, 'id' | 'name' | 'legalName' | 'country' | 'lang' | 'timezone' | 'currency'>
    >(`/orgs/${orgId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  branches: (orgId: string) => request<OrgBranch[]>(`/orgs/${orgId}/branches`),

  createBranch: (orgId: string, data: { name: string; country?: string; state?: string; city?: string }) =>
    request<OrgBranch>(`/orgs/${orgId}/branches`, { method: 'POST', body: JSON.stringify(data) }),

  updateBranch: (orgId: string, branchId: string, data: { name: string; country?: string; state?: string; city?: string }) =>
    request<OrgBranch>(`/orgs/${orgId}/branches/${branchId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteBranch: (orgId: string, branchId: string) =>
    request<{ ok: boolean }>(`/orgs/${orgId}/branches/${branchId}`, { method: 'DELETE' }),

  areas: (orgId: string) => request<OrgArea[]>(`/orgs/${orgId}/areas`),

  createArea: (orgId: string, data: { name: string; branchId?: string; parentId?: string }) =>
    request<OrgArea>(`/orgs/${orgId}/areas`, { method: 'POST', body: JSON.stringify(data) }),

  updateArea: (orgId: string, areaId: string, data: { name: string; branchId?: string; parentId?: string }) =>
    request<OrgArea>(`/orgs/${orgId}/areas/${areaId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteArea: (orgId: string, areaId: string) =>
    request<{ ok: boolean }>(`/orgs/${orgId}/areas/${areaId}`, { method: 'DELETE' }),

  // ===== Miembros e invitaciones =====
  members: (orgId: string) => request<MemberItem[]>(`/orgs/${orgId}/members`),

  updateMember: (
    orgId: string,
    memberId: string,
    data: { roles?: string[]; status?: 'ACTIVE' | 'SUSPENDED'; accessEnd?: string | null },
  ) =>
    request<MemberItem>(`/orgs/${orgId}/members/${memberId}`, {
      method: 'PATCH',
      // Los campos van explícitos: con `whitelist` + `forbidNonWhitelisted` en la
      // API, cualquier propiedad ajena al DTO (p. ej. `memberId`, que ya viaja en
      // la ruta) tumba la petición con «property X should not exist».
      body: JSON.stringify({
        ...(data.roles ? { roles: data.roles } : {}),
        ...(data.status ? { status: data.status } : {}),
        ...(data.accessEnd !== undefined ? { accessEnd: data.accessEnd } : {}),
      }),
    }),

  removeMember: (orgId: string, memberId: string) =>
    request<{ ok: boolean }>(`/orgs/${orgId}/members/${memberId}`, { method: 'DELETE' }),

  invitations: (orgId: string) => request<InvitationItem[]>(`/orgs/${orgId}/invitations`),

  inviteMember: (orgId: string, data: { email: string; role: string; accessEnd?: string }) =>
    request<InvitationItem>(`/orgs/${orgId}/invitations`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  revokeInvitation: (orgId: string, invitationId: string) =>
    request<{ id: string; email: string; status: string }>(
      `/orgs/${orgId}/invitations/${invitationId}`,
      { method: 'DELETE' },
    ),

  resendInvitation: (orgId: string, invitationId: string) =>
    request<{ ok: boolean; expiresAt: string }>(
      `/orgs/${orgId}/invitations/${invitationId}/resend`,
      { method: 'POST' },
    ),

  roles: () => request<{ roles: string[]; definitions: RoleDefinition[] }>('/users/roles'),

  myInvitations: () =>
    request<{ invitations: PendingInvitation[] }>('/users/invitations'),

  acceptInvitation: (invitationId: string) =>
    request<{ orgId: string; orgName: string; role: string }>('/users/invitations/accept', {
      method: 'POST',
      body: JSON.stringify({ invitationId }),
    }),

  acceptInvitationToken: (token: string) =>
    request<{ orgId: string; orgName: string; role: string }>(
      '/users/invitations/accept-token',
      { method: 'POST', body: JSON.stringify({ token }) },
    ),

  previewInvitation: (token: string, email: string) =>
    request<{
      invitationId: string;
      orgId: string;
      orgName: string;
      role: string;
      accessEnd: string | null;
    }>('/users/invitations/preview', {
      method: 'POST',
      body: JSON.stringify({ token, email }),
      skipRefresh: true,
    }),

  register: (data: { name: string; email: string; password: string; inviteCode?: string }) =>
    request<{ ok: boolean; message: string; joinedOrg: { id: string; name: string } | null }>(
      '/auth/register',
      { method: 'POST', body: JSON.stringify(data), skipRefresh: true },
    ),

  // ===== Iteración 1 =====
  standards: (orgId: string) =>
    request<{ active: OrgStandard[]; catalog: Standard[] }>(`/orgs/${orgId}/standards`),

  activateStandard: (orgId: string, standardId: string, scopeText?: string) =>
    request<OrgStandard>(`/orgs/${orgId}/standards/${standardId}/activate`, {
      method: 'POST',
      body: JSON.stringify({ scopeText }),
    }),

  updateStandardScope: (orgId: string, standardId: string, scopeText: string) =>
    request<OrgStandard>(`/orgs/${orgId}/standards/${standardId}/scope`, {
      method: 'PATCH',
      body: JSON.stringify({ scopeText }),
    }),

  requirements: (orgId: string, standardId: string) =>
    request<RequirementWithStatus[]>(`/orgs/${orgId}/standards/${standardId}/requirements`),

  setRequirementLevel: (orgId: string, standardId: string, clauseId: string, level: string) =>
    request(`/orgs/${orgId}/standards/${standardId}/requirements/${clauseId}/level`, {
      method: 'PUT',
      body: JSON.stringify({ level }),
    }),

  compliance: (orgId: string, standardId: string) =>
    request<ComplianceSummary>(`/orgs/${orgId}/standards/${standardId}/compliance`),

  runDiagnosis: (orgId: string, standardId: string) =>
    request<DiagnosisResult>(`/orgs/${orgId}/diagnosis/${standardId}/run`, {
      method: 'POST',
    }),

  getDiagnosis: (orgId: string, standardId: string) =>
    request<DiagnosisResult>(`/orgs/${orgId}/diagnosis/${standardId}`),

  context: (orgId: string) =>
    request<ContextData>(`/orgs/${orgId}/context`),

  // --- FODA: análisis y elementos ---
  createSwotAnalysis: (orgId: string, data: AnalysisInput) =>
    request<SwotAnalysis>(`/orgs/${orgId}/context/swot/analyses`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateSwotAnalysis: (
    orgId: string,
    id: string,
    data: { name?: string; description?: string | null; period?: string | null },
  ) =>
    request<SwotAnalysis>(`/orgs/${orgId}/context/swot/analyses/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteSwotAnalysis: (orgId: string, id: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/context/swot/analyses/${id}`, {
      method: 'DELETE',
    }),

  addSwot: (orgId: string, analysisId: string, type: string, text: string) =>
    request<SwotItem>(`/orgs/${orgId}/context/swot`, {
      method: 'POST',
      body: JSON.stringify({ analysisId, type, text }),
    }),

  // --- PESTEL: análisis y factores ---
  createPestelAnalysis: (orgId: string, data: AnalysisInput) =>
    request<PestelAnalysis>(`/orgs/${orgId}/context/pestel/analyses`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updatePestelAnalysis: (
    orgId: string,
    id: string,
    data: { name?: string; description?: string | null; period?: string | null },
  ) =>
    request<PestelAnalysis>(`/orgs/${orgId}/context/pestel/analyses/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deletePestelAnalysis: (orgId: string, id: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/context/pestel/analyses/${id}`, {
      method: 'DELETE',
    }),

  addPestel: (orgId: string, data: { analysisId: string; type: string; impact?: string; text: string }) =>
    request<PestelItem>(`/orgs/${orgId}/context/pestel`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updatePestel: (orgId: string, id: string, data: { type?: string; impact?: string; text?: string }) =>
    request(`/orgs/${orgId}/context/pestel/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deletePestel: (orgId: string, id: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/context/pestel/${id}`, {
      method: 'DELETE',
    }),

  addParty: (orgId: string, data: { name: string; needs?: string; expectations?: string; relevance?: string }) =>
    request(`/orgs/${orgId}/context/parties`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateSwot: (orgId: string, id: string, data: { type?: string; text?: string }) =>
    request(`/orgs/${orgId}/context/swot/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteSwot: (orgId: string, id: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/context/swot/${id}`, {
      method: 'DELETE',
    }),

  updateParty: (
    orgId: string,
    id: string,
    data: { name?: string; needs?: string | null; expectations?: string | null; relevance?: string },
  ) =>
    request(`/orgs/${orgId}/context/parties/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteParty: (orgId: string, id: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/context/parties/${id}`, {
      method: 'DELETE',
    }),

  addIssue: (orgId: string, data: { isInternal: boolean; text: string }) =>
    request(`/orgs/${orgId}/context/issues`, { method: 'POST', body: JSON.stringify(data) }),

  updateIssue: (orgId: string, id: string, data: { isInternal?: boolean; text?: string }) =>
    request(`/orgs/${orgId}/context/issues/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteIssue: (orgId: string, id: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/context/issues/${id}`, {
      method: 'DELETE',
    }),

  addLegal: (
    orgId: string,
    data: { source: string; reference: string; requirement: string; appliesTo?: string },
  ) =>
    request(`/orgs/${orgId}/context/legal`, { method: 'POST', body: JSON.stringify(data) }),

  updateLegal: (
    orgId: string,
    id: string,
    data: {
      source?: string;
      reference?: string;
      requirement?: string;
      appliesTo?: string | null;
      status?: string;
    },
  ) =>
    request(`/orgs/${orgId}/context/legal/${id}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteLegal: (orgId: string, id: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/context/legal/${id}`, {
      method: 'DELETE',
    }),

  addProcess: (orgId: string, data: { name: string; inputs?: string; outputs?: string }) =>
    request(`/orgs/${orgId}/context/processes`, { method: 'POST', body: JSON.stringify(data) }),

  updateProcess: (
    orgId: string,
    id: string,
    data: { name?: string; inputs?: string | null; outputs?: string | null; areaId?: string | null },
  ) =>
    request(`/orgs/${orgId}/context/processes/${id}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteProcess: (orgId: string, id: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/context/processes/${id}`, {
      method: 'DELETE',
    }),

  planning: (orgId: string) =>
    request<PlanningData>(`/orgs/${orgId}/planning`),

  addRisk: (orgId: string, data: { title: string; description?: string; category?: string }) =>
    request(`/orgs/${orgId}/planning/risks`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  assessRisk: (orgId: string, riskId: string, likelihood: number, impact: number) =>
    request(`/orgs/${orgId}/planning/risks/${riskId}/assess`, {
      method: 'POST',
      body: JSON.stringify({ likelihood, impact }),
    }),

  addObjective: (orgId: string, title: string, dueDate?: string) =>
    request(`/orgs/${orgId}/planning/objectives`, {
      method: 'POST',
      body: JSON.stringify({ title, dueDate }),
    }),

  updateObjective: (
    orgId: string,
    objectiveId: string,
    data: { title?: string; dueDate?: string | null; status?: string },
  ) =>
    request(`/orgs/${orgId}/planning/objectives/${objectiveId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteObjective: (orgId: string, objectiveId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/planning/objectives/${objectiveId}`, {
      method: 'DELETE',
    }),

  updateRisk: (
    orgId: string,
    riskId: string,
    data: { title?: string; description?: string | null; category?: string | null; status?: string },
  ) =>
    request(`/orgs/${orgId}/planning/risks/${riskId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteRisk: (orgId: string, riskId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/planning/risks/${riskId}`, {
      method: 'DELETE',
    }),

  addTreatment: (orgId: string, riskId: string, data: { type: string; plan: string }) =>
    request(`/orgs/${orgId}/planning/risks/${riskId}/treatments`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateTreatment: (
    orgId: string,
    treatmentId: string,
    data: { type?: string; plan?: string | null; dueDate?: string | null; status?: string },
  ) =>
    request(`/orgs/${orgId}/planning/treatments/${treatmentId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteTreatment: (orgId: string, treatmentId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/planning/treatments/${treatmentId}`, {
      method: 'DELETE',
    }),

  updateKpi: (
    orgId: string,
    kpiId: string,
    data: { name?: string; formula?: string | null; target?: number | null; frequency?: string | null; unit?: string | null },
  ) =>
    request(`/orgs/${orgId}/planning/kpis/${kpiId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteKpi: (orgId: string, kpiId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/planning/kpis/${kpiId}`, {
      method: 'DELETE',
    }),

  addKpiResult: (orgId: string, kpiId: string, data: { period: string; value: number; evidenceId?: string }) =>
    request(`/orgs/${orgId}/planning/kpis/${kpiId}/results`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  addKpi: (orgId: string, objectiveId: string, data: { name: string; target?: number; unit?: string }) =>
    request(`/orgs/${orgId}/planning/objectives/${objectiveId}/kpis`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  plans: (orgId: string) =>
    request<PlanningData['plans']>(`/orgs/${orgId}/planning/plans`),

  addTask: (orgId: string, planId: string, data: { title: string; priority?: string; dueDate?: string }) =>
    request(`/orgs/${orgId}/planning/plans/${planId}/tasks`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  createPlan: (orgId: string, data: { title: string; standardId?: string; startDate?: string; endDate?: string }) =>
    request(`/orgs/${orgId}/planning/plans`, { method: 'POST', body: JSON.stringify(data) }),

  updatePlan: (
    orgId: string,
    planId: string,
    data: { title?: string; status?: string; startDate?: string | null; endDate?: string | null },
  ) =>
    request(`/orgs/${orgId}/planning/plans/${planId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deletePlan: (orgId: string, planId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/planning/plans/${planId}`, {
      method: 'DELETE',
    }),

  updateTaskStatus: (orgId: string, taskId: string, status: string) =>
    request(`/orgs/${orgId}/planning/tasks/${taskId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  deleteTask: (orgId: string, taskId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/planning/tasks/${taskId}`, {
      method: 'DELETE',
    }),

  // ===== Iteración 2: Documentos =====
  documents: (orgId: string, filters: DocumentFilters = {}) =>
    request<DocumentPage>(`/orgs/${orgId}/documents${queryString(filters)}`, undefined),

  /** Documentos con revisión vencida o próxima, según el reloj del servidor. */
  docReviewAlerts: (orgId: string) =>
    request<DocReviewAlerts>(`/orgs/${orgId}/documents/review-alerts`),

  /**
   * Inventario en CSV. Se descarga con `fetch` (cookie httpOnly incluida) para
   * poder avisar en pantalla si el servidor rechaza la exportación —por
   * ejemplo, cuando el inventario filtrado excede el tope— en lugar de navegar
   * fuera de la aplicación y mostrar el error en crudo.
   */
  documentsCsv: (orgId: string, filters: DocumentFilters = {}) =>
    requestText(`/orgs/${orgId}/documents/export.csv${queryString(filters)}`),

  createDocument: (
    orgId: string,
    data: {
      code: string;
      title: string;
      type?: string;
      content?: string;
      areaId?: string | null;
      validityUntil?: string | null;
      reviewDate?: string | null;
      sourceProvider?: string | null;
      sourceRef?: string | null;
      /** Sedes a las que aplica; vacío = toda la organización. */
      branchIds?: string[];
    },
  ) =>
    request<DocumentItem>(`/orgs/${orgId}/documents`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateDocument: (
    orgId: string,
    documentId: string,
    data: {
      title?: string;
      type?: string;
      areaId?: string | null;
      validityUntil?: string | null;
      reviewDate?: string | null;
      sourceProvider?: string | null;
      sourceRef?: string | null;
      branchIds?: string[];
    },
  ) =>
    request<DocumentItem>(`/orgs/${orgId}/documents/${documentId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  /** Adjunta el archivo original del documento (multipart; una sola pieza). */
  uploadDocumentFile: (orgId: string, documentId: string, file: File) => {
    const form = new FormData();
    form.append('file', file, file.name);
    return request<DocumentFileItem>(`/orgs/${orgId}/documents/${documentId}/files`, {
      method: 'POST',
      body: form,
    });
  },

  /**
   * Pide permiso para subir directo al almacén. `null` cuando el servidor no
   * firma URLs (almacenamiento en disco): entonces se usa `uploadDocumentFile`.
   */
  documentUploadTicket: (
    orgId: string,
    documentId: string,
    data: { filename: string; mime?: string; size: number },
  ) =>
    request<UploadTicket | null>(`/orgs/${orgId}/documents/${documentId}/files/ticket`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  confirmDocumentUpload: (
    orgId: string,
    documentId: string,
    data: { key: string; filename: string; mime?: string },
  ) =>
    request<DocumentFileItem>(`/orgs/${orgId}/documents/${documentId}/files/confirm`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  /**
   * Sube el binario a la URL firmada. Va directo al almacén, así que no pasa por
   * el proxy de la web ni por la API: es lo que permite superar el límite de
   * 4,5 MB de las funciones de Vercel.
   */
  putToSignedUrl: (ticket: UploadTicket, file: File) =>
    fetch(ticket.url, {
      method: ticket.method,
      headers: ticket.headers,
      body: file,
    }).then((res) => {
      if (!res.ok) {
        throw new ApiError(res.status, `No se pudo subir el archivo (${res.status})`);
      }
    }),

  documentFiles: (orgId: string, documentId: string) =>
    request<DocumentFileItem[]>(`/orgs/${orgId}/documents/${documentId}/files`),

  /** Capacidad de subida del entorno (directa o limitada por el proxy). */
  documentUploadCapabilities: (orgId: string) =>
    request<UploadCapabilities>(`/orgs/${orgId}/documents/upload-capabilities`),

  deleteDocumentFile: (orgId: string, fileId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/documents/files/${fileId}`, {
      method: 'DELETE',
    }),

  /** URL de descarga; la cookie httpOnly viaja al navegar, sin exponer tokens. */
  documentFileUrl: (orgId: string, fileId: string) =>
    `${BASE}/orgs/${orgId}/documents/files/${fileId}/download`,

  distributeDocument: (
    orgId: string,
    documentId: string,
    data: { areaId?: string | null; userId?: string | null; channel?: string },
  ) =>
    request<{ id: string }>(`/orgs/${orgId}/documents/${documentId}/distributions`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  undoDistribution: (orgId: string, distributionId: string) =>
    request<{ ok: boolean; deleted: string }>(
      `/orgs/${orgId}/documents/distributions/${distributionId}`,
      { method: 'DELETE' },
    ),

  notifyReview: (orgId: string, documentId: string) =>
    request<{ id: string }>(`/orgs/${orgId}/documents/${documentId}/notify-review`, {
      method: 'POST',
    }),


  deleteDocument: (orgId: string, documentId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/documents/${documentId}`, {
      method: 'DELETE',
    }),

  obsoleteDocument: (orgId: string, documentId: string) =>
    request<DocumentItem>(`/orgs/${orgId}/documents/${documentId}/obsolete`, {
      method: 'POST',
    }),

  docAction: (
    orgId: string,
    documentId: string,
    action: 'submit' | 'approve' | 'publish',
    comment?: string,
  ) =>
    request<DocumentItem>(`/orgs/${orgId}/documents/${documentId}/${action}`, {
      method: 'POST',
      // El comentario viaja tal cual: la API lo guarda en el paso del flujo.
      body: JSON.stringify(comment ? { comment } : {}),
    }),

  newDocumentVersion: (orgId: string, documentId: string, content: string, changesNote?: string) =>
    request<DocumentItem>(`/orgs/${orgId}/documents/${documentId}/versions`, {
      method: 'POST',
      body: JSON.stringify({ content, changesNote }),
    }),

  documentHistory: (orgId: string, documentId: string) =>
    request<DocumentHistory>(`/orgs/${orgId}/documents/${documentId}/history`),

  // ===== Iteración 2: Evidencias =====
  evidences: (orgId: string) =>
    request<EvidenceItem[]>(`/orgs/${orgId}/evidences`),

  createEvidence: (orgId: string, data: { title: string; classification?: string; reviewDate?: string; restrictionFlags?: { noDownload?: boolean; noAiSend?: boolean; mask?: boolean } }) =>
    request<EvidenceItem>(`/orgs/${orgId}/evidences`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateEvidence: (
    orgId: string,
    evidenceId: string,
    data: { title?: string; classification?: string; reviewDate?: string | null; restrictionFlags?: { noDownload?: boolean; noAiSend?: boolean; mask?: boolean } },
  ) =>
    request<EvidenceItem>(`/orgs/${orgId}/evidences/${evidenceId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteEvidence: (orgId: string, evidenceId: string) =>
    request<{ ok: boolean; deleted: string; freedBytes: number }>(
      `/orgs/${orgId}/evidences/${evidenceId}`,
      { method: 'DELETE' },
    ),

  /** Sube uno o varios archivos reales (multipart; el navegador fija el boundary). */
  uploadEvidenceFiles: (orgId: string, evidenceId: string, files: File[]) => {
    const form = new FormData();
    for (const file of files) form.append('files', file, file.name);
    return request<EvidenceFile | { files: EvidenceFile[] }>(
      `/orgs/${orgId}/evidences/${evidenceId}/files`,
      { method: 'POST', body: form },
    );
  },

  deleteEvidenceFile: (orgId: string, fileId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/evidences/files/${fileId}`, {
      method: 'DELETE',
    }),

  /** URL de descarga; la cookie httpOnly viaja al navegar, sin exponer tokens. */
  evidenceDownloadUrl: (orgId: string, fileId: string) =>
    `${BASE}/orgs/${orgId}/evidences/files/${fileId}/download`,

  linkEvidence: (orgId: string, evidenceId: string, clauseIds: string[]) =>
    request(`/orgs/${orgId}/evidences/${evidenceId}/requirements`, {
      method: 'POST',
      body: JSON.stringify({ clauseIds }),
    }),

  unlinkEvidence: (orgId: string, evidenceId: string, clauseId: string) =>
    request(`/orgs/${orgId}/evidences/${evidenceId}/requirements/${clauseId}`, {
      method: 'DELETE',
    }),

  requirementEvidence: (orgId: string, clauseId: string) =>
    request<EvidenceItem[]>(`/orgs/${orgId}/evidences/requirement/${clauseId}`),

  // ===== Iteración 3: Auditorías, NC, Revisión, Tableros =====
  audits: (orgId: string) =>
    request<AuditItem[]>(`/orgs/${orgId}/audits`),

  createAudit: (orgId: string, data: { title: string; scope?: string; startDate?: string; endDate?: string }) =>
    request<AuditItem>(`/orgs/${orgId}/audits`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  auditReport: (orgId: string, auditId: string) =>
    request<AuditReport>(`/orgs/${orgId}/audits/${auditId}/report`),

  updateAudit: (
    orgId: string,
    auditId: string,
    data: { title?: string; scope?: string | null; startDate?: string | null; endDate?: string | null },
  ) =>
    request<AuditItem>(`/orgs/${orgId}/audits/${auditId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteAudit: (orgId: string, auditId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/audits/${auditId}`, {
      method: 'DELETE',
    }),

  generateChecklist: (orgId: string, auditId: string) =>
    request(`/orgs/${orgId}/audits/${auditId}/checklist`, { method: 'POST' }),

  setChecklistResult: (orgId: string, itemId: string, data: { result: string; comment?: string }) =>
    request(`/orgs/${orgId}/audits/checklist/${itemId}/result`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  addFinding: (
    orgId: string,
    auditId: string,
    data: { type: string; description: string; clauseId?: string; classification?: string },
  ) =>
    request(`/orgs/${orgId}/audits/${auditId}/findings`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateFinding: (
    orgId: string,
    findingId: string,
    data: { status?: string; description?: string; classification?: string; type?: string },
  ) =>
    request(`/orgs/${orgId}/audits/findings/${findingId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteFinding: (orgId: string, findingId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/audits/findings/${findingId}`, {
      method: 'DELETE',
    }),

  closeAudit: (orgId: string, auditId: string) =>
    request<AuditItem>(`/orgs/${orgId}/audits/${auditId}/close`, { method: 'POST' }),

  ncs: (orgId: string) =>
    request<NcItem[]>(`/orgs/${orgId}/nc`),

  registerNc: (orgId: string, data: { title: string; description?: string; priority?: string }) =>
    request<NcItem>(`/orgs/${orgId}/nc`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  ncCorrection: (orgId: string, ncId: string, description: string) =>
    request(`/orgs/${orgId}/nc/${ncId}/corrections`, {
      method: 'POST',
      body: JSON.stringify({ description }),
    }),

  ncRootCause: (orgId: string, ncId: string, data: { causes?: string[]; analysis?: string }) =>
    request(`/orgs/${orgId}/nc/${ncId}/root-causes`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  ncAction: (orgId: string, ncId: string, data: { title: string }) =>
    request(`/orgs/${orgId}/nc/${ncId}/corrective-actions`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  ncVerify: (orgId: string, actionId: string, result: 'EFFECTIVE' | 'NOT_EFFECTIVE') =>
    request(`/orgs/${orgId}/nc/corrective-actions/${actionId}/verify`, {
      method: 'POST',
      body: JSON.stringify({ result }),
    }),

  ncLesson: (orgId: string, ncId: string, lesson: string) =>
    request(`/orgs/${orgId}/nc/${ncId}/lessons`, {
      method: 'POST',
      body: JSON.stringify({ lesson }),
    }),

  ncClose: (orgId: string, ncId: string, note?: string) =>
    request(`/orgs/${orgId}/nc/${ncId}/close`, {
      method: 'POST',
      body: JSON.stringify({ note }),
    }),

  ncReopen: (orgId: string, ncId: string, reason: string) =>
    request(`/orgs/${orgId}/nc/${ncId}/reopen`, {
      method: 'POST',
      body: JSON.stringify({ reason }),
    }),

  updateNc: (
    orgId: string,
    ncId: string,
    data: { title?: string; description?: string | null; priority?: string; classification?: string; status?: string },
  ) =>
    request(`/orgs/${orgId}/nc/${ncId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteNc: (orgId: string, ncId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/nc/${ncId}`, { method: 'DELETE' }),

  deleteNcAction: (orgId: string, ncId: string, actionId: string) =>
    request<{ ok: boolean; deleted: string; remaining: number }>(
      `/orgs/${orgId}/nc/${ncId}/corrective-actions/${actionId}`,
      { method: 'DELETE' },
    ),

  reviews: (orgId: string) =>
    request<ReviewItem[]>(`/orgs/${orgId}/mgmt-reviews`),

  createReview: (orgId: string, data: { code: string; period: string }) =>
    request<ReviewItem>(`/orgs/${orgId}/mgmt-reviews`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  addAgreement: (orgId: string, reviewId: string, decision: string) =>
    request(`/orgs/${orgId}/mgmt-reviews/${reviewId}/agreements`, {
      method: 'POST',
      body: JSON.stringify({ decision }),
    }),

  updateAgreement: (
    orgId: string,
    agreementId: string,
    data: { decision?: string; assigneeId?: string | null; dueDate?: string | null; status?: string },
  ) =>
    request(`/orgs/${orgId}/mgmt-reviews/agreements/${agreementId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  completeAgreement: (orgId: string, agreementId: string) =>
    request(`/orgs/${orgId}/mgmt-reviews/agreements/${agreementId}/complete`, { method: 'PATCH' }),

  deleteAgreement: (orgId: string, agreementId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/mgmt-reviews/agreements/${agreementId}`, {
      method: 'DELETE',
    }),

  addReviewEntry: (
    orgId: string,
    reviewId: string,
    data: { entryType: string; source?: string; content?: unknown },
  ) =>
    request(`/orgs/${orgId}/mgmt-reviews/${reviewId}/entries`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  deleteReviewEntry: (orgId: string, entryId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/mgmt-reviews/entries/${entryId}`, {
      method: 'DELETE',
    }),

  setReviewStatus: (orgId: string, reviewId: string, status: string) =>
    request(`/orgs/${orgId}/mgmt-reviews/${reviewId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  closeReview: (orgId: string, reviewId: string) =>
    request(`/orgs/${orgId}/mgmt-reviews/${reviewId}/close`, { method: 'POST' }),

  deleteReview: (orgId: string, reviewId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/mgmt-reviews/${reviewId}`, {
      method: 'DELETE',
    }),

  dashboardSummary: (orgId: string) =>
    request<DashboardSummary>(`/orgs/${orgId}/dashboard/summary`),

  dashboardCompliance: (orgId: string) =>
    request<ClauseComplianceRow[]>(`/orgs/${orgId}/dashboard/compliance`),

  // ===== Iteración 4: ISO 27001, ISO 22301, Notificaciones =====
  isms: (orgId: string) =>
    request<IsmsData>(`/orgs/${orgId}/isms`),

  addAsset: (orgId: string, data: { name: string; type?: string; classification?: string; location?: string }) =>
    request(`/orgs/${orgId}/isms/assets`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateAsset: (
    orgId: string,
    assetId: string,
    data: { name?: string; type?: string; classification?: string; location?: string | null; status?: string },
  ) =>
    request(`/orgs/${orgId}/isms/assets/${assetId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteAsset: (orgId: string, assetId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/isms/assets/${assetId}`, {
      method: 'DELETE',
    }),

  addIsmsIncident: (orgId: string, data: { title: string; description?: string; severity?: string }) =>
    request(`/orgs/${orgId}/isms/incidents`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateIsmsIncident: (
    orgId: string,
    incidentId: string,
    data: { status?: string; severity?: string; description?: string | null },
  ) =>
    request(`/orgs/${orgId}/isms/incidents/${incidentId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteIsmsIncident: (orgId: string, incidentId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/isms/incidents/${incidentId}`, {
      method: 'DELETE',
    }),

  updateSoa: (orgId: string, controlId: string, data: { applicable?: boolean; implementationStatus?: string; justification?: string }) =>
    request(`/orgs/${orgId}/isms/soa/${controlId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  /** Declaración de aplicabilidad de una norma concreta (27001 o 42001). */
  soaByStandard: (orgId: string, standardId?: string) =>
    request<SoaControlRow[]>(
      `/orgs/${orgId}/isms/soa/by-standard${standardId ? `?standardId=${encodeURIComponent(standardId)}` : ''}`,
    ),

  bcms: (orgId: string) =>
    request<BcmsData>(`/orgs/${orgId}/bcms`),

  addBia: (orgId: string, data: { processName: string; criticality?: string; rtoHours?: number; rpoHours?: number }) =>
    request(`/orgs/${orgId}/bcms/bia`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  addContinuityPlan: (orgId: string, data: { title: string; strategy?: string; content?: string; biaId?: string }) =>
    request(`/orgs/${orgId}/bcms/plans`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateBia: (
    orgId: string,
    biaId: string,
    data: { processName?: string; criticality?: string; rtoHours?: number | null; rpoHours?: number | null; status?: string },
  ) =>
    request(`/orgs/${orgId}/bcms/bia/${biaId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteBia: (orgId: string, biaId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/bcms/bia/${biaId}`, {
      method: 'DELETE',
    }),

  updateContinuityPlan: (
    orgId: string,
    planId: string,
    data: { title?: string; strategy?: string | null; content?: string | null; status?: string },
  ) =>
    request(`/orgs/${orgId}/bcms/plans/${planId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteContinuityPlan: (orgId: string, planId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/bcms/plans/${planId}`, {
      method: 'DELETE',
    }),

  addExercise: (orgId: string, data: { title: string; type?: string; scheduledAt?: string }) =>
    request(`/orgs/${orgId}/bcms/exercises`, { method: 'POST', body: JSON.stringify(data) }),

  recordExercise: (
    orgId: string,
    exerciseId: string,
    data: { result: string; status?: string; planId?: string | null },
  ) =>
    request(`/orgs/${orgId}/bcms/exercises/${exerciseId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteExercise: (orgId: string, exerciseId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/bcms/exercises/${exerciseId}`, {
      method: 'DELETE',
    }),

  // ===== ISO/IEC 20000-1 (SGS de TI) =====
  itsm: (orgId: string) => request<ItsmData>(`/orgs/${orgId}/itsm`),

  addService: (
    orgId: string,
    data: { code: string; name: string; description?: string; category?: string; criticality?: string },
  ) => request(`/orgs/${orgId}/itsm/services`, { method: 'POST', body: JSON.stringify(data) }),

  updateService: (
    orgId: string,
    serviceId: string,
    data: { name?: string; description?: string | null; category?: string; criticality?: string; status?: string },
  ) => request(`/orgs/${orgId}/itsm/services/${serviceId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteService: (orgId: string, serviceId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/itsm/services/${serviceId}`, {
      method: 'DELETE',
    }),

  addSla: (
    orgId: string,
    data: { serviceCode: string; customer: string; responseHours?: number; resolutionHours?: number; availabilityPct?: number },
  ) => request(`/orgs/${orgId}/itsm/slas`, { method: 'POST', body: JSON.stringify(data) }),

  updateSla: (
    orgId: string,
    slaId: string,
    data: { customer?: string; responseHours?: number; resolutionHours?: number; availabilityPct?: number; status?: string },
  ) => request(`/orgs/${orgId}/itsm/slas/${slaId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteSla: (orgId: string, slaId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/itsm/slas/${slaId}`, {
      method: 'DELETE',
    }),

  addServiceRequest: (
    orgId: string,
    data: {
      folio: string;
      serviceCode?: string;
      type?: string;
      title: string;
      description?: string;
      priority?: string;
    },
  ) => request(`/orgs/${orgId}/itsm/requests`, { method: 'POST', body: JSON.stringify(data) }),

  updateServiceRequest: (
    orgId: string,
    requestId: string,
    data: {
      title?: string;
      description?: string | null;
      type?: string;
      priority?: string;
      status?: string;
      assigneeId?: string | null;
    },
  ) => request(`/orgs/${orgId}/itsm/requests/${requestId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteServiceRequest: (orgId: string, requestId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/itsm/requests/${requestId}`, {
      method: 'DELETE',
    }),

  // ===== ISO 37001 (gestión antisoborno) =====
  abms: (orgId: string) => request<AbmsData>(`/orgs/${orgId}/abms`),

  addBriberyRisk: (
    orgId: string,
    data: { area: string; activity: string; likelihood: number; impact: number; mitigation?: string },
  ) => request(`/orgs/${orgId}/abms/risks`, { method: 'POST', body: JSON.stringify(data) }),

  updateBriberyRisk: (
    orgId: string,
    riskId: string,
    data: {
      area?: string;
      activity?: string;
      likelihood?: number;
      impact?: number;
      mitigation?: string | null;
      status?: string;
    },
  ) => request(`/orgs/${orgId}/abms/risks/${riskId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteBriberyRisk: (orgId: string, riskId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/abms/risks/${riskId}`, {
      method: 'DELETE',
    }),

  upsertBriberyControl: (
    orgId: string,
    data: { code: string; title: string; description?: string; status?: string },
  ) => request(`/orgs/${orgId}/abms/controls`, { method: 'POST', body: JSON.stringify(data) }),

  updateBriberyControl: (
    orgId: string,
    controlId: string,
    data: { status?: string; description?: string | null },
  ) => request(`/orgs/${orgId}/abms/controls/${controlId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteBriberyControl: (orgId: string, controlId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/abms/controls/${controlId}`, {
      method: 'DELETE',
    }),

  addBriberyIncident: (
    orgId: string,
    data: { title: string; description?: string; severity?: string; detectedAt?: string },
  ) => request(`/orgs/${orgId}/abms/incidents`, { method: 'POST', body: JSON.stringify(data) }),

  updateBriberyIncident: (
    orgId: string,
    incidentId: string,
    data: {
      title?: string;
      description?: string | null;
      severity?: string;
      status?: string;
      resolution?: string | null;
    },
  ) => request(`/orgs/${orgId}/abms/incidents/${incidentId}`, { method: 'PATCH', body: JSON.stringify(data) }),

  deleteBriberyIncident: (orgId: string, incidentId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/abms/incidents/${incidentId}`, {
      method: 'DELETE',
    }),

  notifications: (orgId: string) =>
    request<NotificationsData>(`/orgs/${orgId}/notifications`),

  markAllNotificationsRead: (orgId: string) =>
    request(`/orgs/${orgId}/notifications/read-all`, {
      method: 'PATCH',
    }),

  markNotificationRead: (orgId: string, notificationId: string) =>
    request(`/orgs/${orgId}/notifications/${notificationId}/read`, { method: 'PATCH' }),

  markNotificationUnread: (orgId: string, notificationId: string) =>
    request(`/orgs/${orgId}/notifications/${notificationId}/unread`, { method: 'PATCH' }),

  deleteNotification: (orgId: string, notificationId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/notifications/${notificationId}`, {
      method: 'DELETE',
    }),

  clearNotifications: (orgId: string) =>
    request<{ ok: boolean }>(`/orgs/${orgId}/notifications`, { method: 'DELETE' }),

  // ===== ISO 42001 =====
  aiSystems: (orgId: string) =>
    request<AiSystemsData>(`/orgs/${orgId}/ai-systems`),

  addAiSystem: (orgId: string, data: { name: string; type?: string; vendor?: string; description?: string; dataClassification?: string }) =>
    request(`/orgs/${orgId}/ai-systems`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateAiLifecycle: (orgId: string, systemId: string, stage: string) =>
    request(`/orgs/${orgId}/ai-systems/${systemId}/lifecycle`, {
      method: 'PATCH',
      body: JSON.stringify({ stage }),
    }),

  updateAiSystem: (
    orgId: string,
    systemId: string,
    data: { name?: string; type?: string; vendor?: string | null; description?: string | null; dataClassification?: string },
  ) =>
    request(`/orgs/${orgId}/ai-systems/${systemId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteAiSystem: (orgId: string, systemId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/ai-systems/${systemId}`, {
      method: 'DELETE',
    }),

  addAiUseCase: (
    orgId: string,
    data: { systemId: string; name: string; purpose?: string; supervision?: string },
  ) =>
    request(`/orgs/${orgId}/ai-systems/use-cases`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateAiUseCase: (
    orgId: string,
    useCaseId: string,
    data: { name?: string; purpose?: string | null; supervision?: string },
  ) =>
    request(`/orgs/${orgId}/ai-systems/use-cases/${useCaseId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteAiUseCase: (orgId: string, useCaseId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/ai-systems/use-cases/${useCaseId}`, {
      method: 'DELETE',
    }),

  addAiRisk: (orgId: string, data: { systemId: string; title: string; description?: string; likelihood?: number; impact?: number }) =>
    request(`/orgs/${orgId}/ai-systems/risks`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  updateAiRisk: (
    orgId: string,
    riskId: string,
    data: { title?: string; description?: string | null; likelihood?: number; impact?: number },
  ) =>
    request(`/orgs/${orgId}/ai-systems/risks/${riskId}`, {
      method: 'PATCH',
      body: JSON.stringify(data),
    }),

  deleteAiRisk: (orgId: string, riskId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/ai-systems/risks/${riskId}`, {
      method: 'DELETE',
    }),

  addAiControl: (
    orgId: string,
    riskId: string,
    data: { title: string; description?: string; source?: string },
  ) =>
    request(`/orgs/${orgId}/ai-systems/risks/${riskId}/controls`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  deleteAiControl: (orgId: string, controlId: string) =>
    request<{ ok: boolean; deleted: string }>(`/orgs/${orgId}/ai-systems/controls/${controlId}`, {
      method: 'DELETE',
    }),

  // ===== Iteración 5: Capa de IA =====
  aiUseCases: (orgId: string) =>
    request<AiUseCaseItem[]>(`/orgs/${orgId}/ai/use-cases`),

  aiInvoke: (orgId: string, data: { useCase: string; module?: string; entity?: string; context: Record<string, unknown> }) =>
    request<AiInteractionResult>(`/orgs/${orgId}/ai/interactions`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),

  aiDecide: (
    orgId: string,
    interactionId: string,
    decision: string,
    opts?: { note?: string; modifiedOutput?: string },
  ) =>
    request(`/orgs/${orgId}/ai/interactions/${interactionId}/decision`, {
      method: 'POST',
      body: JSON.stringify({ decision, note: opts?.note, modifiedOutput: opts?.modifiedOutput }),
    }),

  aiSearch: (orgId: string, q: string) =>
    request<AiSearchResult[]>(`/orgs/${orgId}/ai/search?q=${encodeURIComponent(q)}`),

  aiInteractions: (orgId: string) =>
    request<AiInteractionLog[]>(`/orgs/${orgId}/ai/interactions`),

  aiSetUseCaseStatus: (orgId: string, useCaseId: string, status: 'ENABLED' | 'DISABLED') =>
    request(`/orgs/${orgId}/ai/use-cases/${useCaseId}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  aiIncidents: (orgId: string) =>
    request<AiIncidentItem[]>(`/orgs/${orgId}/ai/incidents`),

  // ===== Iteración 6: Suscripción + Exportación =====
  subscription: (orgId: string) =>
    request<SubscriptionData>(`/orgs/${orgId}/billing/subscription`),

  billingPlans: (orgId: string) =>
    request<PlanItem[]>(`/orgs/${orgId}/billing/plans`),

  changePlan: (orgId: string, planCode: string) =>
    request<ChangePlanResult>(`/orgs/${orgId}/billing/plan`, {
      method: 'POST',
      body: JSON.stringify({ planCode }),
    }),

  billingUsage: (orgId: string) => request<UsageSnapshot>(`/orgs/${orgId}/billing/usage`),

  // ===== Auditoría =====
  auditLog: (
    orgId: string,
    params: {
      page?: number;
      pageSize?: number;
      action?: string;
      entity?: string;
      entityId?: string;
      actorId?: string;
    } = {},
  ) => {
    const qs = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) {
      if (v !== undefined && v !== null && v !== '') qs.set(k, String(v));
    }
    const suffix = qs.toString() ? `?${qs}` : '';
    return request<AuditPage>(`/orgs/${orgId}/audit${suffix}`);
  },

  auditIntegrity: (orgId: string) =>
    request<{ intact: boolean; count: number; brokenAt?: number; reason?: string }>(
      `/orgs/${orgId}/audit/integrity`,
    ),

  exportAll: (orgId: string) =>
    request<ExportData>(`/orgs/${orgId}/export/all`),

  // ===== C1: Firma electrónica =====
  acceptDocument: (orgId: string, documentId: string) =>
    request<SignatureItem>(`/orgs/${orgId}/documents/${documentId}/accept`, {
      method: 'POST',
    }),

  documentSignatures: (orgId: string, documentId: string) =>
    request<SignatureItem[]>(`/orgs/${orgId}/documents/${documentId}/signatures`),

  verifySignature: (orgId: string, signatureId: string) =>
    request<SignatureVerification>(
      `/orgs/${orgId}/documents/signatures/${signatureId}/verify`,
    ),

  revokeSignature: (orgId: string, signatureId: string, reason?: string) =>
    request<{ ok: boolean; revoked: string }>(
      `/orgs/${orgId}/documents/signatures/${signatureId}`,
      { method: 'DELETE', body: JSON.stringify({ reason }) },
    ),

  // ===== C2: Plantillas =====
  templates: (orgId: string, kind?: string) =>
    request<TemplateItem[]>(`/orgs/${orgId}/documents/templates${kind ? `?kind=${kind}` : ''}`),

  createFromTemplate: (orgId: string, templateId: string) =>
    request<DocumentItem>(`/orgs/${orgId}/documents/templates/${templateId}/create`, {
      method: 'POST',
    }),

  // ===== C3: Consola Consultor =====
  consultantClients: () =>
    request<ConsultantClients>(`/consultant/clients`),

  consultantConsolidated: () =>
    request<ConsultantConsolidated>(`/consultant/consolidated`),

  consultantClientSummary: (orgId: string) =>
    request<ConsultantClientSummary>(`/consultant/clients/${orgId}/summary`),

  // ===== Panel de plataforma =====
  // Rutas sin `orgId` a propósito: el administrador de plataforma no pertenece
  // a las organizaciones que administra.
  platformOrgs: (q?: string) =>
    request<PlatformOrgRow[]>(`/platform/orgs${q ? `?q=${encodeURIComponent(q)}` : ''}`),

  platformOrg: (id: string) => request<PlatformOrgDetail>(`/platform/orgs/${id}`),

  platformCreateOrg: (input: PlatformCreateOrgInput) =>
    request<PlatformCreateOrgResult>('/platform/orgs', {
      method: 'POST',
      body: JSON.stringify(input),
    }),

  platformSetOrgStatus: (id: string, status: 'ACTIVE' | 'SUSPENDED') =>
    request<{ id: string; name: string; status: string }>(`/platform/orgs/${id}/status`, {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }),

  platformPlans: () => request<PlatformPlan[]>('/platform/plans'),

  platformStandards: () => request<PlatformStandard[]>('/platform/standards'),
};

// Tipos del panel de plataforma
export interface PlatformOrgRow {
  id: string;
  name: string;
  legalName: string | null;
  plan: string;
  status: string;
  users: number;
  standards: number;
  storageGb: number;
  createdAt: string;
}

export interface PlatformOrgDetail extends PlatformOrgRow {
  country: string;
  currency: string;
  admins: { id: string; name: string; email: string; lastLoginAt: string | null }[];
  subscription: { planCode: string; status: string; periodEnd: string | null } | null;
}

export interface PlatformCreateOrgInput {
  name: string;
  legalName?: string;
  plan: string;
  standards?: string[];
  adminName: string;
  adminEmail: string;
}

export interface PlatformCreateOrgResult {
  orgId: string;
  adminEmail: string;
  /** Solo se devuelve si la cuenta se creó ahora; nunca se vuelve a mostrar. */
  temporaryPassword: string | null;
  templates: number;
}

export interface PlatformPlan {
  code: string;
  name: string;
  monthlyUsd: number;
  users: number;
  storageGb?: number;
  standards: number;
  aiTokens: number;
}

export interface PlatformStandard {
  code: string;
  title: string;
  edition: string | null;
}


// Tipos C3
export interface ConsultantClientSummary {
  compliancePct: number;
  implemented: number;
  totalRequirements: number;
  ncOpen: number;
  upcomingAudits: number;
  pendingTasks: number;
  openRisks: number;
  objectives: number;
  health: 'GOOD' | 'WATCH' | 'CRITICAL';
}

export interface ConsultantClient {
  orgId: string;
  name: string;
  planCode: string;
  roles: string[];
  accessEnd: string | null;
  summary: ConsultantClientSummary;
}

export interface ConsultantClients {
  clients: ConsultantClient[];
}

export interface ConsultantConsolidated {
  totalClients: number;
  avgCompliance: number;
  totalNC: number;
  totalPendingTasks: number;
  clientsOnTrack: number;
  clients: ConsultantClient[];
}

export interface TemplateItem {
  id: string;
  code: string;
  title: string;
  kind: string;
  version: string;
  content: { sections?: { heading: string; body: string }[] };
}

export interface SignatureItem {
  id: string;
  version: string;
  signerName: string | null;
  signerEmail: string | null;
  kind: string; // APPROVAL | ACCEPTANCE
  contentHash: string;
  signedAt: string;
}

// Tipos Iteración 6
export interface SubscriptionData {
  subscription: {
    planCode: string;
    planName: string;
    status: string;
    periodStart: string | null;
    periodEnd: string | null;
    cfdiRef: string | null;
    monthlyUsd: number;
    /** `local` = sin pasarela real; `stripe` cuando se configuran claves. */
    paymentProvider: string;
    livePayments: boolean;
  };
  quotas: {
    users: { used: number; active: number; pending: number; quota: number; pct: number };
    storageGb: { used: number; quota: number; pct: number };
    standards: { used: number; quota: number; pct: number };
    aiTokens: { used: number; quota: number; pct: number; period: string };
  };
}

export interface UsageSnapshot {
  planCode: string;
  limits: PlanItem;
  seats: number;
  pendingInvitations: number;
  standards: number;
  storageGb: number;
  aiTokens: number;
  period: string;
}

export interface ChangePlanResult {
  applied: boolean;
  /** Presente cuando el proveedor es real: hay que completar el pago. */
  checkout: { mode: 'local' | 'live'; ref: string; url: string; amountUsd: number } | null;
  planCode: string;
  message: string;
  usage?: SubscriptionData;
}

export interface PlanItem {
  code: string;
  name: string;
  users: number;
  storageGb: number;
  standards: number;
  aiTokens: number;
  monthlyUsd: number;
}

export interface ExportData {
  exportId: string;
  exportedAt: string;
  size: number;
  data: Record<string, unknown>;
}

// Tipos Iteración 5
export interface AiUseCaseItem {
  id: string;
  code: string;
  name: string;
  purpose: string | null;
  module: string | null;
  supervisionLevel: string;
  status: string;
  monthlyQuota: number | null;
  spentTokens: number;
  quotaUsedPct: number;
}

export interface AiInteractionResult {
  interactionId: string;
  status: string;
  output: string;
  sources: { ref: string; title: string }[];
  model: string;
  promptVersion: number;
  decision: string;
}

export interface AiSearchResult {
  id: string;
  title: string;
  content: string | null;
  sourceType: string;
  similarity: number;
}

export interface AiInteractionLog {
  id: string;
  module: string | null;
  decision: string;
  status: string;
  createdAt: string;
  useCase: { code: string; name: string };
  sources: { ref: string }[];
}

export interface AiIncidentItem {
  id: string;
  type: string;
  severity: string;
  description: string;
  status: string;
  createdAt: string;
}

// Tipos ISO 42001
export interface AiSystemsData {
  systems: {
    id: string;
    name: string;
    type: string;
    vendor: string | null;
    description: string | null;
    dataClassification: string;
    lifecycleStage: string;
    status: string;
  }[];
  useCases: { id: string; name: string; purpose: string | null; supervision: string; status: string; system: { name: string } }[];
  assessments: { id: string; riskLevel: string; status: string; system: { name: string } }[];
  risks: {
    id: string;
    systemId: string;
    title: string;
    likelihood: number;
    impact: number;
    score: number;
    status: string;
    system: { name: string };
    controls: { id: string; title: string; source: string; status: string }[];
  }[];
  events: { id: string; eventType: string; description: string | null; createdAt: string }[];
  summary: { total: number; deployed: number; highRisk: number; pendingAssessments: number };
}

// Tipos de Iteración 4
export interface IsmsData {
  assets: {
    id: string;
    name: string;
    type: string;
    classification: string;
    location: string | null;
    status: string;
    createdAt: string;
  }[];
  soa: { id: string; controlCode: string; controlName: string; applicable: boolean; justification: string | null; implementationStatus: string }[];
  incidents: {
    id: string;
    title: string;
    description: string | null;
    severity: string;
    status: string;
    detectedAt: string;
    resolvedAt: string | null;
  }[];
  summary: { total: number; applicable: number; implemented: number; soaProgress: number };
  /** Avance de la SOA por norma (ISO 27001 y ISO 42001 tienen Anexo A propio). */
  soaByStandard: {
    id: string;
    code: string;
    edition: string;
    total: number;
    applicable: number;
    implemented: number;
    progress: number;
  }[];
}

/** Fila de la Declaración de Aplicabilidad con la norma a la que pertenece. */
export interface SoaControlRow {
  id: string;
  standardId: string;
  controlCode: string;
  controlName: string;
  applicable: boolean;
  justification: string | null;
  implementationStatus: string;
  standard: { code: string; edition: string; title: string };
}


export interface BcmsData {
  bias: { id: string; processName: string; criticality: string; rtoHours: number | null; rpoHours: number | null; status: string }[];
  plans: {
    id: string;
    title: string;
    strategy: string | null;
    content: string | null;
    status: string;
    lastTestedAt: string | null;
  }[];
  exercises: {
    id: string;
    title: string;
    type: string;
    planId: string | null;
    scheduledAt: string | null;
    status: string;
    result: string | null;
  }[];
  summary: { processes: number; critical: number; activePlans: number };
}

export interface ItsmData {
  services: {
    id: string;
    code: string;
    name: string;
    description: string | null;
    category: string;
    criticality: string;
    status: string;
    ownerId: string | null;
  }[];
  slas: {
    id: string;
    serviceCode: string;
    customer: string;
    responseHours: number;
    resolutionHours: number;
    availabilityPct: string;
    status: string;
  }[];
  requests: {
    id: string;
    folio: string;
    serviceCode: string | null;
    type: string;
    title: string;
    description: string | null;
    priority: string;
    status: string;
    assigneeId: string | null;
    resolvedAt: string | null;
    createdAt: string;
  }[];
  summary: {
    services: number;
    slas: number;
    openRequests: number;
    incidents: number;
    resolutionRate: number;
  };
}

export interface AbmsData {
  risks: {
    id: string;
    area: string;
    activity: string;
    likelihood: number;
    impact: number;
    score: number;
    mitigation: string | null;
    status: string;
  }[];
  controls: {
    id: string;
    code: string;
    title: string;
    description: string | null;
    status: string;
  }[];
  incidents: {
    id: string;
    title: string;
    description: string | null;
    severity: string;
    status: string;
    resolution: string | null;
    detectedAt: string;
  }[];
  summary: {
    risks: number;
    highRisks: number;
    controls: number;
    implemented: number;
    controlProgress: number;
    openIncidents: number;
  };
}

export interface NotificationsData {
  items: { id: string; type: string; title: string; body: string | null; entity: string | null; readAt: string | null; createdAt: string }[];
  unread: number;
}
// Tipos de Iteración 3
export interface AuditItem {
  id: string;
  title: string;
  scope: string | null;
  startDate: string | null;
  endDate: string | null;
  status: string;
  program: { year: number };
  findings: FindingItem[];
  checklists: { id: string; items: ChecklistResult[] }[];
}

export interface FindingItem {
  id: string;
  type: string;
  description: string;
  classification: string;
  status: string;
}

export interface ChecklistResult {
  id: string;
  question: string;
  result: string | null;
}

export interface AuditReport {
  audit: { id: string; title: string; status: string };
  findings: FindingItem[];
  byType: Record<string, number>;
  checklistProgress: number;
}

export interface NcItem {
  id: string;
  folio: string;
  title: string;
  description: string | null;
  priority: string;
  status: string;
  reportedAt: string;
  corrections: { id: string; description: string }[];
  rootCauses: { id: string; method: string; analysis: string | null; causes: unknown }[];
  actions: { id: string; title: string; status: string; verifications: { id: string; result: string }[] }[];
  lessons: { id: string; lesson: string }[];
}

export interface ReviewItem {
  id: string;
  code: string;
  period: string;
  date: string;
  status: string;
  entries: { id: string; entryType: string; source: string | null }[];
  agreements: { id: string; decision: string; dueDate: string | null; status: string }[];
}

export interface AuditEvent {
  id: string;
  orgId: string | null;
  actorId: string | null;
  action: string;
  entity: string | null;
  entityId: string | null;
  before: unknown;
  after: unknown;
  ip: string | null;
  userAgent: string | null;
  chainKey: string;
  seq: number;
  prevHash: string;
  hash: string;
  createdAt: string;
}

export interface AuditPage {
  items: AuditEvent[];
  page: number;
  pageSize: number;
  total: number;
  pages: number;
}

export interface DashboardSummary {  compliance: { pct: number; implemented: number; pending: number; total: number };
  nc: { open: number; critical: number };
  audits: { upcoming: number };
  plans: { active: number; pendingTasks: number };
  objectives: { total: number };
}

/** Una fila del avance por cláusula, ya separada por norma. */
export interface ClauseComplianceRow {
  standard: string;
  code: string;
  count: number;
  implemented: number;
  pct: number;
}

// Tipos de Iteración 2
export interface DocumentItem {
  id: string;
  code: string;
  title: string;
  type: string;
  status: string;
  areaId: string | null;
  ownerId: string | null;
  /** Fin de vigencia: pasado, el documento exige revisión. */
  validityUntil?: string | null;
  /** Fecha de la revisión periódica pendiente. */
  reviewDate?: string | null;
  /** Procedencia de un documento de origen externo (type = EXTERNO). */
  sourceProvider?: string | null;
  sourceRef?: string | null;
  /** Sedes a las que aplica; vacío = toda la organización. */
  branchIds?: string[];
  createdAt?: string;
  updatedAt?: string;
  versions?: { id: string; version: string; content: string | null; changesNote: string | null }[];
  signatures?: SignatureItem[];
  /** Archivos adjuntos (metadatos); el binario se descarga aparte. */
  files?: DocumentFileItem[];
}

export interface DocumentFileItem {
  id: string;
  filename: string;
  size: number;
  mime: string | null;
  sha256?: string | null;
  createdAt?: string;
}

/** Permiso temporal para subir directo al almacenamiento (Azure Blob). */
export interface UploadTicket {
  key: string;
  url: string;
  method: 'PUT';
  headers: Record<string, string>;
  expiresAt: string;
  /** Nombre saneado por el servidor; es el que se guarda al confirmar. */
  filename: string;
}

/** Qué permite el entorno: subida directa al almacén o solo por el proxy. */
export interface UploadCapabilities {
  direct: boolean;
  /** Tope efectivo del entorno, en MB. */
  maxMb: number;
  /** Tope del proxy `/api/*` cuando no hay subida directa. */
  proxyMaxMb: number;
}

/**
 * Filtros del inventario. Viajan a la API: con miles de documentos no se puede
 * filtrar en el navegador lo que la base ya sabe acotar.
 */
export interface DocumentFilters {
  status?: string;
  type?: string;
  areaId?: string;
  q?: string;
  due?: 'overdue' | 'soon';
  page?: number;
  pageSize?: number;
}

export interface DocumentPage {
  items: DocumentItem[];
  page: number;
  pageSize: number;
  total: number;
  pages: number;
}

/** Revisión pendiente o próxima; el conteo lo hace el servidor. */
export interface DocReviewAlerts {
  items: {
    id: string;
    code: string;
    title: string;
    reviewDate: string;
    validityUntil: string | null;
    status: string;
  }[];
  overdue: number;
  dueSoon: number;
  soonUntil: string;
}

export interface DocumentHistory extends Omit<DocumentItem, 'versions'> {
  versions: {
    id: string;
    version: string;
    content: string | null;
    changesNote: string | null;
    createdAt: string;
  }[];
  workflowSteps: {
    id: string;
    step: string;
    action: string;
    comment: string | null;
    at: string;
    assigneeId: string | null;
  }[];
  distributions: {
    id: string;
    channel: string;
    at: string;
    areaId: string | null;
    userId: string | null;
  }[];
  signatures?: SignatureItem[];
}

/** Resultado de verificar una firma: la firma puede ser válida y el texto no. */
export interface SignatureVerification {
  valid: boolean;
  contentIntact: boolean;
  version: string;
  signerName: string | null;
  signedAt: string;
}

export interface EvidenceFile {
  id: string;
  blobName: string;
  size: number;
  sha256: string | null;
  mime: string | null;
  version?: number;
  createdAt?: string;
}

export interface EvidenceItem {
  id: string;
  title: string;
  type: string;
  classification: string;
  validityUntil: string | null;
  reviewDate: string | null;
  restrictionFlags: { noDownload?: boolean; noAiSend?: boolean; mask?: boolean } | null;
  files: EvidenceFile[];
  // `clauseId` es la clave del vínculo (el backend borra por evidenceId+clauseId);
  // `id` es el id de la fila de unión y no sirve para desvincular.
  requirements: { id: string; clauseId: string; clause: { code: string } }[];
}
