import type { Locale } from '@/lib/i18n';

/**
 * Etiquetas legibles de los roles de organización.
 *
 * La lista de códigos debe coincidir con `ORG_ROLES` del API
 * (`apps/api/src/common/roles.ts`). Vive en un solo lugar para que la barra
 * superior y la administración de usuarios no se desincronicen.
 */
export const ROLE_LABELS: Record<string, { es: string; en: string }> = {
  admin_org: { es: 'Administrador', en: 'Administrator' },
  resp_sgi: { es: 'Responsable SGI', en: 'IMS manager' },
  resp_norma: { es: 'Responsable de norma', en: 'Standard owner' },
  resp_proceso: { es: 'Responsable de proceso', en: 'Process owner' },
  resp_riesgos: { es: 'Responsable de riesgos', en: 'Risk owner' },
  controlador_doc: { es: 'Controlador documental', en: 'Document controller' },
  auditor_interno: { es: 'Auditor interno', en: 'Internal auditor' },
  resp_accion: { es: 'Responsable de acción', en: 'Action owner' },
  alta_direccion: { es: 'Alta dirección', en: 'Top management' },
  colaborador: { es: 'Colaborador', en: 'Contributor' },
  consultor_externo: { es: 'Consultor externo', en: 'External consultant' },
  auditor_externo: { es: 'Auditor externo', en: 'External auditor' },
  solo_lectura: { es: 'Solo lectura', en: 'Read only' },
};

/** Traduce un código de rol; si no se reconoce, devuelve el código tal cual. */
export function roleLabel(code: string, locale: Locale): string {
  const entry = ROLE_LABELS[code];
  return entry ? (locale === 'es-MX' ? entry.es : entry.en) : code;
}
