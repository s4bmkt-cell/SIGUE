import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

const here = dirname(fileURLToPath(import.meta.url));

// En Vercel el runtime lo monta la plataforma a partir del build estándar: el
// directorio `standalone` no se usa y solo estorba al rastreo de dependencias.
// El resto de destinos (imagen Docker) sí lo necesitan.
const onVercel = Boolean(process.env.VERCEL);

/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  // El proxy `/api/*` → API vive en `app/api/[...path]/route.ts`, no en
  // `rewrites`. Un rewrite se resuelve al construir la imagen y deja la URL de
  // la API grabada dentro del build; el route handler la lee en tiempo de
  // ejecución (`API_INTERNAL_URL`), así que la misma imagen sirve en cualquier
  // entorno. Además reenvía la IP del cliente para que el rate limit siga
  // siendo por persona y no por contenedor.
  //
  // `standalone` genera un servidor mínimo con solo las dependencias usadas: la
  // imagen final no necesita `node_modules` completo.
  ...(onVercel ? {} : { output: 'standalone' }),
  // En un monorepo el rastreo debe partir de la raíz para resolver el workspace.
  outputFileTracingRoot: join(here, '..', '..'),
};

export default nextConfig;
