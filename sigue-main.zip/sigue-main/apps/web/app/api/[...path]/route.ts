import type { NextRequest } from 'next/server';

/**
 * Proxy same-origin hacia la API.
 *
 * Existe por dos razones:
 *  1. Las cookies de sesión son `httpOnly` y `SameSite=Lax`: el navegador solo
 *     las envía al mismo origen, así que la web y la API deben verse como uno.
 *  2. La URL de la API se resuelve **en tiempo de ejecución** (`API_INTERNAL_URL`),
 *     no al construir la imagen. Un `rewrite` de `next.config` se hornea en el
 *     build y obligaría a reconstruir la imagen por cada entorno.
 *
 * El cuerpo y la respuesta se transmiten en streaming (las descargas de
 * evidencias no caben en memoria) y se reenvía la IP del cliente para que el
 * rate limit de la API siga siendo por persona y no por contenedor.
 */
export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

const API_ORIGIN = (
  process.env.API_INTERNAL_URL ??
  process.env.NEXT_PUBLIC_API_URL ??
  'http://localhost:3001'
).replace(/\/$/, '');

/** Cabeceras de salto a salto: no se reenvían, son de la conexión, no del mensaje. */
const HOP_BY_HOP = new Set([
  'connection',
  'keep-alive',
  'proxy-authenticate',
  'proxy-authorization',
  'te',
  'trailer',
  'trailers',
  'transfer-encoding',
  'upgrade',
  'host',
  'content-length',
]);

/**
 * Cabeceras del cliente que no deben llegar a la API.
 *
 * `expect` es la trampa de las subidas grandes: curl (y otros clientes) añaden
 * `Expect: 100-continue` a partir de ~1 MB, y undici —el `fetch` de Node—
 * rechaza esa cabecera con `NotSupportedError`, así que la subida moría en el
 * proxy con un 502 genérico. Es una cabecera de la conexión, no del mensaje.
 */
const DROP_REQUEST = new Set([...HOP_BY_HOP, 'accept-encoding', 'cookie', 'expect']);

/** Cabeceras de respuesta que gestiona Next o el cliente HTTP. */
const DROP_RESPONSE = new Set([...HOP_BY_HOP, 'content-encoding', 'connection']);

async function proxy(req: NextRequest, context: { params: Promise<{ path: string[] }> }) {
  const { path } = await context.params;
  const target = new URL(`${API_ORIGIN}/api/${path.join('/')}`);
  target.search = req.nextUrl.search;

  const headers = new Headers();
  req.headers.forEach((value, key) => {
    if (!DROP_REQUEST.has(key.toLowerCase())) headers.set(key, value);
  });

  // La sesión viaja en cookies httpOnly; se reenvían tal cual.
  const cookie = req.headers.get('cookie');
  if (cookie) headers.set('cookie', cookie);

  // Cadena de proxies: la primera entrada es el cliente real. La API confía en
  // un único salto (este proxy) y usa `x-forwarded-for` para el rate limit.
  const forwardedFor = req.headers.get('x-forwarded-for');
  const clientIp = forwardedFor?.split(',')[0]?.trim() || req.headers.get('x-real-ip');
  if (clientIp) headers.set('x-forwarded-for', clientIp);
  headers.set('x-forwarded-host', req.headers.get('host') ?? '');
  headers.set('x-forwarded-proto', req.nextUrl.protocol.replace(':', ''));

  const method = req.method.toUpperCase();
  const hasBody = method !== 'GET' && method !== 'HEAD';
  // El cuerpo se materializa antes de reenviarlo. Pasar el `ReadableStream` de
  // la petición directamente a `fetch` funciona en subidas pequeñas, pero rompe
  // a partir de ~1 MB: la petición falla y el navegador solo ve un 502. Como la
  // plataforma ya tiene el cuerpo en memoria (y limita el tamaño a ~4,5 MB), se
  // envía como un bloque con longitud conocida.
  const body = hasBody ? Buffer.from(await req.arrayBuffer()) : undefined;

  let upstream: Response;
  try {
    upstream = await fetch(target, {
      method,
      headers,
      body,
      redirect: 'manual',
      cache: 'no-store',
    });
  } catch (error) {
    // La API no responde (arrancando o caída): el cliente recibe un 502 claro
    // en lugar de un error de red opaco. El detalle va al log del servidor, que
    // es el único sitio donde se puede diagnosticar sin exponerlo al navegador.
    console.error(`[proxy] ${method} ${target.pathname} falló:`, error);
    return Response.json(
      { statusCode: 502, message: 'La API no está disponible' },
      { status: 502 },
    );
  }

  const responseHeaders = new Headers();
  upstream.headers.forEach((value, key) => {
    if (!DROP_RESPONSE.has(key.toLowerCase()) && key.toLowerCase() !== 'set-cookie') {
      responseHeaders.append(key, value);
    }
  });
  // Varias cookies (access + refresh + pista) deben llegar por separado.
  const setCookies = upstream.headers.getSetCookie?.() ?? [];
  for (const value of setCookies) responseHeaders.append('set-cookie', value);

  return new Response(upstream.body, {
    status: upstream.status,
    headers: responseHeaders,
  });
}

export {
  proxy as GET,
  proxy as POST,
  proxy as PUT,
  proxy as PATCH,
  proxy as DELETE,
  proxy as HEAD,
  proxy as OPTIONS,
};
