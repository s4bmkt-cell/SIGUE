'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { Button } from '@/components/ui/button';

/**
 * Restablecimiento de contraseña con el token que llega por correo.
 * El token se consume una sola vez; al guardar, la API cierra todas las sesiones.
 */
export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<div className="min-h-screen grid place-items-center text-ink-soft">Cargando…</div>}>
      <ResetPasswordForm />
    </Suspense>
  );
}

function ResetPasswordForm() {
  const { t } = useI18n();
  const router = useRouter();
  const token = useSearchParams().get('token') ?? '';

  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    if (password !== confirm) {
      setError(t.auth.passwordsDontMatch);
      return;
    }
    setLoading(true);
    try {
      await api.resetPassword(token, password);
      setDone(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : t.auth.resetInvalid);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen grid place-items-center bg-page px-4">
      <div className="w-full max-w-md bg-white border border-line rounded-card shadow-card p-8">
        <h1 className="text-2xl font-extrabold text-navy">{t.auth.resetTitle}</h1>
        <p className="text-sm text-ink-soft mt-1 mb-6">{t.auth.resetSubtitle}</p>

        {!token ? (
          <p className="text-sm text-danger" role="alert">
            {t.auth.resetInvalid}
          </p>
        ) : done ? (
          <>
            <p className="text-sm text-ok" role="status">
              {t.auth.resetDone}
            </p>
            <Button className="w-full mt-6" onClick={() => router.push('/login')}>
              {t.auth.backToLogin}
            </Button>
          </>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
              {t.auth.newPassword}
              <input
                type="password"
                autoComplete="new-password"
                required
                minLength={8}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="h-10 rounded-btn border border-line px-3 text-sm"
              />
            </label>
            <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
              {t.auth.confirmPassword}
              <input
                type="password"
                autoComplete="new-password"
                required
                minLength={8}
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                className="h-10 rounded-btn border border-line px-3 text-sm"
              />
            </label>
            {error && (
              <p className="text-sm text-danger" role="alert">
                {error}
              </p>
            )}
            <Button className="w-full" type="submit" disabled={loading || token === ''}>
              {loading ? t.common.loading : t.auth.resetSubmit}
            </Button>
          </form>
        )}

        {!done && (
          <Link href="/login" className="block text-center text-sm text-info mt-6">
            {t.auth.backToLogin}
          </Link>
        )}
      </div>
    </div>
  );
}
