'use client';

import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useEffect, useRef, useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useAuth } from '@/components/providers/auth-provider';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';

interface Preview {
  invitationId: string;
  orgId: string;
  orgName: string;
  role: string;
  accessEnd: string | null;
}

/**
 * Aceptación de una invitación llegada por correo.
 *
 * El token se valida sin sesión (para mostrar a qué organización y rol invita) y,
 * si la persona no tiene cuenta, se registra en el mismo paso con el correo
 * invitado. El backend exige que el correo coincida: el enlace no sirve para
 * apropiarse de una invitación ajena.
 */
export default function AcceptInvitationPage() {
  return (
    <Suspense fallback={<div className="min-h-screen grid place-items-center text-ink-soft">…</div>}>
      <AcceptInvitation />
    </Suspense>
  );
}

function AcceptInvitation() {
  const { t } = useI18n();
  const { user, loading: authLoading, signIn, signOut, refreshUser } = useAuth();
  const router = useRouter();
  const token = useSearchParams().get('token') ?? '';

  const [preview, setPreview] = useState<Preview | null>(null);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [mode, setMode] = useState<'login-required' | 'register'>('login-required');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [accepted, setAccepted] = useState<string | null>(null);
  /** Falló el canje automático: normalmente la sesión abierta es de otra persona. */
  const [sessionMismatch, setSessionMismatch] = useState(false);

  const roleLabel = (code: string) => code.replace(/_/g, ' ');

  // Con sesión, el token se canjea en cuanto se conoce al usuario. Sin sesión no
  // se consulta nada: la validación se hace contra el correo que escriba.
  const triedRef = useRef(false);
  useEffect(() => {
    if (!token || authLoading || !user || triedRef.current) return;
    triedRef.current = true;
    let active = true;
    api
      .acceptInvitationToken(token)
      .then((res) => {
        if (!active) return;
        setAccepted(res.orgName);
        refreshUser().catch(() => undefined);
      })
      .catch((e: unknown) => {
        if (!active) return;
        // El backend distingue "otro correo" (la sesión es de otra persona) de
        // "enlace inválido". En el primer caso se ofrece cambiar de cuenta.
        setPreviewError(e instanceof Error ? e.message : t.invitation.invalid);
        setSessionMismatch(true);
      });
    return () => {
      active = false;
    };
  }, [token, user, authLoading, refreshUser, t.invitation.invalid]);

  async function switchAccount() {
    await signOut();
    setSessionMismatch(false);
    setPreviewError(null);
    setEmail('');
    setPreview(null);
  }

  function validatePreview(candidateEmail: string) {
    if (!token || !candidateEmail) return;
    api
      .previewInvitation(token, candidateEmail)
      .then((res) => {
        setPreview(res);
        setPreviewError(null);
      })
      .catch((e: unknown) => {
        setPreview(null);
        setPreviewError(e instanceof Error ? e.message : t.invitation.invalid);
      });
  }

  async function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      await api.register({ name, email: email.trim().toLowerCase(), password, inviteCode: token });
      const signed = await signIn(email.trim().toLowerCase(), password);
      if (!signed.ok) throw new Error(signed.error);
      router.push('/');
    } catch (err) {
      setError(err instanceof Error ? err.message : t.invitation.error);
    } finally {
      setBusy(false);
    }
  }

  const field = 'h-11 w-full rounded-btn border border-line px-3 text-sm text-ink';

  return (
    <div className="min-h-screen grid place-items-center bg-page px-4 py-10">
      <Card className="w-full max-w-lg">
        <h1 className="text-2xl font-extrabold text-navy">{t.invitation.title}</h1>
        <p className="text-sm text-ink-soft mt-1">{t.invitation.subtitle}</p>

        {accepted ? (
          <div className="mt-6 space-y-4">
            <p className="text-sm text-success" role="status">
              {t.invitation.accepted}: <strong>{accepted}</strong>
            </p>
            <Button className="w-full" onClick={() => router.push('/')}>
              {t.invitation.goToPanel}
            </Button>
          </div>
        ) : !token ? (
          <p className="mt-6 text-sm text-danger" role="alert">
            {t.invitation.invalid}
          </p>
        ) : authLoading ? (
          <p className="mt-6 text-sm text-ink-soft">{t.invitation.loading}</p>
        ) : user && sessionMismatch ? (
          <div className="mt-6 space-y-4">
            <p className="text-sm text-danger" role="alert">
              {previewError ?? t.invitation.invalid}
            </p>
            <p className="text-sm text-ink-soft">
              {t.invitation.sessionMismatch.replace('{email}', user.email)}
            </p>
            <Button className="w-full" onClick={switchAccount}>
              {t.invitation.switchAccount}
            </Button>
          </div>
        ) : user ? (
          <p className="mt-6 text-sm text-ink-soft">{t.invitation.loading}</p>
        ) : (
          <div className="mt-6 space-y-4">
            <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
              {t.invitation.emailHint}
              <input
                type="email"
                required
                className={field}
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  validatePreview(e.target.value);
                }}
                onBlur={() => validatePreview(email)}
              />
            </label>

            {preview && (
              <div className="rounded-btn border border-line bg-page px-3 py-2 text-sm">
                <div>
                  {t.invitation.inviteTo}: <strong>{preview.orgName}</strong>
                </div>
                <div className="text-ink-soft">
                  {t.invitation.role}: {roleLabel(preview.role)}
                </div>
              </div>
            )}
            {previewError && (
              <p className="text-sm text-danger" role="alert">
                {previewError}
              </p>
            )}

            {preview && mode === 'register' ? (
              <form className="space-y-3" onSubmit={handleRegister}>
                <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
                  {t.invitation.name}
                  <input
                    required
                    className={field}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </label>
                <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
                  {t.invitation.password}
                  <input
                    type="password"
                    required
                    minLength={8}
                    autoComplete="new-password"
                    className={field}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </label>
                {error && (
                  <p className="text-sm text-danger" role="alert">
                    {error}
                  </p>
                )}
                <Button type="submit" className="w-full" disabled={busy}>
                  {busy ? t.invitation.accepting : t.invitation.createAccount}
                </Button>
                <button
                  type="button"
                  className="text-sm text-info hover:underline"
                  onClick={() => setMode('login-required')}
                >
                  {t.invitation.haveAccount}
                </button>
              </form>
            ) : (
              <div className="space-y-3">
                <Button
                  className="w-full"
                  disabled={!preview}
                  onClick={() => setMode('register')}
                >
                  {t.invitation.createAccount}
                </Button>
                <Link
                  href={`/login?next=${encodeURIComponent(`/accept-invitation?token=${token}`)}`}
                  className="block text-center text-sm text-info hover:underline"
                >
                  {t.invitation.haveAccount}
                </Link>
              </div>
            )}

            <p className="text-xs text-ink-muted">{t.invitation.accountHint}</p>
          </div>
        )}
      </Card>
    </div>
  );
}
