'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { useAuth } from '@/components/providers/auth-provider';
import { useI18n } from '@/components/providers/i18n-provider';
import { useToast } from '@/components/providers/toast-provider';
import {
  canOpenView,
  Sidebar,
  SIDEBAR_WIDTH,
  SIDEBAR_WIDTH_COLLAPSED,
  useSidebarCollapsed,
  type ViewKey,
} from '@/components/layout/sidebar';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { Topbar } from '@/components/layout/topbar';
import { DashboardHome } from '@/components/dashboard/dashboard-home';
import { StandardsView } from '@/components/views/standards-view';
import { DiagnosisView } from '@/components/views/diagnosis-view';
import { ContextView } from '@/components/views/context-view';
import { PlanningView } from '@/components/views/planning-view';
import { DocumentsView } from '@/components/views/documents-view';
import { EvidencesView } from '@/components/views/evidences-view';
import { AuditsView } from '@/components/views/audits-view';
import { NcView } from '@/components/views/nc-view';
import { ReviewView } from '@/components/views/review-view';
import { DashboardsView } from '@/components/views/dashboards-view';
import { IsmsView } from '@/components/views/isms-view';
import { BcmsView } from '@/components/views/bcms-view';
import { ItsmView } from '@/components/views/itsm-view';
import { AbmsView } from '@/components/views/abms-view';
import { NotificationsView } from '@/components/views/notifications-view';
import { AiSystemsView } from '@/components/views/ai-systems-view';
import { AiGovernanceView } from '@/components/views/ai-governance-view';
import { SubscriptionView } from '@/components/views/subscription-view';
import { TemplatesView } from '@/components/views/templates-view';
import { ConsultantView } from '@/components/views/consultant-view';
import { OrgAdminView } from '@/components/views/org-admin-view';
import { PlatformView } from '@/components/views/platform-view';
import { SecurityView } from '@/components/views/security-view';
import { CopilotFab } from '@/components/copilot/copilot-fab';

export default function HomePage() {
  const { user, loading, signOut } = useAuth();
  const router = useRouter();
  const perms = usePermissions();
  const { orgId } = useActiveOrg();
  const { t } = useI18n();
  const toast = useToast();
  const [view, setView] = useState<ViewKey>('home');
  // El ancho de la barra y el margen del contenido salen de la misma fuente:
  // así el panel se desplaza con la animación y no se solapan.
  const sidebarCollapsed = useSidebarCollapsed();

  // Navegación central: cierra cualquier popover abierto de la Topbar
  // (búsqueda/notificaciones/menú de usuario) antes de cambiar de vista.
  const navigate = (v: ViewKey) => {
    window.dispatchEvent(new Event('sigue:nav'));
    // Antes esta comprobación solo se hacía al pintar (`activeView`), así que
    // pulsar "Usuarios y organización" sin ser administrador volvía al inicio
    // sin explicación: parecía que el clic no hacía nada.
    if (!canOpenView(v, perms)) {
      toast.error(t.common.noAccess);
      return;
    }
    setView(v);
  };

  useEffect(() => {
    if (!loading && !user) router.replace('/login');
  }, [loading, user, router]);

  // Al cambiar de organización el rol puede perder acceso a la vista actual
  // (p. ej. un consultor que deja de ser admin del cliente). Se deriva en el
  // render en lugar de corregirlo con un efecto, para no encadenar renders.
  const allowed = view === 'home' || canOpenView(view, perms);
  const activeView: ViewKey = allowed ? view : 'home';

  // El regreso al inicio tampoco puede ser mudo: se avisa una vez por vista.
  const warnedView = useRef<ViewKey | null>(null);
  useEffect(() => {
    if (allowed || warnedView.current === view) return;
    warnedView.current = view;
    toast.error(t.common.noAccess);
  }, [allowed, view, toast, t.common.noAccess]);

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-ink-soft">Cargando…</div>;
  }
  if (!user) return null;

  const sidebarWidth = sidebarCollapsed ? SIDEBAR_WIDTH_COLLAPSED : SIDEBAR_WIDTH;

  return (
    <div className="flex h-screen">
      <Sidebar currentView={activeView} onNavigate={navigate} />
      <main
        className={`flex-1 h-screen overflow-y-auto transition-[margin] duration-200 ease-out ${
          activeView !== 'home' ? 'main-scroll' : ''
        }`}
        style={{ marginLeft: sidebarWidth }}
      >
        <Topbar user={user} onSignOut={signOut} onNavigate={navigate} />
        {activeView === 'home' && <DashboardHome user={user} onNavigate={navigate} />}
        {activeView !== 'home' && (
          <div className="p-8">
            {activeView === 'standards' && <StandardsView />}
            {activeView === 'diagnosis' && <DiagnosisView />}
            {activeView === 'context' && <ContextView />}
            {activeView === 'planning' && <PlanningView />}
            {activeView === 'documents' && <DocumentsView />}
            {activeView === 'templates' && <TemplatesView />}
            {activeView === 'evidences' && <EvidencesView />}
            {activeView === 'audits' && <AuditsView />}
            {activeView === 'nc' && <NcView />}
            {activeView === 'review' && <ReviewView />}
            {activeView === 'dashboards' && <DashboardsView />}
            {activeView === 'isms' && <IsmsView />}
            {activeView === 'bcms' && <BcmsView />}
            {activeView === 'itsm' && <ItsmView />}
            {activeView === 'abms' && <AbmsView />}
            {activeView === 'notifications' && <NotificationsView />}
            {activeView === 'ai-systems' && <AiSystemsView />}
            {activeView === 'ai-governance' && <AiGovernanceView />}
            {activeView === 'subscription' && <SubscriptionView />}
            {activeView === 'consultant' && <ConsultantView />}
            {activeView === 'org-admin' && <OrgAdminView />}
            {activeView === 'platform' && <PlatformView />}
            {activeView === 'security' && <SecurityView />}
          </div>
        )}
        {/* Copiloto contextual (transversal). La `key` reinicia su borrador
            al cambiar de vista u organización en lugar de arrastrarlo. */}
        <CopilotFab key={`${activeView}:${orgId}`} currentView={activeView} />
      </main>
    </div>
  );
}
