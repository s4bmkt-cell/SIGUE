'use client';

import { useRouter, useSearchParams } from 'next/navigation';
import { Suspense, useEffect, useRef, useState } from 'react';
import { useI18n } from '@/components/providers/i18n-provider';
import { useAuth } from '@/components/providers/auth-provider';
import { api } from '@/lib/api/client';

const LANGUAGES = [
  { code: 'es-MX' as const, label: 'Español (MX)', short: 'ES' },
  { code: 'en-US' as const, label: 'English (US)', short: 'EN' },
];

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen" />}>
      <LoginForm />
    </Suspense>
  );
}

function LoginForm() {
  const { t, locale, setLocale } = useI18n();
  const { signIn, verifyMfa } = useAuth();
  const router = useRouter();
  // Destino tras iniciar sesión (p. ej. el enlace de invitación). Solo permite
  // rutas internas para no convertirse en un redirect abierto.
  const rawNext = useSearchParams().get('next');
  const next = rawNext && rawNext.startsWith('/') && !rawNext.startsWith('//') ? rawNext : '/';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [remember, setRemember] = useState(true);
  const [mode, setMode] = useState<'login' | 'forgot'>('login');
  const [forgotSent, setForgotSent] = useState(false);

  const [mfaChallenge, setMfaChallenge] = useState<string | null>(null);
  const [mfaCode, setMfaCode] = useState('');

  const [langOpen, setLangOpen] = useState(false);
  const langRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (langRef.current && !langRef.current.contains(e.target as Node)) {
        setLangOpen(false);
      }
    }
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await signIn(email, password);
    setLoading(false);

    if (!res.ok) {
      setError(res.error ?? t.auth.error);
      return;
    }
    if (res.mfaRequired) {
      setMfaChallenge(res.challengeId);
      return;
    }
    router.push(next);
  }

  async function handleMfa(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    const res = await verifyMfa(mfaChallenge!, mfaCode);
    setLoading(false);
    if (res.ok) router.push(next);
    else setError(res.error ?? t.auth.error);
  }

  async function handleForgot(e: React.FormEvent) {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      await api.forgotPassword(email);
      setForgotSent(true);
    } catch (e) {
      setError(e instanceof Error ? e.message : t.auth.error);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="signlogin-shell">
      {/* Panel hero izquierdo */}
      <div className="signlogin-hero">
        <div className="sign-logo" aria-label="SIGN">
          <img
            src="/S.png"
            alt="Logo SIGN"
            width={112}
            height={82}
            className="sign-logo-img"
          />
          <span>
            SIGN
            <div className="sign-logo-sub">{t.auth.logoSubtitle}</div>
          </span>
        </div>
        <div className="signlogin-copy">
          <h1>
            {t.auth.stepPlan}. {t.auth.stepImplement}.
            <br />
            {t.auth.stepVerify}. <span>{t.auth.stepImprove}</span>
            <em>.</em>
          </h1>
          <p>{t.auth.heroTagline}</p>
          <div className="signlogin-standards">
            <span>ISO 9001</span>
            <span>ISO/IEC 27001</span>
            <span>ISO 22301</span>
            <span>ISO/IEC 20000-1</span>
            <span>ISO 37001</span>
            <span>ISO/IEC 42001</span>
          </div>
        </div>
        <div className="signlogin-path" aria-hidden="true">
          <svg viewBox="0 0 900 210" fill="none">
            <defs>
              <filter id="signloginGlow" filterUnits="userSpaceOnUse" x="0" y="100" width="900" height="120">
                <feGaussianBlur stdDeviation="4" result="blur" />
                <feMerge>
                  <feMergeNode in="blur" />
                  <feMergeNode in="SourceGraphic" />
                </feMerge>
              </filter>
            </defs>
            <path
              d="M99 155 L819 155"
              stroke="#3d88ff"
              strokeWidth="2.5"
            />
            <path
              d="M99 155 L819 155"
              stroke="#3d88ff"
              strokeWidth="2"
              filter="url(#signloginGlow)"
            />
            {/* Nodos sobre la línea recta + etiqueta debajo */}
            <g>
              {/* Planificar */}
              <circle cx="99" cy="155" r="11" fill="#0a4db3" stroke="#eaf2ff" strokeWidth="5" />
              <text x="99" y="192" textAnchor="middle" fill="#bfcae4" fontSize="16">{t.auth.stepPlan}</text>
              {/* Implementar */}
              <circle cx="339" cy="155" r="11" fill="#0a4db3" stroke="#eaf2ff" strokeWidth="5" />
              <text x="339" y="192" textAnchor="middle" fill="#bfcae4" fontSize="16">{t.auth.stepImplement}</text>
              {/* Verificar */}
              <circle cx="579" cy="155" r="11" fill="#0a4db3" stroke="#eaf2ff" strokeWidth="5" />
              <text x="579" y="192" textAnchor="middle" fill="#bfcae4" fontSize="16">{t.auth.stepVerify}</text>
              {/* Mejorar */}
              <circle cx="819" cy="155" r="11" fill="#04b879" stroke="#eaf2ff" strokeWidth="5" />
              <text x="819" y="192" textAnchor="middle" fill="#00df98" fontWeight="700" fontSize="16">{t.auth.stepImprove}</text>
            </g>
          </svg>
        </div>
        <div className="signlogin-copyright">{t.auth.copyright}</div>
      </div>

      {/* Panel derecho (formulario) */}
      <main className="signlogin-panel">
        <section className="signlogin-card">
          <div className="signlogin-form">
            <div className="signlogin-lang" ref={langRef}>
            <button
              className="signlogin-language"
              type="button"
              aria-haspopup="listbox"
              aria-expanded={langOpen}
              onClick={() => setLangOpen((v) => !v)}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <circle cx="12" cy="12" r="9" />
                <path d="M3 12h18M12 3a14 14 0 0 1 0 18M12 3a14 14 0 0 0 0 18" />
              </svg>
              {LANGUAGES.find((l) => l.code === locale)?.label}
              <svg className="signlogin-lang-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                <path d="m6 9 6 6 6-6" />
              </svg>
            </button>
            {langOpen && (
              <ul className="signlogin-lang-menu" role="listbox" aria-label={t.common.language}>
                {LANGUAGES.map((l) => (
                  <li key={l.code}>
                    <button
                      type="button"
                      role="option"
                      aria-selected={locale === l.code}
                      className={locale === l.code ? 'active' : ''}
                      onClick={() => {
                        setLocale(l.code);
                        setLangOpen(false);
                      }}
                    >
                      <span className="signlogin-lang-code">{l.short}</span>
                      {l.label}
                      {locale === l.code && (
                        <svg className="signlogin-lang-check" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
                          <path d="m5 13 4 4L19 7" />
                        </svg>
                      )}
                    </button>
                  </li>
                ))}
              </ul>
            )}
            </div>

            <svg className="signlogin-shield" viewBox="0 0 64 64" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
              <path d="M32 5 54 13v16c0 14-9 25-22 30C19 54 10 43 10 29V13z" />
              <path d="m22 32 7 7 14-16" />
            </svg>

            {mode === 'forgot' ? (
              <form onSubmit={handleForgot}>
                <h1>{t.auth.forgotTitle}</h1>
                <p className="signlogin-subtitle">{t.auth.forgotSubtitle}</p>

                {forgotSent ? (
                  <>
                    <p className="signlogin-message" role="status">
                      {t.auth.forgotSent}
                    </p>
                    <button
                      className="signlogin-submit"
                      type="button"
                      onClick={() => {
                        setMode('login');
                        setForgotSent(false);
                      }}
                    >
                      {t.auth.backToLogin} <span>→</span>
                    </button>
                  </>
                ) : (
                  <>
                    <label className="signlogin-field" htmlFor="forgotEmail">
                      {t.auth.email}
                      <div className="signlogin-control">
                        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                          <rect x="3" y="5" width="18" height="14" rx="2" />
                          <path d="m3 7 9 6 9-6" />
                        </svg>
                        <input
                          id="forgotEmail"
                          type="email"
                          autoComplete="username"
                          placeholder="mariana.torres@org.mx"
                          value={email}
                          onChange={(e) => setEmail(e.target.value)}
                          required
                        />
                      </div>
                    </label>
                    <button className="signlogin-submit" type="submit" disabled={loading}>
                      {loading ? t.auth.signingIn : t.auth.sendLink} <span>→</span>
                    </button>
                    {error && (
                      <p className="signlogin-message" role="alert">
                        {error}
                      </p>
                    )}
                    <button
                      className="signlogin-back"
                      type="button"
                      onClick={() => {
                        setMode('login');
                        setError(null);
                      }}
                    >
                      ← {t.auth.backToLogin}
                    </button>
                  </>
                )}
              </form>
            ) : !mfaChallenge ? (
              <form onSubmit={handleSubmit}>
                <h1>{t.auth.welcomeTitle}</h1>
                <p className="signlogin-subtitle">{t.auth.loginSubtitle}</p>

                <label className="signlogin-field" htmlFor="loginEmail">
                  {t.auth.email}
                  <div className="signlogin-control">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                      <rect x="3" y="5" width="18" height="14" rx="2" />
                      <path d="m3 7 9 6 9-6" />
                    </svg>
                    <input
                      id="loginEmail"
                      type="email"
                      autoComplete="username"
                      placeholder="mariana.torres@org.mx"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                    />
                  </div>
                </label>

                <label className="signlogin-field" htmlFor="loginPassword">
                  {t.auth.password}
                  <div className="signlogin-control">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                      <rect x="4" y="10" width="16" height="11" rx="2" />
                      <path d="M8 10V7a4 4 0 0 1 8 0v3" />
                    </svg>
                    <input
                      id="loginPassword"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete="current-password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    <button
                      className="signlogin-toggle"
                      type="button"
                      aria-label={t.auth.showPassword}
                      aria-pressed={showPassword}
                      onClick={() => setShowPassword((v) => !v)}
                    >
                      <svg width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                        <path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12" />
                        <circle cx="12" cy="12" r="3" />
                      </svg>
                    </button>
                  </div>
                </label>

                <div className="signlogin-options">
                  <input
                    id="rememberMe"
                    type="checkbox"
                    checked={remember}
                    onChange={(e) => setRemember(e.target.checked)}
                  />
                  <label htmlFor="rememberMe">{t.auth.rememberMe}</label>
                  <button
                    type="button"
                    className="signlogin-link"
                    onClick={() => {
                      setMode('forgot');
                      setError(null);
                    }}
                  >
                    {t.auth.forgotPassword}
                  </button>
                </div>

                <button className="signlogin-submit" type="submit" disabled={loading}>
                  {loading ? t.common.loading : t.auth.signIn} <span>→</span>
                </button>
                {error && (
                  <p className="signlogin-message" role="alert">
                    {error}
                  </p>
                )}
                <div className="signlogin-security">
                  <span>♢ {t.auth.mfaEnabled}</span>
                  <span>♙ {t.auth.tlsEncryption}</span>
                  <span>♢ {t.auth.secureAccess}</span>
                </div>
              </form>
            ) : (
              <form onSubmit={handleMfa}>
                <h1>{t.auth.mfaTitle}</h1>
                <p className="signlogin-subtitle">{t.auth.mfaSubtitle}</p>
                <label className="signlogin-field" htmlFor="mfaCode">
                  {t.auth.mfaCode}
                  <div className="signlogin-control">
                    <input
                      id="mfaCode"
                      type="text"
                      inputMode="numeric"
                      maxLength={6}
                      value={mfaCode}
                      onChange={(e) => setMfaCode(e.target.value.replace(/\D/g, ''))}
                      required
                    />
                  </div>
                </label>
                <button className="signlogin-submit" type="submit" disabled={loading || mfaCode.length !== 6}>
                  {loading ? t.common.loading : t.auth.verify} <span>→</span>
                </button>
                {error && (
                  <p className="signlogin-message" role="alert">
                    {error}
                  </p>
                )}
              </form>
            )}
          </div>
        </section>
      </main>
    </div>
  );
}
