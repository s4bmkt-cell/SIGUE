'use client';

import type { ReactNode } from 'react';
import { Button } from '@/components/ui/button';

/** Carga en línea para el cuerpo de una tarjeta o de una vista. */
export function LoadingState({ label = 'Cargando…' }: { label?: string }) {
  return (
    <div className="flex items-center justify-center gap-3 py-10 text-sm text-ink-soft" role="status">
      <span
        className="size-4 animate-spin rounded-full border-2 border-line-strong border-t-primary"
        aria-hidden="true"
      />
      {label}
    </div>
  );
}

/** Esqueleto de tarjetas: se usa mientras llegan los datos de una vista. */
export function SkeletonCards({ count = 3 }: { count?: number }) {
  return (
    <div className="space-y-3" aria-hidden="true">
      {Array.from({ length: count }, (_, i) => (
        <div key={i} className="animate-pulse rounded-card border border-line bg-white p-5">
          <div className="h-3 w-1/3 rounded bg-page" />
          <div className="mt-3 h-3 w-2/3 rounded bg-page" />
          <div className="mt-2 h-3 w-1/2 rounded bg-page" />
        </div>
      ))}
    </div>
  );
}

interface EmptyStateProps {
  title: string;
  hint?: string;
  action?: ReactNode;
}

/** Estado vacío: explica que no hay datos todavía y qué se puede hacer. */
export function EmptyState({ title, hint, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center rounded-card border border-dashed border-line-strong bg-page/60 px-6 py-10 text-center">
      <p className="text-sm font-semibold text-ink">{title}</p>
      {hint && <p className="mt-1 max-w-md text-xs text-ink-soft">{hint}</p>}
      {action && <div className="mt-4">{action}</div>}
    </div>
  );
}

interface ErrorStateProps {
  message: string;
  onRetry?: () => void;
  retryLabel?: string;
}

/** Error de carga: muestra el mensaje del servidor y permite reintentar. */
export function ErrorState({ message, onRetry, retryLabel = 'Reintentar' }: ErrorStateProps) {
  return (
    <div
      role="alert"
      className="rounded-card border border-danger/30 bg-danger-bg px-4 py-3 text-sm text-danger"
    >
      <div className="flex flex-wrap items-center gap-3">
        <p className="flex-1">{message}</p>
        {onRetry && (
          <Button size="sm" variant="outline" onClick={onRetry}>
            {retryLabel}
          </Button>
        )}
      </div>
    </div>
  );
}

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  action?: ReactNode;
}

/** Encabezado uniforme de las vistas: título, subtítulo y acción principal. */
export function SectionHeader({ title, subtitle, action }: SectionHeaderProps) {
  return (
    <div className="flex flex-wrap items-end justify-between gap-4">
      <div>
        <h1 className="text-2xl font-extrabold text-navy">{title}</h1>
        {subtitle && <p className="mt-1 text-sm text-ink-soft">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}
