'use client';

import { useEffect, useRef, type ReactNode } from 'react';
import { X } from 'lucide-react';

interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: string;
  subtitle?: ReactNode;
  children: ReactNode;
  /** Acciones fijas al pie, visibles mientras el cuerpo hace scroll. */
  footer?: ReactNode;
  /** Ancho máximo del panel central; por defecto dos columnas de formulario. */
  size?: 'md' | 'lg' | 'xl';
}

const SIZE_CLASS: Record<'md' | 'lg' | 'xl', string> = {
  md: 'max-w-lg',
  lg: 'max-w-2xl',
  // Lectura de un documento completo: una página de texto necesita más ancho.
  xl: 'max-w-4xl',
};

/**
 * Ventana emergente centrada para formularios cortos.
 *
 * Comparte las reglas del `Drawer` (cierre con `Esc`, clic fuera, bloqueo del
 * scroll de fondo y foco al abrir) para que ambos se comporten igual. Se usa un
 * modal y no un panel lateral cuando la tarea es un alta rápida: el inventario
 * queda a la vista detrás y al cerrar no se perdió el contexto.
 */
export function Modal({ open, onClose, title, subtitle, children, footer, size = 'lg' }: ModalProps) {
  const panelRef = useRef<HTMLDivElement>(null);
  // `onClose` suele llegar como función inline, así que cambia de identidad en
  // cada render. Guardarla en un ref permite que el efecto de abajo dependa solo
  // de `open`: si dependiera de la función, cada tecla lo reejecutaría y el foco
  // volvería al panel, sacando el cursor del campo que se está escribiendo.
  const onCloseRef = useRef(onClose);
  useEffect(() => {
    onCloseRef.current = onClose;
  }, [onClose]);

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onCloseRef.current();
    };
    document.addEventListener('keydown', onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    panelRef.current?.focus();
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = previous;
    };
  }, [open]);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto p-4 sm:items-center">
      <div className="fixed inset-0 bg-navy/30" aria-hidden="true" onClick={onClose} />
      <div
        ref={panelRef}
        role="dialog"
        aria-modal="true"
        aria-label={title}
        tabIndex={-1}
        className={`relative flex max-h-[90vh] w-full flex-col rounded-card bg-white shadow-card outline-none ${
          SIZE_CLASS[size]
        }`}
      >
        <header className="flex items-start gap-3 border-b border-line px-5 py-4">
          <div className="min-w-0 flex-1">
            <h2 className="truncate text-base font-extrabold text-navy">{title}</h2>
            {subtitle && <div className="mt-0.5 text-xs text-ink-soft">{subtitle}</div>}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Cerrar"
            className="flex size-8 shrink-0 items-center justify-center rounded-btn text-ink-muted transition-colors hover:bg-page hover:text-ink"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        </header>

        <div className="main-scroll flex-1 overflow-y-auto px-5 py-4">{children}</div>

        {footer && (
          <footer className="flex flex-wrap items-center justify-end gap-2 rounded-b-card border-t border-line px-5 py-3">
            {footer}
          </footer>
        )}
      </div>
    </div>
  );
}
