import { describe, expect, it } from 'vitest';
import { initialsOf } from './avatar';

describe('Avatar', () => {
  it('toma las iniciales de las dos primeras palabras', () => {
    expect(initialsOf('Mariana Torres')).toBe('MT');
    expect(initialsOf('Jorge Aldana Ruiz')).toBe('JA');
  });

  it('usa una sola letra cuando el nombre tiene una palabra', () => {
    expect(initialsOf('Mariana')).toBe('M');
  });

  it('no falla con espacios sobrantes ni con un nombre vacío', () => {
    expect(initialsOf('  Mariana   Torres  ')).toBe('MT');
    expect(initialsOf('')).toBe('–');
  });
});
