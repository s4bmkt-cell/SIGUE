import type { HTMLAttributes } from 'react';

/**
 * Paleta de los avatares: los cinco colores de acento del sistema. El color se
 * deriva del nombre, así la misma persona conserva el suyo entre pantallas.
 */
const COLORS = ['#2f66eb', '#0BAA70', '#e07b00', '#9333ea', '#0891b2'];

/** Iniciales de un nombre: dos letras como máximo ("Mariana Torres" → "MT"). */
export function initialsOf(name: string): string {
  const words = name.trim().split(/\s+/).filter(Boolean);
  if (words.length === 0) return '–';
  return words
    .slice(0, 2)
    .map((word) => word[0])
    .join('')
    .toUpperCase();
}

function avatarColor(name: string): string {
  let sum = 0;
  for (const char of initialsOf(name)) sum += char.charCodeAt(0);
  return COLORS[sum % COLORS.length];
}

interface AvatarProps extends Omit<HTMLAttributes<HTMLSpanElement>, 'children'> {
  /** Nombre completo de la persona. Vacío se dibuja como un círculo neutro. */
  name: string | null | undefined;
  /**
   * Nombre accesible; por defecto el propio nombre. Se usa cuando el avatar va
   * acompañado de un contexto que no está a la vista (por ejemplo el tipo de
   * firma).
   */
  label?: string;
  /** Diámetro en píxeles. */
  size?: number;
  /** Borde del círculo: permite distinguir avatares superpuestos. */
  ringClassName?: string;
}

/**
 * Círculo con las iniciales de la persona.
 *
 * El sistema todavía no guarda fotos de perfil (ni el usuario ni la firma
 * tienen un campo de imagen), así que las iniciales son la representación
 * disponible de cada firmante.
 */
export function Avatar({
  name,
  label,
  size = 24,
  ringClassName = 'ring-2 ring-white',
  className = '',
  style,
  ...props
}: AvatarProps) {
  const full = name?.trim() ?? '';
  const accessible = label ?? (full || '—');

  return (
    <span
      role="img"
      aria-label={accessible}
      title={accessible}
      className={`inline-flex shrink-0 items-center justify-center rounded-full font-semibold ${
        full ? 'text-white' : 'border border-line bg-page text-ink-muted'
      } ${ringClassName} ${className}`}
      style={{
        width: size,
        height: size,
        fontSize: Math.max(9, Math.round(size * 0.4)),
        ...(full ? { background: avatarColor(full) } : {}),
        ...style,
      }}
      {...props}
    >
      {initialsOf(full)}
    </span>
  );
}
