'use client';

import type { LucideIcon } from 'lucide-react';
import { ArrowUpRight } from 'lucide-react';

interface ModuleTileProps {
  icon: LucideIcon;
  title: string;
  /** Texto emergente: qué hay dentro de la sección. */
  hint?: string;
  /** Número de elementos; se omite mientras los datos cargan. */
  total?: number | null;
  onOpen: () => void;
}

/**
 * Acceso a una sección desde una portada de módulo.
 *
 * Composición alineada a la izquierda: icono grande en un contenedor
 * translúcido, título debajo y contador arriba a la derecha. La tarjeta es
 * compacta y el contenido ocupa el ancho, así que no quedan huecos vacíos en
 * rejillas de seis.
 */
export function ModuleTile({ icon: Icon, title, hint, total, onOpen }: ModuleTileProps) {
  return (
    <button
      type="button"
      onClick={onOpen}
      title={hint}
      aria-label={hint ? `${title} — ${hint}` : title}
      className="group relative flex min-h-[124px] flex-col items-start justify-between gap-3 overflow-hidden rounded-card border border-white/15 bg-gradient-to-br from-[#4b7ef2] via-primary to-[#2455d4] p-4 text-left text-white shadow-[0_1px_2px_rgba(16,35,67,.10),0_10px_22px_-10px_rgba(47,102,235,.65)] transition-all duration-200 hover:-translate-y-1 hover:border-white/30 hover:shadow-[0_2px_4px_rgba(16,35,67,.12),0_16px_30px_-12px_rgba(47,102,235,.75)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-info"
    >
      {/* Filo de luz superior: da volumen sin cargar el color. */}
      <span
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-white/50 to-transparent"
      />
      <span className="flex size-14 items-center justify-center rounded-xl bg-white/15 ring-1 ring-inset ring-white/30 transition-colors duration-200 group-hover:bg-white/25">
        <Icon className="size-8" strokeWidth={1.5} aria-hidden="true" />
      </span>
      <span className="pr-4 text-[11.5px] font-semibold uppercase leading-tight tracking-[0.05em]">
        {title}
      </span>
      {total != null && (
        <span className="absolute right-2.5 top-2.5 min-w-[22px] rounded-full bg-white/20 px-1.5 py-0.5 text-center text-[10.5px] font-bold tabular-nums ring-1 ring-inset ring-white/25 backdrop-blur-sm">
          {total}
        </span>
      )}
      <ArrowUpRight
        className="absolute bottom-3 right-3 size-3.5 -translate-x-1 translate-y-1 opacity-0 transition-all duration-200 group-hover:translate-x-0 group-hover:translate-y-0 group-hover:opacity-80"
        aria-hidden="true"
      />
    </button>
  );
}
