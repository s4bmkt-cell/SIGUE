'use client';

import { forwardRef, type ButtonHTMLAttributes } from 'react';

export type IconTone = 'neutral' | 'primary' | 'danger' | 'solidDanger';

interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  /**
   * Nombre accesible y tooltip. El botón no muestra texto, así que sin esto
   * quedaría un icono mudo para lectores de pantalla.
   */
  label: string;
  tone?: IconTone;
  /**
   * `false` deja crecer el botón con su contenido. Lo usa la confirmación en
   * dos pasos, que pasa de icono a texto sin cambiar de elemento.
   */
  square?: boolean;
}

const base =
  'inline-flex shrink-0 items-center justify-center rounded-btn transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-info disabled:opacity-50 disabled:cursor-not-allowed';

const tones: Record<IconTone, string> = {
  neutral: 'text-ink-soft hover:bg-page hover:text-ink',
  primary: 'bg-primary text-white hover:bg-primary-strong shadow-sm',
  danger: 'text-danger hover:bg-danger-bg',
  // Estado armado de una confirmación: tiene que leerse como acción destructiva.
  solidDanger: 'bg-danger text-white hover:opacity-90',
};

/**
 * Botón cuadrado de un solo icono, para barras de acciones de tablas.
 *
 * El nombre accesible viaja en `aria-label` y en `title`: el tooltip nativo es
 * lo que hace las acciones descubribles sin gastar ancho de columna.
 */
export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(
  ({ label, tone = 'neutral', square = true, className = '', type = 'button', ...props }, ref) => (
    <button
      ref={ref}
      type={type}
      aria-label={label}
      title={label}
      className={`${base} ${square ? 'size-7' : 'h-7 px-2 text-[11px] font-semibold'} ${
        tones[tone]
      } ${className}`}
      {...props}
    />
  ),
);
IconButton.displayName = 'IconButton';
