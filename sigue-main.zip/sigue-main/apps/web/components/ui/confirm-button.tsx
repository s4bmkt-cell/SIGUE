'use client';

import { useEffect, useState, type ReactNode } from 'react';
import { Button } from '@/components/ui/button';
import { IconButton, type IconTone } from '@/components/ui/icon-button';

interface ConfirmButtonProps {
  /** Texto del botón en reposo. */
  children: ReactNode;
  /** Texto del botón mientras pide confirmación ("¿Seguro?"). */
  confirmLabel: string;
  onConfirm: () => void;
  disabled?: boolean;
  variant?: 'primary' | 'outline' | 'ghost' | 'danger';
  size?: 'sm' | 'md';
  className?: string;
}

interface ConfirmIconButtonProps {
  /** Icono mostrado en reposo. */
  children: ReactNode;
  /** Nombre accesible y tooltip del botón. */
  label: string;
  /** Texto que sustituye al icono mientras pide confirmación. */
  confirmLabel: string;
  onConfirm: () => void;
  disabled?: boolean;
  tone?: IconTone;
}

/**
 * Botón de icono con confirmación en dos pasos.
 *
 * Mismo mecanismo que `ConfirmButton`, pero en reposo ocupa un cuadrado con el
 * icono: en una tabla de acciones el texto completo de "Marcar obsoleto" o
 * "Eliminar" no cabe sin empujar las columnas. Al armarse sí muestra texto,
 * porque en ese momento el botón debe entenderse sin ambigüedad.
 */
export function ConfirmIconButton({
  children,
  label,
  confirmLabel,
  onConfirm,
  disabled,
  tone = 'neutral',
}: ConfirmIconButtonProps) {
  const [armed, setArmed] = useState(false);

  useEffect(() => {
    if (!armed) return;
    const timer = setTimeout(() => setArmed(false), 4000);
    return () => clearTimeout(timer);
  }, [armed]);

  // Un solo elemento que cambia de forma: si se intercambiara por otro botón,
  // el foco se perdería justo cuando la persona debe confirmar.
  return (
    <IconButton
      label={armed ? confirmLabel : label}
      tone={armed ? 'solidDanger' : tone}
      square={!armed}
      disabled={disabled}
      onClick={() => {
        if (!armed) {
          setArmed(true);
          return;
        }
        setArmed(false);
        onConfirm();
      }}
      onBlur={() => setArmed(false)}
    >
      {armed ? confirmLabel : children}
    </IconButton>
  );
}

/**
 * Botón con confirmación en dos pasos.
 *
 * Se evita `window.confirm` (bloquea el hilo, no se puede estilizar y en pruebas
 * automatizadas el navegador puede descartarlo). Al pulsar por primera vez el
 * botón cambia de texto; un segundo clic dentro de 4 s ejecuta la acción.
 */
export function ConfirmButton({
  children,
  confirmLabel,
  onConfirm,
  disabled,
  variant = 'outline',
  size = 'sm',
  className = '',
}: ConfirmButtonProps) {
  const [armed, setArmed] = useState(false);

  // El estado armado caduca solo y también se limpia al desmontar.
  useEffect(() => {
    if (!armed) return;
    const timer = setTimeout(() => setArmed(false), 4000);
    return () => clearTimeout(timer);
  }, [armed]);

  return (
    <Button
      size={size}
      variant={armed ? 'danger' : variant}
      className={className}
      disabled={disabled}
      onClick={() => {
        if (!armed) {
          setArmed(true);
          return;
        }
        setArmed(false);
        onConfirm();
      }}
      // Al salir del botón se desarma: un clic perdido no deja el borrado a un
      // clic de distancia.
      onBlur={() => setArmed(false)}
    >
      {armed ? confirmLabel : children}
    </Button>
  );
}
