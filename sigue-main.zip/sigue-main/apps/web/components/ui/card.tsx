import type { HTMLAttributes, ReactNode } from 'react';

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  title?: string;
  subtitle?: string;
  action?: ReactNode;
}

export function Card({ title, subtitle, action, children, className = '', ...props }: CardProps) {
  return (
    <div
      className={`bg-white border border-line rounded-card shadow-card p-5 ${className}`}
      {...props}
    >
      {(title || action) && (
        <div className="flex items-center gap-3 mb-2">
          {title && <h3 className="text-[15px] font-bold text-ink">{title}</h3>}
          {action && <div className="ml-auto">{action}</div>}
        </div>
      )}
      {subtitle && <p className="text-xs text-ink-muted mb-3">{subtitle}</p>}
      {children}
    </div>
  );
}
