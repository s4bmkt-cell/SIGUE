import type { HTMLAttributes } from 'react';

type Tone = 'ok' | 'warn' | 'danger' | 'info' | 'muted';

const tones: Record<Tone, string> = {
  ok: 'text-success bg-success-bg',
  warn: 'text-warning bg-warning-bg',
  danger: 'text-danger bg-danger-bg',
  info: 'text-info bg-info-bg',
  muted: 'text-ink-soft bg-page',
};

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  tone?: Tone;
  dot?: boolean;
}

export function Badge({ tone = 'muted', dot = true, className = '', children, ...props }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[11.5px] font-semibold ${tones[tone]} ${className}`}
      {...props}
    >
      {dot && <span className="size-1.5 rounded-full bg-current" aria-hidden="true" />}
      {children}
    </span>
  );
}
