'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { api, type MemberItem, type OrgArea, type OrgBranch } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useAuth } from '@/components/providers/auth-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { ROLE_LABELS, roleLabel as roleLabelFor } from '@/lib/roles';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ConfirmButton } from '@/components/ui/confirm-button';

type Tab = 'general' | 'members' | 'invitations' | 'structure';

/** Formularios internos: estado local acotado a la vista. */
export function OrgAdminView() {
  const { t, locale } = useI18n();
  const { user } = useAuth();
  const { orgId, org, setOrgId, organizations } = useActiveOrg();
  const qc = useQueryClient();
  const [tab, setTab] = useState<Tab>('general');
  const [error, setError] = useState<string | null>(null);

  const roleLabel = (code: string) => roleLabelFor(code, locale);

  const profileQuery = useQuery({
    queryKey: ['org-profile', orgId],
    queryFn: () => api.orgProfile(orgId!),
    enabled: !!orgId,
  });

  // Los roles se leen de la organización activa, no del token global: un
  // consultor puede ser administrador en un cliente y solo lectura en otro.
  const isAdminGlobal = user?.platform === true || !!user?.roles.includes('admin_global');
  const isAdmin = isAdminGlobal || !!profileQuery.data?.roles?.includes('admin_org');
  // Solo se ofrecen las organizaciones que realmente puede administrar.
  const adminOrganizations = useMemo(
    () =>
      isAdminGlobal
        ? organizations
        : organizations.filter((o) => o.roles?.includes('admin_org')),
    [organizations, isAdminGlobal],
  );

  // Si la organización activa no se administra, se ofrece cambiar a una que sí.
  // No se cambia sola: `setOrgId` recarga la página y devolvería al inicio.

  const membersQuery = useQuery({
    queryKey: ['org-members', orgId],
    queryFn: () => api.members(orgId!),
    enabled: !!orgId && tab === 'members' && isAdmin,
  });

  const invitationsQuery = useQuery({
    queryKey: ['org-invitations', orgId],
    queryFn: () => api.invitations(orgId!),
    enabled: !!orgId && tab === 'invitations' && isAdmin,
  });

  const rolesQuery = useQuery({ queryKey: ['roles'], queryFn: () => api.roles(), enabled: isAdmin });
  const roleCodes = useMemo(() => rolesQuery.data?.roles ?? Object.keys(ROLE_LABELS), [rolesQuery.data]);

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: ['org-profile', orgId] });
    qc.invalidateQueries({ queryKey: ['org-members', orgId] });
    qc.invalidateQueries({ queryKey: ['org-invitations', orgId] });
    qc.invalidateQueries({ queryKey: ['orgs'] });
  };

  const run = <T,>(fn: () => Promise<T>) => {
    setError(null);
    return fn().catch((e: unknown) => {
      setError(e instanceof Error ? e.message : 'Error');
      throw e;
    });
  };

  if (!orgId) {
    return <p className="text-sm text-ink-soft">{t.common.loading}</p>;
  }

  // Evita mostrar "solo administradores" mientras se resuelve la membresía.
  if (!isAdmin && profileQuery.isLoading) {
    return <p className="text-sm text-ink-soft">{t.common.loading}</p>;
  }

  // La API ya rechaza las operaciones sin rol; ocultarlas evita que el usuario
  // llegue a formularios que no puede guardar. Si administra otra organización,
  // se ofrece cambiar a ella en lugar de dejarlo en un callejón sin salida.
  if (!isAdmin) {
    return (
      <div className="space-y-3">
        <h1 className="text-2xl font-extrabold text-navy">{t.orgAdmin.title}</h1>
        <p className="text-sm text-ink-soft" role="status">
          {t.orgAdmin.onlyAdmins}
        </p>
        {adminOrganizations.length > 0 && (
          <div className="flex flex-wrap gap-2">
            {adminOrganizations.map((o) => (
              <Button key={o.id} size="sm" variant="outline" onClick={() => setOrgId(o.id)}>
                {o.name}
              </Button>
            ))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start gap-4">
        <div className="flex-1 min-w-[260px]">
          <h1 className="text-2xl font-extrabold text-navy">{t.orgAdmin.title}</h1>
          <p className="text-sm text-ink-soft mt-1">{t.orgAdmin.subtitle}</p>
        </div>
        {/* Selector de organización: un consultor puede administrar varias. */}
        {adminOrganizations.length > 1 && (
          <label className="flex flex-col gap-1 text-xs font-semibold text-ink-soft">
            {t.org.memberships}
            <select
              className="h-9 rounded-btn border border-line px-2 text-sm font-normal text-ink"
              value={orgId}
              onChange={(e) => setOrgId(e.target.value)}
            >
              {adminOrganizations.map((o) => (
                <option key={o.id} value={o.id}>
                  {o.name}
                </option>
              ))}
            </select>
          </label>
        )}
      </div>

      {error && (
        <p className="rounded-btn bg-danger-bg px-3 py-2 text-sm text-danger" role="alert">
          {error}
        </p>
      )}

      <div className="flex flex-wrap gap-2 border-b border-line pb-2">
        {(
          [
            ['general', t.orgAdmin.tabGeneral],
            ['members', t.orgAdmin.tabMembers],
            ['invitations', t.orgAdmin.tabInvitations],
            ['structure', t.orgAdmin.tabStructure],
          ] as [Tab, string][]
        ).map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={`rounded-btn px-3 py-1.5 text-sm font-semibold ${
              tab === key ? 'bg-primary text-white' : 'text-ink-soft hover:bg-page'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {tab === 'general' && profileQuery.data && (
        <GeneralTab
          orgId={orgId}
          plan={org?.plan}
          quotaUsers={profileQuery.data.quotaUsers}
          users={profileQuery.data.users}
          initial={profileQuery.data}
          onSaved={invalidate}
          onError={setError}
          run={run}
        />
      )}

      {tab === 'members' && (
        <MembersTab
          orgId={orgId}
          members={membersQuery.data ?? []}
          loading={membersQuery.isLoading}
          roleCodes={roleCodes}
          roleLabel={roleLabel}
          invalidate={invalidate}
          onError={setError}
          run={run}
        />
      )}

      {tab === 'invitations' && (
        <InvitationsTab
          orgId={orgId}
          invitations={invitationsQuery.data ?? []}
          loading={invitationsQuery.isLoading}
          roleCodes={roleCodes}
          roleLabel={roleLabel}
          invalidate={invalidate}
          run={run}
        />
      )}

      {tab === 'structure' && (
        <StructureTab
          orgId={orgId}
          refresh={() => {
            invalidate();
            qc.invalidateQueries({ queryKey: ['org-branches', orgId] });
            qc.invalidateQueries({ queryKey: ['org-areas', orgId] });
          }}
          run={run}
          onError={setError}
        />
      )}
    </div>
  );
}

function formFrom(profile: Awaited<ReturnType<typeof api.orgProfile>>) {
  return {
    name: profile.name,
    legalName: profile.legalName ?? '',
    country: profile.country,
    timezone: profile.timezone,
    lang: profile.lang,
  };
}

function GeneralTab({
  orgId,
  initial,
  plan,
  quotaUsers,
  users,
  onSaved,
  onError,
  run,
}: {
  orgId: string;
  initial: Awaited<ReturnType<typeof api.orgProfile>>;
  plan?: string;
  quotaUsers: number;
  users: number;
  onSaved: () => void;
  onError: (m: string | null) => void;
  run: <T>(fn: () => Promise<T>) => Promise<T>;
}) {
  const { t } = useI18n();
  const [form, setForm] = useState(() => formFrom(initial));
  const [saved, setSaved] = useState(false);

  // Cuando la consulta devuelve datos nuevos (p. ej. tras guardar) se resincroniza
  // el formulario. Se hace durante el render, no en un efecto, para no disparar
  // un segundo render por cada cambio.
  const [loaded, setLoaded] = useState(initial);
  if (loaded !== initial) {
    setLoaded(initial);
    setForm(formFrom(initial));
  }

  const mutation = useMutation({
    mutationFn: () =>
      run(() =>
        api.updateOrg(orgId, {
          name: form.name.trim(),
          legalName: form.legalName.trim() || undefined,
          country: form.country,
          timezone: form.timezone,
          lang: form.lang,
        }),
      ),
    onSuccess: () => {
      onSaved();
      onError(null);
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
    },
    // El error ya se muestra desde el contenedor; se evita la promesa rechazada.
    onError: () => undefined,
  });

  const field = 'h-10 w-full rounded-btn border border-line px-3 text-sm text-ink';

  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card className="lg:col-span-2" title={t.orgAdmin.tabGeneral}>
        <form
          className="grid gap-4 sm:grid-cols-2 mt-2"
          onSubmit={(e) => {
            e.preventDefault();
            mutation.mutate();
          }}
        >
          <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
            {t.orgAdmin.name}
            <input
              className={field}
              required
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
            />
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
            {t.orgAdmin.legalName}
            <input
              className={field}
              value={form.legalName}
              onChange={(e) => setForm({ ...form, legalName: e.target.value })}
            />
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
            {t.orgAdmin.country}
            <input
              className={field}
              maxLength={2}
              value={form.country}
              onChange={(e) => setForm({ ...form, country: e.target.value.toUpperCase() })}
            />
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
            {t.orgAdmin.timezone}
            <input
              className={field}
              value={form.timezone}
              onChange={(e) => setForm({ ...form, timezone: e.target.value })}
            />
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
            {t.orgAdmin.language}
            <select
              className={field}
              value={form.lang}
              onChange={(e) => setForm({ ...form, lang: e.target.value })}
            >
              <option value="es-MX">Español (MX)</option>
              <option value="en-US">English (US)</option>
            </select>
          </label>
          <div className="flex items-end">
            <Button type="submit" disabled={mutation.isPending}>
              {mutation.isPending ? t.common.loading : t.common.save}
            </Button>
            {saved && (
              <span className="ml-3 text-sm text-success" role="status">
                {t.orgAdmin.saved}
              </span>
            )}
          </div>
        </form>
      </Card>

      <Card title={t.org.plan}>
        <dl className="mt-2 space-y-3 text-sm">
          <div className="flex justify-between">
            <dt className="text-ink-muted">{t.org.plan}</dt>
            <dd className="font-semibold">{plan}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-ink-muted">{t.orgAdmin.tabMembers}</dt>
            <dd className="font-semibold">{t.orgAdmin.quota(users, quotaUsers)}</dd>
          </div>
        </dl>
      </Card>
    </div>
  );
}

function MembersTab({
  orgId,
  members,
  loading,
  roleCodes,
  roleLabel,
  invalidate,
  onError,
  run,
}: {
  orgId: string;
  members: MemberItem[];
  loading: boolean;
  roleCodes: string[];
  roleLabel: (code: string) => string;
  invalidate: () => void;
  onError: (m: string | null) => void;
  run: <T>(fn: () => Promise<T>) => Promise<T>;
}) {
  const { t } = useI18n();

  const [editing, setEditing] = useState<string | null>(null);
  const [roles, setRoles] = useState<string[]>([]);

  const updateMutation = useMutation({
    mutationFn: (vars: { memberId: string; roles?: string[]; status?: 'ACTIVE' | 'SUSPENDED' }) =>
      // El `memberId` viaja solo en la ruta: la API rechaza propiedades que no
      // estén en el DTO («property memberId should not exist»).
      run(() =>
        api.updateMember(orgId, vars.memberId, { roles: vars.roles, status: vars.status }),
      ),
    onSuccess: () => {
      invalidate();
      setEditing(null);
      onError(null);
    },
    onError: (e: unknown) => onError(e instanceof Error ? e.message : 'Error'),
  });

  const removeMutation = useMutation({
    mutationFn: (memberId: string) => run(() => api.removeMember(orgId, memberId)),
    onSuccess: () => {
      invalidate();
      onError(null);
    },
    onError: (e: unknown) => onError(e instanceof Error ? e.message : 'Error'),
  });

  if (loading) return <p className="text-sm text-ink-soft">{t.common.loading}</p>;

  return (
    <Card title={`${t.orgAdmin.tabMembers} · ${members.length}`}>
      <div className="mt-2 overflow-x-auto">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left text-xs uppercase tracking-wide text-ink-muted">
              <th className="py-2 pr-4">{t.orgAdmin.member}</th>
              <th className="py-2 pr-4">{t.orgAdmin.roles}</th>
              <th className="py-2 pr-4">{t.orgAdmin.status}</th>
              <th className="py-2 pr-4">{t.orgAdmin.lastLogin}</th>
              <th className="py-2 text-right">{t.common.actions}</th>
            </tr>
          </thead>
          <tbody>
            {members.map((m) => (
              <tr key={m.id} className="border-t border-line align-top">
                <td className="py-2.5 pr-4">
                  <div className="font-semibold text-ink">{m.name}</div>
                  <div className="text-xs text-ink-muted">{m.email}</div>
                  {m.accessEnd && (
                    <div className="text-[11px] text-warning">
                      {t.orgAdmin.accessEnd}: {new Date(m.accessEnd).toLocaleDateString()}
                    </div>
                  )}
                </td>
                <td className="py-2.5 pr-4">
                  {editing === m.id ? (
                    <div className="flex flex-wrap gap-1">
                      {roleCodes.map((code) => {
                        const checked = roles.includes(code);
                        return (
                          <label
                            key={code}
                            className={`cursor-pointer rounded-full border px-2 py-0.5 text-[11.5px] font-semibold ${
                              checked ? 'border-primary bg-info-bg text-info' : 'border-line text-ink-soft'
                            }`}
                          >
                            <input
                              type="checkbox"
                              className="sr-only"
                              checked={checked}
                              onChange={() =>
                                setRoles((prev) =>
                                  checked ? prev.filter((r) => r !== code) : [...prev, code],
                                )
                              }
                            />
                            {roleLabel(code)}
                          </label>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {m.roles.map((r) => (
                        <Badge key={r} tone="info" dot={false}>
                          {roleLabel(r)}
                        </Badge>
                      ))}
                    </div>
                  )}
                </td>
                <td className="py-2.5 pr-4">
                  <Badge tone={m.status === 'ACTIVE' ? 'ok' : 'warn'}>
                    {m.status === 'ACTIVE' ? t.orgAdmin.active : t.orgAdmin.suspended}
                  </Badge>
                </td>
                <td className="py-2.5 pr-4 text-ink-soft">
                  {m.lastLoginAt ? new Date(m.lastLoginAt).toLocaleString() : t.orgAdmin.never}
                </td>
                <td className="py-2.5 text-right whitespace-nowrap">
                  {editing === m.id ? (
                    <span className="inline-flex gap-2">
                      <Button
                        size="sm"
                        disabled={updateMutation.isPending || roles.length === 0}
                        onClick={() =>
                          updateMutation.mutate({
                            memberId: m.id,
                            roles,
                            status: m.status as 'ACTIVE' | 'SUSPENDED',
                          })
                        }
                      >
                        {t.common.save}
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setEditing(null)}>
                        {t.common.cancel}
                      </Button>
                    </span>
                  ) : (
                    <span className="inline-flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setEditing(m.id);
                          setRoles(m.roles);
                        }}
                      >
                        {t.orgAdmin.roles}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() =>
                          updateMutation.mutate({
                            memberId: m.id,
                            roles: m.roles,
                            status: m.status === 'ACTIVE' ? 'SUSPENDED' : 'ACTIVE',
                          })
                        }
                        disabled={updateMutation.isPending}
                      >
                        {m.status === 'ACTIVE' ? t.orgAdmin.suspend : t.orgAdmin.activateMember}
                      </Button>
                      <ConfirmButton
                        confirmLabel={t.orgAdmin.removeMemberConfirm}
                        variant="danger"
                        disabled={removeMutation.isPending}
                        onConfirm={() => removeMutation.mutate(m.id)}
                      >
                        {t.orgAdmin.removeMember}
                      </ConfirmButton>
                    </span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  );
}

function InvitationsTab({
  orgId,
  invitations,
  loading,
  roleCodes,
  roleLabel,
  invalidate,
  run,
}: {
  orgId: string;
  invitations: Awaited<ReturnType<typeof api.invitations>>;
  loading: boolean;
  roleCodes: string[];
  roleLabel: (code: string) => string;
  invalidate: () => void;
  run: <T>(fn: () => Promise<T>) => Promise<T>;
}) {
  const { t } = useI18n();
  const [email, setEmail] = useState('');
  const [role, setRole] = useState('colaborador');
  const [accessEnd, setAccessEnd] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const inviteMutation = useMutation({
    mutationFn: () =>
      run(() =>
        api.inviteMember(orgId, {
          email: email.trim().toLowerCase(),
          role,
          accessEnd: accessEnd ? new Date(accessEnd).toISOString() : undefined,
        }),
      ),
    onSuccess: () => {
      setEmail('');
      setAccessEnd('');
      setSent(true);
      setError(null);
      invalidate();
      setTimeout(() => setSent(false), 3000);
    },
    onError: (e: unknown) => setError(e instanceof Error ? e.message : 'Error'),
  });

  const revokeMutation = useMutation({
    mutationFn: (id: string) => run(() => api.revokeInvitation(orgId, id)),
    onSuccess: () => {
      setError(null);
      invalidate();
    },
    onError: (e: unknown) => setError(e instanceof Error ? e.message : 'Error'),
  });

  const resendMutation = useMutation({
    mutationFn: (id: string) => run(() => api.resendInvitation(orgId, id)),
    onSuccess: () => {
      setError(null);
      invalidate();
    },
    onError: (e: unknown) => setError(e instanceof Error ? e.message : 'Error'),
  });

  const field = 'h-10 w-full rounded-btn border border-line px-3 text-sm text-ink';

  return (
    <div className="space-y-4">
      <Card title={t.orgAdmin.invite}>
        <form
          className="grid gap-3 sm:grid-cols-[2fr_1.2fr_1.1fr_auto] mt-2 items-end"
          onSubmit={(e) => {
            e.preventDefault();
            inviteMutation.mutate();
          }}
        >
          <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
            {t.orgAdmin.inviteEmail}
            <input
              type="email"
              required
              className={field}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="persona@empresa.mx"
            />
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
            {t.orgAdmin.inviteRole}
            <select className={field} value={role} onChange={(e) => setRole(e.target.value)}>
              {roleCodes.map((code) => (
                <option key={code} value={code}>
                  {roleLabel(code)}
                </option>
              ))}
            </select>
          </label>
          <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
            {t.orgAdmin.inviteAccessEnd}
            <input
              type="date"
              className={field}
              value={accessEnd}
              onChange={(e) => setAccessEnd(e.target.value)}
            />
          </label>
          <Button type="submit" disabled={inviteMutation.isPending}>
            {inviteMutation.isPending ? t.common.loading : t.orgAdmin.sendInvite}
          </Button>
        </form>
        {sent && (
          <p className="mt-3 text-sm text-success" role="status">
            {t.orgAdmin.invitationSent}
          </p>
        )}
        {error && (
          <p className="mt-3 text-sm text-danger" role="alert">
            {error}
          </p>
        )}
      </Card>

      <Card title={`${t.orgAdmin.tabInvitations} · ${invitations.length}`}>
        {loading ? (
          <p className="text-sm text-ink-soft">{t.common.loading}</p>
        ) : invitations.length === 0 ? (
          <p className="text-sm text-ink-soft">{t.orgAdmin.noInvitations}</p>
        ) : (
          <table className="w-full text-sm mt-2">
            <thead>
              <tr className="text-left text-xs uppercase tracking-wide text-ink-muted">
                <th className="py-2 pr-4">{t.orgAdmin.inviteEmail}</th>
                <th className="py-2 pr-4">{t.orgAdmin.inviteRole}</th>
                <th className="py-2 pr-4">{t.orgAdmin.status}</th>
                <th className="py-2 pr-4">{t.orgAdmin.expiresAt}</th>
                <th className="py-2 text-right">{t.common.actions}</th>
              </tr>
            </thead>
            <tbody>
              {invitations.map((inv) => (
                <tr key={inv.id} className="border-t border-line">
                  <td className="py-2.5 pr-4 font-medium">{inv.email}</td>
                  <td className="py-2.5 pr-4">{roleLabel(inv.role)}</td>
                  <td className="py-2.5 pr-4">
                    <Badge tone={inv.status === 'PENDING' ? 'warn' : 'muted'}>
                      {inv.status === 'PENDING' ? t.orgAdmin.pending : t.orgAdmin.expired}
                    </Badge>
                  </td>
                  <td className="py-2.5 pr-4 text-ink-soft">
                    {new Date(inv.expiresAt).toLocaleDateString()}
                  </td>
                  <td className="py-2.5 text-right whitespace-nowrap">
                    <span className="inline-flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        disabled={resendMutation.isPending}
                        onClick={() => resendMutation.mutate(inv.id)}
                      >
                        {t.orgAdmin.resend}
                      </Button>
                      <ConfirmButton
                        confirmLabel={t.orgAdmin.revokeConfirm}
                        variant="danger"
                        disabled={revokeMutation.isPending}
                        onConfirm={() => revokeMutation.mutate(inv.id)}
                      >
                        {t.orgAdmin.revoke}
                      </ConfirmButton>
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}

function StructureTab({
  orgId,
  refresh: refreshAll,
  run,
  onError,
}: {
  orgId: string;
  refresh: () => void;
  run: <T>(fn: () => Promise<T>) => Promise<T>;
  onError: (m: string | null) => void;
}) {
  const { t } = useI18n();

  const branchesQuery = useQuery({
    queryKey: ['org-branches', orgId],
    queryFn: () => api.branches(orgId),
  });
  const areasQuery = useQuery({
    queryKey: ['org-areas', orgId],
    queryFn: () => api.areas(orgId),
  });

  const [branchName, setBranchName] = useState('');
  const [city, setCity] = useState('');
  const [areaName, setAreaName] = useState('');
  const [areaBranch, setAreaBranch] = useState('');

  const refresh = refreshAll;

  const createBranch = useMutation({
    mutationFn: () =>
      run(() => api.createBranch(orgId, { name: branchName.trim(), city: city.trim() || undefined })),
    onSuccess: () => {
      setBranchName('');
      setCity('');
      onError(null);
      refresh();
    },
    // El error ya se muestra desde el contenedor (vía `run`).
    onError: () => undefined,
  });

  const createArea = useMutation({
    mutationFn: () =>
      run(() =>
        api.createArea(orgId, { name: areaName.trim(), branchId: areaBranch || undefined }),
      ),
    onSuccess: () => {
      setAreaName('');
      onError(null);
      refresh();
    },
    onError: () => undefined,
  });

  const deleteBranch = useMutation({
    mutationFn: (id: string) => run(() => api.deleteBranch(orgId, id)),
    onSuccess: () => {
      onError(null);
      refresh();
    },
    onError: () => undefined,
  });

  const deleteArea = useMutation({
    mutationFn: (id: string) => run(() => api.deleteArea(orgId, id)),
    onSuccess: () => {
      onError(null);
      refresh();
    },
    onError: () => undefined,
  });

  const field = 'h-10 w-full rounded-btn border border-line px-3 text-sm text-ink';
  const branches: OrgBranch[] = branchesQuery.data ?? [];
  const areas: OrgArea[] = areasQuery.data ?? [];

  return (
    <div className="space-y-4">
      <div className="grid gap-4 lg:grid-cols-2">
        <Card title={t.orgAdmin.branches}>
          <form
            className="grid gap-3 sm:grid-cols-[2fr_1.4fr_auto] mt-2 items-end"
            onSubmit={(e) => {
              e.preventDefault();
              createBranch.mutate();
            }}
          >
            <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
              {t.orgAdmin.branchName}
              <input
                required
                className={field}
                value={branchName}
                onChange={(e) => setBranchName(e.target.value)}
              />
            </label>
            <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
              {t.orgAdmin.city}
              <input className={field} value={city} onChange={(e) => setCity(e.target.value)} />
            </label>
            <Button type="submit" disabled={createBranch.isPending}>
              {t.orgAdmin.addBranch}
            </Button>
          </form>

          {branches.length === 0 ? (
            <p className="mt-4 text-sm text-ink-soft">{t.orgAdmin.noBranches}</p>
          ) : (
            <ul className="mt-4 divide-y divide-line">
              {branches.map((b) => (
                <li key={b.id} className="flex items-center gap-3 py-2">
                  <div className="flex-1">
                    <div className="font-semibold text-ink">{b.name}</div>
                    <div className="text-xs text-ink-muted">
                      {[b.city, b.state, b.country].filter(Boolean).join(' · ')}
                    </div>
                  </div>
                  <ConfirmButton
                    confirmLabel={t.orgAdmin.deleteConfirm}
                    variant="danger"
                    disabled={deleteBranch.isPending}
                    onConfirm={() => deleteBranch.mutate(b.id)}
                  >
                    {t.orgAdmin.delete}
                  </ConfirmButton>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card title={t.orgAdmin.areas}>
          <form
            className="grid gap-3 sm:grid-cols-[2fr_1.4fr_auto] mt-2 items-end"
            onSubmit={(e) => {
              e.preventDefault();
              createArea.mutate();
            }}
          >
            <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
              {t.orgAdmin.areaName}
              <input
                required
                className={field}
                value={areaName}
                onChange={(e) => setAreaName(e.target.value)}
              />
            </label>
            <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
              {t.orgAdmin.branch}
              <select
                className={field}
                value={areaBranch}
                onChange={(e) => setAreaBranch(e.target.value)}
              >
                <option value="">{t.orgAdmin.noBranch}</option>
                {branches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.name}
                  </option>
                ))}
              </select>
            </label>
            <Button type="submit" disabled={createArea.isPending}>
              {t.orgAdmin.addArea}
            </Button>
          </form>

          {areas.length === 0 ? (
            <p className="mt-4 text-sm text-ink-soft">{t.orgAdmin.noAreas}</p>
          ) : (
            <ul className="mt-4 divide-y divide-line">
              {areas.map((a) => (
                <li key={a.id} className="flex items-center gap-3 py-2">
                  <div className="flex-1">
                    <div className="font-semibold text-ink">{a.name}</div>
                    <div className="text-xs text-ink-muted">
                      {branches.find((b) => b.id === a.branchId)?.name ?? t.orgAdmin.noBranch}
                    </div>
                  </div>
                  <ConfirmButton
                    confirmLabel={t.orgAdmin.deleteConfirm}
                    variant="danger"
                    disabled={deleteArea.isPending}
                    onConfirm={() => deleteArea.mutate(a.id)}
                  >
                    {t.orgAdmin.delete}
                  </ConfirmButton>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>
    </div>
  );
}
