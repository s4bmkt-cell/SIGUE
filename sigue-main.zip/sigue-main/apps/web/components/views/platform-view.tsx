'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import {
  api,
  type PlatformCreateOrgResult,
  type PlatformOrgDetail,
} from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select } from '@/components/ui/form';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const STATUS_TONES: Record<string, 'ok' | 'warn' | 'muted'> = {
  ACTIVE: 'ok',
  SUSPENDED: 'warn',
};

const dateFmt = (iso: string | null) => (iso ? new Date(iso).toLocaleDateString() : '—');

/**
 * Panel de plataforma: catálogo de empresas y su ciclo de vida.
 *
 * No usa la organización activa: las rutas de `/platform` no llevan `orgId`
 * porque el administrador de plataforma no pertenece a las organizaciones que
 * administra. Solo se ven metadatos (plan, estado, personas, consumo): el
 * contenido del SGI de cada cliente queda fuera del alcance a propósito.
 */
export function PlatformView() {
  const { t } = useI18n();
  const { isGlobalAdmin } = usePermissions();
  const qc = useQueryClient();

  const [search, setSearch] = useState('');
  const [applied, setApplied] = useState('');
  const [notice, setNotice] = useState<{ tone: 'ok' | 'error'; text: string } | null>(null);
  const [created, setCreated] = useState<PlatformCreateOrgResult | null>(null);
  const [detailId, setDetailId] = useState<string | null>(null);

  const orgsQuery = useQuery({
    queryKey: ['platform-orgs', applied],
    queryFn: () => api.platformOrgs(applied || undefined),
    enabled: isGlobalAdmin,
  });

  const plansQuery = useQuery({
    queryKey: ['platform-plans'],
    queryFn: () => api.platformPlans(),
    enabled: isGlobalAdmin,
  });

  const standardsQuery = useQuery({
    queryKey: ['platform-standards'],
    queryFn: () => api.platformStandards(),
    enabled: isGlobalAdmin,
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: 'ACTIVE' | 'SUSPENDED' }) =>
      api.platformSetOrgStatus(id, status),
    onSuccess: (org) => {
      setNotice({ tone: 'ok', text: `${org.name}: ${org.status}` });
      qc.invalidateQueries({ queryKey: ['platform-orgs'] });
      qc.invalidateQueries({ queryKey: ['orgs'] });
    },
    onError: (error: Error) => setNotice({ tone: 'error', text: error.message }),
  });

  const orgs = useMemo(() => orgsQuery.data ?? [], [orgsQuery.data]);

  if (!isGlobalAdmin) {
    return <p className="text-sm text-ink-soft">{t.platform.noAccess}</p>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-navy">{t.platform.title}</h1>
        <p className="mt-1 text-sm text-ink-soft">{t.platform.subtitle}</p>
      </div>

      {notice && (
        <div
          className={`rounded-btn border px-4 py-3 text-sm ${
            notice.tone === 'ok'
              ? 'border-success/30 bg-success-bg text-success'
              : 'border-danger/30 bg-danger-bg text-danger'
          }`}
          role="status"
        >
          {notice.text}
        </div>
      )}

      {created && (
        <CreatedOrgPanel result={created} onClose={() => setCreated(null)} />
      )}

      <Card
        title={t.platform.newOrg}
        subtitle={t.platform.newOrgSubtitle}
      >
        <CreateOrgForm
          plans={plansQuery.data ?? []}
          standards={standardsQuery.data ?? []}
          onCreated={(result) => {
            setCreated(result);
            setNotice({ tone: 'ok', text: t.platform.createdOk });
            qc.invalidateQueries({ queryKey: ['platform-orgs'] });
            qc.invalidateQueries({ queryKey: ['orgs'] });
          }}
          onError={(message) => setNotice({ tone: 'error', text: message })}
        />
      </Card>

      <Card
        title={t.platform.org}
        action={
          <form
            className="flex items-end gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              setApplied(search.trim());
            }}
          >
            <Input
              name="platform-search"
              placeholder={t.platform.searchPlaceholder}
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-64"
            />
            <Button type="submit" size="sm" variant="outline">
              {t.platform.search}
            </Button>
          </form>
        }
      >
        {orgsQuery.isLoading && <SkeletonCards count={3} />}

        {orgsQuery.isError && (
          <ErrorState
            message={(orgsQuery.error as Error).message}
            onRetry={() => orgsQuery.refetch()}
            retryLabel={t.common.retry}
          />
        )}

        {!orgsQuery.isLoading && !orgsQuery.isError && orgs.length === 0 && (
          <EmptyState
            title={applied ? t.platform.emptySearch : t.platform.empty}
            hint={t.platform.suspendedHint}
          />
        )}

        {orgs.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-line text-left text-[11px] uppercase tracking-wide text-ink-muted">
                  <th className="py-2 pr-3 font-semibold">{t.platform.org}</th>
                  <th className="py-2 pr-3 font-semibold">{t.platform.plan}</th>
                  <th className="py-2 pr-3 font-semibold">{t.platform.status}</th>
                  <th className="py-2 pr-3 text-right font-semibold">{t.platform.users}</th>
                  <th className="py-2 pr-3 text-right font-semibold">{t.platform.standards}</th>
                  <th className="py-2 pr-3 text-right font-semibold">{t.platform.storage}</th>
                  <th className="py-2 pr-3 font-semibold">{t.platform.created}</th>
                  <th className="py-2 font-semibold">{t.platform.actions}</th>
                </tr>
              </thead>
              <tbody>
                {orgs.map((org) => (
                  <tr key={org.id} className="border-b border-line/60 last:border-0">
                    <td className="py-2.5 pr-3">
                      <button
                        type="button"
                        className="text-left font-semibold text-ink hover:text-info"
                        onClick={() => setDetailId(org.id)}
                        title={t.platform.detail}
                      >
                        {org.name}
                      </button>
                      {org.legalName && org.legalName !== org.name && (
                        <div className="text-[11px] text-ink-muted">{org.legalName}</div>
                      )}
                    </td>
                    <td className="py-2.5 pr-3">{org.plan}</td>
                    <td className="py-2.5 pr-3">
                      <Badge tone={STATUS_TONES[org.status] ?? 'muted'}>
                        {org.status === 'SUSPENDED' ? t.platform.suspended : t.platform.active}
                      </Badge>
                    </td>
                    <td className="py-2.5 pr-3 text-right tabular-nums">{org.users}</td>
                    <td className="py-2.5 pr-3 text-right tabular-nums">{org.standards}</td>
                    <td className="py-2.5 pr-3 text-right tabular-nums">{org.storageGb} GB</td>
                    <td className="py-2.5 pr-3 text-ink-soft">{dateFmt(org.createdAt)}</td>
                    <td className="py-2.5">
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setDetailId(org.id)}
                        >
                          {t.platform.detail}
                        </Button>
                        {org.status === 'ACTIVE' ? (
                          <ConfirmButton
                            confirmLabel={t.platform.confirmSuspend}
                            onConfirm={() =>
                              statusMutation.mutate({ id: org.id, status: 'SUSPENDED' })
                            }
                            disabled={statusMutation.isPending}
                          >
                            {t.platform.suspend}
                          </ConfirmButton>
                        ) : (
                          <Button
                            size="sm"
                            variant="outline"
                            disabled={statusMutation.isPending}
                            onClick={() =>
                              statusMutation.mutate({ id: org.id, status: 'ACTIVE' })
                            }
                          >
                            {t.platform.reactivate}
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <p className="mt-3 text-[11px] text-ink-muted">{t.platform.suspendedHint}</p>
          </div>
        )}
      </Card>

      {detailId && (
        <OrgDetailPanel id={detailId} onClose={() => setDetailId(null)} />
      )}
    </div>
  );
}

/** Formulario de alta. El estado vive aquí para no re-renderizar la tabla. */
function CreateOrgForm({
  plans,
  standards,
  onCreated,
  onError,
}: {
  plans: { code: string; name: string; monthlyUsd: number; users: number }[];
  standards: { code: string; title: string }[];
  onCreated: (result: PlatformCreateOrgResult) => void;
  onError: (message: string) => void;
}) {
  const { t } = useI18n();
  const [name, setName] = useState('');
  const [legalName, setLegalName] = useState('');
  const [plan, setPlan] = useState('');
  const [adminName, setAdminName] = useState('');
  const [adminEmail, setAdminEmail] = useState('');
  const [selected, setSelected] = useState<string[]>([]);

  const mutation = useMutation({
    mutationFn: () =>
      api.platformCreateOrg({
        name: name.trim(),
        legalName: legalName.trim() || undefined,
        plan: plan || plans[0]?.code,
        standards: selected,
        adminName: adminName.trim(),
        adminEmail: adminEmail.trim(),
      }),
    onSuccess: (result) => {
      onCreated(result);
      setName('');
      setLegalName('');
      setPlan('');
      setAdminName('');
      setAdminEmail('');
      setSelected([]);
    },
    onError: (error: Error) => onError(error.message),
  });

  const canSubmit =
    name.trim().length >= 2 &&
    adminName.trim().length >= 2 &&
    /.+@.+\..+/.test(adminEmail) &&
    !mutation.isPending;

  return (
    <form
      className="grid gap-3 md:grid-cols-2"
      onSubmit={(e) => {
        e.preventDefault();
        if (canSubmit) mutation.mutate();
      }}
    >
      <Input
        name="org-name"
        label={t.platform.name}
        value={name}
        onChange={(e) => setName(e.target.value)}
        required
        minLength={2}
        maxLength={160}
      />
      <Input
        name="org-legal-name"
        label={t.platform.legalName}
        value={legalName}
        onChange={(e) => setLegalName(e.target.value)}
        maxLength={200}
      />
      <Select
        name="org-plan"
        label={t.platform.plan}
        value={plan}
        onChange={(e) => setPlan(e.target.value)}
      >
        <option value="">—</option>
        {plans.map((p) => (
          <option key={p.code} value={p.code}>
            {p.name} · ${p.monthlyUsd}/mes · {p.users} {t.platform.users.toLowerCase()}
          </option>
        ))}
      </Select>
      <Input
        name="org-admin-name"
        label={t.platform.adminName}
        value={adminName}
        onChange={(e) => setAdminName(e.target.value)}
        required
        minLength={2}
        maxLength={120}
      />
      <Input
        name="org-admin-email"
        label={t.platform.adminEmail}
        type="email"
        value={adminEmail}
        onChange={(e) => setAdminEmail(e.target.value)}
        required
      />
      <fieldset className="md:col-span-2">
        <legend className="mb-1.5 text-sm font-medium text-ink">
          {t.platform.standardsLabel}
        </legend>
        <div className="flex flex-wrap gap-2">
          {standards.map((s) => {
            const checked = selected.includes(s.code);
            return (
              <label
                key={s.code}
                className={`flex cursor-pointer items-center gap-2 rounded-full border px-3 py-1 text-xs ${
                  checked
                    ? 'border-primary bg-info-bg text-info'
                    : 'border-line text-ink-soft'
                }`}
              >
                <input
                  type="checkbox"
                  className="size-3.5"
                  checked={checked}
                  onChange={(e) =>
                    setSelected((prev) =>
                      e.target.checked
                        ? [...prev, s.code]
                        : prev.filter((code) => code !== s.code),
                    )
                  }
                />
                {s.title}
              </label>
            );
          })}
        </div>
      </fieldset>
      <div className="md:col-span-2">
        <Button type="submit" disabled={!canSubmit}>
          {mutation.isPending ? t.platform.creating : t.platform.create}
        </Button>
      </div>
    </form>
  );
}

/** Contraseña temporal: se muestra una vez y se puede copiar. */
function CreatedOrgPanel({
  result,
  onClose,
}: {
  result: PlatformCreateOrgResult;
  onClose: () => void;
}) {
  const { t } = useI18n();
  const [copied, setCopied] = useState(false);

  return (
    <div className="rounded-card border border-warning/40 bg-warning-bg p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <h3 className="text-sm font-bold text-ink">{t.platform.passwordTitle}</h3>
          <p className="mt-1 text-xs text-ink-soft">
            {result.temporaryPassword ? t.platform.passwordWarning : t.platform.passwordExisting}
          </p>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <code className="rounded-btn bg-white px-3 py-1.5 font-mono text-sm text-ink">
              {result.adminEmail}
            </code>
            {result.temporaryPassword && (
              <>
                <code className="rounded-btn bg-white px-3 py-1.5 font-mono text-sm text-ink">
                  {result.temporaryPassword}
                </code>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={async () => {
                    try {
                      await navigator.clipboard.writeText(result.temporaryPassword!);
                      setCopied(true);
                    } catch {
                      // Sin permiso de portapapeles: el texto sigue visible.
                    }
                  }}
                >
                  {copied ? t.platform.copied : t.platform.copy}
                </Button>
              </>
            )}
          </div>
        </div>
        <Button size="sm" variant="ghost" onClick={onClose}>
          {t.platform.close}
        </Button>
      </div>
    </div>
  );
}

/** Detalle de una empresa: administradores, suscripción y métricas. */
function OrgDetailPanel({ id, onClose }: { id: string; onClose: () => void }) {
  const { t } = useI18n();
  const query = useQuery({
    queryKey: ['platform-org', id],
    queryFn: () => api.platformOrg(id),
  });

  return (
    <Card
      title={t.platform.detailTitle}
      action={
        <Button size="sm" variant="ghost" onClick={onClose}>
          {t.platform.close}
        </Button>
      }
    >
      {query.isLoading && <SkeletonCards count={1} />}
      {query.isError && (
        <ErrorState
          message={(query.error as Error).message}
          onRetry={() => query.refetch()}
          retryLabel={t.common.retry}
        />
      )}
      {query.data && <OrgDetailBody org={query.data} />}
    </Card>
  );
}

function OrgDetailBody({ org }: { org: PlatformOrgDetail }) {
  const { t } = useI18n();
  return (
    <div className="space-y-4">
      <div className="grid gap-3 text-sm md:grid-cols-4">
        <Metric label={t.platform.plan} value={org.plan} />
        <Metric label={t.platform.status} value={org.status} />
        <Metric label={t.platform.users} value={String(org.users)} />
        <Metric label={t.platform.storage} value={`${org.storageGb} GB`} />
      </div>

      {org.subscription && (
        <div className="rounded-btn border border-line px-3 py-2 text-xs text-ink-soft">
          <span className="font-semibold text-ink">{t.platform.subscription}:</span>{' '}
          {org.subscription.planCode} · {org.subscription.status}
          {org.subscription.periodEnd && ` · ${dateFmt(org.subscription.periodEnd)}`}
        </div>
      )}

      <div>
        <div className="mb-1.5 text-[11px] font-semibold uppercase tracking-wide text-ink-muted">
          {t.platform.admins}
        </div>
        {org.admins.length === 0 && (
          <p className="text-sm text-ink-soft">{t.common.noData}</p>
        )}
        <ul className="divide-y divide-line/60">
          {org.admins.map((a) => (
            <li key={a.id} className="flex flex-wrap items-center gap-2 py-2 text-sm">
              <span className="font-medium text-ink">{a.name}</span>
              <span className="text-ink-soft">{a.email}</span>
              <span className="ml-auto text-[11px] text-ink-muted">
                {t.platform.lastAccess}:{' '}
                {a.lastLoginAt ? dateFmt(a.lastLoginAt) : t.platform.never}
              </span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-btn border border-line px-3 py-2">
      <div className="text-[11px] font-semibold text-ink-muted">{label}</div>
      <div className="text-base font-bold text-navy">{value}</div>
    </div>
  );
}
