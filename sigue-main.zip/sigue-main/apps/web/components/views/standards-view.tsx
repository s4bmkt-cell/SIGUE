'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api, type Standard } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const LEVELS = ['NOT_IMPLEMENTED', 'PARTIAL', 'IMPLEMENTED', 'MATURE'] as const;

function levelBadge(level: string, t: ReturnType<typeof useI18n>['t']) {
  const map: Record<string, { tone: 'danger' | 'warn' | 'ok' | 'info'; label: string }> = {
    NOT_IMPLEMENTED: { tone: 'danger', label: t.standards.notImplemented },
    PARTIAL: { tone: 'warn', label: t.standards.partial },
    IMPLEMENTED: { tone: 'ok', label: t.standards.implemented },
    MATURE: { tone: 'info', label: t.standards.mature },
  };
  const m = map[level] ?? map.NOT_IMPLEMENTED;
  return <Badge tone={m.tone}>{m.label}</Badge>;
}

export function StandardsView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();
  const [selectedStandard, setSelectedStandard] = useState<Standard | null>(null);
  // Alcance de la norma que se está editando (una a la vez).
  const [editingScopeFor, setEditingScopeFor] = useState<string | null>(null);
  const [scopeDraft, setScopeDraft] = useState('');

  const standardsQuery = useQuery({
    queryKey: ['standards', orgId],
    queryFn: () => api.standards(orgId!),
    enabled: !!orgId,
  });

  const requirementsQuery = useQuery({
    queryKey: ['requirements', orgId, selectedStandard?.id],
    queryFn: () => api.requirements(orgId!, selectedStandard!.id),
    enabled: !!orgId && !!selectedStandard,
  });

  const complianceQuery = useQuery({
    queryKey: ['compliance', orgId, selectedStandard?.id],
    queryFn: () => api.compliance(orgId!, selectedStandard!.id),
    enabled: !!orgId && !!selectedStandard,
  });

  const activateMutation = useMutation({
    mutationFn: (std: Standard) => api.activateStandard(orgId!, std.id),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['standards', orgId] });
      qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
      toast.success(t.common.saved);
    },
  });

  // Declarar o corregir el alcance de una norma ya activa.
  const scopeMutation = useMutation({
    mutationFn: ({ standardId, scopeText }: { standardId: string; scopeText: string }) =>
      api.updateStandardScope(orgId!, standardId, scopeText),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['standards', orgId] });
      toast.success(t.common.saved);
      setEditingScopeFor(null);
    },
  });

  const setLevelMutation = useMutation({
    mutationFn: ({ clauseId, level }: { clauseId: string; level: string }) =>
      api.setRequirementLevel(orgId!, selectedStandard!.id, clauseId, level),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['requirements', orgId, selectedStandard?.id] });
      qc.invalidateQueries({ queryKey: ['compliance', orgId, selectedStandard?.id] });
      qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
      qc.invalidateQueries({ queryKey: ['dashboard-compliance', orgId] });
      toast.success(t.common.saved);
    },
  });

  if (!orgId) return null;
  const { active, catalog } = standardsQuery.data ?? { active: [], catalog: [] };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-navy">{t.standards.title}</h1>
        <p className="text-sm text-ink-soft mt-1">{t.standards.subtitle}</p>
      </div>

      {standardsQuery.isLoading && <SkeletonCards count={2} />}

      {standardsQuery.isError && (
        <ErrorState
          message={(standardsQuery.error as Error).message}
          onRetry={() => standardsQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      <div className="grid lg:grid-cols-3 gap-4">
        {/* Catálogo */}
        <Card title={t.standards.catalog}>
          {catalog.length === 0 ? (
            <EmptyState title={t.standards.noActive} />
          ) : (
            <div className="space-y-2 mt-2">
              {catalog.map((std) => {
                const isActive = active.some((a) => a.standardId === std.id);
                return (
                  <div key={std.id} className="flex items-center gap-3 border border-line rounded-btn px-3 py-2.5">
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold truncate">{std.code} · {std.edition}</div>
                      <div className="text-[11px] text-ink-muted truncate">{std.title}</div>
                    </div>
                    {isActive ? (
                      <Badge tone="ok">{t.standards.active}</Badge>
                    ) : canWrite ? (
                      <Button
                        size="sm"
                        onClick={() => activateMutation.mutate(std)}
                        disabled={activateMutation.isPending}
                      >
                        {t.standards.activate}
                      </Button>
                    ) : null}
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* Resumen de cumplimiento de la norma seleccionada */}
        <Card title={t.standards.myStandards}>
          {active.length === 0 && <p className="text-sm text-ink-soft">{t.standards.noActive}</p>}
          {active.map((a) => {
            const isSelected = selectedStandard?.id === a.standard.id;
            const editingScope = editingScopeFor === a.standard.id;
            return (
              <div
                key={a.id}
                className={`w-full border rounded-btn px-3 py-2.5 mb-2 transition-colors ${
                  isSelected ? 'border-primary bg-info-bg' : 'border-line hover:border-line-strong'
                }`}
              >
                <div className="flex items-start gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedStandard(a.standard)}
                    className="flex-1 min-w-0 text-left"
                  >
                    <div className="text-sm font-semibold">{a.standard.code} · {a.standard.edition}</div>
                    {/* Si la norma se activó sin alcance, se dice, en vez de dejar el hueco. */}
                    <div
                      className={`text-[11px] line-clamp-2 ${
                        a.scopeText?.trim() ? 'text-ink-muted' : 'text-warning'
                      }`}
                    >
                      {a.scopeText?.trim() || t.standards.noScope}
                    </div>
                  </button>
                  {/* El alcance se declara aquí, junto a la norma: antes solo se
                      podía fijar al activarla y quedaba vacío para siempre. */}
                  {canWrite && (
                    <button
                      type="button"
                      className="shrink-0 text-[11px] font-semibold text-primary hover:underline"
                      onClick={() => {
                        setEditingScopeFor(editingScope ? null : a.standard.id);
                        setScopeDraft(a.scopeText ?? '');
                      }}
                    >
                      {editingScope ? t.common.cancel : t.standards.editScope}
                    </button>
                  )}
                </div>
                {editingScope && (
                  <div className="mt-2 space-y-2">
                    <textarea
                      value={scopeDraft}
                      onChange={(e) => setScopeDraft(e.target.value)}
                      rows={3}
                      placeholder={t.standards.scopePlaceholder}
                      className="w-full rounded-btn border border-line px-2 py-1.5 text-xs"
                      aria-label={t.standards.scopeLabel}
                    />
                    <Button
                      size="sm"
                      disabled={scopeMutation.isPending || !scopeDraft.trim()}
                      onClick={() =>
                        scopeMutation.mutate({ standardId: a.standard.id, scopeText: scopeDraft.trim() })
                      }
                    >
                      {scopeMutation.isPending ? t.common.saving : t.common.save}
                    </Button>
                  </div>
                )}
              </div>
            );
          })}
        </Card>

        {/* KPI de cumplimiento */}
        <Card title={t.standards.state}>
          {!selectedStandard ? (
            <p className="text-sm text-ink-soft">{t.standards.selectStandard}</p>
          ) : complianceQuery.isError ? (
            <ErrorState
              message={(complianceQuery.error as Error).message}
              onRetry={() => complianceQuery.refetch()}
              retryLabel={t.common.retry}
            />
          ) : (
            <div className="space-y-3 mt-2">
              <div className="text-sm font-semibold text-navy">{selectedStandard.code} · {selectedStandard.edition}</div>
              <div className="text-3xl font-extrabold text-navy">
                {complianceQuery.data?.pct ?? '—'}%
              </div>
              <div className="text-[12px] text-ink-soft">
                {complianceQuery.data
                  ? `${complianceQuery.data.implemented}/${complianceQuery.data.total}`
                  : t.common.loading}
              </div>
              <Badge tone="ok">
                {compliantStatusLabel(
                  active.find((a) => a.standardId === selectedStandard.id)?.status,
                  t,
                )}
              </Badge>
            </div>
          )}
        </Card>
      </div>

      {/* Requisitos con niveles */}
      {selectedStandard && (
        <Card
          title={`${t.standards.requirements} · ${selectedStandard.code}`}
          action={<Button size="sm" variant="outline" onClick={() => setSelectedStandard(null)}>{t.common.close}</Button>}
        >
          {requirementsQuery.isLoading && <p className="text-sm text-ink-soft">{t.common.loading}</p>}
          {requirementsQuery.isError && (
            <ErrorState
              message={(requirementsQuery.error as Error).message}
              onRetry={() => requirementsQuery.refetch()}
              retryLabel={t.common.retry}
            />
          )}
          {requirementsQuery.data?.length === 0 && <EmptyState title={t.common.noData} />}
          <table className="w-full text-[13px] mt-2">
            <thead>
              <tr className="text-[10.5px] uppercase tracking-wider text-ink-muted text-left border-b-2 border-line-strong">
                <th className="py-2 w-24">{t.standards.clause}</th>
                <th>{t.standards.requirements}</th>
                <th className="w-44">{t.standards.state}</th>
                <th className="w-36">{t.standards.setLevel}</th>
              </tr>
            </thead>
            <tbody>
              {requirementsQuery.data?.map((r) =>
                r.kind === 'clause' ? (
                  <tr key={r.id} className="bg-page">
                    <td colSpan={4} className="py-2 px-2 text-[11px] font-bold uppercase tracking-wider text-ink-soft">
                      {r.code} · {r.title}
                    </td>
                  </tr>
                ) : (
                  <tr key={r.id} className="border-b border-line">
                    <td className="py-2 font-mono text-xs">{r.code}</td>
                    <td>
                      <div className="font-medium">{r.title}</div>
                      <div className="text-[11px] text-ink-muted line-clamp-1">{r.requirementText}</div>
                    </td>
                    <td className="py-2">{levelBadge(r.level, t)}</td>
                    <td className="py-2">
                      <select
                        value={r.level}
                        onChange={(e) => setLevelMutation.mutate({ clauseId: r.id, level: e.target.value })}
                        className="text-xs border border-line rounded-btn px-2 py-1 bg-white disabled:opacity-50"
                        aria-label={`${t.standards.setLevel} ${r.code}`}
                        disabled={!canWrite}
                      >
                        {LEVELS.map((l) => (
                          <option key={l} value={l}>
                            {levelBadgeLabel(l, t)}
                          </option>
                        ))}
                      </select>
                    </td>
                  </tr>
                ),
              )}
            </tbody>
          </table>
        </Card>
      )}
    </div>
  );
}

function levelBadgeLabel(level: string, t: ReturnType<typeof useI18n>['t']) {
  return (
    {
      NOT_IMPLEMENTED: t.standards.notImplemented,
      PARTIAL: t.standards.partial,
      IMPLEMENTED: t.standards.implemented,
      MATURE: t.standards.mature,
    }[level] ?? level
  );
}

function compliantStatusLabel(status: string | undefined, t: ReturnType<typeof useI18n>['t']) {
  if (status === 'ACTIVE') return t.standards.statusActive;
  if (status === 'INACTIVE') return t.standards.statusInactive;
  return status ?? '';
}
