'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const DECISION_TONES: Record<string, 'ok' | 'info' | 'warn' | 'danger' | 'muted'> = {
  ACCEPTED: 'ok',
  MODIFIED: 'info',
  REJECTED: 'warn',
  REPORTED: 'danger',
  PENDING: 'muted',
};

export function AiGovernanceView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();
  const [query, setQuery] = useState('');

  const useCasesQuery = useQuery({
    queryKey: ['ai-use-cases', orgId],
    queryFn: () => api.aiUseCases(orgId!),
    enabled: !!orgId,
  });
  const interactionsQuery = useQuery({
    queryKey: ['ai-interactions', orgId],
    queryFn: () => api.aiInteractions(orgId!),
    enabled: !!orgId,
  });
  const incidentsQuery = useQuery({
    queryKey: ['ai-incidents', orgId],
    queryFn: () => api.aiIncidents(orgId!),
    enabled: !!orgId,
  });
  const searchQuery = useQuery({
    queryKey: ['ai-search', orgId, query],
    queryFn: () => api.aiSearch(orgId!, query),
    enabled: !!orgId && query.trim().length > 1,
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: 'ENABLED' | 'DISABLED' }) =>
      api.aiSetUseCaseStatus(orgId!, id, status),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['ai-use-cases', orgId] });
      toast.success(t.common.saved);
    },
    onError: (err) =>
      toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  if (!orgId) return null;
  const useCases = useCasesQuery.data ?? [];
  const interactions = interactionsQuery.data ?? [];
  const incidents = incidentsQuery.data ?? [];

  const decisionLabel = (d: string) =>
    ({
      ACCEPTED: t.aiGovernance.accepted,
      MODIFIED: t.aiGovernance.modified,
      REJECTED: t.aiGovernance.rejected,
      REPORTED: t.aiGovernance.reported,
      PENDING: t.aiGovernance.pending,
    })[d] ?? d;

  const loading = useCasesQuery.isLoading || interactionsQuery.isLoading;
  const error = (useCasesQuery.error ?? interactionsQuery.error) as Error | null;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-navy">{t.aiGovernance.title}</h1>
        <p className="mt-1 text-sm text-ink-soft">{t.aiGovernance.subtitle}</p>
      </div>

      {loading && <SkeletonCards count={3} />}

      {error && (
        <ErrorState
          message={error.message}
          onRetry={() => {
            useCasesQuery.refetch();
            interactionsQuery.refetch();
          }}
          retryLabel={t.common.retry}
        />
      )}

      {/* Casos de uso con cuotas y desactivación */}
      <Card title={t.aiGovernance.useCases}>
        {useCases.length === 0 ? (
          <EmptyState title={t.aiGovernance.noInteractions} />
        ) : (
          <div className="mt-2 space-y-2">
            {useCases.map((uc) => (
              <div
                key={uc.id}
                className="flex flex-wrap items-center justify-between gap-3 rounded-btn border border-line px-3 py-2.5"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[11px] font-semibold text-primary">
                      {uc.code}
                    </span>
                    <span className="text-sm font-medium">{uc.name}</span>
                  </div>
                  <div className="text-[11px] text-ink-muted">{uc.purpose}</div>
                </div>
                <div className="flex flex-wrap items-center gap-3">
                  {uc.monthlyQuota != null && (
                    <div className="text-[11px] text-ink-soft">
                      {t.aiGovernance.quota}: {uc.spentTokens}/{uc.monthlyQuota}{' '}
                      {t.aiGovernance.used}
                      <div className="mt-1 h-1.5 w-24 overflow-hidden rounded-full bg-page">
                        <div
                          className="h-full rounded-full bg-primary"
                          style={{ width: `${Math.min(uc.quotaUsedPct, 100)}%` }}
                        />
                      </div>
                    </div>
                  )}
                  <Badge tone={uc.status === 'ENABLED' ? 'ok' : 'muted'}>
                    {uc.status === 'ENABLED'
                      ? t.aiGovernance.enabled
                      : t.aiGovernance.disabled}
                  </Badge>
                  <Button
                    size="sm"
                    variant={uc.status === 'ENABLED' ? 'outline' : 'primary'}
                    disabled={!canWrite || statusMutation.isPending}
                    onClick={() =>
                      statusMutation.mutate({
                        id: uc.id,
                        status: uc.status === 'ENABLED' ? 'DISABLED' : 'ENABLED',
                      })
                    }
                  >
                    {uc.status === 'ENABLED' ? t.aiGovernance.disable : t.aiGovernance.enable}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Búsqueda semántica */}
      <Card title={t.aiGovernance.search}>
        <Input
          placeholder={t.aiGovernance.searchPlaceholder}
          aria-label={t.aiGovernance.search}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        {searchQuery.isFetching && (
          <p className="mt-3 text-xs text-ink-muted" role="status">
            {t.common.loading}
          </p>
        )}
        {searchQuery.isError && (
          <div className="mt-3">
            <ErrorState message={(searchQuery.error as Error).message} />
          </div>
        )}
        {!searchQuery.isFetching && query.trim().length > 1 && searchQuery.data?.length === 0 && (
          <p className="mt-3 text-sm text-ink-soft">{t.common.noData}</p>
        )}
        {searchQuery.data && searchQuery.data.length > 0 && (
          <div className="mt-3 space-y-1.5">
            {searchQuery.data.map((r) => (
              <div
                key={r.id}
                className="flex items-center justify-between border-b border-line pb-1.5 text-sm last:border-0"
              >
                <div>
                  <span className="font-medium">{r.title}</span>
                  <span className="ml-2 text-xs text-ink-muted">({r.sourceType})</span>
                </div>
                <Badge
                  tone={r.similarity > 0.7 ? 'ok' : r.similarity > 0.4 ? 'warn' : 'muted'}
                  dot={false}
                >
                  {t.aiGovernance.similarity}: {r.similarity}
                </Badge>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Bitácora */}
      <Card title={`${t.aiGovernance.interactions} · ${interactions.length}`}>
        {interactions.length === 0 ? (
          <p className="text-sm text-ink-soft">{t.aiGovernance.noInteractions}</p>
        ) : (
          <div className="mt-2 space-y-1.5">
            {interactions.map((i) => (
              <div
                key={i.id}
                className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-1.5 text-sm last:border-0"
              >
                <div className="flex min-w-0 items-center gap-2">
                  <span className="font-mono text-[11px] text-primary">{i.useCase.code}</span>
                  <span className="truncate text-ink-soft">{i.useCase.name}</span>
                  {i.module && (
                    <Badge tone="muted" dot={false}>
                      {i.module}
                    </Badge>
                  )}
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  {i.sources.length > 0 && (
                    <span className="text-[10px] text-ink-muted">
                      {i.sources.length} {t.copilot.sources}
                    </span>
                  )}
                  <Badge tone={DECISION_TONES[i.decision] ?? 'muted'}>
                    {decisionLabel(i.decision)}
                  </Badge>
                  <span className="text-[10px] text-ink-muted">
                    {new Date(i.createdAt).toLocaleString(undefined, {
                      day: '2-digit',
                      month: 'short',
                    })}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Incidentes */}
      <Card title={`${t.aiGovernance.incidents} · ${incidents.length}`}>
        {incidents.length === 0 ? (
          <p className="text-sm text-ink-soft">{t.aiGovernance.noIncidents}</p>
        ) : (
          <div className="mt-2 space-y-1.5">
            {incidents.map((inc) => (
              <div
                key={inc.id}
                className="flex flex-wrap items-center justify-between gap-3 border-b border-line pb-1.5 text-sm last:border-0"
              >
                <div className="flex items-center gap-2">
                  <Badge tone={inc.severity === 'ALTA' || inc.severity === 'CRITICA' ? 'danger' : 'warn'}>
                    {inc.severity}
                  </Badge>
                  <span className="text-ink-soft">{inc.description}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone="muted" dot={false}>
                    {inc.type}
                  </Badge>
                  <Badge tone={inc.status === 'RESOLVED' ? 'ok' : 'danger'}>
                    {inc.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
