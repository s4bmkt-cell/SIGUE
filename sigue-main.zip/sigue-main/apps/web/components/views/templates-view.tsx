'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const KINDS = {
  POLITICA: 'typePolicy',
  PROCEDIMIENTO: 'typeProcedure',
  FORMATO: 'typeForm',
  REGISTRO: 'typeRecord',
  MANUAL: 'typeManual',
} as const;

const KIND_TONES: Record<string, 'info' | 'ok' | 'warn' | 'muted'> = {
  POLITICA: 'info',
  PROCEDIMIENTO: 'ok',
  FORMATO: 'warn',
  REGISTRO: 'muted',
};

export function TemplatesView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();
  const [filter, setFilter] = useState('');

  const templatesQuery = useQuery({
    queryKey: ['templates', orgId, filter],
    queryFn: () => api.templates(orgId!, filter || undefined),
    enabled: !!orgId,
  });

  const createFromTemplate = useMutation({
    mutationFn: (templateId: string) => api.createFromTemplate(orgId!, templateId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['documents', orgId] });
      qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
      toast.success(t.documents.templateCreated);
    },
    onError: (err) =>
      toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  if (!orgId) return null;
  const templates = templatesQuery.data ?? [];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.documents.templates}</h1>
          <p className="mt-1 text-sm text-ink-soft">{t.documents.templatesSubtitle}</p>
        </div>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
          aria-label={t.documents.type}
        >
          <option value="">{t.documents.allTypes}</option>
          {Object.entries(KINDS).map(([value, key]) => (
            <option key={value} value={value}>
              {t.documents[key]}
            </option>
          ))}
        </select>
      </div>

      {templatesQuery.isLoading && <SkeletonCards count={3} />}

      {templatesQuery.isError && (
        <ErrorState
          message={(templatesQuery.error as Error).message}
          onRetry={() => templatesQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {!templatesQuery.isLoading && templates.length === 0 && (
        <EmptyState title={t.documents.templatesEmpty} />
      )}

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {templates.map((tpl) => (
          <Card key={tpl.id}>
            <div className="flex items-center justify-between gap-2">
              <Badge tone={KIND_TONES[tpl.kind] ?? 'muted'} dot={false}>
                {t.documents[KINDS[tpl.kind as keyof typeof KINDS] ?? 'typePolicy']}
              </Badge>
              <span className="font-mono text-[10px] text-ink-muted">{tpl.code}</span>
            </div>
            <h3 className="mt-2 text-sm font-semibold">{tpl.title}</h3>
            <div className="mt-1 text-[11px] text-ink-muted">
              {/* La versión ya viene con prefijo "v1" desde la API. */}
              {tpl.content.sections?.length ?? 0} {t.documents.sections} · {tpl.version}
            </div>
            {tpl.content.sections && tpl.content.sections.length > 0 && (
              <ul className="mt-2 space-y-0.5 text-[11px] text-ink-soft">
                {tpl.content.sections.slice(0, 3).map((s) => (
                  <li key={s.heading} className="truncate">
                    · {s.heading}
                  </li>
                ))}
              </ul>
            )}
            <Button
              size="sm"
              className="mt-3 w-full"
              onClick={() => createFromTemplate.mutate(tpl.id)}
              disabled={!canWrite || createFromTemplate.isPending}
            >
              {t.documents.createFromTemplate}
            </Button>
          </Card>
        ))}
      </div>
      {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
    </div>
  );
}
