'use client';

import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import type { LucideIcon } from 'lucide-react';
import { Globe2, Layers, LayoutGrid, Scale, ShieldCheck, Target, Users, Workflow } from 'lucide-react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { ModuleTile } from '@/components/ui/module-tile';
import { useContextData, type ContextSectionKey } from './context/shared';
import { SwotSection } from './context/swot-section';
import { PestelSection } from './context/pestel-section';
import { PartiesSection } from './context/parties-section';
import { LegalSection } from './context/legal-section';
import { IssuesSection } from './context/issues-section';
import { ProcessesSection } from './context/processes-section';
import { ScopeSection } from './context/scope-section';
import { SoaSection } from './context/soa-section';

/**
 * Contexto de la organización (ISO 4.1–4.4).
 *
 * La vista abre con un mosaico de accesos, no con los datos: cinco bloques que
 * el usuario reconoce de un vistazo. Cada tarjeta abre su sección a pantalla
 * completa con una miga «Contexto / Sección» para volver.
 */
export function ContextView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const { query } = useContextData(orgId);
  // El alcance vive en la norma (`OrgStandard.scopeText`), no en el contexto:
  // se consulta la norma con la misma clave que Normas y requisitos para que
  // ambas pantallas compartan caché.
  const standardsQuery = useQuery({
    queryKey: ['standards', orgId],
    queryFn: () => api.standards(orgId!),
    enabled: !!orgId,
  });
  const [section, setSection] = useState<ContextSectionKey | null>(null);

  if (!orgId) return null;

  const goBack = () => setSection(null);

  if (section === 'swot') return <SwotSection orgId={orgId} onBack={goBack} />;
  if (section === 'pestel') return <PestelSection orgId={orgId} onBack={goBack} />;
  if (section === 'parties') return <PartiesSection orgId={orgId} onBack={goBack} />;
  if (section === 'legal') return <LegalSection orgId={orgId} onBack={goBack} />;
  if (section === 'issues') return <IssuesSection orgId={orgId} onBack={goBack} />;
  if (section === 'processes') return <ProcessesSection orgId={orgId} onBack={goBack} />;
  if (section === 'scope') return <ScopeSection orgId={orgId} onBack={goBack} />;
  if (section === 'soa') return <SoaSection orgId={orgId} onBack={goBack} />;

  const c = query.data;
  // El contador solo aparece cuando ya llegaron los datos: un "0" mientras
  // carga se leería como que la sección está vacía.
  const count = (n: number | undefined) => (n == null ? null : n);

  const tiles: {
    key: ContextSectionKey;
    icon: LucideIcon;
    title: string;
    description: string;
    total: number | null;
  }[] = [
    {
      key: 'swot',
      icon: LayoutGrid,
      title: t.context.swot,
      description: t.context.swotHint,
      // El contador dice cuántos FODA hay, no cuántos elementos: los elementos
      // solo tienen sentido dentro de su análisis.
      total: count(c?.swotAnalyses.length),
    },
    {
      key: 'pestel',
      icon: Globe2,
      title: t.context.pestel,
      description: t.context.pestelHint,
      total: count(c?.pestelAnalyses.length),
    },
    {
      key: 'parties',
      icon: Users,
      title: t.context.parties,
      description: t.context.partiesHint,
      total: count(c?.parties.length),
    },
    {
      key: 'legal',
      icon: Scale,
      title: t.context.legal,
      description: t.context.legalHint,
      total: count(c?.legal.length),
    },
    {
      key: 'issues',
      icon: Layers,
      title: t.context.issues,
      description: t.context.issuesHint,
      total: count(c?.issues.length),
    },
    {
      key: 'processes',
      icon: Workflow,
      title: t.context.processes,
      description: t.context.processesHint,
      total: count(c?.processes.length),
    },
    {
      key: 'scope',
      // El contador del alcance cuenta normas activas con alcance declarado.
      icon: Target,
      title: t.context.scope,
      description: t.context.scopeHint,
      total: standardsQuery.data
        ? standardsQuery.data.active.filter((a) => a.scopeText?.trim()).length
        : null,
    },
    {
      key: 'soa',
      // La SoA existe por norma con Anexo A (27001 y 42001); el contador
      // refleja cuántas declaraciones hay, no cuántos controles.
      icon: ShieldCheck,
      title: t.context.soaTile,
      description: t.context.soaHint,
      total: standardsQuery.data
        ? standardsQuery.data.active.filter((a) =>
            ['ISO27001', 'ISO42001'].includes(a.standard.code),
          ).length
        : null,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.context.title}</h1>
          <p className="text-sm text-ink-soft mt-1">{t.context.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {/* Ocho accesos: en pantallas anchas caben en una sola fila; en anchos
          intermedios se acomodan en dos. */}
      <div className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 gap-3">
        {tiles.map((tile) => (
          <ModuleTile
            key={tile.key}
            icon={tile.icon}
            title={tile.title}
            hint={`${t.context.openSection}: ${tile.description}`}
            total={tile.total}
            onOpen={() => setSection(tile.key)}
          />
        ))}
      </div>

      <p className="text-xs text-ink-muted">{t.context.hubHint}</p>
    </div>
  );
}
