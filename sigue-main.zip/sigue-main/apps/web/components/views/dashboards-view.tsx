'use client';

import { useQuery } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

export function DashboardsView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();

  const summaryQuery = useQuery({
    queryKey: ['dashboard-summary', orgId],
    queryFn: () => api.dashboardSummary(orgId!),
    enabled: !!orgId,
  });

  const complianceQuery = useQuery({
    queryKey: ['dashboard-compliance', orgId],
    queryFn: () => api.dashboardCompliance(orgId!),
    enabled: !!orgId,
  });

  // Con varias normas activas, el mismo código de cláusula aparece en más de
  // una; cada fila se identifica por norma + código.
  const grouped = useMemo(() => {
    const map = new Map<string, { code: string; count: number; implemented: number; pct: number }[]>();
    for (const row of complianceQuery.data ?? []) {
      const list = map.get(row.standard) ?? [];
      list.push(row);
      map.set(row.standard, list);
    }
    return [...map.entries()];
  }, [complianceQuery.data]);
  const [openStandard, setOpenStandard] = useState<string | null>(null);

  if (!orgId) return null;
  const s = summaryQuery.data;

  const kpis = s
    ? [
        {
          label: t.dashboards.compliance,
          value: `${s.compliance.pct}%`,
          sub: `${s.compliance.pending} ${t.dashboards.pendingReq}`,
        },
        {
          label: t.dashboards.openNC,
          value: String(s.nc.open),
          sub: `${s.nc.critical} ${t.dashboards.critical}`,
          danger: s.nc.critical > 0,
        },
        {
          label: t.dashboards.upcomingAudits,
          value: String(s.audits.upcoming),
          sub: t.audits.title,
        },
        {
          label: t.dashboards.activePlans,
          value: String(s.plans.active),
          sub: `${s.plans.pendingTasks} ${t.dashboards.pendingTasks}`,
        },
      ]
    : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-navy">{t.dashboards.title}</h1>
        <p className="mt-1 text-sm text-ink-soft">{t.dashboards.subtitle}</p>
      </div>

      {summaryQuery.isLoading && <SkeletonCards count={3} />}

      {summaryQuery.isError && (
        <ErrorState
          message={(summaryQuery.error as Error).message}
          onRetry={() => summaryQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {/* KPIs */}
      {s && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {kpis.map((kpi, i) => (
            <div key={i} className="rounded-card border border-line bg-white p-4 shadow-card">
              <div className="text-xs font-semibold text-ink-muted">{kpi.label}</div>
              <div
                className={`text-[26px] font-extrabold ${kpi.danger ? 'text-danger' : 'text-navy'}`}
              >
                {kpi.value}
              </div>
              <div className="text-[11.5px] text-ink-soft">{kpi.sub}</div>
            </div>
          ))}
        </div>
      )}

      {/* Preparación para certificación */}
      {s && (
        <Card title={t.dashboards.readyForCert}>
          <div className="mt-2 flex items-center gap-4">
            <span className="text-3xl font-extrabold text-navy">{s.compliance.pct}%</span>
            <div
              className="h-3 flex-1 overflow-hidden rounded-full bg-page"
              role="progressbar"
              aria-valuenow={s.compliance.pct}
              aria-valuemin={0}
              aria-valuemax={100}
            >
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${s.compliance.pct}%` }}
              />
            </div>
          </div>
          <div className="mt-3 flex flex-wrap gap-2">
            <Badge tone="ok" dot={false}>
              {s.objectives.total} {t.dashboards.objectives}
            </Badge>
            <Badge tone="info" dot={false}>
              {s.audits.upcoming} {t.dashboards.upcomingAudits}
            </Badge>
            <Badge tone={s.nc.open > 0 ? 'warn' : 'ok'} dot={false}>
              {s.nc.open} {t.dashboards.openNC}
            </Badge>
          </div>
        </Card>
      )}

      {/* Cumplimiento por cláusula */}
      <Card title={t.dashboards.complianceByClause}>
        {complianceQuery.isLoading && <SkeletonCards count={2} />}
        {complianceQuery.isError && (
          <ErrorState
            message={(complianceQuery.error as Error).message}
            onRetry={() => complianceQuery.refetch()}
            retryLabel={t.common.retry}
          />
        )}
        {!complianceQuery.isLoading && !complianceQuery.isError && grouped.length === 0 && (
          <EmptyState title={t.common.noData} />
        )}
        {grouped.length > 0 && (
          <div className="mt-2 space-y-2">
            {grouped.map(([standard, rows]) => {
              const total = rows.reduce((n, r) => n + r.count, 0);
              const done = rows.reduce((n, r) => n + r.implemented, 0);
              const pct = total ? Math.round((done / total) * 100) : 0;
              const open = openStandard === standard;
              return (
                <div key={standard} className="border border-line rounded-card overflow-hidden">
                  <button
                    onClick={() => setOpenStandard(open ? null : standard)}
                    aria-expanded={open}
                    className="w-full flex items-center gap-3 px-3 py-2.5 text-left hover:bg-page"
                  >
                    <span className="w-24 shrink-0 text-xs font-bold text-navy">{standard}</span>
                    <div className="h-2 flex-1 overflow-hidden rounded-full bg-page">
                      <div className="h-full rounded-full bg-primary" style={{ width: `${pct}%` }} />
                    </div>
                    <span className="w-24 text-right text-xs text-ink-soft">
                      {done}/{total} · {pct}%
                    </span>
                    <span className="w-4 text-ink-muted">{open ? '▾' : '▸'}</span>
                  </button>
                  {open && (
                    <ul className="space-y-2.5 border-t border-line px-3 py-3">
                      {rows.map((c) => (
                        <li key={c.code} className="flex items-center gap-3 text-[13px]">
                          <span className="w-24 font-mono text-xs font-semibold text-ink">{c.code}</span>
                          <div className="h-2 flex-1 overflow-hidden rounded-full bg-page">
                            <div className="h-full rounded-full bg-primary" style={{ width: `${c.pct}%` }} />
                          </div>
                          <span className="w-20 text-right text-ink-soft">
                            {c.implemented}/{c.count} · {c.pct}%
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </Card>
    </div>
  );
}
