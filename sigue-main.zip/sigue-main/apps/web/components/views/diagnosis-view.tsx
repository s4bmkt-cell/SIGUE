'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const PRIORITY_TONE = {
  HIGH: 'danger',
  MEDIUM: 'warn',
  LOW: 'muted',
} as const;

export function DiagnosisView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const standardsQuery = useQuery({
    queryKey: ['standards', orgId],
    queryFn: () => api.standards(orgId!),
    enabled: !!orgId,
  });
  // Con varias normas activas el diagnóstico debe poder ejecutarse por norma.
  // Sin selección explícita se usa la primera activa (el `select` la refleja).
  const activeList = standardsQuery.data?.active ?? [];
  const [pickedId, setPickedId] = useState<string | null>(null);
  const activeStd = activeList.find((a) => a.standardId === pickedId) ?? activeList[0];

  const diagnosisQuery = useQuery({
    queryKey: ['diagnosis', orgId, activeStd?.standardId],
    queryFn: () => api.getDiagnosis(orgId!, activeStd!.standardId),
    enabled: !!orgId && !!activeStd?.standardId,
  });

  const runMutation = useMutation({
    mutationFn: () => api.runDiagnosis(orgId!, activeStd!.standardId),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['diagnosis', orgId] });
      qc.invalidateQueries({ queryKey: ['planning', orgId] });
      qc.invalidateQueries({ queryKey: ['plans', orgId] });
      toast.success(t.diagnosis.done);
    },
  });

  if (!orgId) return null;
  const d = diagnosisQuery.data;

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.diagnosis.title}</h1>
          <p className="text-sm text-ink-soft mt-1">{t.diagnosis.subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          {activeList.length > 1 ? (
            <select
              value={activeStd?.standardId ?? ''}
              onChange={(e) => setPickedId(e.target.value)}
              aria-label={t.standards.selectStandard}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
            >              {activeList.map((a) => (
                <option key={a.id} value={a.standardId}>
                  {a.standard.code}
                </option>
              ))}
            </select>
          ) : (
            activeStd && <Badge tone="ok">{activeStd.standard.code}</Badge>
          )}
          {canWrite && (
            <Button
              onClick={() => runMutation.mutate()}
              disabled={runMutation.isPending || !activeStd}
            >
              {runMutation.isPending
                ? t.diagnosis.running
                : d
                  ? t.diagnosis.reRun
                  : t.diagnosis.run}
            </Button>
          )}
        </div>
      </div>

      {!activeStd && !standardsQuery.isLoading && (
        <EmptyState title={t.standards.noActive} hint={t.standards.subtitle} />
      )}

      {standardsQuery.isError && (
        <ErrorState
          message={(standardsQuery.error as Error).message}
          onRetry={() => standardsQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {diagnosisQuery.isLoading && <SkeletonCards count={2} />}

      {diagnosisQuery.isError && (
        <ErrorState
          message={(diagnosisQuery.error as Error).message}
          onRetry={() => diagnosisQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {/* KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { label: t.diagnosis.maturity, value: d ? `${d.maturity}/5` : '—' },
          { label: t.diagnosis.gap, value: d ? `${d.gap}%` : '—', danger: (d?.gap ?? 0) > 50 },
          { label: t.diagnosis.evaluated, value: d ? `${d.evaluated}/${d.total}` : '—' },
          { label: t.diagnosis.planTitle, value: d ? d.plan.tasks.length : '—', sub: t.diagnosis.tasks },
        ].map((kpi, i) => (
          <div key={i} className="bg-white border border-line rounded-card shadow-card p-4">
            <div className="text-xs text-ink-muted font-semibold">{kpi.label}</div>
            <div className={`text-[26px] font-extrabold ${kpi.danger ? 'text-danger' : 'text-navy'}`}>{kpi.value}</div>
            {kpi.sub && <div className="text-[11.5px] text-ink-soft">{kpi.sub}</div>}
          </div>
        ))}
      </div>

      {d && (
        <>
          {/* Niveles */}
          <Card title={t.standards.state}>
            <div className="flex gap-2 flex-wrap mt-2">
              {Object.entries(d.levels).map(([level, count]) => (
                <div key={level} className="flex items-center gap-2 border border-line rounded-btn px-3 py-2">
                  <span className="text-sm font-semibold">{count}</span>
                  {levelBadge(level, t)}
                </div>
              ))}
            </div>
          </Card>

          {/* Recomendaciones */}
          <Card title={t.diagnosis.recommendations}>
            {d.recommendations.length === 0 ? (
              <EmptyState title={t.diagnosis.noGaps} />
            ) : (
              <ul className="space-y-2 mt-2">
                {d.recommendations.map((r, i) => (
                  <li key={i} className="flex gap-3 text-sm border-b border-line pb-2 last:border-0">
                    <span className="font-mono text-xs text-primary mt-0.5">{r.clause}</span>
                    <div>
                      <div className="font-medium">{r.title}</div>
                      <div className="text-xs text-ink-soft">{recommendationText(r, t)}</div>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {/* Plan generado */}
          <Card title={`${t.diagnosis.planTitle} · ${d.plan.title}`}>
            <p className="text-xs text-ink-muted mb-2">{t.diagnosis.months}</p>
            {d.plan.tasks.length === 0 ? (
              <EmptyState title={t.diagnosis.noTasks} />
            ) : (
              <div className="space-y-1.5">
                {d.plan.tasks.map((task, i) => (
                  <div key={i} className="flex items-center gap-3 text-sm border-b border-line pb-1.5 last:border-0">
                    <Badge
                      tone={PRIORITY_TONE[task.priority as keyof typeof PRIORITY_TONE] ?? 'muted'}
                      dot={false}
                    >
                      {t.planning[task.priority === 'HIGH' ? 'priorityHigh' : task.priority === 'MEDIUM' ? 'priorityMedium' : 'priorityLow']}
                    </Badge>
                    <span>{task.title}</span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </>
      )}
    </div>
  );
}

function levelBadge(level: string, t: ReturnType<typeof useI18n>['t']) {
  const map: Record<string, { tone: 'danger' | 'warn' | 'ok' | 'info'; label: string }> = {
    NOT_IMPLEMENTED: { tone: 'danger', label: t.standards.notImplemented },
    PARTIAL: { tone: 'warn', label: t.standards.partial },
    IMPLEMENTED: { tone: 'ok', label: t.standards.implemented },
    MATURE: { tone: 'info', label: t.standards.mature },
  };
  const m = map[level] ?? map.NOT_IMPLEMENTED;
  return <Badge tone={m.tone}>{m.label}</Badge>;
}

/** El backend envía la recomendación ya redactada; se traduce en el cliente. */
function recommendationText(
  r: { clause: string; title: string; level: string },
  t: ReturnType<typeof useI18n>['t'],
) {
  const template = r.level === 'PARTIAL' ? t.diagnosis.recPartial : t.diagnosis.recNotImplemented;
  return template.replace('{code}', r.clause).replace('{title}', r.title);
}
