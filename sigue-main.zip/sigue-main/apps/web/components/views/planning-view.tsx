'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api, type PlanningData } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const RISK_TONES: Record<string, 'ok' | 'warn' | 'danger' | 'info' | 'muted'> = {
  OPEN: 'danger',
  ASSESSED: 'warn',
  TREATED: 'ok',
  CLOSED: 'muted',
};

/** Estados del plan/objetivo → etiqueta localizada. */
function lifecycleLabel(status: string, t: ReturnType<typeof useI18n>['t']) {
  const map: Record<string, string> = {
    ACTIVE: t.planning.statusActive,
    DRAFT: t.planning.statusDraft,
    COMPLETED: t.planning.statusCompleted,
    CANCELLED: t.planning.statusCancelled,
  };
  return map[status] ?? status;
}

/** Estado de tarea → etiqueta y tono. El tramo `PENDING|IN_PROGRESS|DONE`. */
function taskMeta(status: string, t: ReturnType<typeof useI18n>['t']) {
  if (status === 'DONE') return { label: t.planning.done, tone: 'ok' as const, done: true };
  if (status === 'IN_PROGRESS')
    return { label: t.planning.inProgress, tone: 'info' as const, done: false };
  return { label: t.planning.pending, tone: 'muted' as const, done: false };
}

export function PlanningView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [riskTitle, setRiskTitle] = useState('');
  const [riskCategory, setRiskCategory] = useState('OPERATIVO');
  const [objectiveTitle, setObjectiveTitle] = useState('');
  const [planTitle, setPlanTitle] = useState('');
  // Una entrada por plan: antes era un único estado compartido y el texto se
  // perdía al escribir en otro plan.
  const [taskDrafts, setTaskDrafts] = useState<Record<string, string>>({});
  const [kpiDrafts, setKpiDrafts] = useState<Record<string, { name: string; target: string }>>({});
  const [treatmentDrafts, setTreatmentDrafts] = useState<Record<string, string>>({});

  const planningQuery = useQuery({
    queryKey: ['planning', orgId],
    queryFn: () => api.planning(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['planning', orgId] });
    qc.invalidateQueries({ queryKey: ['plans', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
  };

  const addRisk = useMutation({
    mutationFn: () => api.addRisk(orgId!, { title: riskTitle, category: riskCategory }),
    onSuccess: () => {
      refresh();
      setRiskTitle('');
      toast.success(t.common.saved);
    },
  });

  const assessRisk = useMutation({
    mutationFn: ({ riskId, l, i }: { riskId: string; l: number; i: number }) =>
      api.assessRisk(orgId!, riskId, l, i),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
  });

  const removeRisk = useMutation({
    mutationFn: (riskId: string) => api.deleteRisk(orgId!, riskId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const addTreatment = useMutation({
    mutationFn: ({ riskId, plan }: { riskId: string; plan: string }) =>
      api.addTreatment(orgId!, riskId, { type: 'MITIGAR', plan }),
    onSuccess: (_data, vars) => {
      refresh();
      setTreatmentDrafts((d) => ({ ...d, [vars.riskId]: '' }));
      toast.success(t.common.saved);
    },
  });

  const addObjective = useMutation({
    mutationFn: () => api.addObjective(orgId!, objectiveTitle),
    onSuccess: () => {
      refresh();
      setObjectiveTitle('');
      toast.success(t.common.saved);
    },
  });

  const removeObjective = useMutation({
    mutationFn: (objectiveId: string) => api.deleteObjective(orgId!, objectiveId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const addKpi = useMutation({
    mutationFn: ({ objectiveId, name, target }: { objectiveId: string; name: string; target?: number }) =>
      api.addKpi(orgId!, objectiveId, { name, target }),
    onSuccess: (_data, vars) => {
      refresh();
      setKpiDrafts((d) => ({ ...d, [vars.objectiveId]: { name: '', target: '' } }));
      toast.success(t.common.saved);
    },
  });

  const createPlan = useMutation({
    mutationFn: () => api.createPlan(orgId!, { title: planTitle }),
    onSuccess: () => {
      refresh();
      setPlanTitle('');
      toast.success(t.common.saved);
    },
  });

  const removePlan = useMutation({
    mutationFn: (planId: string) => api.deletePlan(orgId!, planId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const addTask = useMutation({
    mutationFn: ({ planId, title }: { planId: string; title: string }) =>
      api.addTask(orgId!, planId, { title, priority: 'MEDIUM' }),
    onSuccess: (_data, vars) => {
      refresh();
      setTaskDrafts((d) => ({ ...d, [vars.planId]: '' }));
      toast.success(t.common.saved);
    },
  });

  const setTaskStatus = useMutation({
    mutationFn: ({ taskId, status }: { taskId: string; status: string }) =>
      api.updateTaskStatus(orgId!, taskId, status),
    onSuccess: () => refresh(),
  });

  const removeTask = useMutation({
    mutationFn: (taskId: string) => api.deleteTask(orgId!, taskId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  if (!orgId) return null;

  const d: PlanningData | undefined = planningQuery.data;

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.planning.title}</h1>
          <p className="text-sm text-ink-soft mt-1">{t.planning.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {planningQuery.isLoading && <SkeletonCards count={3} />}

      {planningQuery.isError && (
        <ErrorState
          message={(planningQuery.error as Error).message}
          onRetry={() => planningQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {planningQuery.isSuccess && (
        <>
          <div className="grid lg:grid-cols-2 gap-4">
            {/* Riesgos */}
            <Card title={t.planning.risks}>
              {(d?.risks ?? []).length === 0 ? (
                <div className="mt-2">
                  <EmptyState title={t.planning.noRisks} hint={t.planning.subtitle} />
                </div>
              ) : (
                <div className="space-y-2 mt-2">
                  {(d?.risks ?? []).map((r) => {
                    const score = r.assessments?.[0]?.score;
                    return (
                      <div key={r.id} className="border border-line rounded-btn px-3 py-2.5">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold">{r.title}</span>
                          <div className="flex items-center gap-2 shrink-0">
                            <Badge tone={RISK_TONES[r.status] ?? 'muted'}>
                              {r.status === 'TREATED'
                                ? t.planning.treated
                                : r.status === 'OPEN'
                                  ? t.planning.open
                                  : r.status}
                            </Badge>
                            {canWrite && (
                              <ConfirmButton
                                confirmLabel={t.common.confirmDelete}
                                onConfirm={() => removeRisk.mutate(r.id)}
                                variant="ghost"
                                className="h-6 px-1.5 text-[11px]"
                              >
                                {t.common.delete}
                              </ConfirmButton>
                            )}
                          </div>
                        </div>
                        <div className="flex items-center gap-3 mt-1.5 flex-wrap">
                          <span className="text-xs text-ink-muted">
                            {t.planning.score}: <b className="text-ink">{score ?? '—'}</b>
                          </span>
                          {score === undefined || score === null ? (
                            canWrite && (
                              <div className="flex gap-1.5">
                                {[
                                  { l: 2, i: 2, label: '4' },
                                  { l: 3, i: 3, label: '9' },
                                  { l: 4, i: 4, label: '16' },
                                ].map((opt) => (
                                  <Button
                                    key={opt.label}
                                    size="sm"
                                    variant="outline"
                                    className="h-6 px-2 text-[11px]"
                                    onClick={() =>
                                      assessRisk.mutate({ riskId: r.id, l: opt.l, i: opt.i })
                                    }
                                  >
                                    {t.planning.assess} {opt.label}
                                  </Button>
                                ))}
                              </div>
                            )
                          ) : (
                            r.treatments?.[0] && (
                              <span className="text-xs text-ink-soft">{r.treatments[0].plan}</span>
                            )
                          )}
                        </div>
                        {canWrite && !r.treatments?.length && (
                          <div className="flex gap-2 mt-2">
                            <Input
                              placeholder={t.planning.addTreatment}
                              value={treatmentDrafts[r.id] ?? ''}
                              onChange={(e) =>
                                setTreatmentDrafts((s) => ({ ...s, [r.id]: e.target.value }))
                              }
                              className="h-8 text-xs flex-1"
                              onKeyDown={(e) => {
                                if (e.key === 'Enter' && treatmentDrafts[r.id])
                                  addTreatment.mutate({ riskId: r.id, plan: treatmentDrafts[r.id] });
                              }}
                            />
                            <Button
                              size="sm"
                              className="h-8"
                              onClick={() =>
                                addTreatment.mutate({ riskId: r.id, plan: treatmentDrafts[r.id] })
                              }
                              disabled={!treatmentDrafts[r.id] || addTreatment.isPending}
                            >
                              {t.common.add}
                            </Button>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
              {canWrite && (
                <div className="flex gap-2 mt-3 flex-wrap">
                  <Input
                    placeholder={t.planning.addRisk}
                    value={riskTitle}
                    onChange={(e) => setRiskTitle(e.target.value)}
                    className="flex-1 min-w-[160px]"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && riskTitle) addRisk.mutate();
                    }}
                  />
                  <select
                    value={riskCategory}
                    onChange={(e) => setRiskCategory(e.target.value)}
                    className="text-xs border border-line rounded-btn px-2 bg-white"
                    aria-label={t.planning.risks}
                  >
                    <option value="OPERATIVO">{t.planning.categoryOperational}</option>
                    <option value="ESTRATEGICO">{t.planning.categoryStrategic}</option>
                    <option value="CUMPLIMIENTO">{t.planning.categoryCompliance}</option>
                    <option value="SEGURIDAD">{t.planning.categorySecurity}</option>
                  </select>
                  <Button
                    size="sm"
                    onClick={() => addRisk.mutate()}
                    disabled={!riskTitle || addRisk.isPending}
                  >
                    {t.planning.addRisk}
                  </Button>
                </div>
              )}
            </Card>

            {/* Objetivos */}
            <Card title={t.planning.objectives}>
              {(d?.objectives ?? []).length === 0 ? (
                <div className="mt-2">
                  <EmptyState title={t.planning.noObjectives} hint={t.planning.subtitle} />
                </div>
              ) : (
                <div className="space-y-2 mt-2">
                  {(d?.objectives ?? []).map((o) => (
                    <div key={o.id} className="border border-line rounded-btn px-3 py-2.5">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-semibold">{o.title}</span>
                        <div className="flex items-center gap-2 shrink-0">
                          <Badge tone={o.status === 'COMPLETED' ? 'ok' : 'info'}>{lifecycleLabel(o.status, t)}</Badge>
                          {canWrite && (
                            <ConfirmButton
                              confirmLabel={t.common.confirmDelete}
                              onConfirm={() => removeObjective.mutate(o.id)}
                              variant="ghost"
                              className="h-6 px-1.5 text-[11px]"
                            >
                              {t.common.delete}
                            </ConfirmButton>
                          )}
                        </div>
                      </div>
                      {o.kpis.length > 0 && (
                        <div className="mt-1.5 flex gap-2 flex-wrap">
                          {o.kpis.map((k) => (
                            <span
                              key={k.id}
                              className="text-[11px] bg-page rounded-btn px-2 py-0.5 text-ink-soft"
                            >
                              {k.name}: {k.target ?? '—'}
                              {k.unit ?? ''}
                            </span>
                          ))}
                        </div>
                      )}
                      {canWrite && (
                        <div className="flex gap-2 mt-2">
                          <Input
                            placeholder={t.planning.kpiName}
                            value={kpiDrafts[o.id]?.name ?? ''}
                            onChange={(e) =>
                              setKpiDrafts((s) => ({
                                ...s,
                                [o.id]: { ...(s[o.id] ?? { target: '' }), name: e.target.value },
                              }))
                            }
                            className="h-8 text-xs flex-1"
                          />
                          <Input
                            placeholder={t.planning.kpiTarget}
                            inputMode="numeric"
                            value={kpiDrafts[o.id]?.target ?? ''}
                            onChange={(e) =>
                              setKpiDrafts((s) => ({
                                ...s,
                                [o.id]: { ...(s[o.id] ?? { name: '' }), target: e.target.value },
                              }))
                            }
                            className="h-8 text-xs w-24"
                          />
                          <Button
                            size="sm"
                            className="h-8"
                            onClick={() => {
                              const draft = kpiDrafts[o.id];
                              if (!draft?.name) return;
                              const target = Number(draft.target);
                              addKpi.mutate({
                                objectiveId: o.id,
                                name: draft.name,
                                target: Number.isFinite(target) && target > 0 ? target : undefined,
                              });
                            }}
                            disabled={!kpiDrafts[o.id]?.name || addKpi.isPending}
                          >
                            {t.planning.addKpi}
                          </Button>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
              {canWrite && (
                <div className="flex gap-2 mt-3">
                  <Input
                    placeholder={t.planning.addObjective}
                    value={objectiveTitle}
                    onChange={(e) => setObjectiveTitle(e.target.value)}
                    className="flex-1"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && objectiveTitle) addObjective.mutate();
                    }}
                  />
                  <Button
                    size="sm"
                    onClick={() => addObjective.mutate()}
                    disabled={!objectiveTitle || addObjective.isPending}
                  >
                    {t.planning.addObjective}
                  </Button>
                </div>
              )}
            </Card>
          </div>

          {/* Planes de trabajo */}
          <Card title={t.planning.plans}>
            {(d?.plans ?? []).length === 0 ? (
              <div className="mt-2">
                <EmptyState title={t.planning.noPlans} hint={t.planning.selectPlan} />
              </div>
            ) : (
              <div className="space-y-4 mt-2">
                {(d?.plans ?? []).map((p) => {
                  const done = p.tasks.filter((x) => x.status === 'DONE').length;
                  const pct = p.tasks.length ? Math.round((done / p.tasks.length) * 100) : 0;
                  return (
                    <div key={p.id} className="border border-line rounded-btn p-3">
                      <div className="flex items-center justify-between gap-2 flex-wrap">
                        <div className="min-w-0">
                          <span className="text-sm font-semibold">{p.title}</span>
                          <div className="text-[11px] text-ink-muted mt-0.5">
                            {done}/{p.tasks.length} · {pct}%
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge tone={p.status === 'COMPLETED' ? 'ok' : 'info'}>{lifecycleLabel(p.status, t)}</Badge>
                          {canWrite && (
                            <ConfirmButton
                              confirmLabel={t.common.confirmDelete}
                              onConfirm={() => removePlan.mutate(p.id)}
                              variant="ghost"
                              className="h-6 px-1.5 text-[11px]"
                            >
                              {t.common.delete}
                            </ConfirmButton>
                          )}
                        </div>
                      </div>
                      <div className="h-1.5 rounded-full bg-page mt-2 overflow-hidden">
                        <div
                          className="h-full rounded-full bg-[#16a34a] transition-all"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                      <div className="space-y-1 mt-2">
                        {p.tasks.length === 0 && (
                          <p className="text-xs text-ink-muted">{t.planning.noPlanTasks}</p>
                        )}
                        {p.tasks.map((task) => {
                          const meta = taskMeta(task.status, t);
                          return (
                            <div
                              key={task.id}
                              className="flex items-center gap-3 text-xs border-b border-line pb-1 last:border-0"
                            >
                              {canWrite ? (
                                <input
                                  type="checkbox"
                                  checked={meta.done}
                                  onChange={() =>
                                    setTaskStatus.mutate({
                                      taskId: task.id,
                                      status: meta.done ? 'PENDING' : 'DONE',
                                    })
                                  }
                                  className="size-3.5 accent-[#16a34a] cursor-pointer shrink-0"
                                  aria-label={task.title}
                                />
                              ) : (
                                <span className="size-3.5 shrink-0" />
                              )}
                              <Badge
                                tone={
                                  task.priority === 'HIGH'
                                    ? 'danger'
                                    : task.priority === 'MEDIUM'
                                      ? 'warn'
                                      : 'muted'
                                }
                                dot={false}
                              >
                                {task.priority === 'HIGH'
                                  ? t.planning.priorityHigh
                                  : task.priority === 'MEDIUM'
                                    ? t.planning.priorityMedium
                                    : t.planning.priorityLow}
                              </Badge>
                              <span className={meta.done ? 'line-through text-ink-muted' : ''}>
                                {task.title}
                              </span>
                              <span className="ml-auto text-ink-muted">{meta.label}</span>
                              {canWrite && (
                                <ConfirmButton
                                  confirmLabel={t.common.confirmDelete}
                                  onConfirm={() => removeTask.mutate(task.id)}
                                  variant="ghost"
                                  className="h-5 px-1 text-[10px]"
                                >
                                  {t.common.delete}
                                </ConfirmButton>
                              )}
                            </div>
                          );
                        })}
                      </div>
                      {canWrite && (
                        <div className="flex gap-2 mt-2">
                          <Input
                            placeholder={t.planning.addTask}
                            value={taskDrafts[p.id] ?? ''}
                            onChange={(e) =>
                              setTaskDrafts((s) => ({ ...s, [p.id]: e.target.value }))
                            }
                            className="flex-1 text-xs"
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && taskDrafts[p.id])
                                addTask.mutate({ planId: p.id, title: taskDrafts[p.id] });
                            }}
                          />
                          <Button
                            size="sm"
                            onClick={() =>
                              addTask.mutate({ planId: p.id, title: taskDrafts[p.id] })
                            }
                            disabled={!taskDrafts[p.id] || addTask.isPending}
                          >
                            {t.planning.addTask}
                          </Button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
            {canWrite && (
              <div className="flex gap-2 mt-4 pt-3 border-t border-line">
                <Input
                  placeholder={t.planning.planTitle}
                  value={planTitle}
                  onChange={(e) => setPlanTitle(e.target.value)}
                  className="flex-1"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && planTitle) createPlan.mutate();
                  }}
                />
                <Button
                  onClick={() => createPlan.mutate()}
                  disabled={!planTitle || createPlan.isPending}
                >
                  {t.planning.newPlan}
                </Button>
              </div>
            )}
          </Card>
        </>
      )}
    </div>
  );
}
