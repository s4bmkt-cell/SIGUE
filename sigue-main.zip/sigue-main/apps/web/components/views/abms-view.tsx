'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const SEVERITIES = {
  CRITICA: 'critical',
  ALTA: 'high',
  MEDIA: 'medium',
  BAJA: 'low',
} as const;

const CONTROL_STATUSES = {
  PLANNED: 'statusPlanned',
  IMPLEMENTED: 'statusImplemented',
  NOT_APPLICABLE: 'statusNotApplicable',
} as const;

const INCIDENT_STATUSES = {
  OPEN: 'statusOpen',
  INVESTIGATING: 'statusInvestigating',
  CLOSED: 'statusClosed',
} as const;

/** ISO 37001:2025 — riesgos, controles e investigaciones de soborno. */
export function AbmsView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [area, setArea] = useState('');
  const [activity, setActivity] = useState('');
  const [likelihood, setLikelihood] = useState('1');
  const [impact, setImpact] = useState('1');
  const [mitigation, setMitigation] = useState('');

  const [controlCode, setControlCode] = useState('');
  const [controlTitle, setControlTitle] = useState('');

  const [incidentTitle, setIncidentTitle] = useState('');
  const [incidentSeverity, setIncidentSeverity] = useState('MEDIA');
  const [resolveFor, setResolveFor] = useState<string | null>(null);
  const [resolution, setResolution] = useState('');

  const abmsQuery = useQuery({
    queryKey: ['abms', orgId],
    queryFn: () => api.abms(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['abms', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
  };

  const onError = (err: unknown) =>
    toast.error(err instanceof Error ? err.message : t.common.saveError);

  const addRisk = useMutation({
    mutationFn: () =>
      api.addBriberyRisk(orgId!, {
        area,
        activity,
        likelihood: Number(likelihood),
        impact: Number(impact),
        mitigation: mitigation || undefined,
      }),
    onSuccess: () => {
      refresh();
      setArea('');
      setActivity('');
      setMitigation('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeRisk = useMutation({
    mutationFn: (riskId: string) => api.deleteBriberyRisk(orgId!, riskId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const upsertControl = useMutation({
    mutationFn: () =>
      api.upsertBriberyControl(orgId!, { code: controlCode, title: controlTitle }),
    onSuccess: () => {
      refresh();
      setControlCode('');
      setControlTitle('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const updateControl = useMutation({
    mutationFn: ({ controlId, status }: { controlId: string; status: string }) =>
      api.updateBriberyControl(orgId!, controlId, { status }),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeControl = useMutation({
    mutationFn: (controlId: string) => api.deleteBriberyControl(orgId!, controlId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const addIncident = useMutation({
    mutationFn: () =>
      api.addBriberyIncident(orgId!, { title: incidentTitle, severity: incidentSeverity }),
    onSuccess: () => {
      refresh();
      setIncidentTitle('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const closeIncident = useMutation({
    mutationFn: ({ incidentId, text }: { incidentId: string; text: string }) =>
      api.updateBriberyIncident(orgId!, incidentId, { status: 'CLOSED', resolution: text }),
    onSuccess: () => {
      refresh();
      setResolveFor(null);
      setResolution('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeIncident = useMutation({
    mutationFn: (incidentId: string) => api.deleteBriberyIncident(orgId!, incidentId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  if (!orgId) return null;
  const d = abmsQuery.data;

  const severityTone = (s: string) =>
    s === 'CRITICA' ? 'danger' : s === 'ALTA' ? 'warn' : 'muted';
  const severityLabel = (s: string) =>
    t.abms[SEVERITIES[s as keyof typeof SEVERITIES] ?? 'medium'];
  const controlStatusLabel = (s: string) =>
    t.abms[CONTROL_STATUSES[s as keyof typeof CONTROL_STATUSES] ?? 'statusPlanned'];
  const incidentStatusLabel = (s: string) =>
    t.abms[INCIDENT_STATUSES[s as keyof typeof INCIDENT_STATUSES] ?? 'statusOpen'];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.abms.title}</h1>
          <p className="mt-1 text-sm text-ink-soft">{t.abms.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {abmsQuery.isLoading && <SkeletonCards count={2} />}

      {abmsQuery.isError && (
        <ErrorState
          message={(abmsQuery.error as Error).message}
          onRetry={() => abmsQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {d && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[
            { label: t.abms.evaluated, value: String(d.summary.risks) },
            {
              label: t.abms.highRisks,
              value: String(d.summary.highRisks),
              sub: `≥ 15 ${t.abms.score.toLowerCase()}`,
            },
            {
              label: t.abms.controlProgress,
              value: `${d.summary.controlProgress}%`,
              sub: `${d.summary.implemented}/${d.summary.controls}`,
            },
            { label: t.abms.openIncidents, value: String(d.summary.openIncidents) },
          ].map((kpi, i) => (
            <div key={i} className="rounded-card border border-line bg-white p-4 shadow-card">
              <div className="text-xs font-semibold text-ink-muted">{kpi.label}</div>
              <div className="text-[26px] font-extrabold text-navy">{kpi.value}</div>
              {kpi.sub && <div className="text-[11.5px] text-ink-soft">{kpi.sub}</div>}
            </div>
          ))}
        </div>
      )}

      {/* Riesgos */}
      <Card title={t.abms.risks}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.abms.area}
              aria-label={t.abms.area}
              value={area}
              onChange={(e) => setArea(e.target.value)}
              className="w-40"
            />
            <Input
              placeholder={t.abms.activity}
              aria-label={t.abms.activity}
              value={activity}
              onChange={(e) => setActivity(e.target.value)}
              className="min-w-[180px] flex-1"
            />
            <Input
              type="number"
              min={1}
              max={5}
              aria-label={t.abms.likelihood}
              value={likelihood}
              onChange={(e) => setLikelihood(e.target.value)}
              className="w-20"
            />
            <Input
              type="number"
              min={1}
              max={5}
              aria-label={t.abms.impact}
              value={impact}
              onChange={(e) => setImpact(e.target.value)}
              className="w-20"
            />
            <Input
              placeholder={t.abms.mitigation}
              aria-label={t.abms.mitigation}
              value={mitigation}
              onChange={(e) => setMitigation(e.target.value)}
              className="min-w-[160px] flex-1"
            />
            <Button
              onClick={() => addRisk.mutate()}
              disabled={!area || !activity || addRisk.isPending}
            >
              {t.abms.addRisk}
            </Button>
          </div>
        )}
        {canWrite && <p className="mb-3 text-[11px] text-ink-muted">{t.abms.scoreHint}</p>}

        {d && d.risks.length === 0 ? (
          <EmptyState title={t.abms.noRisks} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b-2 border-line-strong text-left text-[10.5px] uppercase tracking-wider text-ink-muted">
                  <th className="w-36 py-2">{t.abms.area}</th>
                  <th className="py-2">{t.abms.activity}</th>
                  <th className="w-20">{t.abms.likelihood}</th>
                  <th className="w-20">{t.abms.impact}</th>
                  <th className="w-20">{t.abms.score}</th>
                  <th className="w-28">{t.abms.mitigation}</th>
                  {canWrite && <th className="w-10" />}
                </tr>
              </thead>
              <tbody>
                {(d?.risks ?? []).map((r) => (
                  <tr key={r.id} className="border-b border-line">
                    <td className="py-2 font-medium">{r.area}</td>
                    <td className="py-2">{r.activity}</td>
                    <td className="py-2">{r.likelihood}</td>
                    <td className="py-2">{r.impact}</td>
                    <td className="py-2">
                      <Badge tone={r.score >= 15 ? 'danger' : r.score >= 8 ? 'warn' : 'ok'}>
                        {r.score}
                      </Badge>
                    </td>
                    <td className="py-2 text-[11.5px] text-ink-soft">
                      {r.mitigation ?? '—'}
                    </td>
                    {canWrite && (
                      <td className="py-2 text-right">
                        <ConfirmButton
                          confirmLabel={t.common.confirmDelete}
                          variant="ghost"
                          className="h-6 px-1.5 text-[11px]"
                          onConfirm={() => removeRisk.mutate(r.id)}
                        >
                          {t.common.delete}
                        </ConfirmButton>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Controles */}
      <Card title={t.abms.controls}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.abms.code}
              aria-label={t.abms.code}
              value={controlCode}
              onChange={(e) => setControlCode(e.target.value)}
              className="w-28"
            />
            <Input
              placeholder={t.abms.controlTitle}
              aria-label={t.abms.controlTitle}
              value={controlTitle}
              onChange={(e) => setControlTitle(e.target.value)}
              className="min-w-[240px] flex-1"
            />
            <Button
              onClick={() => upsertControl.mutate()}
              disabled={!controlCode || !controlTitle || upsertControl.isPending}
            >
              {t.abms.addControl}
            </Button>
          </div>
        )}
        {canWrite && <p className="mb-3 text-[11px] text-ink-muted">{t.abms.controlHint}</p>}

        {d && d.controls.length === 0 ? (
          <EmptyState title={t.abms.noControls} />
        ) : (
          <div className="space-y-2">
            {(d?.controls ?? []).map((c) => (
              <div key={c.id} className="rounded-btn border border-line px-3 py-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="font-mono text-[11px] text-ink-muted">{c.code}</span>
                    <div className="text-sm font-medium">{c.title}</div>
                    {c.description && (
                      <div className="text-[11px] text-ink-muted">{c.description}</div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {canWrite ? (
                      <select
                        value={c.status}
                        onChange={(e) =>
                          updateControl.mutate({ controlId: c.id, status: e.target.value })
                        }
                        className="rounded-btn border border-line bg-white px-2 py-1 text-xs"
                        aria-label={`${t.abms.status} ${c.code}`}
                      >
                        {Object.entries(CONTROL_STATUSES).map(([value, key]) => (
                          <option key={value} value={value}>
                            {t.abms[key]}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <Badge
                        tone={
                          c.status === 'IMPLEMENTED'
                            ? 'ok'
                            : c.status === 'NOT_APPLICABLE'
                              ? 'muted'
                              : 'warn'
                        }
                      >
                        {controlStatusLabel(c.status)}
                      </Badge>
                    )}
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        variant="ghost"
                        className="h-6 px-1.5 text-[11px]"
                        onConfirm={() => removeControl.mutate(c.id)}
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Incidentes */}
      <Card title={t.abms.incidents}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.abms.incidentTitle}
              aria-label={t.abms.incidentTitle}
              value={incidentTitle}
              onChange={(e) => setIncidentTitle(e.target.value)}
              className="min-w-[240px] flex-1"
            />
            <select
              value={incidentSeverity}
              onChange={(e) => setIncidentSeverity(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.abms.severity}
            >
              {Object.entries(SEVERITIES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.abms[key]}
                </option>
              ))}
            </select>
            <Button
              onClick={() => addIncident.mutate()}
              disabled={!incidentTitle || addIncident.isPending}
            >
              {t.abms.addIncident}
            </Button>
          </div>
        )}

        {d && d.incidents.length === 0 ? (
          <EmptyState title={t.abms.noIncidents} />
        ) : (
          <div className="space-y-2">
            {(d?.incidents ?? []).map((i) => (
              <div key={i.id} className="rounded-btn border border-line px-3 py-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="text-sm font-medium">{i.title}</span>
                    <div className="text-[11px] text-ink-muted">
                      {t.abms.detectedAt}: {new Date(i.detectedAt).toLocaleDateString()} ·{' '}
                      {severityLabel(i.severity)}
                    </div>
                    {i.resolution && (
                      <div className="text-[11px] text-ink-soft">
                        {t.abms.resolution}: {i.resolution}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      tone={
                        i.status === 'CLOSED'
                          ? 'ok'
                          : i.status === 'INVESTIGATING'
                            ? 'info'
                            : severityTone(i.severity) === 'danger'
                              ? 'danger'
                              : 'warn'
                      }
                    >
                      {incidentStatusLabel(i.status)}
                    </Badge>
                    {canWrite && i.status !== 'CLOSED' && (
                      <>
                        {i.status !== 'INVESTIGATING' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() =>
                              api
                                .updateBriberyIncident(orgId!, i.id, { status: 'INVESTIGATING' })
                                .then(refresh)
                                .catch(onError)
                            }
                          >
                            {t.abms.statusInvestigating}
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setResolveFor(i.id);
                            setResolution('');
                          }}
                        >
                          {t.abms.statusClosed}
                        </Button>
                      </>
                    )}
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        variant="ghost"
                        className="h-6 px-1.5 text-[11px]"
                        onConfirm={() => removeIncident.mutate(i.id)}
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    )}
                  </div>
                </div>

                {resolveFor === i.id && (
                  <div className="mt-2">
                    <div className="flex flex-wrap gap-2">
                      <Input
                        placeholder={t.abms.resolution}
                        aria-label={t.abms.resolution}
                        value={resolution}
                        onChange={(e) => setResolution(e.target.value)}
                        className="min-w-[220px] flex-1"
                      />
                      <Button
                        size="sm"
                        onClick={() => closeIncident.mutate({ incidentId: i.id, text: resolution })}
                        disabled={!resolution.trim() || closeIncident.isPending}
                      >
                        {t.common.save}
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setResolveFor(null)}>
                        {t.common.cancel}
                      </Button>
                    </div>
                    <p className="mt-1 text-[11px] text-ink-muted">
                      {t.abms.closeNeedsResolution}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
