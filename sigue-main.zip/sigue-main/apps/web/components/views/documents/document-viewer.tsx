'use client';

import { useI18n } from '@/components/providers/i18n-provider';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Modal } from '@/components/ui/modal';
import type { DocumentItem } from '@/lib/api/client';
import { DOC_STATUS_TONES, statusLabel, typeLabel } from './document-meta';

interface DocumentViewerProps {
  doc: DocumentItem | null;
  /** Nombre del área responsable, ya resuelto por la vista. */
  areaName: string | null;
  onClose: () => void;
  /** Abre la ficha completa del mismo documento. */
  onOpenDetail: () => void;
}

/**
 * Lector del documento: la versión vigente tal como está redactada.
 *
 * Es distinto del panel de detalle, que reúne flujo, firmas y distribución. Aquí
 * solo se lee el documento, para eso existe una acción propia: revisar el texto
 * sin el ruido del expediente.
 */
export function DocumentViewer({ doc, areaName, onClose, onOpenDetail }: DocumentViewerProps) {
  const { t, locale } = useI18n();

  if (!doc) return null;

  // El inventario trae la última versión en `versions[0]`; no hace falta otra
  // petición para leer lo que está vigente.
  const latest = doc.versions?.[0];
  const dateLocale = locale === 'en-US' ? 'en-US' : 'es-MX';
  const updated = doc.updatedAt
    ? new Date(doc.updatedAt).toLocaleDateString(dateLocale, { dateStyle: 'medium' })
    : null;

  return (
    <Modal
      open
      onClose={onClose}
      size="xl"
      title={`${doc.code} · ${doc.title}`}
      subtitle={
        <span className="flex flex-wrap items-center gap-1.5">
          <Badge tone={DOC_STATUS_TONES[doc.status] ?? 'muted'}>
            {statusLabel(doc.status, t)}
          </Badge>
          <span>{typeLabel(doc.type, t)}</span>
          <span>·</span>
          <span>{latest?.version ?? t.documents.noVersion}</span>
        </span>
      }
      footer={
        <>
          <Button size="sm" variant="outline" onClick={onOpenDetail}>
            {t.documents.actionView}
          </Button>
          <Button size="sm" onClick={onClose}>
            {t.common.close}
          </Button>
        </>
      }
    >
      <article className="mx-auto max-w-3xl">
        {/* Encabezado tipo documento: código y versión arriba, como circularía
            impreso, para que se reconozca sin salir del lector. */}
        <header className="mb-4 border-b border-line pb-3">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <p className="font-mono text-[11px] font-semibold uppercase tracking-wider text-ink-muted">
                {doc.code}
              </p>
              <h3 className="mt-0.5 text-[15px] font-extrabold text-navy">{doc.title}</h3>
            </div>
            <div className="shrink-0 rounded-btn border border-line bg-page px-2 py-1 text-center">
              <span className="block text-[9px] uppercase tracking-wider text-ink-muted">
                {t.documents.version}
              </span>
              <span className="block font-mono text-xs font-bold text-ink">
                {latest?.version ?? t.documents.noVersion}
              </span>
            </div>
          </div>
          <p className="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-[11px] text-ink-soft">
            <span>
              {t.documents.area}:{' '}
              <strong className="font-semibold text-ink">{areaName ?? t.documents.noArea}</strong>
            </span>
            {doc.validityUntil && (
              <>
                <span className="text-ink-muted">·</span>
                <span>
                  {t.documents.validityUntil}:{' '}
                  <strong className="font-semibold text-ink">
                    {doc.validityUntil.slice(0, 10)}
                  </strong>
                </span>
              </>
            )}
            {updated && (
              <>
                <span className="text-ink-muted">·</span>
                <span>
                  {t.documents.updatedAt}: <strong className="font-semibold text-ink">{updated}</strong>
                </span>
              </>
            )}
          </p>
        </header>

        {latest?.content ? (
          <div className="whitespace-pre-wrap text-[13px] leading-relaxed text-ink">
            {latest.content}
          </div>
        ) : (
          <p className="text-xs text-ink-muted">{t.documents.noContent}</p>
        )}

        {latest?.changesNote && (
          <p className="mt-4 border-t border-line pt-2 text-[10.5px] text-ink-muted">
            {t.documents.changesNote}: {latest.changesNote}
          </p>
        )}
      </article>
    </Modal>
  );
}
