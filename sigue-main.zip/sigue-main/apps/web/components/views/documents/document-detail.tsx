'use client';

import { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { api, type DocumentItem } from '@/lib/api/client';
import { uploadDocumentFile } from '@/lib/document-upload';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { Drawer } from '@/components/ui/drawer';
import { FileText } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { LoadingState } from '@/components/ui/states';
import { SignatureList } from './signature-list';
import {
  DOC_STATUS_TONES,
  MAX_DOCUMENT_FILE_MB,
  fileFitsLimit,
  nextActionOf,
  statusLabel,
  stepLabel,
  toDateInputValue,
  typeLabel,
} from './document-meta';

/** Tamaño legible para el listado de adjuntos. */
function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

interface DocumentDetailProps {
  orgId: string;
  doc: DocumentItem | null;
  canWrite: boolean;
  onClose: () => void;
  /** Se llama tras cualquier cambio que afecte a la fila del inventario. */
  onChanged: () => void;
}
/**
 * Panel de detalle: reúne metadatos, contenido de la versión elegida, flujo de
 * aprobación, distribución y firmas. Es de solo lectura salvo los datos
 * generales (área, vigencia, procedencia), la distribución y la carga de una
 * versión nueva.
 */
export function DocumentDetail({ orgId, doc, canWrite, onClose, onChanged }: DocumentDetailProps) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const qc = useQueryClient();
  const { isAdmin } = usePermissions();
  const dateLocale = locale === 'en-US' ? 'en-US' : 'es-MX';

  const [selectedVersion, setSelectedVersion] = useState<string>('');
  const [newContent, setNewContent] = useState('');
  const [changesNote, setChangesNote] = useState('');
  const [approveComment, setApproveComment] = useState('');

  // Datos generales editables. Se inicializan con lo que trae el documento; el
  // panel se remonta al cambiar de documento (ver `key` en la vista), así que no
  // se arrastran valores de un expediente a otro.
  const [validity, setValidity] = useState(toDateInputValue(doc?.validityUntil));
  const [review, setReview] = useState(toDateInputValue(doc?.reviewDate));
  const [provider, setProvider] = useState(doc?.sourceProvider ?? '');
  const [sourceRef, setSourceRef] = useState(doc?.sourceRef ?? '');

  // Distribución
  const [distArea, setDistArea] = useState('');
  const [distMember, setDistMember] = useState('');
  const [distChannel, setDistChannel] = useState('');

  const docId = doc?.id ?? '';

  const historyQuery = useQuery({
    queryKey: ['doc-history', orgId, docId],
    queryFn: () => api.documentHistory(orgId, docId),
    enabled: !!orgId && !!docId,
  });

  const areasQuery = useQuery({
    queryKey: ['org-areas', orgId],
    queryFn: () => api.areas(orgId),
    enabled: !!orgId,
  });

  const branchesQuery = useQuery({
    queryKey: ['org-branches', orgId],
    queryFn: () => api.branches(orgId),
    enabled: !!orgId,
  });

  // Tope real de subida: lo decide el almacenamiento configurado en la API.
  const uploadCaps = useQuery({
    queryKey: ['doc-upload-caps', orgId],
    queryFn: () => api.documentUploadCapabilities(orgId),
    enabled: !!orgId && canWrite,
    staleTime: 10 * 60 * 1000,
  });
  const maxFileMb = uploadCaps.data?.maxMb ?? MAX_DOCUMENT_FILE_MB;

  // El listado de personas exige rol de administrador en la API; pedirlo sin
  // permiso devolvería 403. Con el rol se ofrece elegir a quién entregar.
  const membersQuery = useQuery({
    queryKey: ['org-members', orgId],
    queryFn: () => api.members(orgId),
    enabled: !!orgId && isAdmin,
  });

  // Al cambiar de documento el panel se remonta (ver `key` en la vista), así que
  // la versión consultada y los borradores no se arrastran de un expediente a otro.

  const refreshAll = () => {
    onChanged();
    qc.invalidateQueries({ queryKey: ['doc-history', orgId, docId] });
  };

  const updateArea = useMutation({
    mutationFn: (areaId: string | null) => api.updateDocument(orgId, docId, { areaId }),
    onSuccess: () => {
      refreshAll();
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const updateBranches = useMutation({
    mutationFn: (branchIds: string[]) => api.updateDocument(orgId, docId, { branchIds }),
    onSuccess: () => {
      refreshAll();
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const updateMetadata = useMutation({
    mutationFn: () =>
      api.updateDocument(orgId, docId, {
        validityUntil: validity || null,
        reviewDate: review || null,
        sourceProvider: provider.trim() || null,
        sourceRef: sourceRef.trim() || null,
      }),
    onSuccess: () => {
      refreshAll();
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const distribute = useMutation({
    mutationFn: () =>
      api.distributeDocument(orgId, docId, {
        areaId: distMember ? null : distArea,
        userId: distMember || null,
        channel: distChannel.trim() || undefined,
      }),
    onSuccess: () => {
      refreshAll();
      setDistArea('');
      setDistMember('');
      setDistChannel('');
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const undoDistribution = useMutation({
    mutationFn: (distributionId: string) => api.undoDistribution(orgId, distributionId),
    onSuccess: () => {
      refreshAll();
      toast.success(t.common.deleted);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const notifyReview = useMutation({
    mutationFn: () => api.notifyReview(orgId, docId),
    onSuccess: () => toast.success(t.documents.reviewNotified),
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const docAction = useMutation({
    mutationFn: ({ action, comment }: { action: 'submit' | 'approve' | 'publish'; comment?: string }) =>
      api.docAction(orgId, docId, action, comment),
    onSuccess: () => {
      refreshAll();
      setApproveComment('');
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const acceptDocument = useMutation({
    mutationFn: () => api.acceptDocument(orgId, docId),
    onSuccess: () => {
      refreshAll();
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const newVersion = useMutation({
    mutationFn: () => api.newDocumentVersion(orgId, docId, newContent, changesNote || undefined),
    onSuccess: () => {
      refreshAll();
      setNewContent('');
      setChangesNote('');
      setSelectedVersion('');
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const uploadFile = useMutation({
    mutationFn: (file: File) => uploadDocumentFile(orgId, docId, file),
    onSuccess: () => {
      refreshAll();
      toast.success(t.documents.fileUploaded);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const removeFile = useMutation({
    mutationFn: (fileId: string) => api.deleteDocumentFile(orgId, fileId),
    onSuccess: () => {
      refreshAll();
      toast.success(t.common.deleted);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  if (!doc) return null;

  const history = historyQuery.data;
  const versions = history?.versions ?? [];
  const files = history?.files ?? [];
  const latest = versions[0];
  const shown = versions.find((v) => v.version === selectedVersion) ?? latest;
  const area = areasQuery.data?.find((a) => a.id === doc.areaId);
  const next = nextActionOf(doc.status, t);
  const canAddVersion = canWrite && doc.status !== 'OBSOLETE';
  const canDistribute = doc.status === 'PUBLISHED';
  const canNotifyReview = canWrite && !!doc.reviewDate && doc.status !== 'OBSOLETE';

  const memberName = (userId: string | null) =>
    membersQuery.data?.find((m) => m.userId === userId)?.name;

  const fmt = (iso: string | null | undefined) =>
    iso ? new Date(iso).toLocaleString(dateLocale, { dateStyle: 'medium', timeStyle: 'short' }) : '—';

  return (
    <Drawer
      open
      onClose={onClose}
      title={`${doc.code} · ${doc.title}`}
      subtitle={
        <span className="flex flex-wrap items-center gap-1.5">
          <Badge tone={DOC_STATUS_TONES[doc.status] ?? 'muted'}>
            {statusLabel(doc.status, t)}
          </Badge>
          <span>{typeLabel(doc.type, t)}</span>
          <span>·</span>
          <span>{latest?.version ?? t.documents.noVersion}</span>
        </span>
      }
      footer={
        <>
          {canWrite && next && (
            <Button
              size="sm"
              onClick={() =>
                docAction.mutate({
                  action: next.action,
                  comment: next.action === 'approve' ? approveComment || undefined : undefined,
                })
              }
              disabled={docAction.isPending}
            >
              {next.label}
            </Button>
          )}
          {canWrite && doc.status === 'PUBLISHED' && (
            <Button
              size="sm"
              variant="outline"
              onClick={() => acceptDocument.mutate()}
              disabled={acceptDocument.isPending}
              title={t.documents.signatureAcceptanceHint}
            >
              {t.documents.acceptDoc}
            </Button>
          )}
          <Button size="sm" variant="outline" onClick={onClose}>
            {t.common.close}
          </Button>
        </>
      }
    >
      {historyQuery.isLoading && <LoadingState label={t.common.loading} />}

      {historyQuery.isError && (
        <p role="alert" className="text-xs text-danger">
          {(historyQuery.error as Error).message}
        </p>
      )}

      {historyQuery.isSuccess && history && (
        <div className="space-y-5">
          <section>
            <h3 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-muted">
              {t.documents.generalData}
            </h3>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-xs">
              <div>
                <dt className="text-ink-muted">{t.documents.code}</dt>
                <dd className="font-mono text-ink">{doc.code}</dd>
              </div>
              <div>
                <dt className="text-ink-muted">{t.documents.version}</dt>
                <dd className="text-ink">{latest?.version ?? t.documents.noVersion}</dd>
              </div>
              <div className="col-span-2">
                <dt className="text-ink-muted">{t.documents.document}</dt>
                <dd className="font-medium text-ink">{doc.title}</dd>
              </div>
              <div>
                <dt className="text-ink-muted">{t.documents.docType}</dt>
                <dd className="text-ink">{typeLabel(doc.type, t)}</dd>
              </div>
              <div>
                <dt className="text-ink-muted">{t.documents.createdAt}</dt>
                <dd className="text-ink">{fmt(doc.createdAt)}</dd>
              </div>
              <div className="col-span-2">
                <dt className="mb-1 text-ink-muted">{t.documents.area}</dt>
                {canWrite ? (
                  <select
                    value={doc.areaId ?? ''}
                    onChange={(e) => updateArea.mutate(e.target.value || null)}
                    disabled={updateArea.isPending || areasQuery.isLoading}
                    aria-label={t.documents.area}
                    className="h-8 w-full rounded-btn border border-line bg-white px-2 text-xs text-ink"
                  >
                    <option value="">{t.documents.noArea}</option>
                    {(areasQuery.data ?? []).map((a) => (
                      <option key={a.id} value={a.id}>
                        {a.name}
                      </option>
                    ))}
                  </select>
                ) : (
                  <dd className="text-ink">{area?.name ?? t.documents.noArea}</dd>
                )}
              </div>
              <div className="col-span-2">
                <dt className="mb-1 text-ink-muted">{t.documents.branches}</dt>
                {canWrite ? (
                  <div className="flex flex-wrap gap-1.5">
                    {branchesQuery.data?.length === 0 && (
                      <span className="text-xs text-ink-muted">{t.documents.noBranchesHint}</span>
                    )}
                    {(branchesQuery.data ?? []).map((b) => {
                      const checked = (doc.branchIds ?? []).includes(b.id);
                      return (
                        <label
                          key={b.id}
                          className={`inline-flex cursor-pointer items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11px] transition-colors ${
                            checked
                              ? 'border-primary bg-info-bg font-semibold text-info'
                              : 'border-line bg-white text-ink-soft hover:bg-page'
                          }`}
                        >
                          <input
                            type="checkbox"
                            checked={checked}
                            disabled={updateBranches.isPending}
                            onChange={() => {
                              const current = doc.branchIds ?? [];
                              updateBranches.mutate(
                                checked
                                  ? current.filter((id) => id !== b.id)
                                  : [...current, b.id],
                              );
                            }}
                            className="size-3 accent-primary"
                          />
                          {b.name}
                        </label>
                      );
                    })}
                    {(doc.branchIds ?? []).length === 0 && (
                      <span className="self-center text-[10.5px] text-ink-muted">
                        {t.documents.allBranchesHint}
                      </span>
                    )}
                  </div>
                ) : (
                  <dd className="text-ink">
                    {(doc.branchIds ?? []).length === 0
                      ? t.documents.allBranchesHint
                      : (doc.branchIds ?? [])
                          .map((id) => branchesQuery.data?.find((b) => b.id === id)?.name)
                          .filter(Boolean)
                          .join(', ')}
                  </dd>
                )}
              </div>
            </dl>
          </section>

          <section>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-[11px] font-bold uppercase tracking-wider text-ink-muted">
                {t.documents.metadataTitle}
              </h3>
              {canNotifyReview && (
                <Button
                  size="sm"
                  variant="ghost"
                  className="h-7 px-2 text-[11px]"
                  onClick={() => notifyReview.mutate()}
                  disabled={notifyReview.isPending}
                  title={t.documents.notifyReviewHint}
                >
                  {t.documents.notifyReview}
                </Button>
              )}
            </div>
            <div className="grid grid-cols-2 gap-2">
              <Input
                type="date"
                name="detailValidity"
                label={t.documents.validityUntil}
                value={validity}
                onChange={(e) => setValidity(e.target.value)}
                disabled={!canWrite}
                className="h-8 text-xs"
              />
              <Input
                type="date"
                name="detailReview"
                label={t.documents.reviewDate}
                value={review}
                onChange={(e) => setReview(e.target.value)}
                disabled={!canWrite}
                className="h-8 text-xs"
              />
              <Input
                name="detailProvider"
                label={t.documents.sourceProvider}
                value={provider}
                onChange={(e) => setProvider(e.target.value)}
                placeholder={t.documents.sourceProviderPlaceholder}
                disabled={!canWrite}
                className="h-8 text-xs"
              />
              <Input
                name="detailSourceRef"
                label={t.documents.sourceRef}
                value={sourceRef}
                onChange={(e) => setSourceRef(e.target.value)}
                placeholder={t.documents.sourceRefPlaceholder}
                disabled={!canWrite}
                className="h-8 text-xs"
              />
            </div>
            {canWrite && (
              <div className="mt-2 flex flex-wrap items-center gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  className="h-8"
                  onClick={() => updateMetadata.mutate()}
                  disabled={updateMetadata.isPending}
                >
                  {t.documents.saveMetadata}
                </Button>
                <p className="text-[10.5px] text-ink-muted">{t.documents.datesHint}</p>
              </div>
            )}
          </section>

          <section>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-[11px] font-bold uppercase tracking-wider text-ink-muted">
                {t.documents.currentContent}
              </h3>
              {versions.length > 1 && (
                <select
                  value={shown?.version ?? ''}
                  onChange={(e) => setSelectedVersion(e.target.value)}
                  aria-label={t.documents.versionPicker}
                  className="h-7 rounded-btn border border-line bg-white px-2 text-[11px] text-ink"
                >
                  {versions.map((v) => (
                    <option key={v.id} value={v.version}>
                      {v.version}
                    </option>
                  ))}
                </select>
              )}
            </div>
            {shown?.content ? (
              <pre className="max-h-80 overflow-auto whitespace-pre-wrap rounded-btn border border-line bg-page p-3 text-xs leading-relaxed text-ink">
                {shown.content}
              </pre>
            ) : (
              <p className="text-xs text-ink-muted">{t.documents.noContent}</p>
            )}            {shown && (
              <p className="mt-1 text-[10.5px] text-ink-muted">
                {shown.version}
                {shown.changesNote ? ` · ${shown.changesNote}` : ''} · {fmt(shown.createdAt)}
              </p>
            )}
          </section>

          <section>
            <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
              <h3 className="text-[11px] font-bold uppercase tracking-wider text-ink-muted">
                {t.documents.attachedFiles}
              </h3>
              {canWrite && (
                <label className="cursor-pointer text-[11px] font-semibold text-primary hover:underline">
                  {uploadFile.isPending ? t.common.loading : t.documents.attachFile}
                  <input
                    type="file"
                    aria-label={t.documents.attachFile}
                    className="sr-only"
                    disabled={uploadFile.isPending}
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      // Se limpia el input para poder volver a elegir el mismo archivo.
                      e.target.value = '';
                      if (!file) return;
                      if (!fileFitsLimit(file, maxFileMb)) {
                        toast.error(`${t.documents.fileTooLarge} (${maxFileMb} MB máximo)`);
                        return;
                      }
                      uploadFile.mutate(file);
                    }}
                  />
                </label>
              )}
            </div>
            {files.length === 0 ? (
              <p className="text-xs text-ink-muted">{t.documents.noFiles}</p>
            ) : (
              <ul className="space-y-1.5">
                {files.map((f) => (
                  <li
                    key={f.id}
                    className="flex flex-wrap items-center gap-2 rounded-btn border border-line bg-page px-2.5 py-1.5"
                  >
                    <FileText className="size-4 shrink-0 text-ink-muted" aria-hidden="true" />
                    <span className="min-w-0 flex-1 truncate text-xs font-medium text-ink">
                      {f.filename}
                    </span>
                    <span className="text-[10.5px] tabular-nums text-ink-muted">
                      {formatBytes(f.size)}
                    </span>
                    <a
                      href={api.documentFileUrl(orgId, f.id)}
                      className="text-[11px] font-semibold text-info hover:underline"
                    >
                      {t.documents.downloadFile}
                    </a>
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        onConfirm={() => removeFile.mutate(f.id)}
                        variant="ghost"
                        className="h-5 px-1 text-[10px] text-danger"
                      >
                        {t.documents.removeFile}
                      </ConfirmButton>
                    )}
                  </li>
                ))}
              </ul>
            )}
          </section>

          <section>
            <h3 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-muted">
              {t.documents.versionsTitle}
            </h3>
            <ol className="space-y-1 text-xs">
              {versions.map((v) => (
                <li key={v.id} className="flex flex-wrap items-baseline gap-2">
                  <button
                    type="button"
                    onClick={() => setSelectedVersion(v.version)}
                    className={`font-mono text-[11.5px] ${
                      shown?.id === v.id ? 'font-bold text-primary' : 'text-info hover:underline'
                    }`}
                  >
                    {v.version}
                  </button>
                  <span className="text-ink-soft">{v.changesNote ?? '—'}</span>
                  <span className="text-[10.5px] text-ink-muted">{fmt(v.createdAt)}</span>
                </li>
              ))}
              {versions.length === 0 && (
                <li className="text-ink-muted">{t.documents.noHistory}</li>
              )}
            </ol>
          </section>

          <section>
            <h3 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-muted">
              {t.documents.workflow}
            </h3>
            {history.workflowSteps.length ? (
              <ol className="space-y-1.5 border-l-2 border-line pl-3 text-xs">
                {history.workflowSteps.map((w) => (
                  <li key={w.id}>
                    <div className="font-semibold text-ink">{stepLabel(w.step, t)}</div>
                    <div className="text-ink-soft">
                      {w.comment ? `“${w.comment}” · ` : ''}
                      {fmt(w.at)}
                    </div>
                  </li>
                ))}
              </ol>
            ) : (
              <p className="text-xs text-ink-muted">{t.documents.workflowEmpty}</p>
            )}
          </section>

          <section>
            <h3 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-muted">
              {t.documents.distributions}
            </h3>
            {history.distributions.length ? (
              <ul className="space-y-1 text-xs text-ink-soft">
                {history.distributions.map((d) => (
                  <li key={d.id} className="flex flex-wrap items-center gap-2">
                    <span>
                      {t.documents.distributionTo}:{' '}
                      <strong className="text-ink">
                        {d.areaId
                          ? areasQuery.data?.find((a) => a.id === d.areaId)?.name ?? '—'
                          : memberName(d.userId) ?? (d.userId ? d.userId.slice(0, 8) : '—')}
                      </strong>
                    </span>
                    <span className="text-ink-muted">· {d.channel} · {fmt(d.at)}</span>
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        onConfirm={() => undoDistribution.mutate(d.id)}
                        variant="ghost"
                        className="h-5 px-1 text-[10px] text-danger"
                      >
                        {t.documents.removeDistribution}
                      </ConfirmButton>
                    )}
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-ink-muted">{t.documents.distributionsEmpty}</p>
            )}

            {canWrite &&
              (canDistribute ? (
                <div className="mt-3 space-y-2 rounded-btn border border-line bg-page/60 p-3">
                  <p className="text-[11px] font-semibold text-ink">
                    {t.documents.addDistribution}
                  </p>
                  <div className="grid grid-cols-2 gap-2">
                    <select
                      value={distArea}
                      onChange={(e) => {
                        setDistArea(e.target.value);
                        // Un destino por entrega: elegir área descarta la persona.
                        if (e.target.value) setDistMember('');
                      }}
                      disabled={!!distMember}
                      aria-label={t.documents.distributionArea}
                      className="h-8 rounded-btn border border-line bg-white px-2 text-xs text-ink disabled:opacity-50"
                    >
                      <option value="">{t.documents.distributionArea}</option>
                      {(areasQuery.data ?? []).map((a) => (
                        <option key={a.id} value={a.id}>
                          {a.name}
                        </option>
                      ))}
                    </select>
                    {/* Elegir persona exige el catálogo de miembros, que la API
                        reserva a administradores; sin ese rol basta el área. */}
                    {isAdmin && (
                      <select
                        value={distMember}
                        onChange={(e) => {
                          setDistMember(e.target.value);
                          if (e.target.value) setDistArea('');
                        }}
                        disabled={!!distArea}
                        aria-label={t.documents.distributionPerson}
                        className="h-8 rounded-btn border border-line bg-white px-2 text-xs text-ink disabled:opacity-50"
                      >
                        <option value="">{t.documents.distributionPerson}</option>
                        {(membersQuery.data ?? [])
                          .filter((m) => m.status === 'ACTIVE')
                          .map((m) => (
                            <option key={m.id} value={m.userId}>
                              {m.name}
                            </option>
                          ))}
                      </select>
                    )}
                    <Input
                      value={distChannel}
                      onChange={(e) => setDistChannel(e.target.value)}
                      placeholder={t.documents.distributionChannelPlaceholder}
                      aria-label={t.documents.distributionChannel}
                      className={`h-8 text-xs ${isAdmin ? 'col-span-2' : ''}`}
                    />
                  </div>
                  <div className="flex justify-end">
                    <Button
                      size="sm"
                      className="h-8"
                      onClick={() => distribute.mutate()}
                      disabled={(!distArea && !distMember) || distribute.isPending}
                    >
                      {t.documents.addDistribution}
                    </Button>
                  </div>
                </div>
              ) : (
                <p className="mt-2 text-[11px] text-ink-muted">
                  {t.documents.distributionOnlyPublished}
                </p>
              ))}
          </section>

          <section>
            <h3 className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-muted">
              {t.documents.signatures}
            </h3>
            <SignatureList
              orgId={orgId}
              documentId={docId}
              signatures={history.signatures ?? []}
              canWrite={canWrite}
            />
          </section>

          {canWrite && next?.action === 'approve' && (
            <section>
              <Input
                name="detailApproveComment"
                label={t.documents.approveComment}
                value={approveComment}
                onChange={(e) => setApproveComment(e.target.value)}
                placeholder={t.documents.approveCommentPlaceholder}
              />
            </section>
          )}

          {canAddVersion && (
            <section className="space-y-2 border-t border-line pt-4">
              <h3 className="text-[11px] font-bold uppercase tracking-wider text-ink-muted">
                {t.documents.newVersion}
              </h3>
              <Textarea
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder={t.documents.newVersionContent}
                aria-label={t.documents.newVersionContent}
                rows={5}
                className="text-xs"
              />
              <div className="flex flex-wrap items-center gap-2">
                <Input
                  value={changesNote}
                  onChange={(e) => setChangesNote(e.target.value)}
                  placeholder={t.documents.changesNotePlaceholder}
                  aria-label={t.documents.changesNote}
                  className="h-8 min-w-[200px] flex-1 text-xs"
                />
                <Button
                  size="sm"
                  className="h-8"
                  onClick={() => newVersion.mutate()}
                  disabled={!newContent.trim() || newVersion.isPending}
                >
                  {t.documents.saveVersion}
                </Button>
              </div>
              <p className="text-[10.5px] text-ink-muted">{t.documents.contentHint}</p>
            </section>
          )}
        </div>
      )}
    </Drawer>
  );
}
