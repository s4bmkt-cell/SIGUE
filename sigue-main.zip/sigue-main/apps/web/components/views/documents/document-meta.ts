import type { MessageSchema } from '@/lib/i18n';

type T = MessageSchema;

/** Tono del estado documental para `Badge`. */
export const DOC_STATUS_TONES: Record<string, 'muted' | 'warn' | 'info' | 'ok' | 'danger'> = {
  DRAFT: 'muted',
  IN_REVIEW: 'warn',
  IN_APPROVAL: 'info',
  PUBLISHED: 'ok',
  OBSOLETE: 'danger',
};

export const DOC_TYPES = [
  'POLITICA',
  'PROCESO',
  'PROCEDIMIENTO',
  'INSTRUCTIVO',
  'GUIA',
  'MANUAL',
  'FORMATO',
  'REGISTRO',
  'EXTERNO',
] as const;

/** Tipo documental → etiqueta localizada. */
export function typeLabel(type: string, t: T) {
  return (
    {
      POLITICA: t.documents.typePolicy,
      PROCEDIMIENTO: t.documents.typeProcedure,
      PROCESO: t.documents.typeProcess,
      INSTRUCTIVO: t.documents.typeInstruction,
      GUIA: t.documents.typeGuide,
      MANUAL: t.documents.typeManual,
      FORMATO: t.documents.typeForm,
      REGISTRO: t.documents.typeRecord,
      EXTERNO: t.documents.typeExternal,
    }[type] ?? type
  );
}

export function statusLabel(status: string, t: T) {
  return (
    {
      DRAFT: t.documents.draft,
      IN_REVIEW: t.documents.inReview,
      IN_APPROVAL: t.documents.inApproval,
      PUBLISHED: t.documents.published,
      OBSOLETE: t.documents.obsolete,
    }[status] ?? status
  );
}

/** Siguiente paso del flujo desde el estado actual, o `null` si es terminal. */
export function nextActionOf(status: string, t: T) {
  return status === 'DRAFT'
    ? ({ action: 'submit', label: t.documents.submit } as const)
    : status === 'IN_REVIEW'
      ? ({ action: 'approve', label: t.documents.approve } as const)
      : status === 'IN_APPROVAL'
        ? ({ action: 'publish', label: t.documents.publish } as const)
        : null;
}

/** Paso del flujo almacenado en `DocWorkflowStep.step` → etiqueta localizada. */
export function stepLabel(step: string, t: T) {
  return (
    {
      REVIEW: t.documents.stepReview,
      APPROVE: t.documents.stepApprove,
      PUBLISH: t.documents.stepPublish,
      OBSOLETE: t.documents.stepObsolete,
      SIGNATURE_REVOKED: t.documents.stepSignatureRevoked,
    }[step] ?? step
  );
}

/** Ventana de aviso de revisión; debe coincidir con `REVIEW_SOON_DAYS` de la API. */
export const REVIEW_SOON_DAYS = 30;

/**
 * Tope del archivo adjunto cuando no se conoce la capacidad del servidor.
 *
 * El límite real lo informa `GET /documents/upload-capabilities`: con
 * almacenamiento en la nube el binario va directo al almacén y cabe un archivo
 * grande; con disco local cruza el proxy `/api/*`, que Vercel corta en 4,5 MB.
 * Este valor es solo el respaldo mientras llega la respuesta.
 */
export const MAX_DOCUMENT_FILE_MB = 250;

/** Tope del proxy `/api/*`; el servidor lo confirma en `proxyMaxMb`. */
export const MAX_PROXY_FILE_MB = 4;

/** `true` si el archivo cabe en el tope indicado. */
export function fileFitsLimit(file: File, maxMb = MAX_DOCUMENT_FILE_MB): boolean {
  return file.size <= maxMb * 1024 * 1024;
}

export type ReviewState = 'none' | 'overdue' | 'soon' | 'ok';

/**
 * Estado de la revisión periódica. Se calcula con el reloj del navegador para
 * pintar el color de la fila; los conteos del aviso los da la API, que es la
 * única que no depende de la hora del equipo.
 */
export function reviewStateOf(reviewDate: string | null | undefined, status: string): ReviewState {
  // Un documento obsoleto ya no se revisa: marcarlo en rojo sería ruido.
  if (!reviewDate || status === 'OBSOLETE') return 'none';
  const due = new Date(reviewDate).getTime();
  if (Number.isNaN(due)) return 'none';
  const now = Date.now();
  if (due < now) return 'overdue';
  if (due - now <= REVIEW_SOON_DAYS * 24 * 60 * 60 * 1000) return 'soon';
  return 'ok';
}

export function reviewLabel(state: ReviewState, t: T) {
  return {
    none: t.documents.noReviewDate,
    overdue: t.documents.reviewExpired,
    soon: t.documents.reviewDueSoon,
    ok: t.documents.reviewOk,
  }[state];
}

export const REVIEW_TONES: Record<ReviewState, 'muted' | 'warn' | 'danger' | 'ok'> = {
  none: 'muted',
  overdue: 'danger',
  soon: 'warn',
  ok: 'ok',
};

/**
 * `AAAA-MM-DD` para un `<input type="date">`. Se corta la cadena ISO en vez de
 * usar `toISOString`, que desplazaría el día según la zona horaria.
 */
export function toDateInputValue(iso: string | null | undefined): string {
  return iso ? iso.slice(0, 10) : '';
}

/** Firma mínima que necesita la columna "Firmas" del inventario. */
interface SignatureLike {
  id: string;
  signerName: string | null;
  signerEmail: string | null;
  kind: string;
}

export interface SignedBy {
  /** Clave estable para `key`: la persona, no la firma. */
  key: string;
  /** Nombre (o correo) que alimenta las iniciales del avatar. */
  name: string | null;
  /** Nombre accesible con los tipos de firma ya resueltos. */
  label: string;
}

/**
 * Agrupa las firmas por persona para la columna del inventario.
 *
 * Una misma persona puede aprobar y aceptar el mismo documento: dos círculos
 * idénticos seguidos no aportan nada, así que se dibuja uno y el tipo de cada
 * firma pasa al título. El detalle conserva la lista completa con sus fechas.
 */
export function signedBy(signatures: SignatureLike[], t: T): SignedBy[] {
  const order: string[] = [];
  const byKey = new Map<string, { name: string | null; kinds: string[] }>();

  for (const s of signatures) {
    // Sin `signerId` en la respuesta se usa el nombre; sin nombre, el correo.
    const key = s.signerName ?? s.signerEmail ?? s.id;
    const name = s.signerName ?? s.signerEmail;
    const kind =
      s.kind === 'APPROVAL' ? t.documents.signatureApproval : t.documents.signatureAcceptance;

    const entry = byKey.get(key);
    if (entry) {
      if (!entry.kinds.includes(kind)) entry.kinds.push(kind);
      continue;
    }
    byKey.set(key, { name, kinds: [kind] });
    order.push(key);
  }

  return order.map((key) => {
    const entry = byKey.get(key)!;
    const who = entry.name ?? t.documents.noOwner;
    return {
      key,
      name: entry.name,
      label: `${who} · ${entry.kinds.join(' / ')}`,
    };
  });
}

