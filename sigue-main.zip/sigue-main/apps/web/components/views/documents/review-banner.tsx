'use client';

import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { Button } from '@/components/ui/button';

interface ReviewBannerProps {
  orgId: string;
  /** Cambia el filtro del inventario a "revisión vencida" o "próxima". */
  onShow: (due: 'overdue' | 'soon') => void;
}

/**
 * Aviso de revisiones pendientes.
 *
 * Solo aparece cuando hay algo que revisar: un banner permanente con ceros se
 * ignora a los dos días. Los conteos vienen de la API para que no dependan del
 * reloj del equipo.
 */
export function ReviewBanner({ orgId, onShow }: ReviewBannerProps) {
  const { t } = useI18n();

  const alertsQuery = useQuery({
    queryKey: ['doc-review-alerts', orgId],
    queryFn: () => api.docReviewAlerts(orgId),
    enabled: !!orgId,
  });

  const alerts = alertsQuery.data;
  if (!alerts || alerts.overdue + alerts.dueSoon === 0) return null;

  return (
    <div
      role="status"
      className={`rounded-card border p-4 ${
        alerts.overdue > 0 ? 'border-danger/40 bg-danger-bg' : 'border-warning/40 bg-warning-bg'
      }`}
    >
      <div className="flex flex-wrap items-center gap-3">
        <p className="text-sm font-bold text-ink">
          {t.documents.reviewAlertsTitle}
        </p>
        <span className="text-xs text-ink-soft">
          {t.documents.reviewOverdueCount}: <strong className="text-ink">{alerts.overdue}</strong>
          {' · '}
          {t.documents.reviewSoonCount}: <strong className="text-ink">{alerts.dueSoon}</strong>
        </span>
        <div className="ml-auto flex flex-wrap gap-2">
          {alerts.overdue > 0 && (
            <Button size="sm" variant="outline" onClick={() => onShow('overdue')}>
              {t.documents.reviewViewOverdue}
            </Button>
          )}
          {alerts.dueSoon > 0 && (
            <Button size="sm" variant="outline" onClick={() => onShow('soon')}>
              {t.documents.reviewViewSoon}
            </Button>
          )}
        </div>
      </div>
      {/* Los códigos hacen el aviso accionable: sin ellos hay que ir a buscar
          qué documento es. */}
      <p className="mt-2 text-[11.5px] text-ink-soft">
        {alerts.items
          .slice(0, 6)
          .map((d) => d.code)
          .join(' · ')}
        {alerts.items.length > 6 ? ' …' : ''}
      </p>
    </div>
  );
}
