'use client';

import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api, type SignatureItem } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useToast } from '@/components/providers/toast-provider';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface SignatureListProps {
  orgId: string;
  documentId: string;
  signatures: SignatureItem[];
  canWrite: boolean;
}

/**
 * Firmas de un documento con verificación de integridad y revocación.
 *
 * La verificación consulta al servidor a propósito: recalcula la firma con el
 * contenido actual de la versión, así que un cambio posterior a la firma se ve
 * aquí y no solo en la base de datos.
 */
export function SignatureList({ orgId, documentId, signatures, canWrite }: SignatureListProps) {
  const { t, locale } = useI18n();
  const toast = useToast();
  const qc = useQueryClient();
  const [checks, setChecks] = useState<Record<string, { valid: boolean; contentIntact: boolean }>>({});
  const [revoking, setRevoking] = useState<string | null>(null);
  const [reason, setReason] = useState('');
  const dateLocale = locale === 'en-US' ? 'en-US' : 'es-MX';

  const verify = useMutation({
    mutationFn: (signatureId: string) => api.verifySignature(orgId, signatureId),
    onSuccess: (res, signatureId) =>
      setChecks((s) => ({
        ...s,
        [signatureId]: { valid: res.valid, contentIntact: res.contentIntact },
      })),
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const revoke = useMutation({
    mutationFn: ({ signatureId, reason }: { signatureId: string; reason?: string }) =>
      api.revokeSignature(orgId, signatureId, reason),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['doc-history', orgId, documentId] });
      qc.invalidateQueries({ queryKey: ['documents', orgId] });
      setRevoking(null);
      setReason('');
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  if (signatures.length === 0) {
    return <p className="text-xs text-ink-muted">{t.documents.signaturesEmpty}</p>;
  }

  return (
    <ul className="space-y-2">
      {signatures.map((s) => {
        const check = checks[s.id];
        return (
          <li key={s.id} className="rounded-btn border border-line bg-page px-3 py-2">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-[12.5px] font-semibold text-ink">
                {s.signerName ?? t.documents.noOwner}
              </span>
              <Badge tone="info" dot={false} className="text-[10px]">
                {s.kind === 'APPROVAL'
                  ? t.documents.signatureApproval
                  : t.documents.signatureAcceptance}
              </Badge>
              <span className="font-mono text-[10.5px] text-ink-muted">{s.version}</span>
              <span className="text-[10.5px] text-ink-muted">
                {new Date(s.signedAt).toLocaleString(dateLocale, {
                  dateStyle: 'medium',
                  timeStyle: 'short',
                })}
              </span>
            </div>
            {s.signerEmail && (
              <div className="mt-0.5 text-[10.5px] text-ink-muted">{s.signerEmail}</div>
            )}

            <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
              <Button
                size="sm"
                variant="outline"
                className="h-6 px-2 text-[10.5px]"
                onClick={() => verify.mutate(s.id)}
                disabled={verify.isPending}
              >
                {t.documents.verifySignature}
              </Button>
              {check && (
                <>
                  <Badge tone={check.valid ? 'ok' : 'danger'} className="text-[10px]">
                    {check.valid ? t.documents.signatureValid : t.documents.signatureInvalid}
                  </Badge>
                  <Badge tone={check.contentIntact ? 'ok' : 'danger'} className="text-[10px]">
                    {check.contentIntact
                      ? t.documents.signatureIntact
                      : t.documents.signatureContentAltered}
                  </Badge>
                </>
              )}
              {canWrite &&
                (revoking === s.id ? (
                  <span className="flex flex-wrap items-center gap-1.5">
                    <Input
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      placeholder={t.documents.revokeReasonPlaceholder}
                      aria-label={t.documents.revokeReason}
                      className="h-6 w-48 text-[10.5px]"
                    />
                    <Button
                      size="sm"
                      variant="danger"
                      className="h-6 px-2 text-[10.5px]"
                      onClick={() => revoke.mutate({ signatureId: s.id, reason: reason || undefined })}
                      disabled={revoke.isPending}
                    >
                      {t.common.confirmDelete}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 px-1.5 text-[10.5px]"
                      onClick={() => {
                        setRevoking(null);
                        setReason('');
                      }}
                    >
                      {t.common.cancel}
                    </Button>
                  </span>
                ) : (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-6 px-1.5 text-[10.5px]"
                    title={t.documents.revokeConfirm}
                    onClick={() => setRevoking(s.id)}
                  >
                    {t.documents.revokeSignature}
                  </Button>
                ))}
            </div>
          </li>
        );
      })}
    </ul>
  );
}
