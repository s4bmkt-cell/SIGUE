import { describe, expect, it } from 'vitest';
import {
  MAX_DOCUMENT_FILE_MB,
  MAX_PROXY_FILE_MB,
  REVIEW_SOON_DAYS,
  fileFitsLimit,
  reviewStateOf,
  signedBy,
  toDateInputValue,
} from './document-meta';

const DAY = 24 * 60 * 60 * 1000;
const iso = (offsetDays: number) => new Date(Date.now() + offsetDays * DAY).toISOString();

describe('reviewStateOf', () => {
  it('un documento sin fecha de revisión no tiene estado de revisión', () => {
    expect(reviewStateOf(null, 'PUBLISHED')).toBe('none');
    expect(reviewStateOf(undefined, 'PUBLISHED')).toBe('none');
  });

  it('un obsoleto no se revisa aunque tenga fecha pasada', () => {
    expect(reviewStateOf(iso(-10), 'OBSOLETE')).toBe('none');
  });

  it('una fecha pasada está vencida', () => {
    expect(reviewStateOf(iso(-1), 'PUBLISHED')).toBe('overdue');
  });

  it('una fecha dentro de la ventana está próxima', () => {
    expect(reviewStateOf(iso(REVIEW_SOON_DAYS - 1), 'PUBLISHED')).toBe('soon');
  });

  it('una fecha fuera de la ventana está al día', () => {
    expect(reviewStateOf(iso(REVIEW_SOON_DAYS + 1), 'PUBLISHED')).toBe('ok');
  });

  it('una fecha ilegible no inventa un aviso', () => {
    expect(reviewStateOf('no-es-fecha', 'PUBLISHED')).toBe('none');
  });
});

describe('toDateInputValue', () => {
  it('recorta la hora sin desplazar el día', () => {
    expect(toDateInputValue('2027-06-30T00:00:00.000Z')).toBe('2027-06-30');
  });

  it('una fecha ausente deja el campo vacío', () => {
    expect(toDateInputValue(null)).toBe('');
    expect(toDateInputValue(undefined)).toBe('');
  });
});

describe('signedBy', () => {
  // Solo se usan estas dos etiquetas y `noOwner`: el resto del diccionario no
  // participa en el cálculo que se está probando.
  const t = {
    documents: {
      signatureApproval: 'Aprobación',
      signatureAcceptance: 'Aceptación',
      noOwner: 'Sin responsable',
    },
  } as unknown as Parameters<typeof signedBy>[1];

  const sig = (id: string, signerName: string | null, kind: string) => ({
    id,
    signerName,
    signerEmail: signerName ? `${id}@org.mx` : null,
    kind,
  });

  it('dibuja un círculo por persona aunque firme dos veces', () => {
    const signers = signedBy(
      [sig('s1', 'Mariana Torres', 'APPROVAL'), sig('s2', 'Mariana Torres', 'ACCEPTANCE')],
      t,
    );

    expect(signers).toHaveLength(1);
    expect(signers[0].label).toBe('Mariana Torres · Aprobación / Aceptación');
  });

  it('respeta el orden en que aparecen los firmantes', () => {
    const signers = signedBy(
      [sig('s1', 'Jorge Aldana', 'APPROVAL'), sig('s2', 'Mariana Torres', 'APPROVAL')],
      t,
    );

    expect(signers.map((s) => s.name)).toEqual(['Jorge Aldana', 'Mariana Torres']);
  });

  it('una firma sin nombre usa el correo y, si tampoco hay, no queda vacía', () => {
    expect(signedBy([sig('s1', null, 'APPROVAL')], t)[0].name).toBeNull();
    expect(signedBy([sig('s1', null, 'APPROVAL')], t)[0].label).toBe(
      'Sin responsable · Aprobación',
    );
  });
});

describe('fileFitsLimit', () => {
  const file = (mb: number) => ({ size: Math.round(mb * 1024 * 1024) }) as File;

  it('acepta lo que cabe en el tope indicado', () => {
    expect(fileFitsLimit(file(MAX_DOCUMENT_FILE_MB - 0.1))).toBe(true);
    expect(fileFitsLimit(file(MAX_DOCUMENT_FILE_MB))).toBe(true);
  });

  it('rechaza lo que supera el tope', () => {
    expect(fileFitsLimit(file(MAX_DOCUMENT_FILE_MB + 0.1))).toBe(false);
  });

  it('con el tope del proxy rechaza lo que Vercel cortaría con un 413', () => {
    expect(fileFitsLimit(file(MAX_PROXY_FILE_MB - 0.5), MAX_PROXY_FILE_MB)).toBe(true);
    expect(fileFitsLimit(file(MAX_PROXY_FILE_MB + 0.5), MAX_PROXY_FILE_MB)).toBe(false);
    expect(fileFitsLimit(file(10), MAX_PROXY_FILE_MB)).toBe(false);
  });
});
