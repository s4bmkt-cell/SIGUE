'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const CRITICALITIES = {
  CRITICA: 'critical',
  ALTA: 'high',
  MEDIA: 'medium',
  BAJA: 'low',
} as const;

const PLAN_STATUSES = {
  DRAFT: 'statusDraft',
  REVIEWED: 'statusReviewed',
  ACTIVE: 'statusActive',
  TESTED: 'statusTested',
} as const;

const EXERCISE_TYPES = {
  TABLE_TOP: 'typeTableTop',
  FULL: 'typeFull',
  SIMULATION: 'typeSimulation',
} as const;

const EXERCISE_STATUSES = {
  PLANNED: 'statusPlanned',
  IN_PROGRESS: 'statusInProgress',
  COMPLETED: 'statusCompleted',
} as const;

export function BcmsView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [processName, setProcessName] = useState('');
  const [criticality, setCriticality] = useState('MEDIA');
  const [rto, setRto] = useState('');
  const [rpo, setRpo] = useState('');

  const [planTitle, setPlanTitle] = useState('');
  const [planStrategy, setPlanStrategy] = useState('');

  const [exerciseTitle, setExerciseTitle] = useState('');
  const [exerciseType, setExerciseType] = useState('TABLE_TOP');
  const [exerciseDate, setExerciseDate] = useState('');
  const [resultFor, setResultFor] = useState<string | null>(null);
  const [exerciseResult, setExerciseResult] = useState('');

  const bcmsQuery = useQuery({
    queryKey: ['bcms', orgId],
    queryFn: () => api.bcms(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['bcms', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
  };

  const onError = (err: unknown) =>
    toast.error(err instanceof Error ? err.message : t.common.saveError);

  const addBia = useMutation({
    mutationFn: () =>
      api.addBia(orgId!, {
        processName,
        criticality,
        rtoHours: rto ? Number(rto) : undefined,
        rpoHours: rpo ? Number(rpo) : undefined,
      }),
    onSuccess: () => {
      refresh();
      setProcessName('');
      setRto('');
      setRpo('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeBia = useMutation({
    mutationFn: (biaId: string) => api.deleteBia(orgId!, biaId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const addPlan = useMutation({
    mutationFn: () =>
      api.addContinuityPlan(orgId!, {
        title: planTitle,
        strategy: planStrategy || undefined,
      }),
    onSuccess: () => {
      refresh();
      setPlanTitle('');
      setPlanStrategy('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const updatePlanStatus = useMutation({
    mutationFn: ({ planId, status }: { planId: string; status: string }) =>
      api.updateContinuityPlan(orgId!, planId, { status }),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError,
  });

  const removePlan = useMutation({
    mutationFn: (planId: string) => api.deleteContinuityPlan(orgId!, planId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const addExercise = useMutation({
    mutationFn: () =>
      api.addExercise(orgId!, {
        title: exerciseTitle,
        type: exerciseType,
        scheduledAt: exerciseDate || undefined,
      }),
    onSuccess: () => {
      refresh();
      setExerciseTitle('');
      setExerciseDate('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const recordExercise = useMutation({
    mutationFn: ({ exerciseId, result }: { exerciseId: string; result: string }) =>
      api.recordExercise(orgId!, exerciseId, { result, status: 'COMPLETED' }),
    onSuccess: () => {
      refresh();
      setResultFor(null);
      setExerciseResult('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeExercise = useMutation({
    mutationFn: (exerciseId: string) => api.deleteExercise(orgId!, exerciseId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  if (!orgId) return null;
  const d = bcmsQuery.data;

  const critTone = (c: string) =>
    c === 'CRITICA' ? 'danger' : c === 'ALTA' ? 'warn' : 'muted';
  const critLabel = (c: string) =>
    t.bcms[CRITICALITIES[c as keyof typeof CRITICALITIES] ?? 'medium'];
  const planStatusLabel = (s: string) =>
    t.bcms[PLAN_STATUSES[s as keyof typeof PLAN_STATUSES] ?? 'statusDraft'];
  const exerciseTypeLabel = (v: string) =>
    t.bcms[EXERCISE_TYPES[v as keyof typeof EXERCISE_TYPES] ?? 'typeTableTop'];
  const exerciseStatusLabel = (s: string) =>
    t.bcms[EXERCISE_STATUSES[s as keyof typeof EXERCISE_STATUSES] ?? 'statusPlanned'];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.bcms.title}</h1>
          <p className="mt-1 text-sm text-ink-soft">{t.bcms.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {bcmsQuery.isLoading && <SkeletonCards count={2} />}

      {bcmsQuery.isError && (
        <ErrorState
          message={(bcmsQuery.error as Error).message}
          onRetry={() => bcmsQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {d && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {[
            { label: t.bcms.bia, value: String(d.summary.processes) },
            {
              label: t.bcms.criticality,
              value: String(d.summary.critical),
              sub: t.bcms.critical,
            },
            {
              label: t.bcms.plans,
              value: String(d.summary.activePlans),
              sub: t.bcms.statusActive,
            },
          ].map((kpi, i) => (
            <div key={i} className="rounded-card border border-line bg-white p-4 shadow-card">
              <div className="text-xs font-semibold text-ink-muted">{kpi.label}</div>
              <div className="text-[26px] font-extrabold text-navy">{kpi.value}</div>
              {kpi.sub && <div className="text-[11.5px] text-ink-soft">{kpi.sub}</div>}
            </div>
          ))}
        </div>
      )}

      {/* BIA */}
      <Card title={t.bcms.bia}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.bcms.processName}
              aria-label={t.bcms.processName}
              value={processName}
              onChange={(e) => setProcessName(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <select
              value={criticality}
              onChange={(e) => setCriticality(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.bcms.criticality}
            >
              {Object.entries(CRITICALITIES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.bcms[key]}
                </option>
              ))}
            </select>
            <Input
              placeholder={t.bcms.rto}
              aria-label={t.bcms.rto}
              type="number"
              min={0}
              value={rto}
              onChange={(e) => setRto(e.target.value)}
              className="w-24"
            />
            <Input
              placeholder={t.bcms.rpo}
              aria-label={t.bcms.rpo}
              type="number"
              min={0}
              value={rpo}
              onChange={(e) => setRpo(e.target.value)}
              className="w-24"
            />
            <Button
              onClick={() => addBia.mutate()}
              disabled={!processName || addBia.isPending}
            >
              {t.bcms.addBia}
            </Button>
          </div>
        )}
        {canWrite && (
          <p className="mb-3 text-[11px] text-ink-muted">
            {t.bcms.addBiaHint} {t.bcms.rtoHint} {t.bcms.criticalProcessHint}
          </p>
        )}

        {d && d.bias.length === 0 ? (
          <EmptyState title={t.bcms.noBia} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b-2 border-line-strong text-left text-[10.5px] uppercase tracking-wider text-ink-muted">
                  <th className="py-2">{t.bcms.process}</th>
                  <th className="w-28">{t.bcms.criticality}</th>
                  <th className="w-24">{t.bcms.rto}</th>
                  <th className="w-24">{t.bcms.rpo}</th>
                  {canWrite && <th className="w-10" />}
                </tr>
              </thead>
              <tbody>
                {(d?.bias ?? []).map((b) => (
                  <tr key={b.id} className="border-b border-line">
                    <td className="py-2 font-medium">{b.processName}</td>
                    <td className="py-2">
                      <Badge tone={critTone(b.criticality) as 'danger' | 'warn' | 'muted'}>
                        {critLabel(b.criticality)}
                      </Badge>
                    </td>
                    <td className="py-2">{b.rtoHours != null ? `${b.rtoHours} h` : '—'}</td>
                    <td className="py-2">{b.rpoHours != null ? `${b.rpoHours} h` : '—'}</td>
                    {canWrite && (
                      <td className="py-2 text-right">
                        <ConfirmButton
                          confirmLabel={t.common.confirmDelete}
                          variant="ghost"
                          className="h-6 px-1.5 text-[11px]"
                          onConfirm={() => removeBia.mutate(b.id)}
                        >
                          {t.common.delete}
                        </ConfirmButton>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Planes */}
      <Card title={t.bcms.plans}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.bcms.planTitle}
              aria-label={t.bcms.planTitle}
              value={planTitle}
              onChange={(e) => setPlanTitle(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <Input
              placeholder={t.bcms.planStrategy}
              aria-label={t.bcms.planStrategy}
              value={planStrategy}
              onChange={(e) => setPlanStrategy(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <Button
              onClick={() => addPlan.mutate()}
              disabled={!planTitle || addPlan.isPending}
            >
              {t.bcms.addPlan}
            </Button>
          </div>
        )}

        {d && d.plans.length === 0 ? (
          <EmptyState title={t.bcms.noPlans} />
        ) : (
          <div className="space-y-2">
            {(d?.plans ?? []).map((p) => (
              <div key={p.id} className="rounded-btn border border-line px-3 py-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="text-sm font-medium">{p.title}</span>
                    {p.strategy && (
                      <div className="text-[11px] text-ink-muted">
                        {t.bcms.strategy}: {p.strategy}
                      </div>
                    )}
                    {p.lastTestedAt && (
                      <div className="text-[11px] text-ink-muted">
                        {t.bcms.statusTested}: {new Date(p.lastTestedAt).toLocaleDateString()}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    {canWrite ? (
                      <select
                        value={p.status}
                        onChange={(e) =>
                          updatePlanStatus.mutate({ planId: p.id, status: e.target.value })
                        }
                        className="rounded-btn border border-line bg-white px-2 py-1 text-xs"
                        aria-label={`${t.bcms.status} ${p.title}`}
                      >
                        {Object.entries(PLAN_STATUSES).map(([value, key]) => (
                          <option key={value} value={value}>
                            {t.bcms[key]}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <Badge
                        tone={
                          p.status === 'ACTIVE' || p.status === 'TESTED'
                            ? 'ok'
                            : p.status === 'REVIEWED'
                              ? 'info'
                              : 'muted'
                        }
                      >
                        {planStatusLabel(p.status)}
                      </Badge>
                    )}
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        variant="ghost"
                        className="h-6 px-1.5 text-[11px]"
                        onConfirm={() => removePlan.mutate(p.id)}
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Ejercicios */}
      <Card title={t.bcms.exercises}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.bcms.exerciseTitle}
              aria-label={t.bcms.exerciseTitle}
              value={exerciseTitle}
              onChange={(e) => setExerciseTitle(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <select
              value={exerciseType}
              onChange={(e) => setExerciseType(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.bcms.type}
            >
              {Object.entries(EXERCISE_TYPES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.bcms[key]}
                </option>
              ))}
            </select>
            <Input
              type="date"
              aria-label={t.bcms.scheduleDate}
              value={exerciseDate}
              onChange={(e) => setExerciseDate(e.target.value)}
              className="w-44"
            />
            <Button
              onClick={() => addExercise.mutate()}
              disabled={!exerciseTitle || addExercise.isPending}
            >
              {t.bcms.addExercise}
            </Button>
          </div>
        )}

        {d && d.exercises.length === 0 ? (
          <EmptyState title={t.bcms.noExercises} />
        ) : (
          <div className="space-y-2">
            {(d?.exercises ?? []).map((e) => (
              <div key={e.id} className="rounded-btn border border-line px-3 py-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="text-sm font-medium">{e.title}</span>
                    <div className="text-[11px] text-ink-muted">
                      {exerciseTypeLabel(e.type)}
                      {e.scheduledAt
                        ? ` · ${new Date(e.scheduledAt).toLocaleDateString()}`
                        : ''}
                    </div>
                    {e.result && (
                      <div className="text-[11px] text-ink-soft">
                        {t.bcms.result}: {e.result}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      tone={
                        e.status === 'COMPLETED'
                          ? 'ok'
                          : e.status === 'IN_PROGRESS'
                            ? 'info'
                            : 'muted'
                      }
                    >
                      {exerciseStatusLabel(e.status)}
                    </Badge>
                    {canWrite && e.status !== 'COMPLETED' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setResultFor(e.id);
                          setExerciseResult('');
                        }}
                      >
                        {t.bcms.recordResult}
                      </Button>
                    )}
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        variant="ghost"
                        className="h-6 px-1.5 text-[11px]"
                        onConfirm={() => removeExercise.mutate(e.id)}
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    )}
                  </div>
                </div>

                {resultFor === e.id && (
                  <div className="mt-2 flex flex-wrap gap-2">
                    <Input
                      placeholder={t.bcms.result}
                      aria-label={t.bcms.result}
                      value={exerciseResult}
                      onChange={(ev) => setExerciseResult(ev.target.value)}
                      className="min-w-[200px] flex-1"
                    />
                    <Button
                      size="sm"
                      onClick={() =>
                        recordExercise.mutate({ exerciseId: e.id, result: exerciseResult })
                      }
                      disabled={!exerciseResult || recordExercise.isPending}
                    >
                      {t.common.save}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setResultFor(null)}
                    >
                      {t.common.cancel}
                    </Button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
