'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const CATEGORIES = {
  SOPORTE: 'catSupport',
  INFRAESTRUCTURA: 'catInfrastructure',
  APLICACION: 'catApplication',
  OTRO: 'catOther',
} as const;

const CRITICALITIES = {
  CRITICA: 'critical',
  ALTA: 'high',
  MEDIA: 'medium',
  BAJA: 'low',
} as const;

const TYPES = {
  INCIDENT: 'typeIncident',
  REQUEST: 'typeRequest',
  PROBLEM: 'typeProblem',
  CHANGE: 'typeChange',
} as const;

const REQUEST_STATUSES = {
  OPEN: 'statusOpen',
  IN_PROGRESS: 'statusInProgress',
  RESOLVED: 'statusResolved',
  CLOSED: 'statusClosed',
} as const;

const PRIORITIES = {
  CRITICA: 'critical',
  ALTA: 'high',
  MEDIA: 'medium',
  BAJA: 'low',
} as const;

/** ISO/IEC 20000-1:2018 — portafolio de servicios, SLA y resolución de casos. */
export function ItsmView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [code, setCode] = useState('');
  const [name, setName] = useState('');
  const [category, setCategory] = useState('SOPORTE');
  const [criticality, setCriticality] = useState('MEDIA');

  const [slaService, setSlaService] = useState('');
  const [slaCustomer, setSlaCustomer] = useState('');
  const [slaResponse, setSlaResponse] = useState('4');
  const [slaResolution, setSlaResolution] = useState('24');
  const [slaAvailability, setSlaAvailability] = useState('99.5');

  const [folio, setFolio] = useState('');
  const [requestTitle, setRequestTitle] = useState('');
  const [requestType, setRequestType] = useState('INCIDENT');
  const [requestPriority, setRequestPriority] = useState('MEDIA');
  const [requestService, setRequestService] = useState('');

  const itsmQuery = useQuery({
    queryKey: ['itsm', orgId],
    queryFn: () => api.itsm(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['itsm', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
  };

  const onError = (err: unknown) =>
    toast.error(err instanceof Error ? err.message : t.common.saveError);

  const addService = useMutation({
    mutationFn: () => api.addService(orgId!, { code, name, category, criticality }),
    onSuccess: () => {
      refresh();
      setCode('');
      setName('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeService = useMutation({
    mutationFn: (serviceId: string) => api.deleteService(orgId!, serviceId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const addSla = useMutation({
    mutationFn: () =>
      api.addSla(orgId!, {
        serviceCode: slaService,
        customer: slaCustomer,
        responseHours: Number(slaResponse),
        resolutionHours: Number(slaResolution),
        availabilityPct: Number(slaAvailability),
      }),
    onSuccess: () => {
      refresh();
      setSlaCustomer('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeSla = useMutation({
    mutationFn: (slaId: string) => api.deleteSla(orgId!, slaId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const addRequest = useMutation({
    mutationFn: () =>
      api.addServiceRequest(orgId!, {
        folio,
        title: requestTitle,
        type: requestType,
        priority: requestPriority,
        serviceCode: requestService || undefined,
      }),
    onSuccess: () => {
      refresh();
      setFolio('');
      setRequestTitle('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const updateRequestStatus = useMutation({
    mutationFn: ({ requestId, status }: { requestId: string; status: string }) =>
      api.updateServiceRequest(orgId!, requestId, { status }),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeRequest = useMutation({
    mutationFn: (requestId: string) => api.deleteServiceRequest(orgId!, requestId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  if (!orgId) return null;
  const d = itsmQuery.data;

  const critTone = (c: string) =>
    c === 'CRITICA' ? 'danger' : c === 'ALTA' ? 'warn' : 'muted';
  const critLabel = (c: string) =>
    t.itsm[CRITICALITIES[c as keyof typeof CRITICALITIES] ?? 'medium'];
  const priorityLabel = (p: string) =>
    t.itsm[PRIORITIES[p as keyof typeof PRIORITIES] ?? 'medium'];
  const typeLabel = (v: string) => t.itsm[TYPES[v as keyof typeof TYPES] ?? 'typeIncident'];
  const statusLabel = (s: string) =>
    t.itsm[REQUEST_STATUSES[s as keyof typeof REQUEST_STATUSES] ?? 'statusOpen'];
  const categoryLabel = (c: string) =>
    t.itsm[CATEGORIES[c as keyof typeof CATEGORIES] ?? 'catOther'];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.itsm.title}</h1>
          <p className="mt-1 text-sm text-ink-soft">{t.itsm.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {itsmQuery.isLoading && <SkeletonCards count={2} />}

      {itsmQuery.isError && (
        <ErrorState
          message={(itsmQuery.error as Error).message}
          onRetry={() => itsmQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {d && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[
            { label: t.itsm.activeServices, value: String(d.summary.services) },
            { label: t.itsm.activeSlas, value: String(d.summary.slas) },
            { label: t.itsm.openRequests, value: String(d.summary.openRequests) },
            {
              label: t.itsm.resolutionRate,
              value: `${d.summary.resolutionRate}%`,
              sub: `${d.summary.incidents} ${t.itsm.incidents.toLowerCase()}`,
            },
          ].map((kpi, i) => (
            <div key={i} className="rounded-card border border-line bg-white p-4 shadow-card">
              <div className="text-xs font-semibold text-ink-muted">{kpi.label}</div>
              <div className="text-[26px] font-extrabold text-navy">{kpi.value}</div>
              {kpi.sub && <div className="text-[11.5px] text-ink-soft">{kpi.sub}</div>}
            </div>
          ))}
        </div>
      )}

      {/* Catálogo de servicios */}
      <Card title={t.itsm.services}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.itsm.serviceCode}
              aria-label={t.itsm.serviceCode}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="w-32"
            />
            <Input
              placeholder={t.itsm.serviceName}
              aria-label={t.itsm.serviceName}
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.itsm.category}
            >
              {Object.entries(CATEGORIES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.itsm[key]}
                </option>
              ))}
            </select>
            <select
              value={criticality}
              onChange={(e) => setCriticality(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.itsm.criticality}
            >
              {Object.entries(CRITICALITIES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.itsm[key]}
                </option>
              ))}
            </select>
            <Button
              onClick={() => addService.mutate()}
              disabled={!code || !name || addService.isPending}
            >
              {t.itsm.addService}
            </Button>
          </div>
        )}

        {d && d.services.length === 0 ? (
          <EmptyState title={t.itsm.noServices} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b-2 border-line-strong text-left text-[10.5px] uppercase tracking-wider text-ink-muted">
                  <th className="w-24 py-2">{t.itsm.serviceCode}</th>
                  <th className="py-2">{t.itsm.serviceName}</th>
                  <th className="w-36">{t.itsm.category}</th>
                  <th className="w-28">{t.itsm.criticality}</th>
                  {canWrite && <th className="w-16" />}
                </tr>
              </thead>
              <tbody>
                {(d?.services ?? []).map((s) => (
                  <tr key={s.id} className="border-b border-line">
                    <td className="py-2 font-mono text-xs">{s.code}</td>
                    <td className="py-2">
                      <div className="font-medium">{s.name}</div>
                      {s.description && (
                        <div className="text-[11px] text-ink-muted">{s.description}</div>
                      )}
                    </td>
                    <td className="py-2">{categoryLabel(s.category)}</td>
                    <td className="py-2">
                      <Badge tone={critTone(s.criticality) as 'danger' | 'warn' | 'muted'}>
                        {critLabel(s.criticality)}
                      </Badge>
                    </td>
                    {canWrite && (
                      <td className="py-2 text-right">
                        <ConfirmButton
                          confirmLabel={t.common.confirmDelete}
                          variant="ghost"
                          className="h-6 px-1.5 text-[11px]"
                          onConfirm={() => removeService.mutate(s.id)}
                        >
                          {t.common.delete}
                        </ConfirmButton>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* SLA */}
      <Card title={t.itsm.slas}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <select
              value={slaService}
              onChange={(e) => setSlaService(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.itsm.services}
            >
              <option value="">{t.itsm.services}…</option>
              {(d?.services ?? []).map((s) => (
                <option key={s.id} value={s.code}>
                  {s.code} · {s.name}
                </option>
              ))}
            </select>
            <Input
              placeholder={t.itsm.customer}
              aria-label={t.itsm.customer}
              value={slaCustomer}
              onChange={(e) => setSlaCustomer(e.target.value)}
              className="min-w-[160px] flex-1"
            />
            <Input
              type="number"
              min={1}
              aria-label={t.itsm.responseHours}
              value={slaResponse}
              onChange={(e) => setSlaResponse(e.target.value)}
              className="w-24"
            />
            <Input
              type="number"
              min={1}
              aria-label={t.itsm.resolutionHours}
              value={slaResolution}
              onChange={(e) => setSlaResolution(e.target.value)}
              className="w-24"
            />
            <Input
              type="number"
              min={0}
              max={100}
              step="0.1"
              aria-label={t.itsm.availability}
              value={slaAvailability}
              onChange={(e) => setSlaAvailability(e.target.value)}
              className="w-28"
            />
            <Button
              onClick={() => addSla.mutate()}
              disabled={!slaService || !slaCustomer || addSla.isPending}
            >
              {t.itsm.addSla}
            </Button>
          </div>
        )}
        {canWrite && <p className="mb-3 text-[11px] text-ink-muted">{t.itsm.slaHint}</p>}

        {d && d.slas.length === 0 ? (
          <EmptyState title={t.itsm.noSlas} />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b-2 border-line-strong text-left text-[10.5px] uppercase tracking-wider text-ink-muted">
                  <th className="w-24 py-2">{t.itsm.serviceCode}</th>
                  <th className="py-2">{t.itsm.customer}</th>
                  <th className="w-28">{t.itsm.responseHours}</th>
                  <th className="w-32">{t.itsm.resolutionHours}</th>
                  <th className="w-32">{t.itsm.availability}</th>
                  {canWrite && <th className="w-10" />}
                </tr>
              </thead>
              <tbody>
                {(d?.slas ?? []).map((s) => (
                  <tr key={s.id} className="border-b border-line">
                    <td className="py-2 font-mono text-xs">{s.serviceCode}</td>
                    <td className="py-2">{s.customer}</td>
                    <td className="py-2">{s.responseHours} h</td>
                    <td className="py-2">{s.resolutionHours} h</td>
                    <td className="py-2">{Number(s.availabilityPct).toFixed(2)}%</td>
                    {canWrite && (
                      <td className="py-2 text-right">
                        <ConfirmButton
                          confirmLabel={t.common.confirmDelete}
                          variant="ghost"
                          className="h-6 px-1.5 text-[11px]"
                          onConfirm={() => removeSla.mutate(s.id)}
                        >
                          {t.common.delete}
                        </ConfirmButton>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Incidentes y peticiones */}
      <Card title={t.itsm.requests}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.itsm.folio}
              aria-label={t.itsm.folio}
              value={folio}
              onChange={(e) => setFolio(e.target.value)}
              className="w-40"
            />
            <Input
              placeholder={t.itsm.requestTitle}
              aria-label={t.itsm.requestTitle}
              value={requestTitle}
              onChange={(e) => setRequestTitle(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <select
              value={requestType}
              onChange={(e) => setRequestType(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.itsm.type}
            >
              {Object.entries(TYPES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.itsm[key]}
                </option>
              ))}
            </select>
            <select
              value={requestPriority}
              onChange={(e) => setRequestPriority(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.itsm.priority}
            >
              {Object.entries(PRIORITIES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.itsm[key]}
                </option>
              ))}
            </select>
            <select
              value={requestService}
              onChange={(e) => setRequestService(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.itsm.services}
            >
              <option value="">{t.itsm.services}…</option>
              {(d?.services ?? []).map((s) => (
                <option key={s.id} value={s.code}>
                  {s.code} · {s.name}
                </option>
              ))}
            </select>
            <Button
              onClick={() => addRequest.mutate()}
              disabled={!folio || !requestTitle || addRequest.isPending}
            >
              {t.itsm.addRequest}
            </Button>
          </div>
        )}
        {canWrite && (
          <p className="mb-3 text-[11px] text-ink-muted">{t.itsm.addRequestHint}</p>
        )}

        {d && d.requests.length === 0 ? (
          <EmptyState title={t.itsm.noRequests} />
        ) : (
          <div className="space-y-2">
            {(d?.requests ?? []).map((r) => (
              <div key={r.id} className="rounded-btn border border-line px-3 py-2">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="font-mono text-[11px] text-ink-muted">{r.folio}</span>
                    <div className="text-sm font-medium">{r.title}</div>
                    <div className="text-[11px] text-ink-muted">
                      {typeLabel(r.type)}
                      {r.serviceCode ? ` · ${r.serviceCode}` : ''} · {priorityLabel(r.priority)}
                      {r.resolvedAt
                        ? ` · ${t.itsm.resolvedAt}: ${new Date(r.resolvedAt).toLocaleDateString()}`
                        : ''}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {canWrite ? (
                      <select
                        value={r.status}
                        onChange={(e) =>
                          updateRequestStatus.mutate({ requestId: r.id, status: e.target.value })
                        }
                        className="rounded-btn border border-line bg-white px-2 py-1 text-xs"
                        aria-label={`${t.itsm.status} ${r.folio}`}
                      >
                        {Object.entries(REQUEST_STATUSES).map(([value, key]) => (
                          <option key={value} value={value}>
                            {t.itsm[key]}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <Badge
                        tone={
                          r.status === 'RESOLVED' || r.status === 'CLOSED'
                            ? 'ok'
                            : r.status === 'IN_PROGRESS'
                              ? 'info'
                              : 'warn'
                        }
                      >
                        {statusLabel(r.status)}
                      </Badge>
                    )}
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        variant="ghost"
                        className="h-6 px-1.5 text-[11px]"
                        onConfirm={() => removeRequest.mutate(r.id)}
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
