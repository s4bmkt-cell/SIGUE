'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api, type ReviewItem } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const ENTRY_TYPES = [
  { value: 'COMPLIANCE', es: 'Cumplimiento', en: 'Compliance' },
  { value: 'AUDITS', es: 'Auditorías', en: 'Audits' },
  { value: 'RISKS', es: 'Riesgos', en: 'Risks' },
  { value: 'NC', es: 'No conformidades', en: 'Nonconformities' },
  { value: 'OBJECTIVES', es: 'Objetivos', en: 'Objectives' },
  { value: 'PROCESS_PERFORMANCE', es: 'Desempeño de procesos', en: 'Process performance' },
] as const;

function entryLabel(type: string, locale: string) {
  const hit = ENTRY_TYPES.find((e) => e.value === type);
  if (!hit) return type;
  return locale === 'en-US' ? hit.en : hit.es;
}

export function ReviewView() {
  const { t, locale } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [code, setCode] = useState('');
  const [period, setPeriod] = useState('');
  const [agreements, setAgreements] = useState<Record<string, string>>({});
  const [entries, setEntries] = useState<Record<string, { entryType: string; source: string }>>({});

  const reviewsQuery = useQuery({
    queryKey: ['reviews', orgId],
    queryFn: () => api.reviews(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => qc.invalidateQueries({ queryKey: ['reviews', orgId] });

  const createReview = useMutation({
    mutationFn: () => api.createReview(orgId!, { code, period }),
    onSuccess: () => {
      refresh();
      setCode('');
      setPeriod('');
      toast.success(t.common.saved);
    },
  });

  const removeReview = useMutation({
    mutationFn: (reviewId: string) => api.deleteReview(orgId!, reviewId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const addAgreement = useMutation({
    mutationFn: ({ reviewId, decision }: { reviewId: string; decision: string }) =>
      api.addAgreement(orgId!, reviewId, decision),
    onSuccess: (_data, vars) => {
      refresh();
      setAgreements((s) => ({ ...s, [vars.reviewId]: '' }));
      toast.success(t.common.saved);
    },
  });

  const completeAgreement = useMutation({
    mutationFn: (agreementId: string) => api.completeAgreement(orgId!, agreementId),
    onSuccess: () => refresh(),
  });

  const removeAgreement = useMutation({
    mutationFn: (agreementId: string) => api.deleteAgreement(orgId!, agreementId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const addEntry = useMutation({
    mutationFn: ({ reviewId, entryType, source }: { reviewId: string; entryType: string; source: string }) =>
      api.addReviewEntry(orgId!, reviewId, { entryType, source }),
    onSuccess: (_data, vars) => {
      refresh();
      setEntries((s) => ({ ...s, [vars.reviewId]: { entryType: vars.entryType, source: '' } }));
      toast.success(t.common.saved);
    },
  });

  const removeEntry = useMutation({
    mutationFn: ({ entryId }: { reviewId: string; entryId: string }) =>
      api.deleteReviewEntry(orgId!, entryId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const closeReview = useMutation({
    mutationFn: (reviewId: string) => api.closeReview(orgId!, reviewId),
    onSuccess: () => {
      refresh();
      toast.success(t.review.closed);
    },
  });

  if (!orgId) return null;
  const reviews: ReviewItem[] = reviewsQuery.data ?? [];

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.review.title}</h1>
          <p className="text-sm text-ink-soft mt-1">{t.review.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {canWrite && (
        <Card>
          <div className="flex gap-3 items-end flex-wrap">
            <Input
              placeholder={t.review.code}
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="flex-1 min-w-[180px]"
            />
            <Input
              placeholder={t.review.period}
              value={period}
              onChange={(e) => setPeriod(e.target.value)}
              className="flex-1 min-w-[180px]"
            />
            <Button
              onClick={() => createReview.mutate()}
              disabled={!code || !period || createReview.isPending}
            >
              {t.review.newReview}
            </Button>
          </div>
        </Card>
      )}

      {reviewsQuery.isLoading && <SkeletonCards count={2} />}

      {reviewsQuery.isError && (
        <ErrorState
          message={(reviewsQuery.error as Error).message}
          onRetry={() => reviewsQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {reviewsQuery.isSuccess && reviews.length === 0 && (
        <EmptyState title={t.review.noReviews} hint={t.review.subtitle} />
      )}

      {reviews.map((r) => {
        const done = r.status === 'COMPLETED';
        const openAgreements = r.agreements.filter((a) => a.status !== 'DONE').length;
        const draft = entries[r.id] ?? { entryType: 'COMPLIANCE', source: '' };

        return (
          <Card key={r.id}>
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="min-w-0">
                <span className="font-semibold">{r.code}</span>
                <span className="text-ink-muted text-sm ml-2">{r.period}</span>
                <div className="text-[11px] text-ink-muted mt-0.5">
                  {new Date(r.date).toLocaleDateString(locale === 'en-US' ? 'en-US' : 'es-MX')}
                  {openAgreements > 0 && ` · ${t.review.openAgreements(openAgreements)}`}
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge tone={done ? 'ok' : 'info'}>
                  {done ? t.review.closed : r.status === 'IN_PROGRESS' ? t.review.inSession : t.review.planned}
                </Badge>
                {canWrite && !done && (
                  <ConfirmButton
                    confirmLabel={t.common.confirmDelete}
                    onConfirm={() => closeReview.mutate(r.id)}
                    variant="outline"
                    className="h-7 px-2.5 text-[11px]"
                  >
                    {t.review.close}
                  </ConfirmButton>
                )}
                {canWrite && !done && (
                  <ConfirmButton
                    confirmLabel={t.common.confirmDelete}
                    onConfirm={() => removeReview.mutate(r.id)}
                    variant="ghost"
                    className="h-7 px-2 text-[11px]"
                  >
                    {t.common.delete}
                  </ConfirmButton>
                )}
              </div>
            </div>

            {/* Entradas */}
            <div className="mt-3">
              <b className="text-xs text-ink-muted uppercase tracking-wide">{t.review.autoEntries}</b>
              {r.entries.length === 0 ? (
                <p className="text-xs text-ink-muted mt-1">{t.review.noEntries}</p>
              ) : (
                <div className="grid md:grid-cols-2 gap-2 mt-2">
                  {r.entries.map((e) => (
                    <div
                      key={e.id}
                      className="border border-line rounded-btn px-3 py-2 text-sm flex items-start justify-between gap-2"
                    >
                      <div className="min-w-0">
                        <div className="font-medium text-xs">{entryLabel(e.entryType, locale)}</div>
                        <div className="text-ink-soft text-xs">{e.source ?? '—'}</div>
                      </div>
                      {canWrite && !done && (
                        <ConfirmButton
                          confirmLabel={t.common.confirmDelete}
                          onConfirm={() => removeEntry.mutate({ reviewId: r.id, entryId: e.id })}
                          variant="ghost"
                          className="h-6 px-1.5 text-[11px] shrink-0"
                        >
                          {t.common.delete}
                        </ConfirmButton>
                      )}
                    </div>
                  ))}
                </div>
              )}
              {canWrite && !done && (
                <div className="flex gap-2 mt-2 flex-wrap">
                  <select
                    value={draft.entryType}
                    onChange={(e) =>
                      setEntries((s) => ({ ...s, [r.id]: { ...draft, entryType: e.target.value } }))
                    }
                    className="text-xs border border-line rounded-btn px-2 bg-white"
                    aria-label={t.review.entryType}
                  >
                    {ENTRY_TYPES.map((e) => (
                      <option key={e.value} value={e.value}>
                        {locale === 'en-US' ? e.en : e.es}
                      </option>
                    ))}
                  </select>
                  <Input
                    placeholder={t.review.entrySource}
                    value={draft.source}
                    onChange={(e) =>
                      setEntries((s) => ({ ...s, [r.id]: { ...draft, source: e.target.value } }))
                    }
                    className="h-8 text-xs flex-1 min-w-[180px]"
                  />
                  <Button
                    size="sm"
                    className="h-8"
                    onClick={() =>
                      addEntry.mutate({ reviewId: r.id, entryType: draft.entryType, source: draft.source })
                    }
                    disabled={!draft.source || addEntry.isPending}
                  >
                    {t.review.addEntry}
                  </Button>
                </div>
              )}
            </div>

            {/* Acuerdos */}
            <div className="mt-3">
              <b className="text-xs text-ink-muted uppercase tracking-wide">{t.review.agreements}</b>
              {r.agreements.length === 0 ? (
                <p className="text-xs text-ink-muted mt-1">{t.review.noAgreements}</p>
              ) : (
                <div className="space-y-1.5 mt-2">
                  {r.agreements.map((a) => (
                    <div
                      key={a.id}
                      className="flex items-center justify-between gap-2 text-sm border-b border-line pb-1.5 last:border-0"
                    >
                      <span className={a.status === 'DONE' ? 'line-through text-ink-muted' : ''}>
                        {a.decision}
                      </span>
                      <div className="flex items-center gap-2 shrink-0">
                        {a.dueDate && (
                          <span className="text-ink-muted text-xs">
                            {t.review.due}:{' '}
                            {new Date(a.dueDate).toLocaleDateString(
                              locale === 'en-US' ? 'en-US' : 'es-MX',
                            )}
                          </span>
                        )}
                        <Badge tone={a.status === 'DONE' ? 'ok' : 'warn'}>
                          {a.status === 'DONE' ? t.review.done : t.review.open}
                        </Badge>
                        {canWrite && a.status !== 'DONE' && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-6 px-2 text-[11px]"
                            onClick={() => completeAgreement.mutate(a.id)}
                            disabled={completeAgreement.isPending}
                          >
                            {t.review.complete}
                          </Button>
                        )}
                        {canWrite && a.status !== 'DONE' && (
                          <ConfirmButton
                            confirmLabel={t.common.confirmDelete}
                            onConfirm={() => removeAgreement.mutate(a.id)}
                            variant="ghost"
                            className="h-6 px-1 text-[10px]"
                          >
                            {t.common.delete}
                          </ConfirmButton>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              {canWrite && !done && (
                <div className="flex gap-2 mt-2">
                  <Input
                    placeholder={t.review.addAgreement}
                    value={agreements[r.id] ?? ''}
                    onChange={(e) =>
                      setAgreements((s) => ({ ...s, [r.id]: e.target.value }))
                    }
                    className="flex-1 text-xs"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && agreements[r.id])
                        addAgreement.mutate({ reviewId: r.id, decision: agreements[r.id] });
                    }}
                  />
                  <Button
                    size="sm"
                    onClick={() =>
                      addAgreement.mutate({ reviewId: r.id, decision: agreements[r.id] })
                    }
                    disabled={!agreements[r.id] || addAgreement.isPending}
                  >
                    {t.review.addAgreement}
                  </Button>
                </div>
              )}
            </div>
          </Card>
        );
      })}
    </div>
  );
}
