'use client';

import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState } from '@/components/ui/states';
import { ContextDataGate, jsonText, useContextData } from './shared';
import { SectionHeading } from './section-heading';

export function PartiesSection({ orgId, onBack }: { orgId: string; onBack: () => void }) {
  const { t } = useI18n();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const { query, refresh } = useContextData(orgId);

  const [name, setName] = useState('');
  const [needs, setNeeds] = useState('');
  const [relevance, setRelevance] = useState('MEDIA');

  const add = useMutation({
    mutationFn: () =>
      api.addParty(orgId, { name, needs: needs || undefined, relevance }),
    onSuccess: () => {
      refresh();
      setName('');
      setNeeds('');
      toast.success(t.common.saved);
    },
  });

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteParty(orgId, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  return (
    <>
      <SectionHeading
        title={t.context.parties}
        subtitle={t.context.partiesHint}
        hint={!canWrite ? t.common.readOnlyHint : undefined}
        onBack={onBack}
      />
      <ContextDataGate query={query}>
        {(c) => (
          <Card>
            {c.parties.length === 0 ? (
              <EmptyState title={t.context.noParties} />
            ) : (
              <div className="space-y-2">
                {c.parties.map((p) => (
                  <div key={p.id} className="border border-line rounded-btn px-3 py-2.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-semibold">{p.name}</span>
                      <div className="flex items-center gap-2">
                        <Badge
                          tone={
                            p.relevance === 'ALTA'
                              ? 'danger'
                              : p.relevance === 'MEDIA'
                                ? 'warn'
                                : 'muted'
                          }
                        >
                          {p.relevance === 'ALTA'
                            ? t.context.high
                            : p.relevance === 'MEDIA'
                              ? t.context.medium
                              : t.context.low}
                        </Badge>
                        {canWrite && (
                          <ConfirmButton
                            confirmLabel={t.common.confirmDelete}
                            onConfirm={() => remove.mutate(p.id)}
                            variant="ghost"
                            className="h-6 px-1.5 text-[11px]"
                          >
                            {t.common.delete}
                          </ConfirmButton>
                        )}
                      </div>
                    </div>
                    <div className="text-[11px] text-ink-muted mt-1">
                      {t.context.needs}: {jsonText(p.needs) || '—'}
                    </div>
                    {jsonText(p.expectations) && (
                      <div className="text-[11px] text-ink-muted">
                        {t.context.expectations}: {jsonText(p.expectations)}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
            {canWrite && (
              <div className="space-y-2 mt-3 pt-3 border-t border-line">
                <Input
                  placeholder={t.context.addParty}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
                <Input
                  placeholder={t.context.needs}
                  value={needs}
                  onChange={(e) => setNeeds(e.target.value)}
                />
                <div className="flex gap-2">
                  <select
                    value={relevance}
                    onChange={(e) => setRelevance(e.target.value)}
                    className="text-xs border border-line rounded-btn px-2 py-2 bg-white"
                    aria-label={t.context.relevance}
                  >
                    <option value="ALTA">{t.context.high}</option>
                    <option value="MEDIA">{t.context.medium}</option>
                    <option value="BAJA">{t.context.low}</option>
                  </select>
                  <Button
                    size="sm"
                    onClick={() => add.mutate()}
                    disabled={!name || add.isPending}
                  >
                    {t.context.addParty}
                  </Button>
                </div>
              </div>
            )}
          </Card>
        )}
      </ContextDataGate>
    </>
  );
}
