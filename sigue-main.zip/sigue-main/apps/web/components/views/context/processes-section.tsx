'use client';

import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState } from '@/components/ui/states';
import { ContextDataGate, useContextData } from './shared';
import { SectionHeading } from './section-heading';

export function ProcessesSection({ orgId, onBack }: { orgId: string; onBack: () => void }) {
  const { t } = useI18n();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const { query, refresh } = useContextData(orgId);

  const [draft, setDraft] = useState({ name: '', inputs: '', outputs: '' });

  const add = useMutation({
    mutationFn: () => api.addProcess(orgId, draft),
    onSuccess: () => {
      refresh();
      setDraft({ name: '', inputs: '', outputs: '' });
      toast.success(t.common.saved);
    },
  });

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteProcess(orgId, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  return (
    <>
      <SectionHeading
        title={t.context.processes}
        subtitle={t.context.processesHint}
        hint={!canWrite ? t.common.readOnlyHint : undefined}
        onBack={onBack}
      />
      <ContextDataGate query={query}>
        {(c) => (
          <Card>
            {c.processes.length === 0 ? (
              <EmptyState title={t.context.noProcesses} />
            ) : (
              <div className="space-y-2">
                {c.processes.map((p) => (
                  <div
                    key={p.id}
                    className="flex items-center gap-3 border border-line rounded-btn px-3 py-2.5"
                  >
                    <span className="size-8 rounded-lg bg-info-bg text-info flex items-center justify-center text-sm shrink-0">
                      ⚙
                    </span>
                    <div className="min-w-0 flex-1">
                      <div className="text-sm font-semibold">{p.name}</div>
                      <div className="text-[11px] text-ink-muted">
                        {p.inputs ? `→ ${p.inputs}` : ''}
                        {p.inputs && p.outputs ? ' · ' : ''}
                        {p.outputs ? `${p.outputs} →` : ''}
                      </div>
                    </div>
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        onConfirm={() => remove.mutate(p.id)}
                        variant="ghost"
                        className="h-6 px-1.5 text-[11px]"
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    )}
                  </div>
                ))}
              </div>
            )}
            {canWrite && (
              <div className="space-y-2 mt-3 pt-3 border-t border-line">
                <Input
                  placeholder={t.context.processName}
                  value={draft.name}
                  onChange={(e) => setDraft({ ...draft, name: e.target.value })}
                />
                <div className="grid sm:grid-cols-2 gap-2">
                  <Input
                    placeholder={t.context.inputs}
                    value={draft.inputs}
                    onChange={(e) => setDraft({ ...draft, inputs: e.target.value })}
                  />
                  <Input
                    placeholder={t.context.outputs}
                    value={draft.outputs}
                    onChange={(e) => setDraft({ ...draft, outputs: e.target.value })}
                  />
                </div>
                <Button
                  size="sm"
                  onClick={() => add.mutate()}
                  disabled={!draft.name || add.isPending}
                >
                  {t.context.addProcess}
                </Button>
              </div>
            )}
          </Card>
        )}
      </ContextDataGate>
    </>
  );
}
