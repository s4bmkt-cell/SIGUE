'use client';

import { useState } from 'react';
import { ChevronRight, Pencil, Plus } from 'lucide-react';
import { useI18n } from '@/components/providers/i18n-provider';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState } from '@/components/ui/states';

/** Datos mínimos que la lista necesita de un análisis (FODA o PESTEL). */
export interface AnalysisSummary {
  id: string;
  name: string;
  description: string | null;
  period: string | null;
  items: { id: string }[];
}

export interface AnalysisFormValues {
  name: string;
  description?: string;
  period?: string;
}

interface AnalysisListProps {
  analyses: AnalysisSummary[];
  canWrite: boolean;
  /** Etiqueta del botón de alta: «Nuevo FODA», «Nuevo PESTEL»… */
  newLabel: string;
  /** Texto de la unidad que se cuenta en cada tarjeta («elementos», «factores»). */
  unitLabel: string;
  emptyTitle: string;
  emptyHint: string;
  /** Solo se usa para nombrar el formulario cuando hay varios en pantalla. */
  formTitle: string;
  onCreate: (values: AnalysisFormValues) => void;
  onUpdate: (id: string, values: AnalysisFormValues) => void;
  onDelete: (id: string) => void;
  onOpen: (id: string) => void;
  creating?: boolean;
}

/**
 * Lista de FODA o PESTEL de la organización.
 *
 * Un análisis es el contenedor —nombre, periodo y descripción— y cada uno
 * guarda sus propios elementos. La lista es el primer nivel de la sección: al
 * pulsar una tarjeta se abre su matriz y el botón de la cabecera vuelve aquí.
 */
export function AnalysisList({
  analyses,
  canWrite,
  newLabel,
  unitLabel,
  emptyTitle,
  emptyHint,
  formTitle,
  onCreate,
  onUpdate,
  onDelete,
  onOpen,
  creating,
}: AnalysisListProps) {
  const { t } = useI18n();
  const [creatingOpen, setCreatingOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<AnalysisFormValues>({ name: '', description: '', period: '' });

  const resetDraft = () => setDraft({ name: '', description: '', period: '' });

  const startCreate = () => {
    setEditingId(null);
    resetDraft();
    setCreatingOpen((open) => !open);
  };

  const startEdit = (analysis: AnalysisSummary) => {
    setCreatingOpen(false);
    setEditingId(analysis.id);
    setDraft({
      name: analysis.name,
      description: analysis.description ?? '',
      period: analysis.period ?? '',
    });
  };

  const submit = () => {
    const values: AnalysisFormValues = {
      name: draft.name.trim(),
      description: draft.description?.trim() || undefined,
      period: draft.period?.trim() || undefined,
    };
    if (!values.name) return;
    if (editingId) {
      onUpdate(editingId, values);
      setEditingId(null);
    } else {
      onCreate(values);
      setCreatingOpen(false);
    }
    resetDraft();
  };

  const form = (
    <div className="mt-3 grid gap-2 border-t border-line pt-3 sm:grid-cols-[minmax(0,1fr)_140px]">
      <Input
        id="analysisName"
        label={t.context.analysisName}
        placeholder={formTitle}
        value={draft.name}
        onChange={(e) => setDraft((d) => ({ ...d, name: e.target.value }))}
        autoFocus
        onKeyDown={(e) => {
          if (e.key === 'Enter') submit();
        }}
      />
      <Input
        id="analysisPeriod"
        label={t.context.analysisPeriod}
        placeholder={t.context.analysisPeriodHint}
        value={draft.period}
        onChange={(e) => setDraft((d) => ({ ...d, period: e.target.value }))}
      />
      <div className="flex flex-col gap-1.5 sm:col-span-2">
        <label htmlFor="analysisDescription" className="text-sm font-medium text-ink">
          {t.context.analysisDescription}
        </label>
        <textarea
          id="analysisDescription"
          value={draft.description}
          onChange={(e) => setDraft((d) => ({ ...d, description: e.target.value }))}
          rows={2}
          className="rounded-btn border border-line px-3 py-2 text-sm text-ink placeholder:text-ink-muted focus:outline-2 focus:outline-offset-1 focus:outline-info"
        />
      </div>
      <div className="flex gap-2 sm:col-span-2">
        <Button size="sm" onClick={submit} disabled={!draft.name.trim() || creating}>
          {editingId ? t.common.save : t.common.create}
        </Button>
        <Button
          size="sm"
          variant="outline"
          onClick={() => {
            setCreatingOpen(false);
            setEditingId(null);
            resetDraft();
          }}
        >
          {t.common.cancel}
        </Button>
      </div>
    </div>
  );

  return (
    <Card>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div>
          <h3 className="text-[15px] font-bold text-ink">{t.context.analysisListTitle}</h3>
          <p className="text-xs text-ink-muted">{t.context.analysisListHint}</p>
        </div>
        {canWrite && (
          <Button size="sm" variant={creatingOpen ? 'outline' : 'primary'} onClick={startCreate}>
            <Plus className="size-3.5" aria-hidden="true" />
            {newLabel}
          </Button>
        )}
      </div>

      {creatingOpen && form}

      {analyses.length === 0 && !creatingOpen ? (
        <EmptyState
          title={emptyTitle}
          hint={emptyHint}
          action={
            canWrite ? (
              <Button size="sm" onClick={startCreate}>
                {newLabel}
              </Button>
            ) : undefined
          }
        />
      ) : (
        <ul className="grid gap-2 sm:grid-cols-2">
          {analyses.map((analysis) => {
            const editing = editingId === analysis.id;
            return (
              <li
                key={analysis.id}
                className={`rounded-card border p-3 transition-colors ${
                  editing ? 'border-primary/40 bg-primary/5' : 'border-line hover:border-line-strong'
                }`}
              >
                <button
                  type="button"
                  onClick={() => onOpen(analysis.id)}
                  className="group flex w-full items-start gap-2 text-left"
                  aria-label={`${t.context.openAnalysis}: ${analysis.name}`}
                >
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-bold text-ink">{analysis.name}</span>
                      {analysis.period && (
                        <span className="rounded-full bg-page px-2 py-0.5 text-[10.5px] font-semibold text-ink-soft">
                          {analysis.period}
                        </span>
                      )}
                    </span>
                    {analysis.description && (
                      <span className="mt-0.5 block text-xs text-ink-muted">
                        {analysis.description}
                      </span>
                    )}
                    <span className="mt-1 block text-[11px] font-semibold text-ink-soft">
                      {analysis.items.length} {unitLabel}
                    </span>
                  </span>
                  <ChevronRight
                    className="mt-0.5 size-4 shrink-0 text-ink-muted transition-transform group-hover:translate-x-0.5"
                    aria-hidden="true"
                  />
                </button>

                {canWrite && (
                  <div className="mt-2 flex items-center gap-1.5 border-t border-line pt-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-6 px-1.5 text-[10.5px]"
                      onClick={() => (editing ? setEditingId(null) : startEdit(analysis))}
                    >
                      <Pencil className="size-3" aria-hidden="true" />
                      {t.common.edit}
                    </Button>
                    <ConfirmButton
                      confirmLabel={t.common.confirmDelete}
                      onConfirm={() => onDelete(analysis.id)}
                      variant="ghost"
                      className="h-6 px-1.5 text-[10.5px]"
                    >
                      {t.common.delete}
                    </ConfirmButton>
                  </div>
                )}

                {editing && form}
              </li>
            );
          })}
        </ul>
      )}
    </Card>
  );
}
