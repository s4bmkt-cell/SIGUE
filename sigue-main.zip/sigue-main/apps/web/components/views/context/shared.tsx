'use client';

import type { ReactNode } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { api, type ContextData } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { ErrorState, SkeletonCards } from '@/components/ui/states';

export type ContextSectionKey =
  | 'swot'
  | 'pestel'
  | 'parties'
  | 'legal'
  | 'issues'
  | 'processes'
  | 'scope'
  | 'soa';

export const SWOT_TYPES = ['FORTALEZA', 'OPORTUNIDAD', 'DEBILIDAD', 'AMENAZA'] as const;

export const PESTEL_TYPES = [
  'POLITICO',
  'ECONOMICO',
  'SOCIAL',
  'TECNOLOGICO',
  'ECOLOGICO',
  'LEGAL',
] as const;

export const PESTEL_IMPACTS = ['POSITIVO', 'NEGATIVO', 'NEUTRO'] as const;

/** El campo `needs` es JSON libre: el formulario escribe `{ text }` y el seed usa claves. */
export function jsonText(value: unknown): string {
  if (!value) return '';
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map(jsonText).filter(Boolean).join(' · ');
  if (typeof value === 'object' && value !== null) {
    const obj = value as Record<string, unknown>;
    if (typeof obj.text === 'string') return obj.text;
    return Object.values(obj).map(jsonText).filter(Boolean).join(' · ');
  }
  return '';
}

/**
 * Datos del contexto compartidos por la portada y las cinco secciones.
 *
 * Todas usan la misma `queryKey`, así que abrir una tarjeta y volver a la
 * portada no vuelve a pedir el contexto: cada mutación solo lo invalida.
 */
export function useContextData(orgId: string | null) {
  const qc = useQueryClient();
  const query = useQuery({
    queryKey: ['context', orgId],
    queryFn: () => api.context(orgId!),
    enabled: !!orgId,
  });
  const refresh = () => qc.invalidateQueries({ queryKey: ['context', orgId] });
  return { query, refresh };
}

/** Estados de carga y error comunes: cada sección solo pinta su contenido. */
export function ContextDataGate({
  query,
  children,
}: {
  query: ReturnType<typeof useContextData>['query'];
  children: (data: ContextData) => ReactNode;
}) {
  const { t } = useI18n();

  if (query.isLoading) return <SkeletonCards count={2} />;
  if (query.isError) {
    return (
      <ErrorState
        message={(query.error as Error).message}
        onRetry={() => query.refetch()}
        retryLabel={t.common.retry}
      />
    );
  }
  if (!query.data) return null;
  return <>{children(query.data)}</>;
}
