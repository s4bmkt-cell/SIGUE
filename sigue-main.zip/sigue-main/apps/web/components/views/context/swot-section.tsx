'use client';

import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { api, type SwotAnalysis } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { ContextDataGate, SWOT_TYPES, useContextData } from './shared';
import { SectionHeading } from './section-heading';
import { AnalysisList, type AnalysisFormValues } from './analysis-list';

const TONES = {
  FORTALEZA: 'ok',
  OPORTUNIDAD: 'info',
  DEBILIDAD: 'warn',
  AMENAZA: 'danger',
} as const;

/**
 * FODA (cláusula 4.1).
 *
 * La organización puede mantener varios análisis —uno por año, sede o línea de
 * negocio—, así que la sección tiene dos niveles: la lista de FODA y, dentro de
 * uno, su matriz de cuatro cuadrantes. Cada elemento pertenece al análisis
 * abierto y no se mezcla con los de los demás.
 */
export function SwotSection({ orgId, onBack }: { orgId: string; onBack: () => void }) {
  const { t } = useI18n();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const { query, refresh } = useContextData(orgId);

  const [openId, setOpenId] = useState<string | null>(null);
  const [type, setType] = useState<string>('FORTALEZA');
  const [text, setText] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');

  const createAnalysis = useMutation({
    mutationFn: (values: AnalysisFormValues) => api.createSwotAnalysis(orgId, values),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
  });

  const updateAnalysis = useMutation({
    mutationFn: ({ id, values }: { id: string; values: AnalysisFormValues }) =>
      api.updateSwotAnalysis(orgId, id, values),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
  });

  const removeAnalysis = useMutation({
    mutationFn: (id: string) => api.deleteSwotAnalysis(orgId, id),
    onSuccess: () => {
      refresh();
      // Si se borra el análisis abierto, la sección vuelve a la lista.
      setOpenId(null);
      toast.success(t.common.deleted);
    },
  });

  const add = useMutation({
    mutationFn: () => api.addSwot(orgId, openId!, type, text),
    onSuccess: () => {
      refresh();
      setText('');
      toast.success(t.common.saved);
    },
  });

  const edit = useMutation({
    mutationFn: ({ id, value }: { id: string; value: string }) =>
      api.updateSwot(orgId, id, { text: value }),
    onSuccess: () => {
      refresh();
      setEditingId(null);
      setEditingText('');
      toast.success(t.common.saved);
    },
  });

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteSwot(orgId, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const groups = {
    FORTALEZA: t.context.strengths,
    OPORTUNIDAD: t.context.opportunities,
    DEBILIDAD: t.context.weaknesses,
    AMENAZA: t.context.threats,
  };

  return (
    <ContextDataGate query={query}>
      {(c) => {
        // El análisis abierto se deriva de los datos: si ya no existe (lo borró
        // otro usuario) la sección cae en la lista en lugar de quedarse vacía.
        const current: SwotAnalysis | undefined = c.swotAnalyses.find((a) => a.id === openId);

        if (!current) {
          return (
            <>
              <SectionHeading
                title={t.context.swot}
                subtitle={t.context.swotListHint}
                hint={!canWrite ? t.common.readOnlyHint : undefined}
                onBack={onBack}
              />
              <AnalysisList
                analyses={c.swotAnalyses}
                canWrite={canWrite}
                newLabel={t.context.swotNew}
                unitLabel={t.context.swotItems}
                emptyTitle={t.context.noSwotAnalyses}
                emptyHint={t.context.noSwotAnalysesHint}
                formTitle={t.context.swotNew}
                onCreate={(values) => createAnalysis.mutate(values)}
                onUpdate={(id, values) => updateAnalysis.mutate({ id, values })}
                onDelete={(id) => removeAnalysis.mutate(id)}
                onOpen={(id) => {
                  setOpenId(id);
                  setType('FORTALEZA');
                  setText('');
                  setEditingId(null);
                }}
                creating={createAnalysis.isPending}
              />
            </>
          );
        }

        return (
          <>
            <SectionHeading
              title={current.name}
              subtitle={current.description ?? t.context.swotHint}
              hint={!canWrite ? t.common.readOnlyHint : undefined}
              onBack={onBack}
              parent={{ label: t.context.swot, onClick: () => setOpenId(null) }}
              backLabel={t.context.backToSwotList}
              backAction={() => setOpenId(null)}
            />
            <Card>
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <Badge tone="muted" dot={false}>
                  {current.period ?? t.context.analysisNoPeriod}
                </Badge>
                <span className="text-xs text-ink-muted">
                  {current.items.length} {t.context.swotItems}
                </span>
              </div>
              <div className="grid md:grid-cols-2 gap-3">
                {SWOT_TYPES.map((swotType) => {
                  const items = current.items.filter((s) => s.type === swotType);
                  return (
                    <div key={swotType} className="border border-line rounded-btn p-3">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge tone={TONES[swotType]}>{groups[swotType]}</Badge>
                        <span className="text-xs text-ink-muted ml-auto">{items.length}</span>
                      </div>
                      {items.length === 0 ? (
                        <p className="text-xs text-ink-muted">{t.context.noSwot}</p>
                      ) : (
                        <ul className="space-y-1.5">
                          {items.map((item) =>
                            editingId === item.id ? (
                              <li key={item.id} className="flex gap-1.5">
                                <Input
                                  value={editingText}
                                  onChange={(e) => setEditingText(e.target.value)}
                                  className="h-7 text-xs flex-1"
                                  autoFocus
                                />
                                <Button
                                  size="sm"
                                  className="h-7 px-2 text-[11px]"
                                  onClick={() => edit.mutate({ id: item.id, value: editingText })}
                                  disabled={!editingText || edit.isPending}
                                >
                                  {t.common.save}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-7 px-1.5 text-[11px]"
                                  onClick={() => setEditingId(null)}
                                >
                                  {t.common.cancel}
                                </Button>
                              </li>
                            ) : (
                              <li
                                key={item.id}
                                className="text-xs text-ink-soft flex items-start gap-1.5 group"
                              >
                                <span className="flex-1">{item.text}</span>
                                {canWrite && (
                                  <span className="flex gap-0.5 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                                    <button
                                      className="text-[10px] text-info hover:underline"
                                      onClick={() => {
                                        setEditingId(item.id);
                                        setEditingText(item.text);
                                      }}
                                    >
                                      {t.context.edit}
                                    </button>
                                    <ConfirmButton
                                      confirmLabel={t.common.confirmDelete}
                                      onConfirm={() => remove.mutate(item.id)}
                                      variant="ghost"
                                      className="h-5 px-1 text-[10px]"
                                    >
                                      {t.common.delete}
                                    </ConfirmButton>
                                  </span>
                                )}
                              </li>
                            ),
                          )}
                        </ul>
                      )}
                    </div>
                  );
                })}
              </div>
              {canWrite && (
                <div className="flex gap-2 mt-3">
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    className="text-xs border border-line rounded-btn px-2 py-2 bg-white"
                    aria-label={t.context.swot}
                  >
                    {SWOT_TYPES.map((s) => (
                      <option key={s} value={s}>
                        {groups[s]}
                      </option>
                    ))}
                  </select>
                  <Input
                    placeholder={t.context.addSwot}
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    className="flex-1"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && text) add.mutate();
                    }}
                  />
                  <Button size="sm" onClick={() => add.mutate()} disabled={!text || add.isPending}>
                    {t.context.add}
                  </Button>
                </div>
              )}
            </Card>
          </>
        );
      }}
    </ContextDataGate>
  );
}
