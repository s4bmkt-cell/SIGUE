'use client';

import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState } from '@/components/ui/states';
import { ContextDataGate, useContextData } from './shared';
import { SectionHeading } from './section-heading';

export function LegalSection({ orgId, onBack }: { orgId: string; onBack: () => void }) {
  const { t } = useI18n();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const { query, refresh } = useContextData(orgId);

  const [draft, setDraft] = useState({ source: '', reference: '', requirement: '' });

  const add = useMutation({
    mutationFn: () => api.addLegal(orgId, draft),
    onSuccess: () => {
      refresh();
      setDraft({ source: '', reference: '', requirement: '' });
      toast.success(t.common.saved);
    },
  });

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteLegal(orgId, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  return (
    <>
      <SectionHeading
        title={t.context.legal}
        subtitle={t.context.legalHint}
        hint={!canWrite ? t.common.readOnlyHint : undefined}
        onBack={onBack}
      />
      <ContextDataGate query={query}>
        {(c) => (
          <Card>
            {c.legal.length === 0 ? (
              <EmptyState title={t.context.noLegal} />
            ) : (
              <div className="space-y-2">
                {c.legal.map((l) => (
                  <div key={l.id} className="border border-line rounded-btn px-3 py-2">
                    <div className="flex items-center gap-2">
                      <Badge tone="info" dot={false}>
                        {l.source}
                      </Badge>
                      <span className="text-sm font-semibold">{l.reference}</span>
                      {canWrite && (
                        <ConfirmButton
                          confirmLabel={t.common.confirmDelete}
                          onConfirm={() => remove.mutate(l.id)}
                          variant="ghost"
                          className="h-6 px-1.5 text-[11px] ml-auto"
                        >
                          {t.common.delete}
                        </ConfirmButton>
                      )}
                    </div>
                    <div className="text-xs text-ink-soft mt-1">{l.requirement}</div>
                  </div>
                ))}
              </div>
            )}
            {canWrite && (
              <div className="space-y-2 mt-3 pt-3 border-t border-line">
                <div className="grid sm:grid-cols-2 gap-2">
                  <Input
                    placeholder={t.context.source}
                    value={draft.source}
                    onChange={(e) => setDraft({ ...draft, source: e.target.value })}
                  />
                  <Input
                    placeholder={t.context.reference}
                    value={draft.reference}
                    onChange={(e) => setDraft({ ...draft, reference: e.target.value })}
                  />
                </div>
                <Input
                  placeholder={t.context.requirement}
                  value={draft.requirement}
                  onChange={(e) => setDraft({ ...draft, requirement: e.target.value })}
                />
                <Button
                  size="sm"
                  onClick={() => add.mutate()}
                  disabled={
                    !draft.source || !draft.reference || !draft.requirement || add.isPending
                  }
                >
                  {t.context.addLegal}
                </Button>
              </div>
            )}
          </Card>
        )}
      </ContextDataGate>
    </>
  );
}
