'use client';

import { Button } from '@/components/ui/button';
import { useI18n } from '@/components/providers/i18n-provider';

/**
 * Cabecera de una sección de contexto.
 *
 * La miga «Contexto / Sección» más el botón de regreso sustituyen a un menú
 * lateral expandido: la barra sigue marcando «Contexto» y volver es un clic.
 *
 * Con `parent` la cabecera gana un nivel: FODA y PESTEL abren la lista de
 * análisis y luego uno de ellos, así que el detalle muestra
 * «Contexto / FODA / FODA 2026» y el botón regresa a la lista.
 */
export function SectionHeading({
  title,
  subtitle,
  hint,
  onBack,
  parent,
  backLabel,
  backAction,
}: {
  title: string;
  subtitle?: string;
  hint?: string;
  onBack: () => void;
  parent?: { label: string; onClick: () => void };
  backLabel?: string;
  /** Destino del botón grande; por defecto sale de la sección (`onBack`). */
  backAction?: () => void;
}) {
  const { t } = useI18n();
  const goBack = backAction ?? onBack;
  return (
    <div className="mb-4">
      <nav aria-label={t.common.breadcrumb} className="mb-2 flex items-center gap-1.5 text-xs">
        <button type="button" onClick={onBack} className="font-semibold text-primary hover:underline">
          {t.context.navLabel}
        </button>
        {parent && (
          <>
            <span className="text-ink-muted" aria-hidden="true">
              /
            </span>
            <button
              type="button"
              onClick={parent.onClick}
              className="font-semibold text-primary hover:underline"
            >
              {parent.label}
            </button>
          </>
        )}
        <span className="text-ink-muted" aria-hidden="true">
          /
        </span>
        <span className="text-ink-soft">{title}</span>
      </nav>
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{title}</h1>
          {subtitle && <p className="text-sm text-ink-soft mt-1">{subtitle}</p>}
        </div>
        <Button variant="outline" size="sm" onClick={goBack}>
          ← {backLabel ?? t.context.backTo}
        </Button>
      </div>
      {hint && <p className="text-xs text-ink-muted mt-2">{hint}</p>}
    </div>
  );
}
