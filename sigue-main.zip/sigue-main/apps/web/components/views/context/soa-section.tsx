'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';
import { SectionHeading } from './section-heading';

const STATUS_TONE = {
  IMPLEMENTED: 'ok',
  PLANNED: 'warn',
  NOT_IMPLEMENTED: 'muted',
} as const;

/**
 * Declaración de Aplicabilidad (ISO/IEC 27001 Anexo A y ISO/IEC 42001 Anexo A).
 *
 * La SoA no es exclusiva de seguridad de la información: cualquier norma con
 * Anexo A exige justificar por qué cada control aplica o se excluye. Por eso la
 * sección ofrece un selector de norma y consulta `isms/soa/by-standard`, que
 * devuelve las filas con su norma. Se comparte la clave `['isms', orgId]` con la
 * vista de seguridad para que el resumen por norma no se pida dos veces.
 */
export function SoaSection({ orgId, onBack }: { orgId: string; onBack: () => void }) {
  const { t } = useI18n();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const summaryQuery = useQuery({
    queryKey: ['isms', orgId],
    queryFn: () => api.isms(orgId),
  });

  const standards = summaryQuery.data?.soaByStandard ?? [];
  const [pickedId, setPickedId] = useState<string | null>(null);

  // La norma elegida se deriva, no se sincroniza con un efecto: si aún no hay
  // selección —o el id guardado ya no existe— se usa la primera declaración.
  const standardId = standards.some((s) => s.id === pickedId)
    ? pickedId
    : (standards[0]?.id ?? null);

  const rowsQuery = useQuery({
    queryKey: ['soa-by-standard', orgId, standardId],
    queryFn: () => api.soaByStandard(orgId, standardId!),
    enabled: !!standardId,
  });

  const [editingJustification, setEditingJustification] = useState<string | null>(null);
  const [justificationDraft, setJustificationDraft] = useState('');

  const update = useMutation({
    mutationFn: ({
      id,
      data,
    }: {
      id: string;
      data: { applicable?: boolean; implementationStatus?: string; justification?: string };
    }) => api.updateSoa(orgId, id, data),
    onSuccess: () => {
      // El avance por norma vive en el panorama del SGSI y las filas en su
      // propia clave: ambas se refrescan tras cada cambio.
      qc.invalidateQueries({ queryKey: ['isms', orgId] });
      qc.invalidateQueries({ queryKey: ['soa-by-standard', orgId] });
      qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
      toast.success(t.common.saved);
      setEditingJustification(null);
      setJustificationDraft('');
    },
    onError: (err: unknown) =>
      toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const selected = standards.find((s) => s.id === standardId);
  const rows = rowsQuery.data ?? [];
  const sinJustificar = rows.filter((r) => !r.applicable && !r.justification?.trim()).length;

  const startJustification = (id: string, current: string | null) => {
    setEditingJustification(editingJustification === id ? null : id);
    setJustificationDraft(current ?? '');
  };

  return (
    <>
      <SectionHeading
        title={t.context.soaTitle}
        subtitle={t.context.soaHint}
        hint={!canWrite ? t.common.readOnlyHint : undefined}
        onBack={onBack}
      />

      {summaryQuery.isLoading && <SkeletonCards count={2} />}

      {summaryQuery.isError && (
        <ErrorState
          message={(summaryQuery.error as Error).message}
          onRetry={() => summaryQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {summaryQuery.isSuccess && standards.length === 0 && (
        <Card>
          <EmptyState title={t.context.soaNoData} />
        </Card>
      )}

      {summaryQuery.isSuccess && standards.length > 0 && (
        <div className="space-y-4">
          <div
            role="tablist"
            aria-label={t.context.soaStandard}
            className="flex flex-wrap gap-2"
          >
            {standards.map((s) => {
              const active = s.id === standardId;
              return (
                <button
                  key={s.id}
                  type="button"
                  role="tab"
                  aria-selected={active}
                  onClick={() => setPickedId(s.id)}
                  className={`flex items-center gap-2 rounded-btn border px-3 py-2 text-left transition-colors ${
                    active
                      ? 'border-primary bg-primary text-white shadow-[0_6px_16px_-8px_rgba(47,102,235,.8)]'
                      : 'border-line bg-white text-ink hover:border-line-strong'
                  }`}
                >
                  <span className="text-[13px] font-semibold">
                    {s.code} · {s.edition}
                  </span>
                  <span
                    className={`rounded-full px-2 py-0.5 text-[11px] font-bold tabular-nums ${
                      active ? 'bg-white/20' : 'bg-page text-ink-soft'
                    }`}
                  >
                    {s.progress}%
                  </span>
                </button>
              );
            })}
          </div>

          <Card
            title={`${t.context.soaTitle} · ${selected?.code ?? ''}`}
            action={
              <span className="text-xs font-semibold text-ink-soft">
                {selected
                  ? t.context.soaCoverage(
                      selected.implemented,
                      selected.applicable,
                      selected.total,
                    )
                  : null}
              </span>
            }
          >
            {selected && (
              <div className="mb-3">
                <div
                  className="h-1.5 w-full overflow-hidden rounded-full bg-page"
                  role="progressbar"
                  aria-valuenow={selected.progress}
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-label={t.isms.soaProgress}
                >
                  <div
                    className="h-full rounded-full bg-primary transition-[width] duration-300"
                    style={{ width: `${selected.progress}%` }}
                  />
                </div>
                {sinJustificar > 0 && (
                  <p className="mt-2 text-xs text-warning">
                    {t.context.soaMissingJustification(sinJustificar)}
                  </p>
                )}
              </div>
            )}

            {rowsQuery.isLoading && <SkeletonCards count={1} />}

            {rowsQuery.isError && (
              <ErrorState
                message={(rowsQuery.error as Error).message}
                onRetry={() => rowsQuery.refetch()}
                retryLabel={t.common.retry}
              />
            )}

            {rowsQuery.isSuccess && rows.length === 0 && (
              <EmptyState title={t.context.soaNoData} />
            )}

            {rows.length > 0 && (
              <div className="-mx-1 overflow-x-auto">
                <table className="w-full text-[13px]">
                  <thead>
                    <tr className="border-b-2 border-line-strong text-left text-[10.5px] uppercase tracking-wider text-ink-muted">
                      <th className="w-20 py-2">{t.isms.controlCode}</th>
                      <th>{t.isms.controlName}</th>
                      <th className="w-28">{t.isms.applicable}</th>
                      <th className="w-40">{t.isms.implementation}</th>
                      <th className="w-16 text-right">{t.isms.status}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {rows.map((c) => {
                      const editing = editingJustification === c.id;
                      return (
                        <tr key={c.id} className="border-b border-line align-top">
                          <td className="py-2 font-mono text-xs">{c.controlCode}</td>
                          <td className="py-2">
                            <div>{c.controlName}</div>
                            {c.justification && (
                              <div className="text-[10.5px] text-ink-muted">
                                {c.justification}
                              </div>
                            )}
                            {!c.applicable && !c.justification && (
                              <div className="text-[10.5px] text-warning">
                                {t.context.soaExcludedNoJustification}
                              </div>
                            )}
                            {editing && (
                              <div className="mt-1.5 flex flex-col gap-1.5">
                                <textarea
                                  value={justificationDraft}
                                  onChange={(e) => setJustificationDraft(e.target.value)}
                                  rows={2}
                                  placeholder={t.context.soaExcludedWhy}
                                  aria-label={`${t.isms.justification} ${c.controlCode}`}
                                  className="w-full rounded-btn border border-line px-2 py-1.5 text-xs"
                                />
                                <div className="flex gap-2">
                                  <Button
                                    size="sm"
                                    disabled={update.isPending || !justificationDraft.trim()}
                                    onClick={() =>
                                      update.mutate({
                                        id: c.id,
                                        data: { justification: justificationDraft.trim() },
                                      })
                                    }
                                  >
                                    {update.isPending ? t.common.saving : t.common.save}
                                  </Button>
                                  <Button
                                    size="sm"
                                    variant="outline"
                                    onClick={() => setEditingJustification(null)}
                                  >
                                    {t.common.cancel}
                                  </Button>
                                </div>
                              </div>
                            )}
                          </td>
                          <td className="py-2">
                            <div className="flex flex-col gap-1">
                              <select
                                value={c.applicable ? 'SI' : 'NO'}
                                onChange={(e) =>
                                  update.mutate({
                                    id: c.id,
                                    data: { applicable: e.target.value === 'SI' },
                                  })
                                }
                                disabled={!canWrite}
                                className="rounded-btn border border-line bg-white px-2 py-1 text-xs"
                                aria-label={`${t.isms.applicable} ${c.controlCode}`}
                              >
                                <option value="SI">{t.isms.applicable}</option>
                                <option value="NO">{t.isms.notApplicable}</option>
                              </select>
                              {canWrite && (
                                <button
                                  type="button"
                                  onClick={() => startJustification(c.id, c.justification)}
                                  className="text-left text-[10.5px] font-semibold text-primary hover:underline"
                                >
                                  {editing ? t.common.cancel : t.context.soaJustify}
                                </button>
                              )}
                            </div>
                          </td>
                          <td className="py-2">
                            <select
                              value={c.implementationStatus}
                              onChange={(e) =>
                                update.mutate({
                                  id: c.id,
                                  data: { implementationStatus: e.target.value },
                                })
                              }
                              disabled={!c.applicable || !canWrite}
                              className="rounded-btn border border-line bg-white px-2 py-1 text-xs"
                              aria-label={`${t.isms.implementation} ${c.controlCode}`}
                            >
                              <option value="NOT_IMPLEMENTED">{t.isms.notImplemented}</option>
                              <option value="PLANNED">{t.isms.planned}</option>
                              <option value="IMPLEMENTED">{t.isms.implemented}</option>
                            </select>
                          </td>
                          <td className="py-2 text-right">
                            <Badge
                              tone={
                                c.applicable
                                  ? STATUS_TONE[
                                      c.implementationStatus as keyof typeof STATUS_TONE
                                    ] ?? 'muted'
                                  : 'muted'
                              }
                              dot={false}
                            >
                              {c.applicable
                                ? c.implementationStatus === 'IMPLEMENTED'
                                  ? '✓'
                                  : '·'
                                : '—'}
                            </Badge>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </Card>
        </div>
      )}
    </>
  );
}
