'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';
import { SectionHeading } from './section-heading';

/**
 * Alcance del sistema de gestión (ISO 4.3).
 *
 * No tiene modelo propio: es el `scopeText` de `OrgStandard`. Por eso consulta
 * la misma `queryKey` que la vista de Normas y requisitos —cualquier edición en
 * una pantalla invalida la caché compartida y la otra se refresca sola— y
 * escribe con el mismo endpoint, de modo que no existan dos verdades.
 */
export function ScopeSection({ orgId, onBack }: { orgId: string; onBack: () => void }) {
  const { t } = useI18n();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  // Misma clave que `standards-view.tsx`: portada, sección y normas comparten
  // una sola entrada de caché.
  const query = useQuery({
    queryKey: ['standards', orgId],
    queryFn: () => api.standards(orgId),
  });

  const [editingFor, setEditingFor] = useState<string | null>(null);
  const [draft, setDraft] = useState('');

  const save = useMutation({
    mutationFn: ({ standardId, scopeText }: { standardId: string; scopeText: string }) =>
      api.updateStandardScope(orgId, standardId, scopeText),
    onSuccess: () => {
      // Las tarjetas de la portada y el lateral de Normas leen la misma clave;
      // también se refresca el resumen del tablero, que muestra el avance.
      qc.invalidateQueries({ queryKey: ['standards', orgId] });
      qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
      toast.success(t.common.saved);
      setEditingFor(null);
      setDraft('');
    },
  });

  const active = query.data?.active ?? [];
  const conAlcance = active.filter((a) => a.scopeText?.trim()).length;

  const startEdit = (standardId: string, current: string | null) => {
    setEditingFor(editingFor === standardId ? null : standardId);
    setDraft(current ?? '');
  };

  return (
    <>
      <SectionHeading
        title={t.context.scope}
        subtitle={t.context.scopeHint}
        hint={!canWrite ? t.common.readOnlyHint : undefined}
        onBack={onBack}
      />

      {query.isLoading && <SkeletonCards count={2} />}

      {query.isError && (
        <ErrorState
          message={(query.error as Error).message}
          onRetry={() => query.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {query.isSuccess && (
        <Card
          title={t.context.scope}
          action={
            <span className="text-xs font-semibold text-ink-soft">
              {t.context.scopeCoverage(conAlcance, active.length)}
            </span>
          }
        >
          <p className="mb-3 text-xs text-ink-muted">{t.context.scopeSync}</p>

          {active.length === 0 ? (
            <EmptyState title={t.context.scopeNoStandards} />
          ) : (
            <ul className="space-y-2">
              {active.map((a) => {
                const declarado = !!a.scopeText?.trim();
                const editing = editingFor === a.standard.id;
                return (
                  <li
                    key={a.id}
                    className="rounded-btn border border-line px-3 py-2.5 transition-colors hover:border-line-strong"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="text-sm font-semibold text-ink">
                        {a.standard.code} · {a.standard.edition}
                      </span>
                      <Badge tone={declarado ? 'ok' : 'warn'} dot={false}>
                        {declarado ? t.context.scopeDefined : t.context.scopeMissing}
                      </Badge>
                      {canWrite && (
                        <button
                          type="button"
                          onClick={() => startEdit(a.standard.id, a.scopeText)}
                          className="ml-auto text-[11px] font-semibold text-primary hover:underline"
                        >
                          {editing
                            ? t.common.cancel
                            : declarado
                              ? t.context.scopeEdit
                              : t.context.scopeDeclare}
                        </button>
                      )}
                    </div>

                    {editing ? (
                      <div className="mt-2 space-y-2">
                        <textarea
                          value={draft}
                          onChange={(e) => setDraft(e.target.value)}
                          rows={3}
                          placeholder={t.standards.scopePlaceholder}
                          aria-label={`${t.standards.scopeLabel} · ${a.standard.code}`}
                          className="w-full rounded-btn border border-line px-2 py-1.5 text-xs"
                        />
                        <Button
                          size="sm"
                          disabled={save.isPending || !draft.trim()}
                          onClick={() =>
                            save.mutate({ standardId: a.standard.id, scopeText: draft.trim() })
                          }
                        >
                          {save.isPending ? t.common.saving : t.common.save}
                        </Button>
                      </div>
                    ) : (
                      <p
                        className={`mt-1 text-xs leading-relaxed ${
                          declarado ? 'text-ink-soft' : 'text-warning'
                        }`}
                      >
                        {a.scopeText?.trim() || t.standards.noScope}
                      </p>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </Card>
      )}
    </>
  );
}
