'use client';

import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState } from '@/components/ui/states';
import { ContextDataGate, useContextData } from './shared';
import { SectionHeading } from './section-heading';

export function IssuesSection({ orgId, onBack }: { orgId: string; onBack: () => void }) {
  const { t } = useI18n();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const { query, refresh } = useContextData(orgId);

  const [text, setText] = useState('');
  const [isInternal, setIsInternal] = useState(true);

  const add = useMutation({
    mutationFn: () => api.addIssue(orgId, { isInternal, text }),
    onSuccess: () => {
      refresh();
      setText('');
      toast.success(t.common.saved);
    },
  });

  const remove = useMutation({
    mutationFn: (id: string) => api.deleteIssue(orgId, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  return (
    <>
      <SectionHeading
        title={t.context.issues}
        subtitle={t.context.issuesHint}
        hint={!canWrite ? t.common.readOnlyHint : undefined}
        onBack={onBack}
      />
      <ContextDataGate query={query}>
        {(c) => (
          <Card>
            {c.issues.length === 0 ? (
              <EmptyState title={t.context.noIssues} />
            ) : (
              <ul className="divide-y divide-line">
                {c.issues.map((i) => (
                  <li key={i.id} className="flex items-center gap-3 py-2 text-sm">
                    <Badge tone={i.isInternal ? 'info' : 'warn'}>
                      {i.isInternal ? t.context.internal : t.context.external}
                    </Badge>
                    <span className="flex-1 text-ink-soft">{i.text}</span>
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        onConfirm={() => remove.mutate(i.id)}
                        variant="ghost"
                        className="h-6 px-1.5 text-[11px]"
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    )}
                  </li>
                ))}
              </ul>
            )}
            {canWrite && (
              <div className="flex gap-2 mt-3 pt-3 border-t border-line flex-wrap">
                <select
                  value={isInternal ? 'internal' : 'external'}
                  onChange={(e) => setIsInternal(e.target.value === 'internal')}
                  className="text-xs border border-line rounded-btn px-2 py-2 bg-white"
                  aria-label={t.context.addIssue}
                >
                  <option value="internal">{t.context.internal}</option>
                  <option value="external">{t.context.external}</option>
                </select>
                <Input
                  placeholder={t.context.addIssue}
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  className="flex-1 min-w-[200px]"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && text) add.mutate();
                  }}
                />
                <Button size="sm" onClick={() => add.mutate()} disabled={!text || add.isPending}>
                  {t.context.add}
                </Button>
              </div>
            )}
          </Card>
        )}
      </ContextDataGate>
    </>
  );
}
