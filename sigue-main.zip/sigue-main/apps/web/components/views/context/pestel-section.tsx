'use client';

import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { api, type PestelAnalysis } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { ContextDataGate, PESTEL_IMPACTS, PESTEL_TYPES, useContextData } from './shared';
import { SectionHeading } from './section-heading';
import { AnalysisList, type AnalysisFormValues } from './analysis-list';

/**
 * Análisis PESTEL (cláusula 4.1).
 *
 * Igual que el FODA, admite varios análisis por organización: la sección abre
 * con la lista y cada análisis tiene sus seis dimensiones del entorno con su
 * lectura de impacto. Los factores de un análisis nunca se mezclan con los de
 * otro.
 */
export function PestelSection({ orgId, onBack }: { orgId: string; onBack: () => void }) {
  const { t } = useI18n();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const { query, refresh } = useContextData(orgId);

  const [openId, setOpenId] = useState<string | null>(null);
  const [type, setType] = useState<string>('POLITICO');
  const [impact, setImpact] = useState<string>('NEUTRO');
  const [text, setText] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingText, setEditingText] = useState('');

  const createAnalysis = useMutation({
    mutationFn: (values: AnalysisFormValues) => api.createPestelAnalysis(orgId, values),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
  });

  const updateAnalysis = useMutation({
    mutationFn: ({ id, values }: { id: string; values: AnalysisFormValues }) =>
      api.updatePestelAnalysis(orgId, id, values),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
  });

  const removeAnalysis = useMutation({
    mutationFn: (id: string) => api.deletePestelAnalysis(orgId, id),
    onSuccess: () => {
      refresh();
      // Si se borra el análisis abierto, la sección vuelve a la lista.
      setOpenId(null);
      toast.success(t.common.deleted);
    },
  });

  const add = useMutation({
    mutationFn: () => api.addPestel(orgId, { analysisId: openId!, type, impact, text }),
    onSuccess: () => {
      refresh();
      setText('');
      toast.success(t.common.saved);
    },
  });

  const edit = useMutation({
    mutationFn: ({ id, value }: { id: string; value: string }) =>
      api.updatePestel(orgId, id, { text: value }),
    onSuccess: () => {
      refresh();
      setEditingId(null);
      setEditingText('');
      toast.success(t.common.saved);
    },
  });

  const remove = useMutation({
    mutationFn: (id: string) => api.deletePestel(orgId, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const dimensions: Record<(typeof PESTEL_TYPES)[number], { label: string; hint: string }> = {
    POLITICO: { label: t.context.pestelPolitical, hint: t.context.pestelPoliticalHint },
    ECONOMICO: { label: t.context.pestelEconomic, hint: t.context.pestelEconomicHint },
    SOCIAL: { label: t.context.pestelSocial, hint: t.context.pestelSocialHint },
    TECNOLOGICO: { label: t.context.pestelTechnological, hint: t.context.pestelTechnologicalHint },
    ECOLOGICO: { label: t.context.pestelEnvironmental, hint: t.context.pestelEnvironmentalHint },
    LEGAL: { label: t.context.pestelLegal, hint: t.context.pestelLegalHint },
  };

  const impactTone = (value: string) =>
    value === 'POSITIVO' ? 'ok' : value === 'NEGATIVO' ? 'danger' : 'muted';
  const impactLabel = (value: string) =>
    value === 'POSITIVO'
      ? t.context.pestelPositive
      : value === 'NEGATIVO'
        ? t.context.pestelNegative
        : t.context.pestelNeutral;

  return (
    <ContextDataGate query={query}>
      {(c) => {
        // El análisis abierto se deriva de los datos: si ya no existe la
        // sección cae en la lista en lugar de quedarse en blanco.
        const current: PestelAnalysis | undefined = c.pestelAnalyses.find((a) => a.id === openId);

        if (!current) {
          return (
            <>
              <SectionHeading
                title={t.context.pestel}
                subtitle={t.context.pestelListHint}
                hint={!canWrite ? t.common.readOnlyHint : undefined}
                onBack={onBack}
              />
              <AnalysisList
                analyses={c.pestelAnalyses}
                canWrite={canWrite}
                newLabel={t.context.pestelNew}
                unitLabel={t.context.pestelItems}
                emptyTitle={t.context.noPestelAnalyses}
                emptyHint={t.context.noPestelAnalysesHint}
                formTitle={t.context.pestelNew}
                onCreate={(values) => createAnalysis.mutate(values)}
                onUpdate={(id, values) => updateAnalysis.mutate({ id, values })}
                onDelete={(id) => removeAnalysis.mutate(id)}
                onOpen={(id) => {
                  setOpenId(id);
                  setType('POLITICO');
                  setImpact('NEUTRO');
                  setText('');
                  setEditingId(null);
                }}
                creating={createAnalysis.isPending}
              />
            </>
          );
        }

        return (
          <>
            <SectionHeading
              title={current.name}
              subtitle={current.description ?? t.context.pestelHint}
              hint={!canWrite ? t.common.readOnlyHint : undefined}
              onBack={onBack}
              parent={{ label: t.context.pestel, onClick: () => setOpenId(null) }}
              backLabel={t.context.backToPestelList}
              backAction={() => setOpenId(null)}
            />
            <Card>
              <div className="mb-3 flex flex-wrap items-center gap-2">
                <Badge tone="muted" dot={false}>
                  {current.period ?? t.context.analysisNoPeriod}
                </Badge>
                <span className="text-xs text-ink-muted">
                  {current.items.length} {t.context.pestelItems}
                </span>
              </div>
              <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-3">
                {PESTEL_TYPES.map((dimension) => {
                  const items = current.items.filter((p) => p.type === dimension);
                  return (
                    <div key={dimension} className="border border-line rounded-btn p-3">
                      <div className="flex items-start gap-2 mb-2">
                        <div className="min-w-0 flex-1">
                          <div className="text-xs font-bold text-ink">
                            {dimensions[dimension].label}
                          </div>
                          <div className="text-[10px] text-ink-muted leading-tight">
                            {dimensions[dimension].hint}
                          </div>
                        </div>
                        <span className="text-xs text-ink-muted">{items.length}</span>
                      </div>
                      {items.length === 0 ? (
                        <p className="text-xs text-ink-muted">{t.context.noPestel}</p>
                      ) : (
                        <ul className="space-y-1.5">
                          {items.map((item) =>
                            editingId === item.id ? (
                              <li key={item.id} className="flex gap-1.5">
                                <Input
                                  value={editingText}
                                  onChange={(e) => setEditingText(e.target.value)}
                                  className="h-7 text-xs flex-1"
                                  autoFocus
                                />
                                <Button
                                  size="sm"
                                  className="h-7 px-2 text-[11px]"
                                  onClick={() => edit.mutate({ id: item.id, value: editingText })}
                                  disabled={!editingText || edit.isPending}
                                >
                                  {t.common.save}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="h-7 px-1.5 text-[11px]"
                                  onClick={() => setEditingId(null)}
                                >
                                  {t.common.cancel}
                                </Button>
                              </li>
                            ) : (
                              <li
                                key={item.id}
                                className="text-xs text-ink-soft flex items-start gap-1.5 group"
                              >
                                <span className="flex-1">
                                  {item.text}
                                  <Badge
                                    tone={impactTone(item.impact)}
                                    dot={false}
                                    className="ml-1.5 align-middle text-[10px]"
                                  >
                                    {impactLabel(item.impact)}
                                  </Badge>
                                </span>
                                {canWrite && (
                                  <span className="flex gap-0.5 opacity-0 group-hover:opacity-100 focus-within:opacity-100 transition-opacity">
                                    <button
                                      className="text-[10px] text-info hover:underline"
                                      onClick={() => {
                                        setEditingId(item.id);
                                        setEditingText(item.text);
                                      }}
                                    >
                                      {t.context.edit}
                                    </button>
                                    <ConfirmButton
                                      confirmLabel={t.common.confirmDelete}
                                      onConfirm={() => remove.mutate(item.id)}
                                      variant="ghost"
                                      className="h-5 px-1 text-[10px]"
                                    >
                                      {t.common.delete}
                                    </ConfirmButton>
                                  </span>
                                )}
                              </li>
                            ),
                          )}
                        </ul>
                      )}
                    </div>
                  );
                })}
              </div>
              {canWrite && (
                <div className="flex flex-wrap gap-2 mt-3 pt-3 border-t border-line">
                  <select
                    value={type}
                    onChange={(e) => setType(e.target.value)}
                    className="text-xs border border-line rounded-btn px-2 py-2 bg-white"
                    aria-label={t.context.pestelDimension}
                  >
                    {PESTEL_TYPES.map((dimension) => (
                      <option key={dimension} value={dimension}>
                        {dimensions[dimension].label}
                      </option>
                    ))}
                  </select>
                  <select
                    value={impact}
                    onChange={(e) => setImpact(e.target.value)}
                    className="text-xs border border-line rounded-btn px-2 py-2 bg-white"
                    aria-label={t.context.pestelImpact}
                  >
                    {PESTEL_IMPACTS.map((value) => (
                      <option key={value} value={value}>
                        {impactLabel(value)}
                      </option>
                    ))}
                  </select>
                  <Input
                    placeholder={t.context.addPestel}
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                    className="flex-1 min-w-[200px]"
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && text) add.mutate();
                    }}
                  />
                  <Button size="sm" onClick={() => add.mutate()} disabled={!text || add.isPending}>
                    {t.context.add}
                  </Button>
                </div>
              )}
            </Card>
          </>
        );
      }}
    </ContextDataGate>
  );
}
