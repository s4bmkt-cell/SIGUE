'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import {
  Archive,
  CircleCheck,
  Eye,
  FileText,
  Paperclip,
  Pencil,
  Plus,
  Send,
  Signature,
  Trash,
} from 'lucide-react';
import { api, type DocumentFilters, type DocumentItem } from '@/lib/api/client';
import { uploadDocumentFile } from '@/lib/document-upload';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useDebouncedValue } from '@/lib/hooks/use-debounced-value';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Avatar } from '@/components/ui/avatar';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { ConfirmIconButton } from '@/components/ui/confirm-button';
import { IconButton } from '@/components/ui/icon-button';
import { Modal } from '@/components/ui/modal';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';
import { DocumentDetail } from './documents/document-detail';
import { DocumentViewer } from './documents/document-viewer';
import { ReviewBanner } from './documents/review-banner';
import {
  DOC_STATUS_TONES,
  DOC_TYPES,
  MAX_DOCUMENT_FILE_MB,
  REVIEW_TONES,
  fileFitsLimit,
  nextActionOf,
  reviewLabel,
  reviewStateOf,
  signedBy,
  statusLabel,
  typeLabel,
} from './documents/document-meta';

const PAGE_SIZE = 25;

type FilterState = { status: string; type: string; areaId: string; due: string };

const EMPTY_FILTERS: FilterState = { status: '', type: '', areaId: '', due: '' };

export function DocumentsView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [newCode, setNewCode] = useState('');
  const [newTitle, setNewTitle] = useState('');
  const [newType, setNewType] = useState<string>('PROCEDIMIENTO');
  const [newArea, setNewArea] = useState('');
  const [newContent, setNewContent] = useState('');
  const [newValidity, setNewValidity] = useState('');
  const [newReview, setNewReview] = useState('');
  const [newProvider, setNewProvider] = useState('');
  const [newRef, setNewRef] = useState('');
  const [newBranches, setNewBranches] = useState<string[]>([]);
  const [newFile, setNewFile] = useState<File | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [search, setSearch] = useState('');
  const [filters, setFilters] = useState<FilterState>(EMPTY_FILTERS);
  const [page, setPage] = useState(1);
  const [detailId, setDetailId] = useState<string | null>(null);
  const [readerId, setReaderId] = useState<string | null>(null);
  const [editing, setEditing] = useState<{ id: string; title: string } | null>(null);
  const [approveComment, setApproveComment] = useState<Record<string, string>>({});

  // La búsqueda se resuelve en la API: se espera a que la persona deje de
  // teclear en lugar de pedir el inventario en cada pulsación.
  const q = useDebouncedValue(search, 300).trim();

  const filtersQuery: DocumentFilters = {
    status: filters.status || undefined,
    type: filters.type || undefined,
    areaId: filters.areaId || undefined,
    due: filters.due === 'overdue' || filters.due === 'soon' ? filters.due : undefined,
    q: q || undefined,
    page,
    pageSize: PAGE_SIZE,
  };

  const docsQuery = useQuery({
    queryKey: ['documents', orgId, filtersQuery],
    queryFn: () => api.documents(orgId!, filtersQuery),
    enabled: !!orgId,
  });

  const areasQuery = useQuery({
    queryKey: ['org-areas', orgId],
    queryFn: () => api.areas(orgId!),
    enabled: !!orgId,
  });

  // Tope real de subida del entorno; se pide al abrir el alta, que es cuando
  // hace falta validar el archivo.
  const uploadCaps = useQuery({
    queryKey: ['doc-upload-caps', orgId],
    queryFn: () => api.documentUploadCapabilities(orgId!),
    enabled: !!orgId && createOpen,
    // Cambia solo si se reconfigura el almacenamiento: no hace falta repetirlo.
    staleTime: 10 * 60 * 1000,
  });
  const maxFileMb = uploadCaps.data?.maxMb ?? MAX_DOCUMENT_FILE_MB;

  // Las sedes se piden al abrir el alta: la mayoría de organizaciones no las usa
  // y no hace falta cargarlas en cada visita al inventario.
  const branchesQuery = useQuery({
    queryKey: ['org-branches', orgId],
    queryFn: () => api.branches(orgId!),
    enabled: !!orgId && createOpen,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['documents', orgId] });
    qc.invalidateQueries({ queryKey: ['doc-review-alerts', orgId] });
  };

  /** Cambiar un filtro devuelve a la primera página: la anterior deja de tener sentido. */
  const setFilter = (patch: Partial<FilterState>) => {
    setFilters((f) => ({ ...f, ...patch }));
    setPage(1);
  };

  const createDocument = useMutation({
    mutationFn: async () => {
      const doc = await api.createDocument(orgId!, {
        code: newCode,
        title: newTitle,
        type: newType,
        // Sin contenido la firma de aceptación falla en la API: el campo es obligatorio.
        content: newContent,
        areaId: newArea || null,
        validityUntil: newValidity || null,
        reviewDate: newReview || null,
        sourceProvider: newType === 'EXTERNO' ? newProvider || null : null,
        sourceRef: newType === 'EXTERNO' ? newRef || null : null,
        branchIds: newBranches,
      });
      // El archivo se sube después del alta porque necesita el id del documento.
      // Si la subida falla no se aborta el alta: el documento ya existe y el
      // archivo se puede adjuntar desde el detalle. Se devuelve el error para
      // avisarlo sin dejar el formulario abierto con un alta ya hecha.
      let fileError: string | null = null;
      if (newFile) {
        try {
          await uploadDocumentFile(orgId!, doc.id, newFile);
        } catch (err) {
          fileError = err instanceof Error ? err.message : null;
        }
      }
      return { doc, fileError };
    },
    onSuccess: ({ fileError }) => {
      refresh();
      setNewCode('');
      setNewTitle('');
      setNewContent('');
      setNewArea('');
      setNewBranches([]);
      setNewFile(null);
      setNewValidity('');
      setNewReview('');
      setNewProvider('');
      setNewRef('');
      // El modal se cierra al guardar: el documento ya aparece en el inventario.
      setCreateOpen(false);
      if (fileError) {
        toast.error(`${t.documents.createdWithoutFile} ${fileError}`);
      } else {
        toast.success(t.common.saved);
      }
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const docAction = useMutation({
    mutationFn: ({
      id,
      action,
      comment,
    }: {
      id: string;
      action: 'submit' | 'approve' | 'publish';
      comment?: string;
    }) => api.docAction(orgId!, id, action, comment),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const acceptDocument = useMutation({
    mutationFn: (id: string) => api.acceptDocument(orgId!, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const updateDocument = useMutation({
    mutationFn: ({ id, title }: { id: string; title: string }) =>
      api.updateDocument(orgId!, id, { title }),
    onSuccess: () => {
      refresh();
      setEditing(null);
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const obsoleteDocument = useMutation({
    mutationFn: (id: string) => api.obsoleteDocument(orgId!, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const deleteDocument = useMutation({
    mutationFn: (id: string) => api.deleteDocument(orgId!, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  // La exportación se pide como texto y se guarda desde el navegador: si el
  // servidor la rechaza (permiso, tope de filas) el aviso aparece aquí y la
  // persona sigue en el inventario, en lugar de aterrizar en una pestaña con
  // el error de la API.
  const exportCsv = useMutation({
    mutationFn: () => api.documentsCsv(orgId!, { ...filtersQuery, page: undefined, pageSize: undefined }),
    onSuccess: (csv) => {
      const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `inventario-documental-${new Date().toISOString().slice(0, 10)}.csv`;
      link.click();
      URL.revokeObjectURL(url);
      toast.success(t.documents.exportDone);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.documents.downloadFailed),
  });

  if (!orgId) return null;

  const docs: DocumentItem[] = docsQuery.data?.items ?? [];
  const total = docsQuery.data?.total ?? 0;
  const pages = docsQuery.data?.pages ?? 0;
  const hasFilters =
    !!(filters.status || filters.type || filters.areaId || filters.due || q);
  // Una página que quedó vacía tras borrar el último registro no es un error:
  // se avisa y se ofrece volver.
  const beyondLast = !!docsQuery.data && pages > 0 && page > pages;

  const areaName = (areaId: string | null) =>
    areasQuery.data?.find((a) => a.id === areaId)?.name;

  // El detalle se lee de la lista para reflejar de inmediato los cambios de
  // estado; el panel se encarga de pedir el historial completo.
  const detailDoc = detailId ? docs.find((d) => d.id === detailId) ?? null : null;
  // El lector usa el mismo registro del inventario: ya trae la última versión.
  const readerDoc = readerId ? docs.find((d) => d.id === readerId) ?? null : null;

  return (
    <div className="space-y-6">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.documents.title}</h1>
          <p className="text-sm text-ink-soft mt-1">{t.documents.subtitle}</p>
        </div>
        <div className="flex items-center gap-3">
          {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
          {canWrite && (
            <Button onClick={() => setCreateOpen(true)}>
              <Plus className="size-4" aria-hidden="true" />
              {t.documents.newDoc}
            </Button>
          )}
        </div>
      </div>

      <ReviewBanner orgId={orgId} onShow={(due) => setFilter({ due })} />

      {/* El alta vive en una ventana emergente para que el inventario quede a la
          vista: el formulario ocupa mucho alto y empujaba la tabla hacia abajo. */}
      <Modal
        open={canWrite && createOpen}
        onClose={() => setCreateOpen(false)}
        title={t.documents.newDocTitle}
        subtitle={t.documents.newDocSubtitle}
        footer={
          <>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>
              {t.common.cancel}
            </Button>
            <Button
              onClick={() => createDocument.mutate()}
              disabled={!newCode || !newTitle || !newContent.trim() || createDocument.isPending}
            >
              {createDocument.isPending ? t.common.loading : t.documents.createDoc}
            </Button>
          </>
        }
      >
        <div className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-3">
            <Input
              placeholder={`${t.documents.code} (PR-08)`}
              value={newCode}
              onChange={(e) => setNewCode(e.target.value)}
            />
            {/* El ancho lo lleva el contenedor: `Input` aplica `className` al
                `<input>`, así que un `col-span` ahí no movería la celda del grid
                y el campo se quedaría en una sola columna. */}
            <div className="sm:col-span-2">
              <Input
                placeholder={t.documents.document}
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
              />
            </div>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <select
              value={newType}
              onChange={(e) => setNewType(e.target.value)}
              className="h-10 border border-line rounded-btn px-3 text-sm bg-white"
              aria-label={t.documents.docType}
            >
              {DOC_TYPES.map((d) => (
                <option key={d} value={d}>
                  {typeLabel(d, t)}
                </option>
              ))}
            </select>
            <select
              value={newArea}
              onChange={(e) => setNewArea(e.target.value)}
              className="h-10 border border-line rounded-btn px-3 text-sm bg-white sm:col-span-2"
              aria-label={t.documents.area}
            >
              <option value="">{t.documents.noArea}</option>
              {(areasQuery.data ?? []).map((a) => (
                <option key={a.id} value={a.id}>
                  {a.name}
                </option>
              ))}
            </select>
          </div>

          <div className="grid gap-3 sm:grid-cols-2">
            <Input
              type="date"
              name="newValidity"
              label={t.documents.validityUntil}
              value={newValidity}
              onChange={(e) => setNewValidity(e.target.value)}
            />
            <Input
              type="date"
              name="newReview"
              label={t.documents.reviewDate}
              value={newReview}
              onChange={(e) => setNewReview(e.target.value)}
            />
          </div>

          {/* Sedes: una, varias o ninguna. Sin marcar ninguna el documento
              aplica a toda la organización, que es el caso más común. */}
          <fieldset>
            <legend className="mb-1.5 text-sm font-medium text-ink">
              {t.documents.branches}
            </legend>
            {branchesQuery.isLoading ? (
              <p className="text-xs text-ink-muted">{t.common.loading}</p>
            ) : (branchesQuery.data ?? []).length === 0 ? (
              <p className="text-xs text-ink-muted">{t.documents.noBranchesHint}</p>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {(branchesQuery.data ?? []).map((b) => {
                  const checked = newBranches.includes(b.id);
                  return (
                    <label
                      key={b.id}
                      className={`inline-flex cursor-pointer items-center gap-1.5 rounded-full border px-2.5 py-1 text-[11.5px] transition-colors ${
                        checked
                          ? 'border-primary bg-info-bg font-semibold text-info'
                          : 'border-line bg-white text-ink-soft hover:bg-page'
                      }`}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() =>
                          setNewBranches((ids) =>
                            checked ? ids.filter((id) => id !== b.id) : [...ids, b.id],
                          )
                        }
                        className="size-3 accent-primary"
                      />
                      {b.name}
                    </label>
                  );
                })}
              </div>
            )}
            <p className="mt-1 text-[11px] text-ink-muted">
              {newBranches.length === 0 ? t.documents.allBranchesHint : t.documents.branchesHint}
            </p>
          </fieldset>

          {/* Archivo original: opcional al crear, se sube después del alta. */}
          <div>
            <span className="mb-1.5 block text-sm font-medium text-ink">
              {t.documents.file}
            </span>
            <label className="flex cursor-pointer items-center gap-2 rounded-btn border border-dashed border-line-strong bg-page/60 px-3 py-2.5 text-xs text-ink-soft transition-colors hover:border-primary hover:bg-info-bg/40">
              <Paperclip className="size-4 shrink-0 text-ink-muted" aria-hidden="true" />
              <span className="min-w-0 flex-1 truncate">
                {newFile ? newFile.name : t.documents.fileCta}
              </span>
              <input
                type="file"
                aria-label={t.documents.file}
                onChange={(e) => {
                  const file = e.target.files?.[0] ?? null;
                  if (file && !fileFitsLimit(file, maxFileMb)) {
                    // Se limpia el input: si no, el mismo archivo no vuelve a
                    // disparar `onChange` al intentarlo otra vez.
                    e.target.value = '';
                    setNewFile(null);
                    toast.error(`${t.documents.fileTooLarge} (${maxFileMb} MB máximo)`);
                    return;
                  }
                  setNewFile(file);
                }}
                className="sr-only"
              />
            </label>
            <div className="mt-1 flex items-start justify-between gap-2">
              <p className="text-[11px] text-ink-muted">
                {t.documents.fileHint} ({maxFileMb} MB)
              </p>
              {newFile && (
                <button
                  type="button"
                  onClick={() => setNewFile(null)}
                  className="shrink-0 text-[11px] font-semibold text-danger hover:underline"
                >
                  {t.documents.fileRemove}
                </button>
              )}
            </div>
          </div>

          {newType === 'EXTERNO' && (
            <div className="grid gap-3 sm:grid-cols-2">
              <Input
                name="newProvider"
                label={t.documents.sourceProvider}
                placeholder={t.documents.sourceProviderPlaceholder}
                value={newProvider}
                onChange={(e) => setNewProvider(e.target.value)}
              />
              <Input
                name="newSourceRef"
                label={t.documents.sourceRef}
                placeholder={t.documents.sourceRefPlaceholder}
                value={newRef}
                onChange={(e) => setNewRef(e.target.value)}
              />
            </div>
          )}

          <div>
            <Textarea
              value={newContent}
              onChange={(e) => setNewContent(e.target.value)}
              placeholder={t.documents.contentPlaceholder}
              aria-label={t.documents.content}
              rows={8}
            />
            <p className="mt-1 text-[11px] text-ink-muted">{t.documents.contentHint}</p>
            {(newValidity || newReview) && (
              <p className="mt-1 text-[11px] text-ink-muted">{t.documents.datesHint}</p>
            )}
          </div>
        </div>
      </Modal>

      <Card
        title={`${t.documents.inventory} · ${total}`}
        action={
          <Button
            size="sm"
            variant="outline"
            className="h-8"
            title={t.documents.exportHint}
            onClick={() => exportCsv.mutate()}
            disabled={exportCsv.isPending || total === 0}
          >
            {exportCsv.isPending ? t.common.loading : t.documents.exportCsv}
          </Button>
        }
      >
        <div className="flex gap-2 mb-3 flex-wrap">
          <Input
            placeholder={t.documents.searchDocs}
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPage(1);
            }}
            className="h-9 text-sm flex-1 min-w-[180px]"
          />
          <select
            value={filters.status}
            onChange={(e) => setFilter({ status: e.target.value })}
            className="h-9 border border-line rounded-btn px-3 text-sm bg-white"
            aria-label={t.documents.filterByStatus}
          >
            <option value="">{t.documents.all}</option>
            <option value="DRAFT">{t.documents.draft}</option>
            <option value="IN_REVIEW">{t.documents.inReview}</option>
            <option value="IN_APPROVAL">{t.documents.inApproval}</option>
            <option value="PUBLISHED">{t.documents.published}</option>
            <option value="OBSOLETE">{t.documents.obsolete}</option>
          </select>
          <select
            value={filters.type}
            onChange={(e) => setFilter({ type: e.target.value })}
            className="h-9 border border-line rounded-btn px-3 text-sm bg-white"
            aria-label={t.documents.filterByType}
          >
            <option value="">{t.documents.allTypes}</option>
            {DOC_TYPES.map((d) => (
              <option key={d} value={d}>
                {typeLabel(d, t)}
              </option>
            ))}
          </select>
          <select
            value={filters.areaId}
            onChange={(e) => setFilter({ areaId: e.target.value })}
            className="h-9 border border-line rounded-btn px-3 text-sm bg-white"
            aria-label={t.documents.filterByArea}
          >
            <option value="">{t.documents.allAreas}</option>
            {(areasQuery.data ?? []).map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
          <select
            value={filters.due}
            onChange={(e) => setFilter({ due: e.target.value })}
            className="h-9 border border-line rounded-btn px-3 text-sm bg-white"
            aria-label={t.documents.filterByReview}
          >
            <option value="">{t.documents.reviewAny}</option>
            <option value="overdue">{t.documents.reviewOverdue}</option>
            <option value="soon">{t.documents.reviewSoon}</option>
          </select>
          {hasFilters && (
            <Button
              size="sm"
              variant="ghost"
              className="h-9"
              onClick={() => {
                setFilters(EMPTY_FILTERS);
                setSearch('');
                setPage(1);
              }}
            >
              {t.documents.clearFilters}
            </Button>
          )}
        </div>

        {docsQuery.isLoading && <SkeletonCards count={2} />}

        {docsQuery.isError && (
          <ErrorState
            message={(docsQuery.error as Error).message}
            onRetry={() => docsQuery.refetch()}
            retryLabel={t.common.retry}
          />
        )}

        {/* La página quedó vacía (por ejemplo tras borrar su último registro):
            se avisa y el paginador de abajo permite volver a la última. */}
        {beyondLast && <p className="mb-2 text-xs text-warning">{t.documents.skippedPage}</p>}

        {/* Una página fuera de rango no es un inventario vacío: el aviso de
            arriba explica qué pasó, así que no se ofrece "crear el primero". */}
        {docsQuery.isSuccess && docs.length === 0 && !beyondLast && (
          <EmptyState
            title={hasFilters ? t.documents.noResults : t.documents.createFirst}
            hint={hasFilters ? undefined : t.documents.subtitle}
            action={
              hasFilters ? (
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => {
                    setFilters(EMPTY_FILTERS);
                    setSearch('');
                    setPage(1);
                  }}
                >
                  {t.documents.clearFilters}
                </Button>
              ) : undefined
            }
          />
        )}

        {docs.length > 0 && (
          <div className="overflow-x-auto">
            <table className="w-full text-[13px] mt-2">
              <thead>
                <tr className="text-[10.5px] uppercase tracking-wider text-ink-muted text-left border-b-2 border-line-strong">
                  {/* Todas las columnas con ancho propio: el espacio sobrante se
                      reparte entre ellas en vez de irse entero a "Documento",
                      que antes acaparaba la tabla y dejaba las demás apretadas. */}
                  <th className="w-[88px] py-2">{t.documents.code}</th>
                  <th className="w-[300px]">{t.documents.document}</th>
                  <th className="w-[110px]">{t.documents.area}</th>
                  <th className="w-[58px]">{t.documents.version}</th>
                  <th className="w-[104px]">{t.documents.state}</th>
                  <th className="w-[124px]">{t.documents.reviewDate}</th>
                  <th className="w-[88px]">{t.documents.signatures}</th>
                  <th className="w-[200px] text-right">{t.common.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-line">
                {docs.map((d) => {
                  const next = nextActionOf(d.status, t);
                  const latest = d.versions?.[0];
                  const review = reviewStateOf(d.reviewDate, d.status);
                  const signers = signedBy(d.signatures ?? [], t);
                  return (
                    <tr key={d.id}>
                      <td className="py-2 font-mono text-xs">{d.code}</td>
                      <td>
                        {editing?.id === d.id ? (
                          <div className="flex gap-1.5">
                            <Input
                              value={editing.title}
                              onChange={(e) => setEditing({ ...editing, title: e.target.value })}
                              className="h-7 text-xs"
                              autoFocus
                            />
                            <Button
                              size="sm"
                              className="h-7 px-2 text-[11px]"
                              onClick={() => updateDocument.mutate({ id: d.id, title: editing.title })}
                              disabled={!editing.title || updateDocument.isPending}
                            >
                              {t.common.save}
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-7 px-1.5 text-[11px]"
                              onClick={() => setEditing(null)}
                            >
                              {t.common.cancel}
                            </Button>
                          </div>
                        ) : (
                          <>
                            <div className="font-medium">{d.title}</div>
                            <div className="text-[11px] text-ink-muted">
                              {typeLabel(d.type, t)}
                              {d.sourceProvider ? ` · ${d.sourceProvider}` : ''}
                            </div>
                          </>
                        )}
                      </td>
                      <td className="py-2 text-xs text-ink-soft">
                        {areaName(d.areaId) ?? <span className="text-ink-muted">—</span>}
                      </td>
                      <td className="py-2">{latest?.version ?? t.documents.noVersion}</td>
                      <td className="py-2">
                        <Badge tone={DOC_STATUS_TONES[d.status] ?? 'muted'}>
                          {statusLabel(d.status, t)}
                        </Badge>
                      </td>
                      <td className="py-2">
                        {review === 'none' ? (
                          <span className="text-[11px] text-ink-muted">{t.documents.noReviewDate}</span>
                        ) : (
                          <div className="flex flex-col gap-1">
                            <Badge tone={REVIEW_TONES[review]}>{reviewLabel(review, t)}</Badge>
                            <span className="text-[10.5px] text-ink-muted">
                              {d.reviewDate?.slice(0, 10)}
                            </span>
                          </div>
                        )}
                      </td>
                      <td className="py-2">
                        {signers.length > 0 ? (
                          /* Los firmantes se leen de un vistazo como avatares. Una
                              misma persona puede aprobar y aceptar: se agrupa en un
                              solo círculo y el tipo de firma queda en el título. */
                          <div className="flex items-center">
                            {signers.slice(0, 3).map((s, i) => (
                              <Avatar
                                key={s.key}
                                name={s.name}
                                label={s.label}
                                size={26}
                                className={i > 0 ? '-ml-1.5' : undefined}
                              />
                            ))}
                            {signers.length > 3 && (
                              <span
                                className="-ml-1.5 inline-flex size-[26px] shrink-0 items-center justify-center rounded-full border border-line bg-page text-[9.5px] font-semibold text-ink-soft ring-2 ring-white"
                                title={`+${signers.length - 3}`}
                              >
                                +{signers.length - 3}
                              </span>
                            )}
                          </div>
                        ) : (
                          <span className="text-ink-muted text-[11px]">—</span>
                        )}
                      </td>
                      <td className="py-2">
                        {/* Acciones en icono: la columna se leía como una lista de
                            frases y empujaba el resto de la tabla. Cada icono
                            conserva su título en `title` y `aria-label`. Se alinean
                            a la derecha y, al confirmar, el botón con texto baja a
                            una segunda línea en vez de ensanchar la columna. */}
                        <div className="flex flex-wrap items-center justify-end gap-1">
                          {canWrite && next && (
                            <IconButton
                              label={next.label}
                              tone="primary"
                              onClick={() =>
                                docAction.mutate({
                                  id: d.id,
                                  action: next.action,
                                  comment:
                                    next.action === 'approve' ? approveComment[d.id] : undefined,
                                })
                              }
                              disabled={docAction.isPending}
                            >
                              {next.action === 'approve' ? (
                                <CircleCheck className="size-4" aria-hidden="true" />
                              ) : (
                                <Send className="size-4" aria-hidden="true" />
                              )}
                            </IconButton>
                          )}
                          {canWrite && d.status === 'PUBLISHED' && (
                            <IconButton
                              label={t.documents.actionAccept}
                              onClick={() => acceptDocument.mutate(d.id)}
                              disabled={acceptDocument.isPending}
                            >
                              <Signature className="size-4" aria-hidden="true" />
                            </IconButton>
                          )}
                          {/* Leer el documento (el texto) es distinto de ver el
                              expediente: por eso son dos iconos y no uno. */}
                          <IconButton
                            label={t.documents.actionRead}
                            onClick={() => setReaderId(d.id)}
                          >
                            <FileText className="size-4" aria-hidden="true" />
                          </IconButton>
                          <IconButton
                            label={t.documents.actionView}
                            onClick={() => setDetailId(d.id)}
                          >
                            <Eye className="size-4" aria-hidden="true" />
                          </IconButton>
                          {canWrite && (
                            <IconButton
                              label={t.documents.actionEdit}
                              onClick={() => setEditing({ id: d.id, title: d.title })}
                            >
                              <Pencil className="size-4" aria-hidden="true" />
                            </IconButton>
                          )}
                          {canWrite && d.status !== 'OBSOLETE' && (
                            <ConfirmIconButton
                              label={t.documents.actionObsolete}
                              confirmLabel={t.documents.confirmObsolete}
                              onConfirm={() => obsoleteDocument.mutate(d.id)}
                            >
                              <Archive className="size-4" aria-hidden="true" />
                            </ConfirmIconButton>
                          )}
                          {/* La API solo borra borradores y obsoletos: un documento en
                              flujo o publicado se retira marcándolo obsoleto. */}
                          {canWrite &&
                            (d.status === 'DRAFT' || d.status === 'OBSOLETE') && (
                            <ConfirmIconButton
                              label={t.documents.actionDelete}
                              confirmLabel={t.common.confirmDelete}
                              onConfirm={() => deleteDocument.mutate(d.id)}
                              tone="danger"
                            >
                              <Trash className="size-4" aria-hidden="true" />
                            </ConfirmIconButton>
                          )}
                        </div>
                        {canWrite && next?.action === 'approve' && (
                          <Input
                            value={approveComment[d.id] ?? ''}
                            onChange={(e) =>
                              setApproveComment((s) => ({ ...s, [d.id]: e.target.value }))
                            }
                            placeholder={t.documents.approveCommentPlaceholder}
                            aria-label={t.documents.approveComment}
                            className="mt-1.5 h-7 text-[11px]"
                          />
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

        {docsQuery.data && (pages > 1 || beyondLast) && (
          <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-line pt-3 text-xs text-ink-soft">
            <Button
              size="sm"
              variant="outline"
              className="h-8"
              // Si la página quedó más allá del final (por ejemplo tras borrar
              // el último registro) se vuelve directo a la última existente.
              onClick={() => setPage((p) => (pages > 0 && p > pages ? pages : Math.max(1, p - 1)))}
              disabled={page <= 1 || docsQuery.isFetching}
            >
              {t.documents.prevPage}
            </Button>
            <span>
              {t.documents.page} {Math.min(page, pages || 1)} {t.documents.pageOf} {pages || 1}
            </span>
            <Button
              size="sm"
              variant="outline"
              className="h-8"
              onClick={() => setPage((p) => Math.min(pages, p + 1))}
              disabled={page >= pages || docsQuery.isFetching}
            >
              {t.documents.nextPage}
            </Button>
            <span className="ml-auto text-ink-muted">
              {total} {t.documents.totalDocs}
            </span>
          </div>
        )}
      </Card>

      {/* Claves con prefijo: los dos paneles son hermanos y, cerrados, ambos
          tendrían `none` como clave. */}
      <DocumentViewer
        key={`reader-${readerId ?? 'none'}`}
        doc={readerDoc}
        areaName={readerDoc ? areaName(readerDoc.areaId) ?? null : null}
        onClose={() => setReaderId(null)}
        onOpenDetail={() => {
          const id = readerId;
          setReaderId(null);
          setDetailId(id);
        }}
      />

      <DocumentDetail
        key={`detail-${detailId ?? 'none'}`}
        orgId={orgId}
        doc={detailDoc}
        canWrite={canWrite}
        onClose={() => setDetailId(null)}
        onChanged={refresh}
      />
    </div>
  );
}
