'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const TYPE_TONES: Record<string, 'info' | 'warn' | 'danger' | 'muted'> = {
  TASK: 'info',
  REMINDER: 'warn',
  APPROVAL: 'info',
  ALERT: 'danger',
  ESCALATION: 'danger',
};

export function NotificationsView() {
  const { t, locale } = useI18n();
  const { orgId } = useActiveOrg();
  const toast = useToast();
  const qc = useQueryClient();
  const [filter, setFilter] = useState<'all' | 'unread'>('all');

  const notifQuery = useQuery({
    queryKey: ['notifications', orgId],
    queryFn: () => api.notifications(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['notifications', orgId] });
    qc.invalidateQueries({ queryKey: ['notifications-unread', orgId] });
  };

  const onError = (err: unknown) =>
    toast.error(err instanceof Error ? err.message : t.common.saveError);

  const markAll = useMutation({
    mutationFn: () => api.markAllNotificationsRead(orgId!),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError,
  });

  const toggleOne = useMutation({
    mutationFn: ({ id, read }: { id: string; read: boolean }) =>
      read
        ? api.markNotificationRead(orgId!, id)
        : api.markNotificationUnread(orgId!, id),
    onSuccess: () => refresh(),
    onError,
  });

  const removeOne = useMutation({
    mutationFn: (id: string) => api.deleteNotification(orgId!, id),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const clearRead = useMutation({
    mutationFn: () => api.clearNotifications(orgId!),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const d = notifQuery.data;
  const items = useMemo(() => {
    const all = d?.items ?? [];
    return filter === 'unread' ? all.filter((n) => !n.readAt) : all;
  }, [d, filter]);
  const unread = d?.unread ?? 0;
  const readCount = (d?.items.length ?? 0) - unread;

  if (!orgId) return null;

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.notif.title}</h1>
          <p className="mt-1 text-sm text-ink-soft">{t.notif.subtitle}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex overflow-hidden rounded-btn border border-line">
            {(['all', 'unread'] as const).map((key) => (
              <button
                key={key}
                onClick={() => setFilter(key)}
                className={`h-8 px-3 text-xs font-semibold transition-colors ${
                  filter === key ? 'bg-primary text-white' : 'bg-white text-ink-soft hover:bg-page'
                }`}
              >
                {key === 'all' ? t.notif.all : t.notif.unreadOnly}
                {key === 'unread' && unread > 0 ? ` (${unread})` : ''}
              </button>
            ))}
          </div>
          {unread > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={() => markAll.mutate()}
              disabled={markAll.isPending}
            >
              {t.notif.markAllRead}
            </Button>
          )}
          {readCount > 0 && (
            <ConfirmButton
              confirmLabel={t.notif.clearReadConfirm}
              onConfirm={() => clearRead.mutate()}
              disabled={clearRead.isPending}
            >
              {t.notif.clearRead}
            </ConfirmButton>
          )}
        </div>
      </div>

      {notifQuery.isLoading && <SkeletonCards count={3} />}

      {notifQuery.isError && (
        <ErrorState
          message={(notifQuery.error as Error).message}
          onRetry={() => notifQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {d && (
        <Card>
          {items.length === 0 ? (
            <EmptyState
              title={t.notif.noNotifications}
              hint={filter === 'all' ? t.notif.emptyHint : undefined}
            />
          ) : (
            <div className="space-y-2">
              {items.map((n) => {
                const read = !!n.readAt;
                return (
                  <div
                    key={n.id}
                    className={`flex items-start gap-3 rounded-btn border border-line px-3 py-2.5 ${
                      read ? 'opacity-70' : 'bg-info-bg/30'
                    }`}
                  >
                    <span
                      className={`mt-1.5 size-2 shrink-0 rounded-full ${
                        read ? 'bg-line-strong' : 'bg-primary'
                      }`}
                      aria-hidden="true"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-sm ${read ? 'font-medium' : 'font-semibold'}`}>
                          {n.title}
                        </span>
                        <Badge tone={TYPE_TONES[n.type] ?? 'muted'} dot={false}>
                          {t.notif.types[n.type as keyof typeof t.notif.types] ?? n.type}
                        </Badge>
                        {n.entity && (
                          <span className="text-[10px] uppercase tracking-wide text-ink-muted">
                            {n.entity}
                          </span>
                        )}
                      </div>
                      {n.body && (
                        <div className="mt-0.5 text-xs text-ink-soft">{n.body}</div>
                      )}
                      <div className="mt-1 text-[10px] text-ink-muted">
                        {new Date(n.createdAt).toLocaleString(locale, {
                          day: '2-digit',
                          month: 'short',
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </div>
                    </div>
                    <div className="flex shrink-0 items-center gap-1">
                      <Button
                        size="sm"
                        variant="outline"
                        className="h-7 px-2 text-[11px]"
                        onClick={() => toggleOne.mutate({ id: n.id, read: !read })}
                        disabled={toggleOne.isPending}
                      >
                        {read ? t.notif.markUnread : t.notif.markRead}
                      </Button>
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        variant="ghost"
                        className="h-7 px-2 text-[11px]"
                        onConfirm={() => removeOne.mutate(n.id)}
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      )}
    </div>
  );
}
