'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useRef, useState } from 'react';
import { api, type EvidenceItem } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const CLASS_TONES: Record<string, 'muted' | 'warn' | 'danger'> = {
  INTERNO: 'muted',
  CONFIDENCIAL: 'warn',
  RESTRINGIDO: 'danger',
};

function classLabel(c: string, t: ReturnType<typeof useI18n>['t']) {
  return (
    {
      INTERNO: t.evidences.internal,
      CONFIDENCIAL: t.evidences.confidential,
      RESTRINGIDO: t.evidences.restricted,
    }[c] ?? c
  );
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

export function EvidencesView() {
  const { t, locale } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [newTitle, setNewTitle] = useState('');
  const [newClass, setNewClass] = useState('INTERNO');
  const [newReviewDate, setNewReviewDate] = useState('');
  const [fileFor, setFileFor] = useState<string | null>(null);
  const [linkFor, setLinkFor] = useState<string | null>(null);
  const [selectedClause, setSelectedClause] = useState('');
  const inputRef = useRef<HTMLInputElement | null>(null);

  const evQuery = useQuery({
    queryKey: ['evidences', orgId],
    queryFn: () => api.evidences(orgId!),
    enabled: !!orgId,
  });

  // Requisitos disponibles para vincular: se toman de las normas activas.
  const standardsQuery = useQuery({
    queryKey: ['standards', orgId],
    queryFn: () => api.standards(orgId!),
    enabled: !!orgId,
  });
  const activeStandards = standardsQuery.data?.active ?? [];
  const requirementsQuery = useQuery({
    queryKey: ['evidence-requirements', orgId, activeStandards.map((s) => s.standardId).join(',')],
    queryFn: async () => {
      const lists = await Promise.all(
        activeStandards.map(async (s) => ({
          standardId: s.standardId,
          standardCode: s.standard?.code ?? s.standardId,
          items: await api.requirements(orgId!, s.standardId),
        })),
      );
      return lists;
    },
    enabled: !!orgId && activeStandards.length > 0,
  });
  // Requisitos planos (para el alta rápida) y agrupados (para el selector con norma).
  const allRequirements = (requirementsQuery.data ?? []).flatMap((g) =>
    g.items.map((r) => ({ ...r, standardCode: g.standardCode })),
  );

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['evidences', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
  };

  const createEvidence = useMutation({
    mutationFn: () =>
      api.createEvidence(orgId!, {
        title: newTitle,
        classification: newClass,
        reviewDate: newReviewDate || undefined,
      }),
    onSuccess: () => {
      refresh();
      setNewTitle('');
      setNewReviewDate('');
      toast.success(t.common.saved);
    },
  });

  const updateEvidence = useMutation({
    mutationFn: ({ id, data }: { id: string; data: { classification?: string; reviewDate?: string | null } }) =>
      api.updateEvidence(orgId!, id, data),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
  });

  const uploadFiles = useMutation({
    mutationFn: ({ evidenceId, files }: { evidenceId: string; files: File[] }) =>
      api.uploadEvidenceFiles(orgId!, evidenceId, files),
    onSuccess: () => {
      refresh();
      setFileFor(null);
      if (inputRef.current) inputRef.current.value = '';
      toast.success(t.common.saved);
    },
  });

  const deleteFile = useMutation({
    mutationFn: (fileId: string) => api.deleteEvidenceFile(orgId!, fileId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const deleteEvidence = useMutation({
    mutationFn: (evidenceId: string) => api.deleteEvidence(orgId!, evidenceId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const linkEvidence = useMutation({
    mutationFn: ({ evidenceId, clauseId }: { evidenceId: string; clauseId: string }) =>
      api.linkEvidence(orgId!, evidenceId, [clauseId]),
    onSuccess: () => {
      refresh();
      setSelectedClause('');
      toast.success(t.common.saved);
    },
  });

  const unlinkEvidence = useMutation({
    mutationFn: ({ evidenceId, clauseId }: { evidenceId: string; clauseId: string }) =>
      api.unlinkEvidence(orgId!, evidenceId, clauseId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  if (!orgId) return null;
  const evs: EvidenceItem[] = evQuery.data ?? [];
  const totalFiles = evs.reduce((n, e) => n + e.files.length, 0);
  const dateLocale = locale === 'en-US' ? 'en-US' : 'es-MX';

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.evidences.title}</h1>
          <p className="text-sm text-ink-soft mt-1">{t.evidences.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {canWrite && (
        <Card>
          <div className="flex gap-3 items-end flex-wrap">
            <div className="flex-1 min-w-[220px]">
              <Input
                placeholder={t.evidences.evidence}
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
              />
            </div>
            <select
              value={newClass}
              onChange={(e) => setNewClass(e.target.value)}
              className="h-10 border border-line rounded-btn px-3 text-sm bg-white"
              aria-label={t.evidences.classification}
            >
              {['INTERNO', 'CONFIDENCIAL', 'RESTRINGIDO'].map((c) => (
                <option key={c} value={c}>
                  {classLabel(c, t)}
                </option>
              ))}
            </select>
            <Input
              type="date"
              value={newReviewDate}
              onChange={(e) => setNewReviewDate(e.target.value)}
              className="w-40"
              aria-label={t.evidences.reviewDate}
              title={t.evidences.reviewDate}
            />
            <Button
              onClick={() => createEvidence.mutate()}
              disabled={!newTitle || createEvidence.isPending}
            >
              {createEvidence.isPending ? t.evidences.uploading : t.evidences.newEvidence}
            </Button>
          </div>
          <p className="text-[11px] text-ink-muted mt-2">{t.evidences.storageNote}</p>
        </Card>
      )}

      <Card title={`${t.evidences.evidence} · ${evs.length} · ${totalFiles} ${t.evidences.totalFiles}`}>
        {evQuery.isLoading && <SkeletonCards count={2} />}

        {evQuery.isError && (
          <ErrorState
            message={(evQuery.error as Error).message}
            onRetry={() => evQuery.refetch()}
            retryLabel={t.common.retry}
          />
        )}

        {evQuery.isSuccess && evs.length === 0 && (
          <EmptyState title={t.evidences.noEvidence} hint={t.evidences.subtitle} />
        )}

        <div className="space-y-3 mt-2">
          {evs.map((ev) => {
            const restricted = !!ev.restrictionFlags?.noDownload;
            const available = allRequirements.filter(
              (r) => !ev.requirements.some((linked) => linked.clauseId === r.id),
            );
            return (
              <div key={ev.id} className="border border-line rounded-btn p-3">
                <div className="flex items-center justify-between gap-2 flex-wrap">
                  <div className="min-w-0">
                    <span className="text-sm font-semibold">{ev.title}</span>
                    <div className="text-[11px] text-ink-muted mt-0.5">
                      {ev.requirements.length > 0
                        ? `${t.evidences.linkedTo}: ${ev.requirements.map((r) => r.clause.code).join(', ')}`
                        : t.evidences.linkedTo}
                    </div>
                  </div>
                  <div className="flex items-center gap-2 flex-wrap">
                    {canWrite ? (
                      <select
                        value={ev.classification}
                        onChange={(e) =>
                          updateEvidence.mutate({
                            id: ev.id,
                            data: { classification: e.target.value },
                          })
                        }
                        className="h-7 text-[11px] border border-line rounded-btn px-1.5 bg-white"
                        aria-label={t.evidences.updateClassification}
                      >
                        {['INTERNO', 'CONFIDENCIAL', 'RESTRINGIDO'].map((c) => (
                          <option key={c} value={c}>
                            {classLabel(c, t)}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <Badge tone={CLASS_TONES[ev.classification] ?? 'muted'}>
                        {classLabel(ev.classification, t)}
                      </Badge>
                    )}
                    <span className="text-xs text-ink-muted">
                      {ev.files.length} {t.evidences.files}
                    </span>
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        onConfirm={() => deleteEvidence.mutate(ev.id)}
                        variant="ghost"
                        className="h-7 px-2 text-[11px]"
                      >
                        {t.evidences.deleteEvidence}
                      </ConfirmButton>
                    )}
                  </div>
                </div>

                {ev.reviewDate && (
                  <div className="text-[11px] text-warning mt-1">
                    {t.evidences.reviewBefore}:{' '}
                    {new Date(ev.reviewDate).toLocaleDateString(dateLocale)}
                  </div>
                )}

                {/* Requisitos vinculados */}
                {ev.requirements.length > 0 && (
                  <div className="flex gap-1.5 flex-wrap mt-2">
                    {ev.requirements.map((r) => (
                      <span
                        key={r.id}
                        className="inline-flex items-center gap-1 text-[10.5px] bg-info-bg text-primary rounded-full pl-2 pr-1 py-0.5"
                      >
                        {r.clause.code}
                        {canWrite && (
                          <button
                            onClick={() =>
                              unlinkEvidence.mutate({ evidenceId: ev.id, clauseId: r.clauseId })
                            }
                            className="size-4 rounded-full hover:bg-primary/15 flex items-center justify-center"
                            aria-label={`${t.evidences.unlink} ${r.clause.code}`}
                          >
                            ×
                          </button>
                        )}
                      </span>
                    ))}
                  </div>
                )}

                {/* Archivos */}
                {ev.files.length === 0 ? (
                  <p className="text-[11px] text-ink-muted mt-2">{t.evidences.noFiles}</p>
                ) : (
                  ev.files.map((f) => (
                    <div
                      key={f.id}
                      className="flex items-center gap-2 text-[11px] text-ink-soft mt-1.5 flex-wrap"
                    >
                      <span className="font-mono">📄 {f.blobName.split('/').pop()}</span>
                      <span className="text-ink-muted">· {formatBytes(f.size)}</span>
                      {f.sha256 && (
                        <span
                          className="text-ink-muted font-mono"
                          title={t.evidences.integrity}
                        >
                          · {f.sha256.slice(0, 10)}…
                        </span>
                      )}
                      {restricted ? (
                        <span className="text-warning">{t.evidences.noDownload}</span>
                      ) : (
                        <a
                          href={api.evidenceDownloadUrl(orgId, f.id)}
                          className="text-navy underline underline-offset-2"
                          download
                        >
                          {t.evidences.download}
                        </a>
                      )}
                      {canWrite && (
                        <ConfirmButton
                          confirmLabel={t.common.confirmDelete}
                          onConfirm={() => deleteFile.mutate(f.id)}
                          variant="ghost"
                          className="h-5 px-1 text-[10px] text-danger"
                        >
                          {t.evidences.deleteFile}
                        </ConfirmButton>
                      )}
                    </div>
                  ))
                )}

                {/* Acciones de archivos y vínculos */}
                {canWrite && (
                  <div className="flex gap-2 mt-2 items-center flex-wrap">
                    {fileFor !== ev.id ? (
                      <Button size="sm" variant="outline" onClick={() => setFileFor(ev.id)}>
                        {t.evidences.addFile}
                      </Button>
                    ) : (
                      <>
                        <input
                          ref={inputRef}
                          type="file"
                          multiple
                          className="text-xs"
                          onChange={(e) => {
                            const files = Array.from(e.target.files ?? []);
                            if (files.length) uploadFiles.mutate({ evidenceId: ev.id, files });
                          }}
                        />
                        <span className="text-[11px] text-ink-muted">{t.evidences.maxSizeMb}</span>
                        {uploadFiles.isPending && (
                          <span className="text-[11px] text-ink-soft">{t.evidences.uploading}</span>
                        )}
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-[11px]"
                          onClick={() => {
                            setFileFor(null);
                            if (inputRef.current) inputRef.current.value = '';
                          }}
                        >
                          {t.common.cancel}
                        </Button>
                      </>
                    )}

                    {linkFor === ev.id ? (
                      <>
                        <select
                          value={selectedClause}
                          onChange={(e) => setSelectedClause(e.target.value)}
                          className="h-8 text-xs border border-line rounded-btn px-2 bg-white max-w-[220px]"
                          aria-label={t.evidences.selectRequirement}
                        >
                          <option value="">{t.evidences.selectRequirement}</option>
                          {available.map((r) => (
                            <option key={`${r.standardCode}-${r.id}`} value={r.id}>
                              {r.standardCode} · {r.code} · {r.title}
                            </option>
                          ))}
                        </select>
                        <Button
                          size="sm"
                          className="h-8"
                          onClick={() =>
                            linkEvidence.mutate({ evidenceId: ev.id, clauseId: selectedClause })
                          }
                          disabled={!selectedClause || linkEvidence.isPending}
                        >
                          {t.evidences.link}
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="h-8 text-[11px]"
                          onClick={() => {
                            setLinkFor(null);
                            setSelectedClause('');
                          }}
                        >
                          {t.common.cancel}
                        </Button>
                      </>
                    ) : (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setLinkFor(ev.id);
                          setSelectedClause('');
                        }}
                        disabled={available.length === 0}
                        title={available.length === 0 ? t.evidences.linkTo : undefined}
                      >
                        {t.evidences.linkTo}
                      </Button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}
