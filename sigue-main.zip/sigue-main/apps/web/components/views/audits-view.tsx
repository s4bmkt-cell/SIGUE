'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api, type AuditItem } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const STATUS_TONES: Record<string, 'muted' | 'info' | 'ok'> = {
  PLANNED: 'muted',
  IN_PROGRESS: 'info',
  COMPLETED: 'ok',
};

const FINDING_TONES: Record<string, 'danger' | 'warn' | 'info'> = {
  NON_CONFORMITY: 'danger',
  NC: 'danger',
  OBSERVATION: 'warn',
  OBSERVACION: 'warn',
  IMPROVEMENT: 'info',
};

/** Tipo de hallazgo → etiqueta localizada (el backend guarda enums en inglés). */
function findingLabel(type: string, t: ReturnType<typeof useI18n>['t']) {
  const map: Record<string, string> = {
    NON_CONFORMITY: t.audits.nonConformity,
    NC: t.audits.nonConformity,
    OBSERVATION: t.audits.observation,
    OBSERVACION: t.audits.observation,
    IMPROVEMENT: t.audits.improvement,
  };
  return map[type] ?? type;
}

/** Resultados admisibles del ítem de checklist (enum del backend). */
const CHECKLIST_RESULTS = ['CONFORME', 'NO_CONFORME', 'OBSERVACION'] as const;

export function AuditsView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [title, setTitle] = useState('');
  const [scope, setScope] = useState('');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [findingDrafts, setFindingDrafts] = useState<Record<string, { type: string; description: string }>>({});

  const auditsQuery = useQuery({
    queryKey: ['audits', orgId],
    queryFn: () => api.audits(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['audits', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
  };

  const createAudit = useMutation({
    mutationFn: () => api.createAudit(orgId!, { title, scope: scope || undefined }),
    onSuccess: () => {
      refresh();
      setTitle('');
      setScope('');
      toast.success(t.common.saved);
    },
  });

  const removeAudit = useMutation({
    mutationFn: (auditId: string) => api.deleteAudit(orgId!, auditId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const generateChecklist = useMutation({
    mutationFn: (auditId: string) => api.generateChecklist(orgId!, auditId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
  });

  const setResult = useMutation({
    mutationFn: ({ itemId, result }: { itemId: string; result: string }) =>
      api.setChecklistResult(orgId!, itemId, { result }),
    onSuccess: () => refresh(),
  });

  const addFinding = useMutation({
    mutationFn: ({ auditId, type, description }: { auditId: string; type: string; description: string }) =>
      api.addFinding(orgId!, auditId, { type, description }),
    onSuccess: (_data, vars) => {
      refresh();
      setFindingDrafts((s) => ({ ...s, [vars.auditId]: { type: vars.type, description: '' } }));
      toast.success(t.common.saved);
    },
  });

  const updateFinding = useMutation({
    mutationFn: ({ findingId, status }: { findingId: string; status: string }) =>
      api.updateFinding(orgId!, findingId, { status }),
    onSuccess: () => refresh(),
  });

  const removeFinding = useMutation({
    mutationFn: (findingId: string) => api.deleteFinding(orgId!, findingId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const closeAudit = useMutation({
    mutationFn: (auditId: string) => api.closeAudit(orgId!, auditId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
  });

  if (!orgId) return null;
  const audits: AuditItem[] = auditsQuery.data ?? [];

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.audits.title}</h1>
          <p className="text-sm text-ink-soft mt-1">{t.audits.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {canWrite && (
        <Card>
          <div className="flex gap-3 items-end flex-wrap">
            <Input
              placeholder={t.audits.auditTitle}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="flex-1 min-w-[220px]"
            />
            <Input
              placeholder={t.audits.scope}
              value={scope}
              onChange={(e) => setScope(e.target.value)}
              className="flex-1 min-w-[220px]"
            />
            <Button onClick={() => createAudit.mutate()} disabled={!title || createAudit.isPending}>
              {t.audits.newAudit}
            </Button>
          </div>
        </Card>
      )}

      {auditsQuery.isLoading && <SkeletonCards count={2} />}

      {auditsQuery.isError && (
        <ErrorState
          message={(auditsQuery.error as Error).message}
          onRetry={() => auditsQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {auditsQuery.isSuccess && audits.length === 0 && (
        <EmptyState title={t.audits.noAudits} hint={t.audits.subtitle} />
      )}

      {audits.map((a) => {
        const items = a.checklists.flatMap((c) => c.items);
        const answered = items.filter((i) => i.result).length;
        const progress = items.length ? Math.round((answered / items.length) * 100) : 0;
        const isOpen = expanded === a.id;
        const draft = findingDrafts[a.id] ?? { type: 'NON_CONFORMITY', description: '' };

        return (
          <Card key={a.id}>
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="min-w-0">
                <div className="font-semibold">{a.title}</div>
                <div className="text-xs text-ink-muted mt-0.5">
                  {a.program.year} · {t.audits.scope}: {a.scope ?? '—'}
                  {items.length > 0 && ` · ${t.audits.progress} ${progress}%`}
                </div>
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge tone={STATUS_TONES[a.status] ?? 'muted'}>
                  {a.status === 'PLANNED'
                    ? t.audits.planned
                    : a.status === 'IN_PROGRESS'
                      ? t.audits.inProgress
                      : a.status === 'COMPLETED'
                        ? t.audits.completed
                        : a.status}
                </Badge>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => setExpanded(isOpen ? null : a.id)}
                >
                  {isOpen ? t.common.close : t.common.open}
                </Button>
                {canWrite && (
                  <ConfirmButton
                    confirmLabel={t.common.confirmDelete}
                    onConfirm={() => removeAudit.mutate(a.id)}
                    variant="ghost"
                    className="h-7 px-2 text-[11px]"
                  >
                    {t.common.delete}
                  </ConfirmButton>
                )}
              </div>
            </div>

            {items.length > 0 && (
              <div className="h-1.5 rounded-full bg-page mt-2 overflow-hidden">
                <div
                  className="h-full rounded-full bg-primary transition-all"
                  style={{ width: `${progress}%` }}
                />
              </div>
            )}

            {a.findings.length > 0 && (
              <div className="mt-2 flex gap-2 flex-wrap">
                {a.findings.map((f) => (
                  <Badge key={f.id} tone={FINDING_TONES[f.type] ?? 'info'} dot={false}>
                    {findingLabel(f.type, t)}
                  </Badge>
                ))}
              </div>
            )}

            {isOpen && (
              <div className="mt-3 border-t border-line pt-3 space-y-4">
                {/* Lista de verificación */}
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2">
                    <b className="text-xs text-ink-muted">{t.audits.checklist}</b>
                    {canWrite && items.length === 0 && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => generateChecklist.mutate(a.id)}
                        disabled={generateChecklist.isPending}
                      >
                        {t.audits.generateChecklist}
                      </Button>
                    )}
                    {canWrite && items.length > 0 && a.status !== 'COMPLETED' && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        onConfirm={() => closeAudit.mutate(a.id)}
                        variant="outline"
                        className="h-7 px-2.5 text-[11px]"
                      >
                        {t.audits.closeAudit}
                      </ConfirmButton>
                    )}
                  </div>
                  {items.length === 0 ? (
                    <p className="text-xs text-ink-soft">{t.audits.checklistEmpty}</p>
                  ) : (
                    <ul className="space-y-2">
                      {items.map((item) => (
                        <li key={item.id} className="text-xs">
                          <div className="text-ink-soft">{item.question}</div>
                          <div className="flex gap-1.5 mt-1">
                            {CHECKLIST_RESULTS.map((r) => (
                              <button
                                key={r}
                                disabled={!canWrite}
                                onClick={() => setResult.mutate({ itemId: item.id, result: r })}
                                className={[
                                  'h-6 px-2 rounded-btn border text-[11px] font-semibold transition-colors disabled:opacity-60',
                                  item.result === r
                                    ? r === 'CONFORME'
                                      ? 'bg-[#E7F8F1] border-[#0BAA70] text-[#087E55]'
                                      : r === 'NO_CONFORME'
                                        ? 'bg-danger-bg border-danger text-danger'
                                        : 'bg-warning-bg border-warning text-warning'
                                    : 'bg-white border-line text-ink-soft hover:border-primary/40',
                                ].join(' ')}
                              >
                                {r === 'CONFORME'
                                  ? t.audits.yes
                                  : r === 'NO_CONFORME'
                                    ? t.audits.no
                                    : t.audits.na}
                              </button>
                            ))}
                          </div>
                        </li>
                      ))}
                    </ul>
                  )}
                  {items.length > 0 && progress < 100 && (
                    <p className="text-[11px] text-ink-muted mt-2">
                      {answered}/{items.length} · {t.audits.closeRequiresChecklist}
                    </p>
                  )}
                </div>

                {/* Hallazgos */}
                <div>
                  <b className="text-xs text-ink-muted">{t.audits.findings}</b>
                  {a.findings.length === 0 ? (
                    <p className="text-xs text-ink-soft mt-1">{t.audits.noFindings}</p>
                  ) : (
                    <ul className="mt-1 space-y-1.5">
                      {a.findings.map((f) => (
                        <li
                          key={f.id}
                          className="flex items-start gap-2 text-xs border border-line rounded-btn px-2.5 py-2"
                        >
                          <Badge tone={FINDING_TONES[f.type] ?? 'info'} dot={false}>
                            {findingLabel(f.type, t)}
                          </Badge>
                          <span className="flex-1 text-ink-soft">{f.description}</span>
                          <button
                            disabled={!canWrite}
                            onClick={() =>
                              updateFinding.mutate({
                                findingId: f.id,
                                status: f.status === 'CLOSED' ? 'OPEN' : 'CLOSED',
                              })
                            }
                            className="text-[11px] text-info hover:underline disabled:no-underline disabled:text-ink-muted shrink-0"
                          >
                            {f.status === 'CLOSED' ? t.common.open : t.audits.findingClosed}
                          </button>
                          {canWrite && (
                            <ConfirmButton
                              confirmLabel={t.common.confirmDelete}
                              onConfirm={() => removeFinding.mutate(f.id)}
                              variant="ghost"
                              className="h-5 px-1 text-[10px]"
                            >
                              {t.common.delete}
                            </ConfirmButton>
                          )}
                        </li>
                      ))}
                    </ul>
                  )}
                  {canWrite && (
                    <div className="flex gap-2 mt-2 flex-wrap">
                      <select
                        value={draft.type}
                        onChange={(e) =>
                          setFindingDrafts((s) => ({
                            ...s,
                            [a.id]: { ...draft, type: e.target.value },
                          }))
                        }
                        className="text-xs border border-line rounded-btn px-2 bg-white"
                        aria-label={t.audits.findingType}
                      >
                        <option value="NON_CONFORMITY">{t.audits.nonConformity}</option>
                        <option value="OBSERVATION">{t.audits.observation}</option>
                        <option value="IMPROVEMENT">{t.audits.improvement}</option>
                      </select>
                      <Input
                        placeholder={t.audits.findingDescription}
                        value={draft.description}
                        onChange={(e) =>
                          setFindingDrafts((s) => ({
                            ...s,
                            [a.id]: { ...draft, description: e.target.value },
                          }))
                        }
                        className="h-8 text-xs flex-1 min-w-[200px]"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && draft.description)
                            addFinding.mutate({ auditId: a.id, ...draft });
                        }}
                      />
                      <Button
                        size="sm"
                        className="h-8"
                        onClick={() => addFinding.mutate({ auditId: a.id, ...draft })}
                        disabled={!draft.description || addFinding.isPending}
                      >
                        {t.audits.addFinding}
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}
