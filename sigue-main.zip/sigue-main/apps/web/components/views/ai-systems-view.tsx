'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const STAGE_LABELS = {
  PROPOSED: 'proposed',
  EVALUATION: 'evaluation',
  DEVELOPMENT: 'development',
  DEPLOYED: 'deployedStage',
  MONITORING: 'monitoring',
  RETIRED: 'retired',
} as const;

const SYSTEM_TYPES = {
  GENERATIVE: 'typeGenerative',
  NLP: 'typeNlp',
  ANALYTICS: 'typeAnalytics',
  VISION: 'typeVision',
  OTHER: 'typeOther',
} as const;

export function AiSystemsView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [systemName, setSystemName] = useState('');
  const [systemType, setSystemType] = useState('GENERATIVE');
  const [useCaseFor, setUseCaseFor] = useState('');
  const [useCaseName, setUseCaseName] = useState('');
  const [riskFor, setRiskFor] = useState('');
  const [riskTitle, setRiskTitle] = useState('');
  const [riskLikelihood, setRiskLikelihood] = useState(3);
  const [riskImpact, setRiskImpact] = useState(3);
  const [controlFor, setControlFor] = useState<string | null>(null);
  const [controlTitle, setControlTitle] = useState('');

  const aiQuery = useQuery({
    queryKey: ['ai-systems', orgId],
    queryFn: () => api.aiSystems(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['ai-systems', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
  };

  const onError = (err: unknown) =>
    toast.error(err instanceof Error ? err.message : t.common.saveError);

  const addSystem = useMutation({
    mutationFn: () =>
      api.addAiSystem(orgId!, {
        name: systemName,
        type: systemType,
        dataClassification: 'CONFIDENCIAL',
      }),
    onSuccess: () => {
      refresh();
      setSystemName('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeSystem = useMutation({
    mutationFn: (systemId: string) => api.deleteAiSystem(orgId!, systemId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const lifecycle = useMutation({
    mutationFn: ({ id, stage }: { id: string; stage: string }) =>
      api.updateAiLifecycle(orgId!, id, stage),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError,
  });

  const addUseCase = useMutation({
    mutationFn: () =>
      api.addAiUseCase(orgId!, {
        systemId: useCaseFor,
        name: useCaseName,
        purpose: undefined,
      }),
    onSuccess: () => {
      refresh();
      setUseCaseName('');
      setUseCaseFor('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeUseCase = useMutation({
    mutationFn: (useCaseId: string) => api.deleteAiUseCase(orgId!, useCaseId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const addRisk = useMutation({
    mutationFn: () =>
      api.addAiRisk(orgId!, {
        // El sistema afectado es el seleccionado: antes se enviaba el id del
        // riesgo anterior y el alta fallaba con 404.
        systemId: riskFor,
        title: riskTitle,
        likelihood: riskLikelihood,
        impact: riskImpact,
      }),
    onSuccess: () => {
      refresh();
      setRiskTitle('');
      setRiskFor('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeRisk = useMutation({
    mutationFn: (riskId: string) => api.deleteAiRisk(orgId!, riskId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const addControl = useMutation({
    mutationFn: ({ riskId, title }: { riskId: string; title: string }) =>
      api.addAiControl(orgId!, riskId, { title, source: 'PROPIO' }),
    onSuccess: () => {
      refresh();
      setControlTitle('');
      setControlFor(null);
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeControl = useMutation({
    mutationFn: (controlId: string) => api.deleteAiControl(orgId!, controlId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  if (!orgId) return null;
  const d = aiQuery.data;
  const systems = d?.systems ?? [];

  const stageLabel = (s: string) =>
    t.aiSystems[STAGE_LABELS[s as keyof typeof STAGE_LABELS] ?? 'evaluation'];
  const stageTone = (s: string) =>
    s === 'DEPLOYED' ? 'ok' : s === 'RETIRED' ? 'muted' : s === 'MONITORING' ? 'info' : 'warn';

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.aiSystems.title}</h1>
          <p className="mt-1 text-sm text-ink-soft">{t.aiSystems.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {aiQuery.isLoading && <SkeletonCards count={2} />}

      {aiQuery.isError && (
        <ErrorState
          message={(aiQuery.error as Error).message}
          onRetry={() => aiQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {/* KPIs */}
      {d && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[
            {
              label: t.aiSystems.systems,
              value: String(d.summary.total),
              sub: `${d.summary.deployed} ${t.aiSystems.deployed}`,
            },
            { label: t.aiSystems.useCases, value: String(d.useCases.length) },
            {
              label: t.aiSystems.risks,
              value: String(d.risks.length),
              sub: `${d.summary.highRisk} ${t.aiSystems.highRisk}`,
              danger: d.summary.highRisk > 0,
            },
            {
              label: t.aiSystems.assessments,
              value: String(d.summary.pendingAssessments),
              sub: t.aiSystems.pendingAssessments,
            },
          ].map((kpi, i) => (
            <div key={i} className="rounded-card border border-line bg-white p-4 shadow-card">
              <div className="text-xs font-semibold text-ink-muted">{kpi.label}</div>
              <div
                className={`text-[26px] font-extrabold ${kpi.danger ? 'text-danger' : 'text-navy'}`}
              >
                {kpi.value}
              </div>
              {kpi.sub && <div className="text-[11.5px] text-ink-soft">{kpi.sub}</div>}
            </div>
          ))}
        </div>
      )}

      {/* Inventario de sistemas */}
      <Card title={t.aiSystems.systems}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.aiSystems.systemName}
              aria-label={t.aiSystems.systemName}
              value={systemName}
              onChange={(e) => setSystemName(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <select
              value={systemType}
              onChange={(e) => setSystemType(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.aiSystems.systemType}
            >
              {Object.entries(SYSTEM_TYPES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.aiSystems[key]}
                </option>
              ))}
            </select>
            <Button
              onClick={() => addSystem.mutate()}
              disabled={!systemName || addSystem.isPending}
            >
              {t.aiSystems.addSystem}
            </Button>
          </div>
        )}
        {canWrite && <p className="mb-3 text-[11px] text-ink-muted">{t.aiSystems.systemHint}</p>}

        {d && systems.length === 0 ? (
          <EmptyState title={t.aiSystems.noSystems} />
        ) : (
          <div className="grid gap-2 md:grid-cols-2">
            {systems.map((s) => (
              <div key={s.id} className="rounded-btn border border-line p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="text-sm font-semibold">{s.name}</span>
                    <div className="text-[11px] text-ink-muted">
                      {t.aiSystems[
                        SYSTEM_TYPES[s.type as keyof typeof SYSTEM_TYPES] ?? 'typeOther'
                      ]}{' '}
                      · {s.vendor ?? '—'} · {s.dataClassification}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      tone={
                        stageTone(s.lifecycleStage) as 'ok' | 'muted' | 'info' | 'warn'
                      }
                    >
                      {stageLabel(s.lifecycleStage)}
                    </Badge>
                    {canWrite && (
                      <>
                        <select
                          value={s.lifecycleStage}
                          onChange={(e) =>
                            lifecycle.mutate({ id: s.id, stage: e.target.value })
                          }
                          className="rounded-btn border border-line bg-white px-1.5 py-1 text-[11px]"
                          aria-label={t.aiSystems.lifecycle}
                        >
                          {Object.entries(STAGE_LABELS).map(([value, key]) => (
                            <option key={value} value={value}>
                              {t.aiSystems[key]}
                            </option>
                          ))}
                        </select>
                        <ConfirmButton
                          confirmLabel={t.common.confirmDelete}
                          variant="ghost"
                          className="h-6 px-1.5 text-[11px]"
                          onConfirm={() => removeSystem.mutate(s.id)}
                        >
                          {t.common.delete}
                        </ConfirmButton>
                      </>
                    )}
                  </div>
                </div>
                {s.description && (
                  <div className="mt-1 text-xs text-ink-soft">{s.description}</div>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Casos de uso */}
      <Card title={t.aiSystems.useCases}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <select
              value={useCaseFor}
              onChange={(e) => setUseCaseFor(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.aiSystems.system}
            >
              <option value="">{t.aiSystems.system}</option>
              {systems.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
            <Input
              placeholder={t.aiSystems.useCaseName}
              aria-label={t.aiSystems.useCaseName}
              value={useCaseName}
              onChange={(e) => setUseCaseName(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <Button
              onClick={() => addUseCase.mutate()}
              disabled={!useCaseFor || !useCaseName || addUseCase.isPending}
            >
              {t.aiSystems.addUseCase}
            </Button>
          </div>
        )}
        {d && d.useCases.length === 0 ? (
          <EmptyState title={t.aiSystems.noUseCases} />
        ) : (
          <div className="space-y-2">
            {(d?.useCases ?? []).map((u) => (
              <div
                key={u.id}
                className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-1 py-2 last:border-0"
              >
                <div className="min-w-0">
                  <span className="text-sm font-medium">{u.name}</span>
                  <div className="text-[11px] text-ink-muted">
                    {u.system.name}
                    {u.purpose ? ` · ${u.purpose}` : ''}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge tone="info">
                    {u.supervision === 'HUMAN_IN_LOOP'
                      ? t.aiSystems.humanInLoop
                      : u.supervision === 'HUMAN_ON_THE_LOOP'
                        ? t.aiSystems.humanOnLoop
                        : t.aiSystems.fullyAuto}
                  </Badge>
                  <Badge
                    tone={
                      u.status === 'APPROVED'
                        ? 'ok'
                        : u.status === 'UNDER_REVIEW'
                          ? 'warn'
                          : 'muted'
                    }
                  >
                    {u.status === 'APPROVED'
                      ? t.aiSystems.statusApproved
                      : u.status === 'UNDER_REVIEW'
                        ? t.aiSystems.statusUnderReview
                        : u.status === 'REJECTED'
                          ? t.aiSystems.statusRejected
                          : t.aiSystems.statusProposed}
                  </Badge>
                  {canWrite && (
                    <ConfirmButton
                      confirmLabel={t.common.confirmDelete}
                      variant="ghost"
                      className="h-6 px-1.5 text-[11px]"
                      onConfirm={() => removeUseCase.mutate(u.id)}
                    >
                      {t.common.delete}
                    </ConfirmButton>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Riesgos con controles */}
      <Card title={t.aiSystems.risks}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <select
              value={riskFor}
              onChange={(e) => setRiskFor(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.aiSystems.systemOfRisk}
            >
              <option value="">{t.aiSystems.system}</option>
              {systems.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
            <Input
              placeholder={t.aiSystems.addRisk}
              aria-label={t.aiSystems.addRisk}
              value={riskTitle}
              onChange={(e) => setRiskTitle(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <label className="flex items-center gap-1 text-[11px] text-ink-muted">
              {t.aiSystems.likelihood}
              <select
                value={riskLikelihood}
                onChange={(e) => setRiskLikelihood(Number(e.target.value))}
                className="h-10 rounded-btn border border-line bg-white px-2 text-sm"
              >
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex items-center gap-1 text-[11px] text-ink-muted">
              {t.aiSystems.impact}
              <select
                value={riskImpact}
                onChange={(e) => setRiskImpact(Number(e.target.value))}
                className="h-10 rounded-btn border border-line bg-white px-2 text-sm"
              >
                {[1, 2, 3, 4, 5].map((n) => (
                  <option key={n} value={n}>
                    {n}
                  </option>
                ))}
              </select>
            </label>
            <Button
              onClick={() => addRisk.mutate()}
              disabled={!riskFor || !riskTitle || addRisk.isPending}
            >
              {t.aiSystems.addRisk}
            </Button>
          </div>
        )}

        {d && d.risks.length === 0 ? (
          <EmptyState title={t.aiSystems.noRisks} />
        ) : (
          <div className="space-y-3">
            {(d?.risks ?? []).map((r) => (
              <div key={r.id} className="rounded-btn border border-line p-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="min-w-0">
                    <span className="text-sm font-semibold">{r.title}</span>
                    <div className="text-[11px] text-ink-muted">
                      {r.system.name} · {t.aiSystems.likelihood}: {r.likelihood} ·{' '}
                      {t.aiSystems.impact}: {r.impact}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge
                      tone={r.score >= 10 ? 'danger' : r.score >= 5 ? 'warn' : 'muted'}
                    >
                      {t.aiSystems.score}: {r.score}
                    </Badge>
                    <Badge
                      tone={
                        r.status === 'TREATED'
                          ? 'ok'
                          : r.status === 'ACCEPTED'
                            ? 'info'
                            : 'danger'
                      }
                    >
                      {r.status === 'TREATED'
                        ? t.aiSystems.riskStatusTreated
                        : r.status === 'ACCEPTED'
                          ? t.aiSystems.riskStatusAccepted
                          : t.aiSystems.riskStatusOpen}
                    </Badge>
                    {canWrite && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        variant="ghost"
                        className="h-6 px-1.5 text-[11px]"
                        onConfirm={() => removeRisk.mutate(r.id)}
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    )}
                  </div>
                </div>

                <div className="mt-2 space-y-1">
                  {r.controls.map((c) => (
                    <div key={c.id} className="flex items-center gap-2 text-xs">
                      <span className="size-1.5 shrink-0 rounded-full bg-current" aria-hidden="true" />
                      <span>{c.title}</span>
                      <Badge tone={c.source === 'ANEXO_A' ? 'info' : 'muted'} dot={false}>
                        {c.source === 'ANEXO_A' ? t.aiSystems.anexoA : t.aiSystems.propio}
                      </Badge>
                      <span className="text-ink-muted">
                        (
                        {c.status === 'IMPLEMENTED'
                          ? t.aiSystems.implemented
                          : c.status === 'VERIFIED'
                            ? t.aiSystems.verified
                            : t.aiSystems.planned}
                        )
                      </span>
                      {canWrite && (
                        <ConfirmButton
                          confirmLabel={t.common.confirmDelete}
                          variant="ghost"
                          className="ml-auto h-6 px-1.5 text-[11px]"
                          onConfirm={() => removeControl.mutate(c.id)}
                        >
                          {t.common.delete}
                        </ConfirmButton>
                      )}
                    </div>
                  ))}
                </div>

                {canWrite &&
                  (controlFor === r.id ? (
                    <div className="mt-2 flex gap-2">
                      <Input
                        placeholder={t.aiSystems.controlTitle}
                        aria-label={t.aiSystems.controlTitle}
                        value={controlTitle}
                        onChange={(e) => setControlTitle(e.target.value)}
                        className="flex-1 text-xs"
                      />
                      <Button
                        size="sm"
                        onClick={() => addControl.mutate({ riskId: r.id, title: controlTitle })}
                        disabled={!controlTitle || addControl.isPending}
                      >
                        {t.aiSystems.addControl}
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setControlFor(null);
                          setControlTitle('');
                        }}
                      >
                        {t.common.cancel}
                      </Button>
                    </div>
                  ) : (
                    <Button
                      size="sm"
                      variant="outline"
                      className="mt-2"
                      onClick={() => setControlFor(r.id)}
                    >
                      {t.aiSystems.addControl}
                    </Button>
                  ))}
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Evaluaciones de impacto */}
      <Card title={t.aiSystems.assessments}>
        {d && d.assessments.length === 0 ? (
          <EmptyState title={t.aiSystems.noAssessments} />
        ) : (
          <div className="space-y-2">
            {(d?.assessments ?? []).map((a) => (
              <div
                key={a.id}
                className="flex flex-wrap items-center justify-between gap-2 border-b border-line px-1 py-2 last:border-0"
              >
                <span className="text-sm">{a.system.name}</span>
                <div className="flex items-center gap-2">
                  <Badge
                    tone={
                      a.riskLevel === 'CRITICAL' || a.riskLevel === 'HIGH'
                        ? 'danger'
                        : a.riskLevel === 'MEDIUM'
                          ? 'warn'
                          : 'ok'
                    }
                  >
                    {a.riskLevel}
                  </Badge>
                  <Badge tone={a.status === 'COMPLETED' ? 'ok' : 'info'}>
                    {a.status === 'COMPLETED'
                      ? t.aiSystems.statusCompleted
                      : t.aiSystems.statusInProgress}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Eventos del ciclo de vida */}
      <Card title={t.aiSystems.events}>
        {d && d.events.length === 0 ? (
          <EmptyState title={t.aiSystems.noEvents} />
        ) : (
          <div className="space-y-1.5">
            {(d?.events ?? []).map((e) => (
              <div
                key={e.id}
                className="flex flex-wrap items-center gap-3 border-b border-line pb-1.5 text-sm last:border-0"
              >
                <Badge tone="info" dot={false}>
                  {e.eventType}
                </Badge>
                <span className="flex-1 text-ink-soft">{e.description}</span>
                <span className="text-xs text-ink-muted">
                  {new Date(e.createdAt).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
