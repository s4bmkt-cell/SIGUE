'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { api, type NcItem } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const STATUS_TONES: Record<string, 'muted' | 'warn' | 'info' | 'ok'> = {
  REGISTERED: 'muted',
  IN_ANALYSIS: 'warn',
  IN_CORRECTIVE_ACTION: 'info',
  VERIFYING: 'warn',
  CLOSED: 'ok',
};

/** El backend cambia el estado de la NC solo; estas son las transiciones visibles. */
const STATUS_FLOW = ['REGISTERED', 'IN_ANALYSIS', 'IN_CORRECTIVE_ACTION', 'VERIFYING', 'CLOSED'] as const;

function statusLabel(s: string, t: ReturnType<typeof useI18n>['t']) {
  return (
    {
      REGISTERED: t.nc.registered,
      IN_ANALYSIS: t.nc.inAnalysis,
      IN_CORRECTIVE_ACTION: t.nc.inCorrective,
      VERIFYING: t.nc.verifying,
      CLOSED: t.nc.closed,
    }[s] ?? s
  );
}

/** Estado de la acción correctiva → etiqueta localizada. */
function actionStatusLabel(status: string, t: ReturnType<typeof useI18n>['t']) {
  return (
    {
      PENDING: t.nc.actionPending,
      IN_PROGRESS: t.nc.actionInProgress,
      DONE: t.nc.actionDone,
      VERIFIED: t.nc.actionVerified,
    }[status] ?? status
  );
}

export function NcView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState('MEDIA');
  const [filter, setFilter] = useState<'open' | 'all'>('open');
  const [expanded, setExpanded] = useState<string | null>(null);
  // Un borrador por NC: compartir uno solo hacía que el texto apareciera en
  // todas las filas abiertas.
  const [corrections, setCorrections] = useState<Record<string, string>>({});
  const [causes, setCauses] = useState<Record<string, string>>({});
  const [analyses, setAnalyses] = useState<Record<string, string>>({});
  const [actionTitles, setActionTitles] = useState<Record<string, string>>({});
  const [lessons, setLessons] = useState<Record<string, string>>({});
  const [reopenReasons, setReopenReasons] = useState<Record<string, string>>({});

  const ncsQuery = useQuery({
    queryKey: ['nc', orgId],
    queryFn: () => api.ncs(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['nc', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
  };

  const registerNc = useMutation({
    mutationFn: () => api.registerNc(orgId!, { title, description, priority }),
    onSuccess: () => {
      refresh();
      setTitle('');
      setDescription('');
      toast.success(t.common.saved);
    },
  });

  const addCorrection = useMutation({
    mutationFn: ({ ncId, text }: { ncId: string; text: string }) =>
      api.ncCorrection(orgId!, ncId, text),
    onSuccess: (_data, vars) => {
      refresh();
      setCorrections((s) => ({ ...s, [vars.ncId]: '' }));
      toast.success(t.common.saved);
    },
  });

  const addRootCause = useMutation({
    mutationFn: ({ ncId, causesText, analysis }: { ncId: string; causesText: string; analysis: string }) =>
      api.ncRootCause(orgId!, ncId, {
        causes: causesText.split('\n').map((c) => c.trim()).filter(Boolean),
        analysis: analysis || undefined,
      }),
    onSuccess: (_data, vars) => {
      refresh();
      setCauses((s) => ({ ...s, [vars.ncId]: '' }));
      setAnalyses((s) => ({ ...s, [vars.ncId]: '' }));
      toast.success(t.common.saved);
    },
  });

  const addAction = useMutation({
    mutationFn: ({ ncId, title: actionTitle }: { ncId: string; title: string }) =>
      api.ncAction(orgId!, ncId, { title: actionTitle }),
    onSuccess: (_data, vars) => {
      refresh();
      setActionTitles((s) => ({ ...s, [vars.ncId]: '' }));
      toast.success(t.common.saved);
    },
  });

  const removeAction = useMutation({
    mutationFn: ({ ncId, actionId }: { ncId: string; actionId: string }) =>
      api.deleteNcAction(orgId!, ncId, actionId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError: (err) => toast.error(err instanceof Error ? err.message : t.common.saveError),
  });

  const verify = useMutation({
    mutationFn: ({ actionId, result }: { actionId: string; result: 'EFFECTIVE' | 'NOT_EFFECTIVE' }) =>
      api.ncVerify(orgId!, actionId, result),
    onSuccess: (data) => {
      refresh();
      const result = (data as { ncStatus?: string } | undefined)?.ncStatus;
      toast.success(result === 'CLOSED' ? t.nc.closed : t.common.saved);
    },
  });

  const addLesson = useMutation({
    mutationFn: ({ ncId, lesson }: { ncId: string; lesson: string }) => api.ncLesson(orgId!, ncId, lesson),
    onSuccess: (_data, vars) => {
      refresh();
      setLessons((s) => ({ ...s, [vars.ncId]: '' }));
      toast.success(t.common.saved);
    },
  });

  const closeNc = useMutation({
    mutationFn: (ncId: string) => api.ncClose(orgId!, ncId),
    onSuccess: () => {
      refresh();
      toast.success(t.nc.closed);
    },
  });

  const reopenNc = useMutation({
    mutationFn: ({ ncId, reason }: { ncId: string; reason: string }) => api.ncReopen(orgId!, ncId, reason),
    onSuccess: (_data, vars) => {
      refresh();
      setReopenReasons((s) => ({ ...s, [vars.ncId]: '' }));
      toast.success(t.common.saved);
    },
  });

  const removeNc = useMutation({
    mutationFn: (ncId: string) => api.deleteNc(orgId!, ncId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
  });

  const ncs = useMemo<NcItem[]>(() => {
    const all = ncsQuery.data ?? [];
    return filter === 'open' ? all.filter((nc) => nc.status !== 'CLOSED') : all;
  }, [ncsQuery.data, filter]);

  if (!orgId) return null;

  const openCount = (ncsQuery.data ?? []).filter((nc) => nc.status !== 'CLOSED').length;

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.nc.title}</h1>
          <p className="text-sm text-ink-soft mt-1">{t.nc.subtitle}</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex rounded-btn border border-line overflow-hidden">
            <button
              onClick={() => setFilter('open')}
              className={`px-3 h-8 text-xs font-semibold transition-colors ${
                filter === 'open' ? 'bg-primary text-white' : 'bg-white text-ink-soft hover:bg-page'
              }`}
            >
              {t.nc.openOnly} ({openCount})
            </button>
            <button
              onClick={() => setFilter('all')}
              className={`px-3 h-8 text-xs font-semibold transition-colors ${
                filter === 'all' ? 'bg-primary text-white' : 'bg-white text-ink-soft hover:bg-page'
              }`}
            >
              {t.nc.allNcs} ({ncsQuery.data?.length ?? 0})
            </button>
          </div>
          {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
        </div>
      </div>

      {canWrite && (
        <Card>
          <div className="flex gap-3 items-end flex-wrap">
            <Input
              placeholder={t.nc.ncTitle}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="flex-1 min-w-[220px]"
            />
            <Input
              placeholder={t.nc.description}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="flex-1 min-w-[220px]"
            />
            <select
              value={priority}
              onChange={(e) => setPriority(e.target.value)}
              className="h-10 border border-line rounded-btn px-3 text-sm bg-white"
              aria-label={t.nc.priority}
            >
              <option value="ALTA">{t.nc.high}</option>
              <option value="MEDIA">{t.nc.medium}</option>
              <option value="BAJA">{t.nc.low}</option>
            </select>
            <Button onClick={() => registerNc.mutate()} disabled={!title || registerNc.isPending}>
              {t.nc.register}
            </Button>
          </div>
        </Card>
      )}

      {ncsQuery.isLoading && <SkeletonCards count={2} />}

      {ncsQuery.isError && (
        <ErrorState
          message={(ncsQuery.error as Error).message}
          onRetry={() => ncsQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {ncsQuery.isSuccess && ncs.length === 0 && (
        <EmptyState
          title={filter === 'open' ? t.nc.noneInFilter : t.nc.noNc}
          hint={t.nc.subtitle}
        />
      )}

      {ncs.map((nc) => {
        const isOpen = expanded === nc.id;
        const closed = nc.status === 'CLOSED';
        const currentStep = STATUS_FLOW.indexOf(nc.status as (typeof STATUS_FLOW)[number]);
        const hasEffective = nc.actions.some((a) =>
          a.verifications.some((v) => v.result === 'EFFECTIVE'),
        );

        return (
          <Card key={nc.id}>
            <div className="flex items-center justify-between gap-3 flex-wrap">
              <div className="min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-xs text-primary font-semibold">{nc.folio}</span>
                  <span className={`font-semibold ${closed ? 'text-ink-soft' : ''}`}>{nc.title}</span>
                </div>
                {nc.description && (
                  <div className="text-xs text-ink-soft mt-0.5">{nc.description}</div>
                )}
              </div>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge
                  tone={nc.priority === 'ALTA' ? 'danger' : nc.priority === 'MEDIA' ? 'warn' : 'muted'}
                >
                  {nc.priority === 'ALTA' ? t.nc.high : nc.priority === 'MEDIA' ? t.nc.medium : t.nc.low}
                </Badge>
                <Badge tone={STATUS_TONES[nc.status] ?? 'muted'}>{statusLabel(nc.status, t)}</Badge>
                <span className="text-[11px] text-ink-muted">{t.nc.actionsCount(nc.actions.length)}</span>
                <Button size="sm" variant="outline" onClick={() => setExpanded(isOpen ? null : nc.id)}>
                  {isOpen ? t.common.close : t.common.open}
                </Button>
              </div>
            </div>

            {/* Progreso del ciclo de vida */}
            <ol className="flex items-center gap-1 mt-3 flex-wrap">
              {STATUS_FLOW.map((step, i) => {
                const done = currentStep >= i;
                return (
                  <li key={step} className="flex items-center gap-1">
                    <span
                      className={[
                        'text-[10.5px] font-semibold px-2 py-0.5 rounded-full',
                        done
                          ? step === 'CLOSED'
                            ? 'bg-[#E7F8F1] text-[#087E55]'
                            : 'bg-info-bg text-primary'
                          : 'bg-page text-ink-muted',
                      ].join(' ')}
                    >
                      {statusLabel(step, t)}
                    </span>
                    {i < STATUS_FLOW.length - 1 && (
                      <span className={`text-[10px] ${done ? 'text-primary' : 'text-ink-muted'}`}>›</span>
                    )}
                  </li>
                );
              })}
            </ol>

            {isOpen && (
              <div className="mt-3 border-t border-line pt-3 space-y-4 text-sm">
                {/* 1. Corrección inmediata */}
                <div>
                  <b className="text-xs text-ink-muted">{t.nc.correction}</b>
                  {nc.corrections.length > 0 ? (
                    <ul className="mt-1 space-y-1">
                      {nc.corrections.map((c) => (
                        <li key={c.id} className="text-ink-soft">
                          • {c.description}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-ink-muted mt-1">{t.nc.correctionPending}</p>
                  )}
                  {canWrite && !closed && (
                    <div className="flex gap-2 mt-1">
                      <Input
                        placeholder={t.nc.addCorrection}
                        value={corrections[nc.id] ?? ''}
                        onChange={(e) =>
                          setCorrections((s) => ({ ...s, [nc.id]: e.target.value }))
                        }
                        className="flex-1 text-xs"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && corrections[nc.id])
                            addCorrection.mutate({ ncId: nc.id, text: corrections[nc.id] });
                        }}
                      />
                      <Button
                        size="sm"
                        onClick={() =>
                          addCorrection.mutate({ ncId: nc.id, text: corrections[nc.id] })
                        }
                        disabled={!corrections[nc.id] || addCorrection.isPending}
                      >
                        {t.common.add}
                      </Button>
                    </div>
                  )}
                </div>

                {/* 2. Causa raíz */}
                <div>
                  <b className="text-xs text-ink-muted">{t.nc.rootCause}</b>
                  {nc.rootCauses.length > 0 ? (
                    <div className="mt-1 text-ink-soft space-y-1">
                      {nc.rootCauses.map((rc) => {
                        const list = Array.isArray(rc.causes)
                          ? (rc.causes as string[])
                          : Object.values((rc.causes as Record<string, string>) ?? {});
                        return (
                          <div key={rc.id}>
                            {list.length > 0 && <div>• {list.join(', ')}</div>}
                            {rc.analysis && (
                              <div>
                                • {t.nc.analysis}: {rc.analysis}
                              </div>
                            )}
                            <div className="text-[10.5px] text-ink-muted">
                              {rc.method === '5_WHYS' ? t.nc.method5Whys : rc.method}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-xs text-ink-muted mt-1">{t.nc.rootCausePending}</p>
                  )}
                  {canWrite && !closed && (
                    <div className="space-y-1.5 mt-1">
                      <Input
                        placeholder={t.nc.causes}
                        value={causes[nc.id] ?? ''}
                        onChange={(e) => setCauses((s) => ({ ...s, [nc.id]: e.target.value }))}
                        className="text-xs"
                      />
                      <div className="flex gap-2">
                        <Input
                          placeholder={t.nc.analysis}
                          value={analyses[nc.id] ?? ''}
                          onChange={(e) =>
                            setAnalyses((s) => ({ ...s, [nc.id]: e.target.value }))
                          }
                          className="flex-1 text-xs"
                        />
                        <Button
                          size="sm"
                          onClick={() =>
                            addRootCause.mutate({
                              ncId: nc.id,
                              causesText: causes[nc.id] ?? '',
                              analysis: analyses[nc.id] ?? '',
                            })
                          }
                          disabled={!causes[nc.id] || addRootCause.isPending}
                        >
                          {t.nc.addRootCause}
                        </Button>
                      </div>
                    </div>
                  )}
                </div>

                {/* 3. Acciones correctivas (varias por NC) */}
                <div>
                  <b className="text-xs text-ink-muted">{t.nc.action}</b>
                  {nc.actions.length > 0 ? (
                    <div className="mt-1 space-y-2">
                      {nc.actions.map((a) => {
                        const verified = a.verifications.some((v) => v.result === 'EFFECTIVE');
                        return (
                          <div
                            key={a.id}
                            className="flex items-center justify-between gap-2 border border-line rounded-btn px-2.5 py-2 flex-wrap"
                          >
                            <div className="min-w-0">
                              <div className="text-xs font-semibold">{a.title}</div>
                              <div className="text-[10.5px] text-ink-muted">
                                {actionStatusLabel(a.status, t)}
                                {a.verifications.length > 0 &&
                                  ` · ${a.verifications[a.verifications.length - 1].result === 'EFFECTIVE' ? t.nc.effective : t.nc.notEffective}`}
                              </div>
                            </div>
                            {canWrite && !closed && (
                              <div className="flex gap-1.5">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-6 px-2 text-[11px]"
                                  onClick={() => verify.mutate({ actionId: a.id, result: 'EFFECTIVE' })}
                                  disabled={verify.isPending || verified}
                                >
                                  {t.nc.effective}
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-6 px-2 text-[11px]"
                                  onClick={() =>
                                    verify.mutate({ actionId: a.id, result: 'NOT_EFFECTIVE' })
                                  }
                                  disabled={verify.isPending || verified}
                                >
                                  {t.nc.notEffective}
                                </Button>
                                {!verified && (
                                  <ConfirmButton
                                    confirmLabel={t.common.confirmDelete}
                                    onConfirm={() =>
                                      removeAction.mutate({ ncId: nc.id, actionId: a.id })
                                    }
                                    variant="ghost"
                                    className="h-6 px-1.5 text-[11px]"
                                  >
                                    {t.common.delete}
                                  </ConfirmButton>
                                )}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-xs text-ink-muted mt-1">{t.nc.verifyHint}</p>
                  )}
                  {canWrite && !closed && (
                    <div className="flex gap-2 mt-1.5">
                      <Input
                        placeholder={t.nc.createAction}
                        value={actionTitles[nc.id] ?? ''}
                        onChange={(e) =>
                          setActionTitles((s) => ({ ...s, [nc.id]: e.target.value }))
                        }
                        className="flex-1 text-xs"
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' && actionTitles[nc.id])
                            addAction.mutate({ ncId: nc.id, title: actionTitles[nc.id] });
                        }}
                      />
                      <Button
                        size="sm"
                        onClick={() =>
                          addAction.mutate({ ncId: nc.id, title: actionTitles[nc.id] })
                        }
                        disabled={!actionTitles[nc.id] || addAction.isPending}
                      >
                        {t.nc.addAction}
                      </Button>
                    </div>
                  )}
                </div>

                {/* 4. Lecciones aprendidas */}
                <div>
                  <b className="text-xs text-ink-muted">{t.nc.lesson}</b>
                  {nc.lessons.length > 0 ? (
                    <ul className="mt-1 space-y-1">
                      {nc.lessons.map((l) => (
                        <li key={l.id} className="text-xs text-ink-soft">
                          • {l.lesson}
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p className="text-xs text-ink-muted mt-1">{t.common.noData}</p>
                  )}
                  {canWrite && !closed && (
                    <div className="flex gap-2 mt-1">
                      <Input
                        placeholder={t.nc.lessonPlaceholder}
                        value={lessons[nc.id] ?? ''}
                        onChange={(e) => setLessons((s) => ({ ...s, [nc.id]: e.target.value }))}
                        className="flex-1 text-xs"
                      />
                      <Button
                        size="sm"
                        onClick={() => addLesson.mutate({ ncId: nc.id, lesson: lessons[nc.id] })}
                        disabled={!lessons[nc.id] || addLesson.isPending}
                      >
                        {t.nc.addLesson}
                      </Button>
                    </div>
                  )}
                </div>

                {/* Cierre / reapertura / eliminación */}
                {canWrite && (
                  <div className="flex items-end gap-2 flex-wrap pt-3 border-t border-line">
                    {!closed ? (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        onConfirm={() => closeNc.mutate(nc.id)}
                        variant="primary"
                        disabled={!hasEffective || closeNc.isPending}
                        className="h-8 px-3 text-xs"
                      >
                        {t.nc.closeNc}
                      </ConfirmButton>
                    ) : (
                      <>
                        <Input
                          placeholder={t.nc.reopenReason}
                          value={reopenReasons[nc.id] ?? ''}
                          onChange={(e) =>
                            setReopenReasons((s) => ({ ...s, [nc.id]: e.target.value }))
                          }
                          className="h-8 text-xs flex-1 min-w-[160px]"
                        />
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            reopenNc.mutate({ ncId: nc.id, reason: reopenReasons[nc.id] })
                          }
                          disabled={!reopenReasons[nc.id] || reopenNc.isPending}
                        >
                          {t.nc.reopenNc}
                        </Button>
                      </>
                    )}
                    {!closed && (
                      <ConfirmButton
                        confirmLabel={t.common.confirmDelete}
                        onConfirm={() => removeNc.mutate(nc.id)}
                        variant="ghost"
                        className="h-8 px-2 text-[11px]"
                      >
                        {t.common.delete}
                      </ConfirmButton>
                    )}
                  </div>
                )}
                {canWrite && !closed && !hasEffective && (
                  <p className="text-[11px] text-ink-muted">{t.nc.verifyHint}</p>
                )}
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}
