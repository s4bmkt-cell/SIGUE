'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ErrorState, SkeletonCards } from '@/components/ui/states';

const STATUS_TONES: Record<string, 'ok' | 'info' | 'warn' | 'muted'> = {
  ACTIVE: 'ok',
  TRIAL: 'info',
  SUSPENDED: 'warn',
  CANCELLED: 'muted',
};

export function SubscriptionView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { isAdmin } = usePermissions();
  const qc = useQueryClient();
  const [exportResult, setExportResult] = useState<string | null>(null);
  const [notice, setNotice] = useState<{ tone: 'ok' | 'error'; text: string } | null>(null);

  const subQuery = useQuery({
    queryKey: ['subscription', orgId],
    queryFn: () => api.subscription(orgId!),
    enabled: !!orgId,
  });
  const plansQuery = useQuery({
    queryKey: ['billing-plans', orgId],
    queryFn: () => api.billingPlans(orgId!),
    enabled: !!orgId,
  });

  const changePlanMutation = useMutation({
    mutationFn: (planCode: string) => api.changePlan(orgId!, planCode),
    onSuccess: (result) => {
      // Con pasarela real el plan no cambia hasta que el pago se completa.
      if (!result.applied && result.checkout?.url) {
        window.location.href = result.checkout.url;
        return;
      }
      setNotice({ tone: 'ok', text: result.message });
      qc.invalidateQueries({ queryKey: ['subscription', orgId] });
      qc.invalidateQueries({ queryKey: ['active-org'] });
    },
    onError: (error: Error) => setNotice({ tone: 'error', text: error.message }),
  });

  const exportMutation = useMutation({
    mutationFn: () => api.exportAll(orgId!),
    onSuccess: (data) => {
      const sections = Object.keys(data.data).length;
      setExportResult(
        `${t.billing.exportSuccess} ${(data.size / 1024).toFixed(1)} KB · ${sections} ${t.billing.exportSections}`,
      );
    },
    onError: (error: Error) => setNotice({ tone: 'error', text: error.message }),
  });

  if (!orgId) return null;
  const sub = subQuery.data;

  const quotaCards = sub
    ? [
        {
          label: t.billing.users,
          used: sub.quotas.users.used,
          quota: sub.quotas.users.quota,
          pct: sub.quotas.users.pct,
          hint: t.billing.usersHint
            .replace('{active}', String(sub.quotas.users.active))
            .replace('{pending}', String(sub.quotas.users.pending)),
        },
        {
          label: t.billing.storage,
          used: `${sub.quotas.storageGb.used} GB`,
          quota: `${sub.quotas.storageGb.quota} GB`,
          pct: sub.quotas.storageGb.pct,
        },
        {
          label: t.billing.standards,
          used: sub.quotas.standards.used,
          quota: sub.quotas.standards.quota,
          pct: sub.quotas.standards.pct,
        },
        {
          label: t.billing.aiTokens,
          used: sub.quotas.aiTokens.used,
          quota: sub.quotas.aiTokens.quota,
          pct: sub.quotas.aiTokens.pct,
          hint: sub.quotas.aiTokens.period,
        },
      ]
    : [];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-navy">{t.billing.title}</h1>
        <p className="text-sm text-ink-soft mt-1">{t.billing.subtitle}</p>
      </div>

      {notice && (
        <div
          className={`rounded-btn border px-4 py-3 text-sm ${
            notice.tone === 'ok'
              ? 'bg-success-bg border-success/30 text-success'
              : 'bg-danger-bg border-danger/30 text-danger'
          }`}
          role="status"
        >
          {notice.text}
        </div>
      )}

      {subQuery.isLoading && <SkeletonCards count={2} />}

      {subQuery.isError && (
        <ErrorState
          message={(subQuery.error as Error).message}
          onRetry={() => subQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {/* Plan actual */}
      {sub && (
        <Card>
          <div className="flex items-center justify-between flex-wrap gap-3">
            <div>
              <div className="text-xs text-ink-muted font-semibold">{t.billing.plan}</div>
              <div className="text-2xl font-extrabold text-navy">{sub.subscription.planName}</div>
              <div className="text-xs text-ink-muted mt-1">
                {t.billing.monthlyUsd}: ${sub.subscription.monthlyUsd} · {t.billing.cfdi}:{' '}
                {sub.subscription.cfdiRef ?? '—'}
              </div>
              <div className="text-[11px] text-ink-muted mt-1">
                {sub.subscription.livePayments
                  ? t.billing.liveGateway
                  : t.billing.localGateway}
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge tone={STATUS_TONES[sub.subscription.status] ?? 'muted'}>
                {sub.subscription.status}
              </Badge>
            </div>
          </div>
        </Card>
      )}

      {/* Cuotas */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {quotaCards.map((q) => (
          <div key={q.label} className="bg-white border border-line rounded-card shadow-card p-4">
            <div className="text-xs text-ink-muted font-semibold">{q.label}</div>
            <div className="text-[22px] font-extrabold text-navy">
              {q.used} <span className="text-sm text-ink-muted">/ {q.quota}</span>
            </div>
            <div className="h-2 bg-page rounded-full mt-2 overflow-hidden">
              <div
                className={`h-full rounded-full ${
                  q.pct >= 85 ? 'bg-danger' : q.pct >= 60 ? 'bg-warning' : 'bg-primary'
                }`}
                style={{ width: `${Math.min(100, q.pct)}%` }}
              />
            </div>
            <div className="text-[11px] text-ink-muted mt-1">{q.hint ?? `${q.pct}%`}</div>
          </div>
        ))}
      </div>

      {/* Planes disponibles */}
      <Card title={t.billing.plans}>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-3 mt-2">
          {(plansQuery.data ?? []).map((p) => {
            const isCurrent = sub?.subscription.planCode === p.code;
            return (
              <div
                key={p.code}
                className={`border rounded-btn p-3 flex flex-col ${
                  isCurrent ? 'border-primary bg-info-bg' : 'border-line'
                }`}
              >
                <div className="font-semibold text-sm">{p.name}</div>
                <div className="text-xl font-extrabold text-navy mt-1">
                  ${p.monthlyUsd}
                  <span className="text-xs text-ink-muted">/{t.billing.perMonth}</span>
                </div>
                <div className="text-[11px] text-ink-soft mt-1 flex-1">
                  {p.users} {t.billing.users.toLowerCase()} · {p.storageGb} GB · {p.standards}{' '}
                  {t.billing.standards.toLowerCase()} · {p.aiTokens} {t.billing.aiTokens.toLowerCase()}
                </div>
                <Button
                  className="mt-3 w-full"
                  variant={isCurrent ? 'outline' : 'primary'}
                  disabled={isCurrent || changePlanMutation.isPending || !isAdmin}
                  onClick={() => changePlanMutation.mutate(p.code)}
                >
                  {isCurrent
                    ? t.billing.currentPlan
                    : changePlanMutation.isPending
                      ? t.billing.changing
                      : t.billing.choosePlan}
                </Button>
              </div>
            );
          })}
        </div>
        <p className="text-[11px] text-ink-muted mt-3">{t.billing.downgradeNote}</p>
      </Card>

      {/* Exportación */}
      <Card title={t.billing.exportTitle}>
        <p className="text-sm text-ink-soft">{t.billing.exportSubtitle}</p>
        <div className="flex items-center gap-3 mt-3">
          <Button onClick={() => exportMutation.mutate()} disabled={exportMutation.isPending}>
            {exportMutation.isPending ? t.billing.exporting : t.billing.export}
          </Button>
          {exportResult && <span className="text-sm text-success font-medium">{exportResult}</span>}
        </div>
      </Card>
    </div>
  );
}
