'use client';

import { useQuery } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const HEALTH_TONES: Record<string, 'ok' | 'warn' | 'danger'> = {
  GOOD: 'ok',
  WATCH: 'warn',
  CRITICAL: 'danger',
};

export function ConsultantView() {
  const { t } = useI18n();
  const { setOrgId, orgId } = useActiveOrg();
  const { has } = usePermissions();
  const [selectedClient, setSelectedClient] = useState<string | null>(null);

  // Solo un consultor o un administrador pueden ver la consola; el resto
  // recibe un 403 del servidor y aquí se evita hacer la petición.
  const allowed = has(['consultor_externo', 'admin_org']);

  const consolidatedQuery = useQuery({
    queryKey: ['consultant-consolidated'],
    queryFn: () => api.consultantConsolidated(),
    enabled: allowed,
  });

  const clientsQuery = useQuery({
    queryKey: ['consultant-clients'],
    queryFn: () => api.consultantClients(),
    enabled: allowed,
  });

  const clientSummaryQuery = useQuery({
    queryKey: ['consultant-client', selectedClient],
    queryFn: () => api.consultantClientSummary(selectedClient!),
    enabled: !!selectedClient,
  });

  if (!orgId) return null;

  if (!allowed) {
    return (
      <EmptyState
        title={t.consultant.title}
        hint={t.common.readOnlyHint}
      />
    );
  }

  const consolidated = consolidatedQuery.data;
  const clients = clientsQuery.data?.clients ?? [];
  const loading = consolidatedQuery.isLoading || clientsQuery.isLoading;
  const error = (consolidatedQuery.error ?? clientsQuery.error) as Error | null;

  const healthLabel = (h: string) =>
    ({ GOOD: t.consultant.good, WATCH: t.consultant.watch, CRITICAL: t.consultant.critical })[h] ??
    h;

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold text-navy">{t.consultant.title}</h1>
        <p className="mt-1 text-sm text-ink-soft">{t.consultant.subtitle}</p>
      </div>

      {loading && <SkeletonCards count={3} />}

      {error && (
        <ErrorState
          message={error.message}
          onRetry={() => {
            consolidatedQuery.refetch();
            clientsQuery.refetch();
          }}
          retryLabel={t.common.retry}
        />
      )}

      {/* KPIs consolidados */}
      {consolidated && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[
            { label: t.consultant.myClients, value: String(consolidated.totalClients) },
            { label: t.consultant.complianceAvg, value: `${consolidated.avgCompliance}%` },
            { label: t.consultant.totalNC, value: String(consolidated.totalNC) },
            {
              label: t.consultant.pendingTasks,
              value: String(consolidated.totalPendingTasks),
              sub: `${consolidated.clientsOnTrack} ${t.consultant.onTrack}`,
            },
          ].map((kpi, i) => (
            <div key={i} className="rounded-card border border-line bg-white p-4 shadow-card">
              <div className="text-xs font-semibold text-ink-muted">{kpi.label}</div>
              <div className="text-[26px] font-extrabold text-navy">{kpi.value}</div>
              {kpi.sub && <div className="text-[11.5px] text-ink-soft">{kpi.sub}</div>}
            </div>
          ))}
        </div>
      )}

      {/* Lista de clientes */}
      <Card title={`${t.consultant.myClients} · ${clients.length}`}>
        {clients.length === 0 ? (
          <EmptyState title={t.consultant.myClients} hint={t.consultant.subtitle} />
        ) : (
          <div className="mt-2 space-y-3">
            {clients.map((c) => (
              <div
                key={c.orgId}
                className={`rounded-btn border p-3 ${
                  selectedClient === c.orgId ? 'border-primary bg-info-bg' : 'border-line'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold">{c.name}</span>
                      <Badge tone="muted" dot={false}>
                        {c.planCode}
                      </Badge>
                      {orgId === c.orgId && <Badge tone="ok" dot={false}>●</Badge>}
                    </div>
                    <div className="mt-0.5 text-[11px] text-ink-muted">
                      {c.accessEnd &&
                        `${t.consultant.accessUntil}: ${new Date(c.accessEnd).toLocaleDateString()}`}
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-3">
                    <Badge tone={HEALTH_TONES[c.summary.health] ?? 'muted'}>
                      {healthLabel(c.summary.health)}
                    </Badge>
                    <div className="text-center">
                      <div className="text-lg font-extrabold text-navy">
                        {c.summary.compliancePct}%
                      </div>
                      <div className="text-[10px] text-ink-muted">
                        {t.consultant.complianceAvg}
                      </div>
                    </div>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() =>
                        setSelectedClient(selectedClient === c.orgId ? null : c.orgId)
                      }
                    >
                      {selectedClient === c.orgId ? t.common.close : t.consultant.openClient}
                    </Button>
                    <Button
                      size="sm"
                      variant="primary"
                      onClick={() => setOrgId(c.orgId)}
                      disabled={orgId === c.orgId}
                    >
                      {t.consultant.switchTo}
                    </Button>
                  </div>
                </div>

                {selectedClient === c.orgId && (
                  <div className="mt-3 grid grid-cols-2 gap-3 border-t border-line pt-3 text-center md:grid-cols-4">
                    {clientSummaryQuery.isLoading ? (
                      <div className="col-span-full text-xs text-ink-muted" role="status">
                        {t.common.loading}
                      </div>
                    ) : clientSummaryQuery.data ? (
                      [
                        {
                          l: t.dashboards.compliance,
                          v: `${clientSummaryQuery.data.compliancePct}%`,
                        },
                        { l: t.dashboards.openNC, v: String(clientSummaryQuery.data.ncOpen) },
                        { l: t.planning.risks, v: String(clientSummaryQuery.data.openRisks) },
                        {
                          l: t.dashboards.pendingTasks,
                          v: String(clientSummaryQuery.data.pendingTasks),
                        },
                      ].map((k, i) => (
                        <div key={i}>
                          <div className="text-lg font-bold text-navy">{k.v}</div>
                          <div className="text-[10px] text-ink-muted">{k.l}</div>
                        </div>
                      ))
                    ) : (
                      <div className="col-span-full">
                        <ErrorState message={(clientSummaryQuery.error as Error)?.message ?? ''} />
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
