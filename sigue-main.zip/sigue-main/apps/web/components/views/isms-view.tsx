'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useState } from 'react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { ConfirmButton } from '@/components/ui/confirm-button';
import { EmptyState, ErrorState, SkeletonCards } from '@/components/ui/states';

const CLASSIFICATIONS = {
  PUBLICO: 'publicClass',
  INTERNO: 'internalClass',
  CONFIDENCIAL: 'confidentialClass',
  SECRETO: 'secretClass',
} as const;

const ASSET_TYPES = {
  INFORMATION: 'typeInformation',
  SOFTWARE: 'typeSoftware',
  HARDWARE: 'typeHardware',
  SERVICE: 'typeService',
  PERSONNEL: 'typePersonnel',
  FACILITY: 'typeFacility',
} as const;

const SEVERITIES = {
  BAJA: 'low',
  MEDIA: 'medium',
  ALTA: 'high',
  CRITICA: 'critical',
} as const;

const INCIDENT_STATUSES = {
  OPEN: 'open',
  IN_PROGRESS: 'inProgress',
  RESOLVED: 'resolved',
  CLOSED: 'closed',
} as const;

export function IsmsView() {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const { canWrite } = usePermissions();
  const toast = useToast();
  const qc = useQueryClient();

  const [assetName, setAssetName] = useState('');
  const [assetType, setAssetType] = useState('INFORMATION');
  const [assetClass, setAssetClass] = useState('INTERNO');
  const [assetLocation, setAssetLocation] = useState('');
  const [incidentTitle, setIncidentTitle] = useState('');
  const [incidentDescription, setIncidentDescription] = useState('');
  const [incidentSeverity, setIncidentSeverity] = useState('MEDIA');

  const ismsQuery = useQuery({
    queryKey: ['isms', orgId],
    queryFn: () => api.isms(orgId!),
    enabled: !!orgId,
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['isms', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
    qc.invalidateQueries({ queryKey: ['dashboard-compliance', orgId] });
  };

  const onError = (err: unknown) =>
    toast.error(err instanceof Error ? err.message : t.common.saveError);

  const addAsset = useMutation({
    mutationFn: () =>
      api.addAsset(orgId!, {
        name: assetName,
        type: assetType,
        classification: assetClass,
        location: assetLocation || undefined,
      }),
    onSuccess: () => {
      refresh();
      setAssetName('');
      setAssetLocation('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeAsset = useMutation({
    mutationFn: (assetId: string) => api.deleteAsset(orgId!, assetId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  const updateSoa = useMutation({
    mutationFn: ({
      id,
      data,
    }: {
      id: string;
      data: { implementationStatus?: string; applicable?: boolean; justification?: string };
    }) => api.updateSoa(orgId!, id, data),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError,
  });

  const addIncident = useMutation({
    mutationFn: () =>
      api.addIsmsIncident(orgId!, {
        title: incidentTitle,
        description: incidentDescription || undefined,
        severity: incidentSeverity,
      }),
    onSuccess: () => {
      refresh();
      setIncidentTitle('');
      setIncidentDescription('');
      toast.success(t.common.saved);
    },
    onError,
  });

  const updateIncident = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) =>
      api.updateIsmsIncident(orgId!, id, { status }),
    onSuccess: () => {
      refresh();
      toast.success(t.common.saved);
    },
    onError,
  });

  const removeIncident = useMutation({
    mutationFn: (incidentId: string) => api.deleteIsmsIncident(orgId!, incidentId),
    onSuccess: () => {
      refresh();
      toast.success(t.common.deleted);
    },
    onError,
  });

  if (!orgId) return null;
  const d = ismsQuery.data;
  const soa = d?.soa ?? [];

  const severityLabel = (s: string) =>
    t.isms[SEVERITIES[s as keyof typeof SEVERITIES] ?? 'medium'];
  const statusLabel = (s: string) =>
    t.isms[INCIDENT_STATUSES[s as keyof typeof INCIDENT_STATUSES] ?? 'open'];

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-navy">{t.isms.title}</h1>
          <p className="mt-1 text-sm text-ink-soft">{t.isms.subtitle}</p>
        </div>
        {!canWrite && <p className="text-xs text-ink-muted">{t.common.readOnlyHint}</p>}
      </div>

      {ismsQuery.isLoading && <SkeletonCards count={2} />}

      {ismsQuery.isError && (
        <ErrorState
          message={(ismsQuery.error as Error).message}
          onRetry={() => ismsQuery.refetch()}
          retryLabel={t.common.retry}
        />
      )}

      {/* KPIs */}
      {d && (
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {[
            {
              label: t.isms.assets,
              value: String(d.assets.length),
              sub: `${d.assets.filter((a) => a.classification === 'CONFIDENCIAL' || a.classification === 'SECRETO').length} ${t.isms.confidentialClass.toLowerCase()}`,
            },
            {
              label: t.isms.soa,
              value: String(d.summary.applicable),
              sub: `${d.summary.total} ${t.isms.controlsOf}`,
            },
            {
              label: t.isms.soaProgress,
              value: `${d.summary.soaProgress}%`,
              sub: t.isms.implemented,
            },
            {
              label: t.isms.incidents,
              value: String(d.incidents.length),
              sub: `${d.incidents.filter((i) => i.status === 'OPEN').length} ${t.isms.open}`,
            },
          ].map((kpi, i) => (
            <div key={i} className="rounded-card border border-line bg-white p-4 shadow-card">
              <div className="text-xs font-semibold text-ink-muted">{kpi.label}</div>
              <div className="text-[26px] font-extrabold text-navy">{kpi.value}</div>
              {kpi.sub && <div className="text-[11.5px] text-ink-soft">{kpi.sub}</div>}
            </div>
          ))}
        </div>
      )}

      {/* Activos */}
      <Card title={t.isms.assets}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.isms.assetName}
              aria-label={t.isms.assetName}
              value={assetName}
              onChange={(e) => setAssetName(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <select
              value={assetType}
              onChange={(e) => setAssetType(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.isms.assetType}
            >
              {Object.entries(ASSET_TYPES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.isms[key]}
                </option>
              ))}
            </select>
            <select
              value={assetClass}
              onChange={(e) => setAssetClass(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.isms.classification}
            >
              {Object.entries(CLASSIFICATIONS).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.isms[key]}
                </option>
              ))}
            </select>
            <Input
              placeholder={t.isms.assetLocation}
              aria-label={t.isms.assetLocation}
              value={assetLocation}
              onChange={(e) => setAssetLocation(e.target.value)}
              className="w-40"
            />
            <Button
              onClick={() => addAsset.mutate()}
              disabled={!assetName || addAsset.isPending}
            >
              {t.isms.addAsset}
            </Button>
          </div>
        )}
        {canWrite && (
          <p className="mb-3 text-[11px] text-ink-muted">
            {t.isms.addAssetHint} {t.isms.classifiedHint}
          </p>
        )}

        {d && d.assets.length === 0 ? (
          <EmptyState title={t.isms.noAssets} />
        ) : (
          <div className="grid gap-2 md:grid-cols-2">
            {(d?.assets ?? []).map((a) => (
              <div
                key={a.id}
                className="flex items-start justify-between gap-2 rounded-btn border border-line px-3 py-2"
              >
                <div className="min-w-0">
                  <span className="text-sm font-medium">{a.name}</span>
                  <div className="text-[11px] text-ink-muted">
                    {t.isms[ASSET_TYPES[a.type as keyof typeof ASSET_TYPES] ?? 'typeInformation']}
                    {a.location ? ` · ${a.location}` : ''}
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-1.5">
                  <Badge
                    tone={
                      a.classification === 'CONFIDENCIAL' || a.classification === 'SECRETO'
                        ? 'warn'
                        : 'muted'
                    }
                  >
                    {
                      t.isms[
                        CLASSIFICATIONS[a.classification as keyof typeof CLASSIFICATIONS] ??
                          'internalClass'
                      ]
                    }
                  </Badge>
                  {canWrite && (
                    <ConfirmButton
                      confirmLabel={t.common.confirmDelete}
                      variant="ghost"
                      className="h-6 px-1.5 text-[11px]"
                      onConfirm={() => removeAsset.mutate(a.id)}
                    >
                      {t.common.delete}
                    </ConfirmButton>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* SOA */}
      <Card title={`${t.isms.soa} · ${d?.summary.soaProgress ?? 0}%`}>
        {d && soa.length === 0 ? (
          <EmptyState title={t.isms.noSoa} />
        ) : (
          <div className="-mx-1 overflow-x-auto">
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b-2 border-line-strong text-left text-[10.5px] uppercase tracking-wider text-ink-muted">
                  <th className="w-20 py-2">{t.isms.controlCode}</th>
                  <th>{t.isms.controlName}</th>
                  <th className="w-28">{t.isms.applicable}</th>
                  <th className="w-40">{t.isms.implementation}</th>
                  <th className="w-10" />
                </tr>
              </thead>
              <tbody>
                {soa.map((c) => (
                  <tr key={c.id} className="border-b border-line">
                    <td className="py-2 font-mono text-xs">{c.controlCode}</td>
                    <td className="py-2">
                      <div>{c.controlName}</div>
                      {c.justification && (
                        <div className="text-[10.5px] text-ink-muted">{c.justification}</div>
                      )}
                    </td>
                    <td className="py-2">
                      <select
                        value={c.applicable ? 'SI' : 'NO'}
                        onChange={(e) =>
                          updateSoa.mutate({
                            id: c.id,
                            data: { applicable: e.target.value === 'SI' },
                          })
                        }
                        disabled={!canWrite}
                        className="rounded-btn border border-line bg-white px-2 py-1 text-xs"
                        aria-label={`${t.isms.applicable} ${c.controlCode}`}
                      >
                        <option value="SI">{t.isms.applicable}</option>
                        <option value="NO">{t.isms.notApplicable}</option>
                      </select>
                    </td>
                    <td className="py-2">
                      <select
                        value={c.implementationStatus}
                        onChange={(e) =>
                          updateSoa.mutate({
                            id: c.id,
                            data: { implementationStatus: e.target.value },
                          })
                        }
                        disabled={!c.applicable || !canWrite}
                        className="rounded-btn border border-line bg-white px-2 py-1 text-xs"
                        aria-label={`${t.isms.implementation} ${c.controlCode}`}
                      >
                        <option value="NOT_IMPLEMENTED">{t.isms.notImplemented}</option>
                        <option value="PLANNED">{t.isms.planned}</option>
                        <option value="IMPLEMENTED">{t.isms.implemented}</option>
                      </select>
                    </td>
                    <td className="py-2 text-right">
                      <Badge
                        tone={
                          c.implementationStatus === 'IMPLEMENTED'
                            ? 'ok'
                            : c.implementationStatus === 'PLANNED'
                              ? 'warn'
                              : 'muted'
                        }
                        dot={false}
                      >
                        {c.applicable
                          ? c.implementationStatus === 'IMPLEMENTED'
                            ? '✓'
                            : '·'
                          : '—'}
                      </Badge>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Incidentes */}
      <Card title={t.isms.incidents}>
        {canWrite && (
          <div className="mb-3 flex flex-wrap items-end gap-2">
            <Input
              placeholder={t.isms.incidentTitle}
              aria-label={t.isms.incidentTitle}
              value={incidentTitle}
              onChange={(e) => setIncidentTitle(e.target.value)}
              className="min-w-[200px] flex-1"
            />
            <Input
              placeholder={t.isms.incidentDescription}
              aria-label={t.isms.incidentDescription}
              value={incidentDescription}
              onChange={(e) => setIncidentDescription(e.target.value)}
              className="min-w-[220px] flex-1"
            />
            <select
              value={incidentSeverity}
              onChange={(e) => setIncidentSeverity(e.target.value)}
              className="h-10 rounded-btn border border-line bg-white px-3 text-sm"
              aria-label={t.isms.severity}
            >
              {Object.entries(SEVERITIES).map(([value, key]) => (
                <option key={value} value={value}>
                  {t.isms[key]}
                </option>
              ))}
            </select>
            <Button
              onClick={() => addIncident.mutate()}
              disabled={!incidentTitle || addIncident.isPending}
            >
              {t.isms.addIncident}
            </Button>
          </div>
        )}

        {d && d.incidents.length === 0 ? (
          <EmptyState title={t.isms.noIncidents} />
        ) : (
          <div className="space-y-2">
            {(d?.incidents ?? []).map((inc) => (
              <div
                key={inc.id}
                className="flex flex-wrap items-start justify-between gap-2 border-b border-line px-1 py-2 last:border-0"
              >
                <div className="min-w-0">
                  <span className="text-sm font-medium">{inc.title}</span>
                  {inc.description && (
                    <div className="text-[11px] text-ink-soft">{inc.description}</div>
                  )}
                  <div className="text-[11px] text-ink-muted">
                    {t.isms.detectedAt}: {new Date(inc.detectedAt).toLocaleDateString()}
                    {inc.resolvedAt &&
                      ` · ${t.isms.resolvedAt}: ${new Date(inc.resolvedAt).toLocaleDateString()}`}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    tone={
                      inc.severity === 'CRITICA' || inc.severity === 'ALTA'
                        ? 'danger'
                        : inc.severity === 'MEDIA'
                          ? 'warn'
                          : 'muted'
                    }
                  >
                    {severityLabel(inc.severity)}
                  </Badge>
                  {canWrite ? (
                    <select
                      value={inc.status}
                      onChange={(e) =>
                        updateIncident.mutate({ id: inc.id, status: e.target.value })
                      }
                      className="rounded-btn border border-line bg-white px-2 py-1 text-xs"
                      aria-label={`${t.isms.status} ${inc.title}`}
                    >
                      {Object.entries(INCIDENT_STATUSES).map(([value, key]) => (
                        <option key={value} value={value}>
                          {t.isms[key]}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <Badge tone={inc.status === 'CLOSED' || inc.status === 'RESOLVED' ? 'ok' : 'info'}>
                      {statusLabel(inc.status)}
                    </Badge>
                  )}
                  {canWrite && (
                    <ConfirmButton
                      confirmLabel={t.common.confirmDelete}
                      variant="ghost"
                      className="h-6 px-1.5 text-[11px]"
                      onConfirm={() => removeIncident.mutate(inc.id)}
                    >
                      {t.common.delete}
                    </ConfirmButton>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
