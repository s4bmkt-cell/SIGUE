'use client';

import { useMutation } from '@tanstack/react-query';
import { useState } from 'react';
import { api, type MfaEnrollment } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useAuth } from '@/components/providers/auth-provider';
import { useToast } from '@/components/providers/toast-provider';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { SectionHeader } from '@/components/ui/states';

/**
 * Seguridad de la cuenta: activación y desactivación del segundo factor.
 *
 * El QR y la semilla los genera la API: la semilla pendiente se guarda cifrada
 * en la base, de modo que el código que se escribe se verifica contra el mismo
 * secreto que se mostró. Desactivar exige un código vigente, así que una sesión
 * robada no basta para quitar el segundo factor.
 */
export function SecurityView() {
  const { t } = useI18n();
  const { user, refreshUser } = useAuth();
  const toast = useToast();

  const [enrollment, setEnrollment] = useState<MfaEnrollment | null>(null);
  const [code, setCode] = useState('');
  const [disableOpen, setDisableOpen] = useState(false);
  const [disableCode, setDisableCode] = useState('');
  const [error, setError] = useState<string | null>(null);

  const enabled = !!user?.mfaEnabled;

  const startMutation = useMutation({
    mutationFn: () => api.mfaSetup(),
    onSuccess: (data) => {
      setEnrollment(data);
      setCode('');
      setError(null);
    },
    onError: (e: unknown) => setError(e instanceof Error ? e.message : t.common.saveError),
  });

  const confirmMutation = useMutation({
    mutationFn: () => api.mfaConfirm(code),
    onSuccess: async () => {
      setEnrollment(null);
      setCode('');
      setError(null);
      await refreshUser();
      toast.success(t.security.enabledToast);
    },
    onError: (e: unknown) => setError(e instanceof Error ? e.message : t.common.saveError),
  });

  const disableMutation = useMutation({
    mutationFn: () => api.mfaDisable(disableCode),
    onSuccess: async () => {
      setDisableOpen(false);
      setDisableCode('');
      setError(null);
      await refreshUser();
      toast.success(t.security.disabledToast);
    },
    onError: (e: unknown) => setError(e instanceof Error ? e.message : t.common.saveError),
  });

  const field = 'h-10 w-full rounded-btn border border-line px-3 text-sm text-ink tracking-[0.3em]';

  const onCodeChange = (value: string, set: (v: string) => void) =>
    set(value.replace(/\D/g, '').slice(0, 6));

  return (
    <div className="max-w-3xl space-y-6">
      <SectionHeader title={t.security.title} subtitle={t.security.subtitle} />

      {error && (
        <p className="rounded-btn bg-danger-bg px-3 py-2 text-sm text-danger" role="alert">
          {error}
        </p>
      )}

      <Card
        title={t.security.secondFactor}
        action={
          <Badge tone={enabled ? 'ok' : 'muted'}>
            {enabled ? t.security.active : t.security.inactive}
          </Badge>
        }
      >
        <p className="text-sm text-ink-soft">{t.security.description}</p>

        {!enabled && !enrollment && (
          <div className="mt-4">
            <Button onClick={() => startMutation.mutate()} disabled={startMutation.isPending}>
              {startMutation.isPending ? t.common.loading : t.security.start}
            </Button>
          </div>
        )}

        {!enabled && enrollment && (
          <div className="mt-5 space-y-4">
            <div className="flex flex-col gap-5 sm:flex-row">
              {/* El QR lo genera la API; el `alt` sirve de texto alternativo y
                  de punto de apoyo para las pruebas. */}
              <img
                src={enrollment.qrDataUrl}
                alt={t.security.qrAlt}
                width={180}
                height={180}
                className="size-[180px] rounded-btn border border-line bg-white p-2"
              />
              <div className="flex-1 space-y-3">
                <p className="text-sm font-semibold text-ink">{t.security.scanHint}</p>
                <div>
                  <p className="text-xs font-semibold uppercase tracking-wide text-ink-muted">
                    {t.security.manualSecret}
                  </p>
                  <code className="mt-1 block break-all rounded-btn bg-page px-3 py-2 font-mono text-sm text-ink">
                    {enrollment.secret}
                  </code>
                </div>
                <p className="text-xs text-ink-soft">{t.security.manualHint}</p>
              </div>
            </div>

            <form
              className="flex flex-wrap items-end gap-3 border-t border-line pt-4"
              onSubmit={(e) => {
                e.preventDefault();
                confirmMutation.mutate();
              }}
            >
              <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
                {t.security.codeLabel}
                <input
                  className={`${field} w-40`}
                  inputMode="numeric"
                  autoComplete="one-time-code"
                  aria-label={t.security.codeLabel}
                  value={code}
                  onChange={(e) => onCodeChange(e.target.value, setCode)}
                  placeholder="000000"
                />
              </label>
              <Button type="submit" disabled={confirmMutation.isPending || code.length !== 6}>
                {confirmMutation.isPending ? t.common.loading : t.security.confirm}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setEnrollment(null);
                  setCode('');
                }}
              >
                {t.common.cancel}
              </Button>
            </form>
          </div>
        )}

        {enabled && !disableOpen && (
          <div className="mt-4 space-y-3">
            <p className="text-sm text-ink-soft">{t.security.enabledHint}</p>
            <Button variant="outline" onClick={() => setDisableOpen(true)}>
              {t.security.disable}
            </Button>
          </div>
        )}

        {enabled && disableOpen && (
          <form
            className="mt-4 flex flex-wrap items-end gap-3 border-t border-line pt-4"
            onSubmit={(e) => {
              e.preventDefault();
              disableMutation.mutate();
            }}
          >
            <label className="flex flex-col gap-1.5 text-sm font-medium text-ink">
              {t.security.disableCodeLabel}
              <input
                className={`${field} w-40`}
                inputMode="numeric"
                autoComplete="one-time-code"
                aria-label={t.security.disableCodeLabel}
                value={disableCode}
                onChange={(e) => onCodeChange(e.target.value, setDisableCode)}
                placeholder="000000"
              />
            </label>
            <Button
              type="submit"
              variant="danger"
              disabled={disableMutation.isPending || disableCode.length !== 6}
            >
              {disableMutation.isPending ? t.common.loading : t.security.disableConfirm}
            </Button>
            <Button
              variant="outline"
              onClick={() => {
                setDisableOpen(false);
                setDisableCode('');
              }}
            >
              {t.common.cancel}
            </Button>
          </form>
        )}
      </Card>

      <Card title={t.security.recommendations}>
        <ul className="mt-2 list-disc space-y-1.5 pl-5 text-sm text-ink-soft">
          <li>{t.security.tipApp}</li>
          <li>{t.security.tipRecovery}</li>
          <li>{t.security.tipLogout}</li>
        </ul>
      </Card>
    </div>
  );
}
