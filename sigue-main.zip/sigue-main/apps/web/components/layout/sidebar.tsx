'use client';

import { useQuery } from '@tanstack/react-query';
import { useSyncExternalStore } from 'react';import { ChevronsLeft, ChevronsRight } from 'lucide-react';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { MenuIcon } from '@/components/layout/menu-icons';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions, type Permissions } from '@/lib/hooks/use-permissions';

/** Ancho de la barra en cada estado. `app/page.tsx` desplaza el contenido con estos valores. */
export const SIDEBAR_WIDTH = 264;
export const SIDEBAR_WIDTH_COLLAPSED = 76;

const STORAGE_KEY = 'sigue.sidebar.collapsed';

export type ViewKey =
  | 'home'
  | 'standards'
  | 'diagnosis'
  | 'context'
  | 'planning'
  | 'documents'
  | 'evidences'
  | 'audits'
  | 'nc'
  | 'review'
  | 'dashboards'
  | 'isms'
  | 'bcms'
  | 'itsm'
  | 'abms'
  | 'notifications'
  | 'ai-systems'
  | 'ai-governance'
  | 'subscription'
  | 'templates'
  | 'consultant'
  | 'org-admin'
  | 'platform'
  | 'security';

interface NavItem {
  view: ViewKey;
  icon: string;
  /** Si se define, el ítem solo aparece cuando el rol tiene ese permiso. */
  visible?: (p: Permissions) => boolean;
}

interface NavGroup {
  key: string;
  items: NavItem[];
}

/**
 * ¿Puede este rol abrir la vista? `app/page.tsx` lo usa para volver al inicio
 * cuando se cambia a una organización donde el rol no tiene acceso.
 */
export function canOpenView(view: ViewKey, perms: Permissions): boolean {
  for (const group of NAV) {
    const item = group.items.find((i) => i.view === view);
    if (item) return !item.visible || item.visible(perms);
  }
  return true;
}

const NAV: NavGroup[] = [
  {
    key: 'operations',
    items: [
      { view: 'home', icon: 'home' },
      { view: 'standards', icon: 'standards' },
      { view: 'diagnosis', icon: 'diagnosis' },
      { view: 'context', icon: 'context' },
      { view: 'planning', icon: 'planning' },
      { view: 'documents', icon: 'documents' },
      { view: 'templates', icon: 'templates' },
      { view: 'evidences', icon: 'evidences' },
      { view: 'isms', icon: 'isms' },
      { view: 'bcms', icon: 'bcms' },
      { view: 'itsm', icon: 'itsm' },
      { view: 'abms', icon: 'abms' },
      { view: 'ai-systems', icon: 'ai-systems' },
      { view: 'ai-governance', icon: 'ai-governance' },
      { view: 'consultant', icon: 'consultant', visible: (p) => p.has(['consultor_externo', 'admin_org']) },
      {
        view: 'subscription',
        icon: 'subscription',
        visible: (p) => p.isGlobalAdmin || p.has(['admin_org', 'alta_direccion']),
      },
    ],
  },
  {
    key: 'verify',
    items: [
      { view: 'audits', icon: 'audits' },
      { view: 'nc', icon: 'nc' },
      { view: 'review', icon: 'review' },
      { view: 'dashboards', icon: 'dashboards' },
    ],
  },
  {
    key: 'config',
    items: [
      // Se muestra a todo el mundo a propósito: quien no administra la
      // organización activa encuentra ahí el motivo y el atajo a una que sí
      // administra. Ocultarlo convertía el clic del menú en un no-op mudo.
      { view: 'org-admin', icon: 'organization' },
      // Panel de plataforma: solo para el administrador global. Ve todas las
      // empresas, no el contenido de ninguna.
      { view: 'platform', icon: 'platform', visible: (p) => p.isGlobalAdmin },
      // La seguridad de la propia cuenta no depende del rol: todo usuario
      // puede activar su segundo factor.
      { view: 'security', icon: 'security' },
      { view: 'notifications', icon: 'notifications' },
    ],
  },
];

/**
 * Estado de plegado de la barra.
 *
 * Vive en `localStorage` y se lee con `useSyncExternalStore`: es la forma
 * correcta de consumir un almacén externo (el propio navegador) sin provocar
 * saltos de hidratación ni `setState` dentro de un efecto. En el servidor el
 * snapshot es siempre «expandida», que es también el estado con el que se pinta
 * la primera vez en el cliente.
 */
const SIDEBAR_EVENT = 'sigue:sidebar';

function subscribeSidebar(callback: () => void) {
  window.addEventListener(SIDEBAR_EVENT, callback);
  window.addEventListener('storage', callback);
  return () => {
    window.removeEventListener(SIDEBAR_EVENT, callback);
    window.removeEventListener('storage', callback);
  };
}

const getCollapsed = () => {
  try {
    return window.localStorage.getItem(STORAGE_KEY) === '1';
  } catch {
    // Modo privado o almacenamiento bloqueado: la barra simplemente no recuerda.
    return false;
  }
};

const getCollapsedOnServer = () => false;

export function useSidebarCollapsed() {
  return useSyncExternalStore(subscribeSidebar, getCollapsed, getCollapsedOnServer);
}

export function setSidebarCollapsed(collapsed: boolean) {
  try {
    window.localStorage.setItem(STORAGE_KEY, collapsed ? '1' : '0');
  } catch {
    // Sin persistencia: el cambio sigue aplicando durante la sesión vía evento.
  }
  window.dispatchEvent(new Event(SIDEBAR_EVENT));
}

export function Sidebar({
  currentView,
  onNavigate,
}: {
  currentView: ViewKey;
  onNavigate: (v: ViewKey) => void;
}) {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const perms = usePermissions();
  const collapsed = useSidebarCollapsed();

  // El contador de NC abiertas sale del servidor, no de una constante.
  const ncQuery = useQuery({
    queryKey: ['nc', orgId],
    queryFn: () => api.ncs(orgId!),
    enabled: !!orgId,
    staleTime: 60_000,
  });
  const openNc = (ncQuery.data ?? []).filter(
    (nc) => nc.status !== 'CLOSED',
  ).length;

  const labelFor = (v: ViewKey) =>
    ({
      home: t.nav.home,
      standards: t.nav.standards,
      diagnosis: t.nav.diagnosis,
      context: t.context.navLabel,
      planning: t.planning.title,
      documents: t.documents.title,
      templates: t.documents.templates,
      evidences: t.evidences.title,
      audits: t.audits.title,
      nc: t.nc.title,
      review: t.review.title,
      dashboards: t.dashboards.title,
      isms: 'ISO/IEC 27001',
      bcms: 'ISO 22301',
      itsm: 'ISO/IEC 20000-1',
      abms: 'ISO 37001',
      notifications: t.notif.title,
      'ai-systems': 'ISO/IEC 42001',
      'ai-governance': t.aiGovernance.title,
      consultant: t.consultant.title,
      subscription: t.billing.title,
      'org-admin': t.orgAdmin.title,
      platform: t.platform.title,
      security: t.security.title,
    })[v];

  return (
    <aside
      className="fixed left-0 top-0 bottom-0 z-20 flex flex-col border-r border-white/[0.07] bg-gradient-to-b from-navy to-[#00112f] text-white transition-[width] duration-200 ease-out"
      style={{ width: collapsed ? SIDEBAR_WIDTH_COLLAPSED : SIDEBAR_WIDTH }}
    >
      {/* Marca. Plegada queda solo el isotipo, centrado. El botón de plegado
          vive aquí arriba: abajo lo tapaba el indicador de Next en desarrollo y
          fuera del riel lo tapaba la topbar (`z-40`). */}
      <div
        className={`flex h-[74px] shrink-0 items-center border-b border-white/10 ${
          collapsed ? 'justify-center px-2' : 'gap-3 pl-5 pr-1.5'
        }`}
      >
        <img
          src="/S.png"
          alt="SIGN"
          width={38}
          height={38}
          className="shrink-0 rounded-lg object-contain"
        />
        {!collapsed && (
          <div className="min-w-0 flex-1">
            <div className="text-[15px] font-extrabold tracking-[0.28em]">SIGN</div>
            <div className="mt-0.5 truncate text-[9px] tracking-[0.24em] text-white/45">
              {t.common.appTagline}
            </div>
          </div>
        )}
        <button
          type="button"
          onClick={() => setSidebarCollapsed(!collapsed)}
          aria-expanded={!collapsed}
          aria-label={collapsed ? t.nav.expand : t.nav.collapse}
          title={collapsed ? t.nav.expand : t.nav.collapse}
          className={`flex size-8 shrink-0 items-center justify-center rounded-lg text-white/45 transition-colors hover:bg-white/10 hover:text-white ${
            collapsed ? 'hidden' : ''
          }`}
        >
          <ChevronsLeft className="size-4" strokeWidth={2} aria-hidden="true" />
        </button>
      </div>

      {/* Plegada, el botón ocupa su propia fila bajo la marca: dentro del riel
          no choca con la topbar y queda alcanzable sin abrir el menú. */}
      {collapsed && (
        <button
          type="button"
          onClick={() => setSidebarCollapsed(false)}
          aria-expanded={false}
          aria-label={t.nav.expand}
          title={t.nav.expand}
          className="mx-2 mt-2 flex h-8 shrink-0 items-center justify-center rounded-lg text-white/45 transition-colors hover:bg-white/10 hover:text-white"
        >
          <ChevronsRight className="size-4" strokeWidth={2} aria-hidden="true" />
        </button>
      )}

      {/* Navegación */}
      <nav
        className={`sidebar-nav flex-1 space-y-0.5 overflow-y-auto overflow-x-hidden ${
          collapsed ? 'px-2 py-2' : 'px-3 py-2'
        }`}
      >
        {NAV.map((group, groupIndex) => (
          <div key={group.key}>
            {collapsed ? (
              // Plegada no caben los títulos: un separador mantiene la agrupación.
              groupIndex > 0 && <div className="mx-2 my-2 border-t border-white/10" />
            ) : (
              <div className="px-3 pb-1 pt-4 text-[10px] font-bold uppercase tracking-[0.15em] text-white/35">
                {t.nav[group.key as keyof typeof t.nav] ?? ''}
              </div>
            )}
            {group.items
              .filter((item) => !item.visible || item.visible(perms))
              .map((item) => {
                const active = currentView === item.view;
                const count = item.view === 'nc' && openNc > 0 ? openNc : null;
                const label = labelFor(item.view);
                return (
                  <button
                    key={item.view}
                    onClick={() => onNavigate(item.view)}
                    title={collapsed ? label : undefined}
                    className={`group relative flex w-full items-center rounded-lg text-[13px] transition-colors ${
                      collapsed ? 'h-10 justify-center px-0' : 'gap-3 px-3 py-2'
                    } ${
                      active
                        ? 'bg-primary font-semibold text-white shadow-[0_6px_16px_-10px_rgba(47,102,235,.9)]'
                        : 'text-white/70 hover:bg-white/[0.08] hover:text-white'
                    }`}
                  >
                    {/* Barra de acento: señal de sección activa sin depender del color. */}
                    <span
                      aria-hidden="true"
                      className={`absolute left-0 top-1/2 h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-white transition-opacity ${
                        active ? 'opacity-90' : 'opacity-0'
                      }`}
                    />
                    <span className="relative flex size-5 shrink-0 items-center justify-center">
                      <MenuIcon name={item.icon} className="size-[18px]" />
                      {collapsed && count != null && (
                        <span className="absolute -right-1 -top-1 size-2 rounded-full bg-danger ring-2 ring-navy" />
                      )}
                    </span>
                    <span className={collapsed ? 'sr-only' : 'flex-1 text-left'}>{label}</span>
                    {!collapsed && count != null && (
                      <span className="rounded-full bg-danger px-2 py-0.5 text-[10px] font-bold tabular-nums text-white">
                        {count}
                      </span>
                    )}
                  </button>
                );
              })}
          </div>
        ))}
      </nav>
    </aside>
  );
}
