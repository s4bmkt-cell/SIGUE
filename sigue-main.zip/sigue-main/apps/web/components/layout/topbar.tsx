'use client';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useEffect, useRef, useState } from 'react';
import { api, type AuthUser, type AiSearchResult } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { useToast } from '@/components/providers/toast-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { roleLabel } from '@/lib/roles';
import { canOpenView, type ViewKey } from '@/components/layout/sidebar';

interface SearchHit {
  id: string;
  title: string;
  sub: string;
  target: ViewKey;
}

/** Tipos de notificación → vista donde se resuelven. */
const NOTIF_TARGETS: Record<string, ViewKey> = {
  TASK: 'planning',
  REMINDER: 'planning',
  APPROVAL: 'documents',
  ALERT: 'nc',
  ESCALATION: 'nc',
};

/** Origen de un resultado de búsqueda → vista donde vive el registro. */
const HIT_TARGETS: Record<string, ViewKey> = {
  document: 'documents',
  evidence: 'evidences',
  requirement: 'standards',
  nc: 'nc',
  risk: 'planning',
};

function sourceLabel(s: string, locale: string) {
  const es: Record<string, string> = {
    document: 'documento',
    evidence: 'evidencia',
    requirement: 'requisito',
    nc: 'NC',
    risk: 'riesgo',
  };
  const en: Record<string, string> = {
    document: 'document',
    evidence: 'evidence',
    requirement: 'requirement',
    nc: 'NC',
    risk: 'risk',
  };
  return (locale === 'en-US' ? en : es)[s] ?? s;
}

function timeAgo(iso: string | null, locale: string) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.max(1, Math.round(diff / 60000));
  if (mins < 60) return `${mins} ${locale === 'en-US' ? 'min' : 'min'}`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `${hours} h`;
  const days = Math.round(hours / 24);
  return `${days} ${locale === 'en-US' ? 'd' : 'd'}`;
}

// Roles legibles: lista única en `lib/roles.ts`, compartida con org-admin.

export function Topbar({
  user,
  onSignOut,
  onNavigate,
}: {
  user: AuthUser;
  onSignOut: () => void;
  onNavigate: (v: ViewKey) => void;
}) {
  const { locale, setLocale } = useI18n();
  const { t } = useI18n();
  const toast = useToast();
  const { orgId, org, organizations, setOrgId } = useActiveOrg();
  const perms = usePermissions();
  // La suscripción la ven admin y alta dirección (además del admin de
  // plataforma, cuyo rol no figura en la membresía).
  const canSeeSubscription = canOpenView('subscription', perms);
  const qc = useQueryClient();

  const [q, setQ] = useState('');
  const [hits, setHits] = useState<SearchHit[]>([]);
  // Término con el que se calculó `hits`; permite derivar "buscando" sin setState en el efecto.
  const [hitsFor, setHitsFor] = useState('');
  const [searchOpen, setSearchOpen] = useState(false);
  const [notifOpen, setNotifOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const searchTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Cierra los popovers cuando la navegación proviene de fuera de la Topbar (sidebar).
  useEffect(() => {
    const close = () => {
      setSearchOpen(false);
      setNotifOpen(false);
      setUserMenuOpen(false);
    };
    window.addEventListener('sigue:nav', close);
    return () => window.removeEventListener('sigue:nav', close);
  }, []);

  // Búsqueda global (debounce). El índice lo sirve la API sobre los datos reales
  // de la organización; sin resultados se dice explícitamente, sin inventarlos.
  useEffect(() => {
    if (searchTimer.current) clearTimeout(searchTimer.current);
    const term = q.trim();
    if (term.length < 2 || !orgId) return;
    searchTimer.current = setTimeout(async () => {
      try {
        const results = await api.aiSearch(orgId, term);
        setHits(
          results.map((r: AiSearchResult) => ({
            id: r.id,
            title: r.title,
            sub: sourceLabel(r.sourceType, locale),
            target: HIT_TARGETS[r.sourceType] ?? 'standards',
          })),
        );
      } catch {
        setHits([]);
      } finally {
        setHitsFor(term);
      }
    }, 250);
    return () => {
      if (searchTimer.current) clearTimeout(searchTimer.current);
    };
  }, [q, orgId, locale]);

  const searchTerm = q.trim();
  const searching = searchTerm.length >= 2 && hitsFor !== searchTerm;

  const notifQuery = useQuery({
    queryKey: ['notifications', orgId],
    queryFn: () => api.notifications(orgId!),
    enabled: !!orgId,
  });

  const notifItems = notifQuery.data?.items ?? [];
  const unread = notifQuery.data?.unread ?? 0;

  const invalidateNotifications = () => {
    qc.invalidateQueries({ queryKey: ['notifications', orgId] });
    qc.invalidateQueries({ queryKey: ['notifications-page', orgId] });
  };

  const markAllMutation = useMutation({
    mutationFn: () => api.markAllNotificationsRead(orgId!),
    onSuccess: invalidateNotifications,
  });

  const markOneMutation = useMutation({
    mutationFn: (id: string) => api.markNotificationRead(orgId!, id),
    onSuccess: invalidateNotifications,
  });

  const initials = user.name
    .split(' ')
    .map((word) => word[0])
    .slice(0, 2)
    .join('')
    .toUpperCase();

  // Los roles del token son los del usuario, no los de la organización activa:
  // el rol que se muestra junto al nombre es el de esta organización.
  const activeRoles = org?.roles?.length ? org.roles : user.roles;
  const roleName = activeRoles.length
    ? roleLabel(activeRoles[0], locale)
    : locale === 'en-US'
      ? 'Viewer'
      : 'Consulta';

  const go = (view: ViewKey) => {
    setSearchOpen(false);
    setNotifOpen(false);
    setUserMenuOpen(false);
    // `page.tsx` no puede abrir una vista que el rol no permite y volvería al
    // inicio en silencio; aquí se explica por qué no pasa nada.
    if (!canOpenView(view, perms)) {
      toast.error(t.common.noAccess);
      return;
    }
    onNavigate(view);
  };

  const openNotification = (id: string, target: ViewKey, read: boolean) => {
    if (!read) markOneMutation.mutate(id);
    go(target);
  };

  return (
    <header className="topbar">
      {(searchOpen || notifOpen || userMenuOpen) && (
        <div
          className="fixed inset-0 z-[1]"
          aria-hidden="true"
          onClick={() => {
            setSearchOpen(false);
            setNotifOpen(false);
            setUserMenuOpen(false);
          }}
        />
      )}

      {/* Búsqueda global */}
      <div className="topbar-search-wrap">
        <div className="topbar-search">
          <svg viewBox="0 0 24 24" aria-hidden="true">
            <circle cx="11" cy="11" r="6.5" />
            <path d="m16 16 4.5 4.5" />
          </svg>
          <input
            type="search"
            value={q}
            onChange={(e) => {
              setQ(e.target.value);
              setSearchOpen(e.target.value.trim().length >= 2);
            }}
            onFocus={() => q.trim().length >= 2 && setSearchOpen(true)}
            placeholder={t.topbar.searchPlaceholder}
            aria-label={t.topbar.searchTitle}
          />
          {searching && <span className="topbar-search-spinner" aria-label={t.topbar.searching} />}
        </div>
        {searchOpen && q.trim().length >= 2 && (
          <div className="topbar-search-results">
            {searching ? (
              <div className="topbar-dropdown-empty">{t.topbar.searching}</div>
            ) : hits.length === 0 ? (
              <div className="topbar-dropdown-empty">{t.topbar.noResults}</div>
            ) : (
              hits.map((hit) => (
                <button key={hit.id} className="topbar-hit" onClick={() => go(hit.target)}>
                  <span className="topbar-hit-title">{hit.title}</span>
                  <span className="topbar-hit-sub">{hit.sub}</span>
                </button>
              ))
            )}
          </div>
        )}
      </div>

      <div className="topbar-actions">
        {/* Selector de organización: un consultor puede entrar a cada cliente. */}
        {organizations.length > 1 && (
          <select
            className="topbar-org-select"
            value={orgId ?? ''}
            onChange={(e) => setOrgId(e.target.value)}
            aria-label={t.topbar.activeOrganization}
          >
            {organizations.map((o) => (
              <option key={o.id} value={o.id}>
                {o.name}
              </option>
            ))}
          </select>
        )}

        <button
          type="button"
          className="topbar-lang"
          aria-label={t.topbar.changeLanguage}
          onClick={() => setLocale(locale === 'es-MX' ? 'en-US' : 'es-MX')}
        >
          {locale === 'es-MX' ? 'ES' : 'EN'}
          <span aria-hidden="true">⌄</span>
        </button>

        {/* Notificaciones */}
        <div className="topbar-pop-root">
          <button
            type="button"
            className="topbar-icon"
            aria-label={t.topbar.notifications}
            aria-expanded={notifOpen}
            onClick={() => setNotifOpen((open) => !open)}
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <path d="M18 9a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9M10 21h4" />
            </svg>
            {unread > 0 && <span className="topbar-badge">{unread}</span>}
          </button>
          {notifOpen && (
            <div className="topbar-pop topbar-notif-pop">
              <div className="topbar-pop-head">
                <strong>{t.topbar.notifications}</strong>
                {unread > 0 && (
                  <button
                    type="button"
                    onClick={() => markAllMutation.mutate()}
                    disabled={!orgId || markAllMutation.isPending}
                    className="topbar-pop-link"
                  >
                    {t.topbar.markAllRead}
                  </button>
                )}
              </div>
              <ul className="topbar-notif-list">
                {notifItems.length === 0 && (
                  <li className="topbar-dropdown-empty">{t.topbar.noNotifications}</li>
                )}
                {notifItems.slice(0, 5).map((n) => {
                  const target = NOTIF_TARGETS[n.type] ?? 'nc';
                  return (
                    <li key={n.id}>
                      <button
                        className={`topbar-notif-item ${!n.readAt ? 'topbar-notif-unread' : ''}`}
                        onClick={() => openNotification(n.id, target, !!n.readAt)}
                      >
                        <span className="topbar-notif-copy">
                          <strong>{n.title}</strong>
                          {n.body && <span>{n.body}</span>}
                        </span>
                        <span className="topbar-notif-when">{timeAgo(n.createdAt ?? null, locale)}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
              <button type="button" className="topbar-pop-footer" onClick={() => go('notifications')}>
                {t.home.viewAll}
              </button>
            </div>
          )}
        </div>

        <span className="topbar-divider" aria-hidden="true" />

        {/* Usuario */}
        <div className="topbar-pop-root">
          <button
            type="button"
            className="topbar-user"
            onClick={() => setUserMenuOpen((open) => !open)}
            aria-expanded={userMenuOpen}
          >
            <span className="topbar-avatar">{initials}</span>
            <span className="topbar-user-copy">
              <strong>{user.name}</strong>
              <small>
                {roleName} · {org?.name ?? '—'}
              </small>
            </span>
            <span className="topbar-chevron" aria-hidden="true">
              ⌄
            </span>
          </button>
          {userMenuOpen && (
            <div className="topbar-user-menu">
              {/* Solo se ofrecen los destinos que el rol puede abrir en esta
                  organización: un colaborador no administra el plan ni los
                  usuarios, y el clic no tendría efecto. */}
              {canSeeSubscription && (
                <button type="button" onClick={() => go('subscription')}>
                  {t.topbar.mySubscription}
                </button>
              )}
              <button type="button" onClick={() => go('security')}>
                {t.topbar.security}
              </button>
              {canOpenView('org-admin', perms) && (
                <button type="button" onClick={() => go('org-admin')}>
                  {t.orgAdmin.title}
                </button>
              )}
              <button type="button" onClick={onSignOut}>
                {t.topbar.signOut}
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
