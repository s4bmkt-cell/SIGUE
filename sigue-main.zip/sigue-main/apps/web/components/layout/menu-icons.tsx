'use client';

// Iconos del menú (SVG inline, estilo Lucide, trazo uniforme).
// Heredan el color actual (currentColor) para integrarse con la barra navy.

const PATHS: Record<string, React.ReactNode> = {
  // Inicio
  home: (
    <>
      <path d="M3 10.5 12 3l9 7.5" />
      <path d="M5 9.5V21h14V9.5" />
      <path d="M9 21v-6h6v6" />
    </>
  ),
  // Normas y requisitos
  standards: (
    <>
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
      <path d="M9 7h7M9 11h7M9 15h4" />
    </>
  ),
  // Diagnóstico inicial
  diagnosis: (
    <>
      <path d="M4 6h16M4 12h10M4 18h6" />
      <path d="m17 11 3 3 3-3" />
    </>
  ),
  // Contexto de la organización
  context: (
    <>
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" />
    </>
  ),
  // Contexto · FODA
  swot: (
    <>
      <path d="M4 5h6v6H4zM14 5h6v6h-6zM4 13h6v6H4zM14 13h6v6h-6z" />
      <path d="m13 7 1 1M12 15l-1-1" />
    </>
  ),
  // Contexto · PESTEL
  pestel: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3.5 9h17M3.5 15h17" />
      <path d="M12 3c2.2 2.4 3.3 5.4 3.3 9s-1.1 6.6-3.3 9c-2.2-2.4-3.3-5.4-3.3-9S9.8 5.4 12 3z" />
    </>
  ),
  // Contexto · Partes interesadas
  parties: (
    <>
      <circle cx="9" cy="8" r="3.2" />
      <path d="M3 20v-1.5A4.5 4.5 0 0 1 7.5 14h3A4.5 4.5 0 0 1 15 18.5V20" />
      <circle cx="17.5" cy="9.5" r="2.4" />
      <path d="M16 14.2a4 4 0 0 1 5 3.9V20" />
    </>
  ),
  // Contexto · Requisitos legales
  legal: (
    <>
      <path d="M12 3v18M5 21h14" />
      <path d="M4 7h6l-3 6a3 3 0 0 0 6 0L10 7" />
      <path d="M14 7h6l-3 6a3 3 0 0 0 6 0l-3-6" />
    </>
  ),
  // Contexto · Cuestiones internas y externas
  issues: (
    <>
      <path d="M12 3 3 8l9 5 9-5z" />
      <path d="M3 12.5 12 17.5l9-5M3 17 12 22l9-5" />
    </>
  ),
  // Contexto · Mapa de procesos
  processes: (
    <>
      <rect x="3" y="3" width="7" height="5" rx="1.2" />
      <rect x="14" y="9.5" width="7" height="5" rx="1.2" />
      <rect x="3" y="16" width="7" height="5" rx="1.2" />
      <path d="M10 5.5h2a2 2 0 0 1 2 2v4.5M10 18.5h2a2 2 0 0 0 2-2v-4.5" />
    </>
  ),
  // Planificación
  planning: (
    <>
      <path d="M12 2v4M12 18v4M2 12h4M18 12h4" />
      <circle cx="12" cy="12" r="4" />
    </>
  ),
  // Información documentada
  documents: (
    <>
      <path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z" />
      <path d="M14 3v6h6" />
      <path d="M9 13h6M9 17h4" />
    </>
  ),
  // Plantillas
  templates: (
    <>
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <path d="M3 9h18M9 21V9" />
    </>
  ),
  // Evidencias
  evidences: (
    <>
      <path d="m21 12-8.5 8.5a2.1 2.1 0 0 1-3-3L17 9a4 4 0 0 1 5.7 5.7L14 23" />
      <path d="M7.5 3.5a4.4 4.4 0 0 1 6.2 0l5.6 5.6" />
    </>
  ),
  // ISO/IEC 27001 (ISMS)
  isms: (
    <>
      <path d="M12 3 5 6v5c0 4.5 3 8.2 7 10 4-1.8 7-5.5 7-10V6z" />
      <path d="m9 12 2 2 4-4" />
    </>
  ),
  // ISO 22301 (BCMS)
  bcms: (
    <>
      <path d="M13 2 4.5 13.5H11L9.5 22 19 9.5h-6.5z" />
    </>
  ),
  // ISO/IEC 20000-1 (gestión de servicios de TI)
  itsm: (
    <>
      <rect x="2.5" y="4" width="19" height="13" rx="2" />
      <path d="M8 21h8M12 17v4" />
      <path d="M8.5 8.5h7M8.5 12h4" />
    </>
  ),
  // ISO 37001 (antisoborno)
  abms: (
    <>
      <path d="M12 3 5 6v5c0 4.5 3 8.2 7 10 4-1.8 7-5.5 7-10V6z" />
      <path d="M12 8v5M12 16.5v.01" />
    </>
  ),
  // ISO/IEC 42001 (Sistemas de IA)
  'ai-systems': (
    <>
      <rect x="5" y="8" width="14" height="11" rx="2" />
      <path d="M12 8V5M9 5h6M12 15.5v.01" />
      <circle cx="12" cy="12" r="1.6" />
    </>
  ),
  // Gobernanza de IA
  'ai-governance': (
    <>
      <path d="M12 3 5 6v5c0 4.5 3 8.2 7 10 4-1.8 7-5.5 7-10V6z" />
      <path d="m9 12 2 2 4-4" />
    </>
  ),
  // Consola Consultor
  consultant: (
    <>
      <path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2" />
      <circle cx="10" cy="7" r="4" />
      <path d="M21 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
    </>
  ),
  // Suscripción
  subscription: (
    <>
      <rect x="2" y="5" width="20" height="14" rx="2" />
      <path d="M2 10h20" />
      <path d="M6 15h4" />
    </>
  ),
  // Auditorías
  audits: (
    <>
      <path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2" />
      <rect x="9" y="3" width="6" height="4" rx="1" />
      <path d="m9 14 2 2 4-4" />
    </>
  ),
  // No conformidades
  nc: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="m9 9 6 6M15 9l-6 6" />
    </>
  ),
  // Revisión por la dirección
  review: (
    <>
      <path d="M3 12a9 9 0 0 1 15.5-6.2L21 8" />
      <path d="M21 3v5h-5" />
      <path d="M21 12a9 9 0 0 1-15.5 6.2L3 16" />
      <path d="M3 21v-5h5" />
    </>
  ),
  // Tableros
  dashboards: (
    <>
      <rect x="3" y="3" width="7" height="7" rx="1.5" />
      <rect x="14" y="3" width="7" height="7" rx="1.5" />
      <rect x="3" y="14" width="7" height="7" rx="1.5" />
      <rect x="14" y="14" width="7" height="7" rx="1.5" />
    </>
  ),
  // Notificaciones
  notifications: (
    <>
      <path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
      <path d="M13.7 21a2 2 0 0 1-3.4 0" />
    </>
  ),
  // Usuarios y organización
  organization: (
    <>
      <circle cx="9" cy="8" r="3.2" />
      <path d="M3 20a6 6 0 0 1 12 0" />
      <path d="M16 5.5a3 3 0 0 1 0 5.8M18 20a5.5 5.5 0 0 0-2-4.3" />
    </>
  ),
  // Seguridad de la cuenta (MFA)
  security: (
    <>
      <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
      <path d="M9.5 12.2l1.8 1.8L15 10.2" />
    </>
  ),
  // Panel de plataforma (catálogo de empresas)
  platform: (
    <>
      <path d="M3 21h18" />
      <path d="M5 21V7l7-4 7 4v14" />
      <path d="M9 21v-5h6v5" />
      <path d="M9 11h.01M15 11h.01" />
    </>
  ),
};

export function MenuIcon({ name, className }: { name: string; className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {PATHS[name] ?? null}
    </svg>
  );
}
