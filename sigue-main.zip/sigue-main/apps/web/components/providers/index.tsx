'use client';

import { MutationCache, QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { useState } from 'react';
import { I18nProvider, useI18n } from '@/components/providers/i18n-provider';
import { ToastProvider, useToast } from '@/components/providers/toast-provider';
import { SessionExpiredError } from '@/lib/api/client';
import { ActiveOrgProvider } from '@/lib/hooks/use-active-org';

/**
 * Arma el `QueryClient` con el aviso de errores ya cableado.
 *
 * Los fallos de lectura se muestran en la propia vista (cada una tiene su
 * `ErrorState` con botón de reintento). Los fallos de mutación no deben perderse:
 * si una vista no los reporta explícitamente, el toast los muestra. Las
 * mutaciones que ya avisan por su cuenta pasan `meta: { silent: true }`.
 */
function QueryClientProviderWithToasts({ children }: { children: React.ReactNode }) {
  const toast = useToast();
  const { t } = useI18n();
  const [client] = useState(
    () =>
      new QueryClient({
        defaultOptions: {
          queries: {
            staleTime: 30_000,
            retry: 1,
            refetchOnWindowFocus: false,
          },
        },
        mutationCache: new MutationCache({
          onError: (error, _vars, _ctx, mutation) => {
            if (mutation.meta?.silent) return;
            // La sesión expirada la maneja el AuthProvider (redirige al login).
            if (error instanceof SessionExpiredError) return;
            toast.error(error instanceof Error ? error.message : t.common.saveError);
          },
        }),
      }),
  );

  return <QueryClientProvider client={client}>{children}</QueryClientProvider>;
}

export function Providers({ children }: { children: React.ReactNode }) {
  // El i18n envuelve a la capa de consultas para que los avisos globales de
  // error puedan traducirse con las mismas cadenas que las vistas.
  return (
    <I18nProvider>
      <ToastProvider>
        <QueryClientProviderWithToasts>
          <ActiveOrgProvider>{children}</ActiveOrgProvider>
        </QueryClientProviderWithToasts>
      </ToastProvider>
    </I18nProvider>
  );
}
