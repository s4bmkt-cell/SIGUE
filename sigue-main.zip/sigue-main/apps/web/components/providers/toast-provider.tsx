'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { useI18n } from '@/components/providers/i18n-provider';

type Tone = 'success' | 'error' | 'info';

interface ToastItem {
  id: number;
  tone: Tone;
  text: string;
}

interface ToastContextValue {
  success: (text: string) => void;
  error: (text: string) => void;
  info: (text: string) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

const TONES: Record<Tone, { box: string; icon: string; label: string }> = {
  success: {
    box: 'border-success/30 bg-white text-ink',
    icon: 'bg-success-bg text-success',
    label: '✓',
  },
  error: {
    box: 'border-danger/30 bg-white text-ink',
    icon: 'bg-danger-bg text-danger',
    label: '!',
  },
  info: {
    box: 'border-info/30 bg-white text-ink',
    icon: 'bg-info-bg text-info',
    label: 'i',
  },
};

/**
 * Avisos efímeros de resultado de una operación.
 *
 * Los errores se muestran también junto al formulario que los produjo; el toast
 * es el canal transversal para las acciones que no tienen un lugar natural donde
 * reportar (cambiar rol, borrar un registro, marcar notificaciones).
 */
export function ToastProvider({ children }: { children: React.ReactNode }) {
  const { t } = useI18n();
  const [items, setItems] = useState<ToastItem[]>([]);
  const nextId = useRef(1);
  const timers = useRef(new Map<number, ReturnType<typeof setTimeout>>());

  const dismiss = useCallback((id: number) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
    const timer = timers.current.get(id);
    if (timer) clearTimeout(timer);
    timers.current.delete(id);
  }, []);

  const push = useCallback(
    (tone: Tone, text: string) => {
      const id = nextId.current++;
      setItems((prev) => [...prev.slice(-3), { id, tone, text }]);
      // Un error merece más tiempo de lectura que una confirmación.
      const ttl = tone === 'error' ? 9000 : 4500;
      timers.current.set(
        id,
        setTimeout(() => dismiss(id), ttl),
      );
    },
    [dismiss],
  );

  // Al desmontar no quedan temporizadores vivos.
  useEffect(() => {
    const pending = timers.current;
    return () => {
      for (const timer of pending.values()) clearTimeout(timer);
      pending.clear();
    };
  }, []);

  const value = useMemo<ToastContextValue>(
    () => ({
      success: (text) => push('success', text),
      error: (text) => push('error', text),
      info: (text) => push('info', text),
    }),
    [push],
  );

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div
        className="fixed bottom-24 right-6 z-50 flex w-[min(380px,calc(100vw-3rem))] flex-col gap-2"
        aria-live="polite"
        aria-atomic="false"
      >
        {items.map((item) => (
          <div
            key={item.id}
            role={item.tone === 'error' ? 'alert' : 'status'}
            className={`flex items-start gap-3 rounded-card border px-4 py-3 text-sm shadow-lg ${TONES[item.tone].box}`}
          >
            <span
              className={`mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full text-[11px] font-bold ${TONES[item.tone].icon}`}
              aria-hidden="true"
            >
              {TONES[item.tone].label}
            </span>
            <p className="flex-1 leading-snug">{item.text}</p>
            <button
              type="button"
              onClick={() => dismiss(item.id)}
              className="text-ink-muted hover:text-ink"
              aria-label={t.common.dismissNotice}
            >
              ✕
            </button>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastContext);
  if (!ctx) throw new Error('useToast debe usarse dentro de ToastProvider');
  return ctx;
}
