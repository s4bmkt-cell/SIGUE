'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api, mayHaveSession, notifySessionChange, setSessionExpiredHandler, type AuthUser } from '@/lib/api/client';

interface AuthContextValue {
  user: AuthUser | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<
    | { ok: true; mfaRequired: false }
    | { ok: true; mfaRequired: true; challengeId: string }
    | { ok: false; error: string }
  >;
  verifyMfa: (challengeId: string, code: string) => Promise<{ ok: boolean; error?: string }>;
  signOut: () => Promise<void>;
  /** Revalida la sesión contra la API (útil tras cambiar de organización). */
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | null>(null);

/**
 * Sesión de la aplicación.
 *
 * No se guarda ningún token en el navegador: viajan en cookies httpOnly emitidas
 * por la API y el cliente HTTP renueva el acceso de forma transparente. Para
 * saber si hay sesión se consulta `GET /auth/me` al arrancar (con reintento de
 * refresh si el access token ya expiró).
 */
export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);

  const loadUser = useCallback(async () => {
    try {
      setUser(await api.me());
    } catch {
      setUser(null);
    }
  }, []);

  // Restaurar sesión al cargar. Sin pista de sesión no se consulta la API: en
  // las pantallas públicas (login, invitación, recuperación) solo generaría un
  // 401 y un refresh fallido en cada visita. La rama sin sesión se resuelve como
  // promesa para no cambiar estado de forma síncrona dentro del efecto.
  useEffect(() => {
    let active = true;
    const restored: Promise<AuthUser | null> = mayHaveSession()
      ? api.me().catch(() => null)
      : Promise.resolve(null);
    restored.then((me) => {
      if (!active) return;
      setUser(me);
      setLoading(false);
    });
    return () => {
      active = false;
    };
  }, []);

  // Si el refresh falla, el cliente avisa: se cierra la sesión local.
  useEffect(() => {
    setSessionExpiredHandler(() => setUser(null));
    return () => setSessionExpiredHandler(null);
  }, []);

  const signIn = useCallback(async (email: string, password: string) => {
    try {
      const result = await api.login(email, password);
      if (result.mfaRequired && result.challengeId) {
        return { ok: true as const, mfaRequired: true as const, challengeId: result.challengeId };
      }
      setUser(await api.me());
      // La cookie de pista solo existe tras el login: avisa a la organización
      // activa para que pida sus organizaciones sin esperar a una recarga.
      notifySessionChange();
      return { ok: true as const, mfaRequired: false as const };
    } catch (e) {
      return { ok: false as const, error: errorMessage(e) };
    }
  }, []);

  const verifyMfa = useCallback(async (challengeId: string, code: string) => {
    try {
      await api.verifyMfa(challengeId, code);
      setUser(await api.me());
      notifySessionChange();
      return { ok: true };
    } catch (e) {
      return { ok: false, error: errorMessage(e) };
    }
  }, []);

  const signOut = useCallback(async () => {
    try {
      await api.logout();
    } catch {
      // Aunque la revocación falle, la sesión local se cierra igual.
    }
    setUser(null);
    notifySessionChange();
  }, []);

  const refreshUser = useCallback(async () => {
    await loadUser();
  }, [loadUser]);

  const value = useMemo(
    () => ({ user, loading, signIn, verifyMfa, signOut, refreshUser }),
    [user, loading, signIn, verifyMfa, signOut, refreshUser],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth debe usarse dentro de AuthProvider');
  return ctx;
}

function errorMessage(e: unknown): string {
  return e instanceof Error ? e.message : 'Error';
}
