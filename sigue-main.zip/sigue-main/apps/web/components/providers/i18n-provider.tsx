'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { messages, type Locale, type MessageSchema } from '@/lib/i18n';

interface I18nContextValue {
  locale: Locale;
  setLocale: (l: Locale) => void;
  // El tipo de t es el esquema es-MX (fuente de verdad); en-US es estructuralmente igual.
  t: MessageSchema;
}

const I18nContext = createContext<I18nContextValue | null>(null);
const STORAGE_KEY = 'sigue.locale';

export function I18nProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>('es-MX');

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    // La preferencia solo existe en cliente: se aplica tras montar para no romper la
    // hidratación (el HTML del servidor siempre sale en es-MX).
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (saved === 'es-MX' || saved === 'en-US') setLocaleState(saved);
  }, []);

  const setLocale = useCallback((l: Locale) => {
    setLocaleState(l);
    localStorage.setItem(STORAGE_KEY, l);
    document.documentElement.lang = l;
  }, []);

  useEffect(() => {
    document.documentElement.lang = locale;
  }, [locale]);

  const t = useMemo(() => messages[locale] as unknown as MessageSchema, [locale]);
  const value = useMemo(() => ({ locale, setLocale, t }), [locale, setLocale, t]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error('useI18n debe usarse dentro de I18nProvider');
  return ctx;
}

