'use client';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { useMemo, useState } from 'react';
import { api, type AuthUser } from '@/lib/api/client';

import { useI18n } from '@/components/providers/i18n-provider';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { usePermissions } from '@/lib/hooks/use-permissions';
import { canOpenView, type ViewKey } from '@/components/layout/sidebar';
import { Button } from '@/components/ui/button';
import { EmptyState, ErrorState, LoadingState } from '@/components/ui/states';

type Priority = 'ALTA' | 'MEDIA' | 'BAJA';

interface HomeTask {
  id: string;
  title: string;
  priority: Priority;
  module: string;
  moduleKey: ViewKey;
  owner: string;
  due: string | null;
  /** `nc` marca tareas que se cierran en su módulo, no desde el tablero. */
  kind: 'nc' | 'task';
}

interface HomeActivity {
  id: string;
  title: string;
  sub: string;
  when: string;
  target: ViewKey;
  tone: 'ok' | 'info' | 'warn';
}

const STEPS = [
  { key: 'diag', target: 'diagnosis' as ViewKey },
  { key: 'plan', target: 'planning' as ViewKey },
  { key: 'impl', target: 'standards' as ViewKey },
  { key: 'audit', target: 'audits' as ViewKey },
];

/** Acción de bitácora → vista donde se puede revisar el registro. */
const ACTION_TARGETS: { prefix: string; target: ViewKey }[] = [
  { prefix: 'nc.', target: 'nc' },
  { prefix: 'documents.', target: 'documents' },
  { prefix: 'evidences.', target: 'evidences' },
  { prefix: 'audits.', target: 'audits' },
  { prefix: 'planning.', target: 'planning' },
  { prefix: 'context.', target: 'context' },
  { prefix: 'standards.', target: 'standards' },
  { prefix: 'isms.', target: 'isms' },
  { prefix: 'bcms.', target: 'bcms' },
  { prefix: 'mgmt_review.', target: 'review' },
  { prefix: 'billing.', target: 'subscription' },
  { prefix: 'ai.', target: 'ai-governance' },
];

/** Nombre legible del módulo dueño de la acción (`nc.register` → No conformidades). */
const MODULE_LABELS: Record<string, { es: string; en: string }> = {
  auth: { es: 'Sesión', en: 'Session' },
  orgs: { es: 'Organización', en: 'Organization' },
  users: { es: 'Usuarios', en: 'Users' },
  invitations: { es: 'Invitaciones', en: 'Invitations' },
  branches: { es: 'Sucursales', en: 'Branches' },
  areas: { es: 'Áreas', en: 'Areas' },
  standards: { es: 'Normas y requisitos', en: 'Standards' },
  diagnosis: { es: 'Diagnóstico', en: 'Diagnosis' },
  context: { es: 'Contexto', en: 'Context' },
  planning: { es: 'Planificación', en: 'Planning' },
  documents: { es: 'Documentos', en: 'Documents' },
  evidences: { es: 'Evidencias', en: 'Evidences' },
  audits: { es: 'Auditorías', en: 'Audits' },
  nc: { es: 'No conformidades', en: 'Nonconformities' },
  mgmt_review: { es: 'Revisión por la dirección', en: 'Management review' },
  isms: { es: 'Seguridad de la información', en: 'Information security' },
  bcms: { es: 'Continuidad del negocio', en: 'Business continuity' },
  ai: { es: 'Gobernanza de IA', en: 'AI governance' },
  billing: { es: 'Suscripción', en: 'Subscription' },
  notifications: { es: 'Notificaciones', en: 'Notifications' },
};

const ACTION_VERBS: Record<string, { es: string; en: string }> = {
  create: { es: 'creado', en: 'created' },
  add: { es: 'añadido', en: 'added' },
  update: { es: 'actualizado', en: 'updated' },
  delete: { es: 'eliminado', en: 'deleted' },
  remove: { es: 'eliminado', en: 'deleted' },
  close: { es: 'cerrado', en: 'closed' },
  reopen: { es: 'reabierto', en: 'reopened' },
  approve: { es: 'aprobado', en: 'approved' },
  publish: { es: 'publicado', en: 'published' },
  submit: { es: 'enviado a revisión', en: 'submitted' },
  verify: { es: 'verificado', en: 'verified' },
  activate: { es: 'activado', en: 'activated' },
  login: { es: 'inicio de sesión', en: 'signed in' },
  logout: { es: 'cierre de sesión', en: 'signed out' },
  change_plan: { es: 'cambio de plan', en: 'plan changed' },
  plan_applied: { es: 'cambio de plan', en: 'plan changed' },
  status_changed: { es: 'cambio de estado', en: 'status changed' },
  invoke: { es: 'consulta al asistente', en: 'assistant query' },
  decision: { es: 'decisión del asistente', en: 'assistant decision' },
  upload: { es: 'archivo subido', en: 'file uploaded' },
  assess: { es: 'evaluado', en: 'assessed' },
  invite: { es: 'invitación enviada', en: 'invitation sent' },
  revoke: { es: 'invitación revocada', en: 'invitation revoked' },
};

function actionTarget(action: string): ViewKey {
  return ACTION_TARGETS.find((a) => action.startsWith(a.prefix))?.target ?? 'dashboards';
}

/**
 * Construye el texto de la bitácora. Si el verbo no está mapeado se muestra el
 * identificador técnico entre paréntesis en lugar de inventar una traducción.
 */
function actionLabel(action: string, locale: string) {
  const isEn = locale === 'en-US';
  const [moduleKey, ...rest] = action.split('.');
  // `auth.login.success` → se usa el primer verbo (`login`); el sufijo es detalle.
  const verb = rest[0] ?? '';
  const moduleLabel = MODULE_LABELS[moduleKey]?.[isEn ? 'en' : 'es'] ?? moduleKey.replace(/_/g, ' ');
  const verbLabel = ACTION_VERBS[verb]?.[isEn ? 'en' : 'es'];
  return `${moduleLabel} · ${verbLabel ?? (verb || rest.join('.'))}`;
}

/**
 * El campo `entity` mezcla nombres de recurso con plantillas de ruta
 * (`orgs/:orgId/billing/plan`). Las rutas no aportan nada al usuario, así que
 * solo se muestran las entidades con nombre propio.
 */
function entityLabel(entity: string | null): string | null {
  if (!entity) return null;
  if (entity.includes(':') || entity.includes('/')) return null;
  return entity;
}

function timeAgo(iso: string, locale: string) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.max(1, Math.round(diff / 60000));
  const isEn = locale === 'en-US';
  if (mins < 60) return isEn ? `${mins} min ago` : `hace ${mins} min`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return isEn ? `${hours} h ago` : `hace ${hours} h`;
  const days = Math.round(hours / 24);
  if (days < 30) return isEn ? `${days} d ago` : `hace ${days} d`;
  return new Date(iso).toLocaleDateString(isEn ? 'en-US' : 'es-MX', {
    day: '2-digit',
    month: 'short',
  });
}

function barColor(pct: number) {
  if (pct >= 80) return '#16a34a';
  if (pct >= 60) return '#d97706';
  return '#dc2626';
}

function avatarBg(initials: string) {
  const colors = ['#2f66eb', '#0BAA70', '#e07b00', '#9333ea', '#0891b2'];
  const idx = (initials.charCodeAt(0) + (initials.charCodeAt(1) || 0)) % colors.length;
  return colors[idx];
}

/**
 * Las NC guardan la prioridad como ALTA/MEDIA/BAJA y las tareas de plan como
 * HIGH/MEDIUM/LOW (herencia de dos módulos distintos). El tablero las unifica
 * en su propia escala.
 */
function normalizePriority(value: string | null | undefined): Priority {
  const v = (value ?? '').toUpperCase();
  if (v === 'ALTA' || v === 'HIGH' || v === 'CRITICA' || v === 'CRITICAL') return 'ALTA';
  if (v === 'BAJA' || v === 'LOW') return 'BAJA';
  return 'MEDIA';
}

function priorityTone(priority: Priority) {
  if (priority === 'ALTA') return 'text-danger';
  if (priority === 'MEDIA') return 'text-warning';
  return 'text-[#16a34a]';
}

function priorityLabel(priority: Priority, t: ReturnType<typeof useI18n>['t']) {
  if (priority === 'ALTA') return t.planning.priorityHigh;
  if (priority === 'MEDIA') return t.planning.priorityMedium;
  return t.planning.priorityLow;
}

function ActivityIcon({ tone }: { tone: HomeActivity['tone'] }) {
  const cls =
    tone === 'ok' ? 'text-[#0BAA70] bg-[#E7F8F1]'
    : tone === 'info' ? 'text-primary bg-info-bg'
    : 'text-warning bg-warning-bg';
  return (
    <span className={`size-8 rounded-full flex items-center justify-center shrink-0 ${cls}`}>
      {tone === 'ok' ? (
        <svg className="size-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
          <polyline points="20 6 9 17 4 12" />
        </svg>
      ) : tone === 'info' ? (
        <svg className="size-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
          <polyline points="14 2 14 8 20 8" />
        </svg>
      ) : (
        <svg className="size-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <rect x="3" y="4" width="18" height="18" rx="2" />
          <line x1="16" y1="2" x2="16" y2="6" />
          <line x1="8" y1="2" x2="8" y2="6" />
          <line x1="3" y1="10" x2="21" y2="10" />
        </svg>
      )}
    </span>
  );
}

export function DashboardHome({
  user,
  onNavigate,
}: {
  user: AuthUser;
  onNavigate: (v: ViewKey) => void;
}) {
  const { t, locale } = useI18n();
  const { org, orgId } = useActiveOrg();
  const perms = usePermissions();
  const qc = useQueryClient();
  const [expandedTask, setExpandedTask] = useState<string | null>(null);

  // La suscripción solo la ven `admin_org`, `alta_direccion` y el admin de
  // plataforma; para el resto la API responde 403 y no debe haber enlace.
  const canSeeSubscription = canOpenView('subscription', perms);

  const summaryQuery = useQuery({
    queryKey: ['dashboard-summary', orgId],
    queryFn: () => api.dashboardSummary(orgId!),
    enabled: !!orgId,
  });

  const complianceQuery = useQuery({
    queryKey: ['dashboard-compliance', orgId],
    queryFn: () => api.dashboardCompliance(orgId!),
    enabled: !!orgId,
  });

  const ncsQuery = useQuery({
    queryKey: ['nc', orgId],
    queryFn: () => api.ncs(orgId!),
    enabled: !!orgId,
  });

  const plansQuery = useQuery({
    queryKey: ['plans', orgId],
    queryFn: () => api.plans(orgId!),
    enabled: !!orgId,
  });

  const standardsQuery = useQuery({
    queryKey: ['standards', orgId],
    queryFn: () => api.standards(orgId!),
    enabled: !!orgId,
  });

  const branchesQuery = useQuery({
    queryKey: ['branches', orgId],
    queryFn: () => api.branches(orgId!),
    enabled: !!orgId,
  });

  const auditsQuery = useQuery({
    queryKey: ['audits', orgId],
    queryFn: () => api.audits(orgId!),
    enabled: !!orgId,
  });

  // El listado de miembros exige rol de administrador en la organización: solo
  // se pide con ese permiso y, si falta, las tareas muestran "sin asignar" en
  // lugar de disparar un 403 en cada carga.
  const membersQuery = useQuery({
    queryKey: ['members', orgId],
    queryFn: () => api.members(orgId!),
    enabled: !!orgId && perms.isAdmin,
    retry: false,
  });

  // La bitácora solo es legible por administradores y auditores; para el resto
  // se cae a las notificaciones, que sí ven todos.
  const auditQuery = useQuery({
    queryKey: ['audit-log', orgId, 'recent'],
    queryFn: () => api.auditLog(orgId!, { pageSize: 5 }),
    enabled: !!orgId && perms.canAudit,
    retry: false,
  });

  const notifQuery = useQuery({
    queryKey: ['notifications', orgId],
    queryFn: () => api.notifications(orgId!),
    enabled: !!orgId && !perms.canAudit,
  });

  const completeTaskMutation = useMutation({
    mutationFn: (taskId: string) => api.updateTaskStatus(orgId!, taskId, 'DONE'),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['plans', orgId] });
      qc.invalidateQueries({ queryKey: ['dashboard-summary', orgId] });
      qc.invalidateQueries({ queryKey: ['planning', orgId] });
    },
  });

  const summary = summaryQuery.data;

  // El detalle por cláusula se agrega por norma: con seis normas activas son
  // casi 300 filas, y en el inicio lo útil es ver el avance de cada estándar.
  const clauses = useMemo(() => {
    const live = complianceQuery.data;
    if (!live) return [];
    const byStandard = new Map<string, { count: number; implemented: number }>();
    for (const row of live) {
      const acc = byStandard.get(row.standard) ?? { count: 0, implemented: 0 };
      acc.count += row.count;
      acc.implemented += row.implemented;
      byStandard.set(row.standard, acc);
    }
    const order = ['ISO9001', 'ISO27001', 'ISO22301', 'ISO20000', 'ISO37001', 'ISO42001'];
    return [...byStandard.entries()]
      .map(([standard, acc]) => ({
        code: standard,
        pct: acc.count ? Math.round((acc.implemented / acc.count) * 100) : 0,
        implemented: acc.implemented,
        count: acc.count,
      }))
      .sort((a, b) => order.indexOf(a.code) - order.indexOf(b.code));
  }, [complianceQuery.data]);

  // Tareas: NC abiertas y tareas de planes. Cada una se cierra en su módulo
  // (o aquí, si es una tarea de plan y hay permiso de escritura).
  const tasks = useMemo<HomeTask[]>(() => {
    const memberName = new Map((membersQuery.data ?? []).map((m) => [m.userId, m.name]));
    const unassigned = t.home.unassigned;

    const ncTasks: HomeTask[] = (ncsQuery.data ?? [])
      .filter((nc) => nc.status !== 'CLOSED')
      .map((nc) => ({
        id: nc.id,
        title: `${nc.folio} · ${nc.title}`,
        priority: normalizePriority(nc.priority),
        module: t.nc.title,
        moduleKey: 'nc' as ViewKey,
        owner: unassigned,
        due: null,
        kind: 'nc' as const,
      }));

    // Cada tarea se identifica con su plan: el seed crea tareas con el mismo
    // nombre en varios planes y sin el plan las filas son indistinguibles.
    const planTasks: HomeTask[] = (plansQuery.data ?? [])
      .flatMap((p) =>
        p.tasks
          .filter((task) => task.status !== 'DONE')
          .map((task) => ({ plan: p, task })),
      )
      .map(({ plan, task }) => ({
        id: task.id,
        title: task.title,
        priority: normalizePriority(task.priority),
        module: plan.title,
        moduleKey: 'planning' as ViewKey,
        owner: task.assigneeId
          ? (memberName.get(task.assigneeId) ?? unassigned)
          : unassigned,
        due: task.dueDate
          ? new Date(task.dueDate).toLocaleDateString(locale === 'en-US' ? 'en-US' : 'es-MX', {
              day: '2-digit',
              month: 'short',
            })
          : null,
        kind: 'task' as const,
      }));

    // Primero lo crítico: la prioridad y luego el tipo. El seed crea varios
    // planes con la misma plantilla de tareas, así que se deduplica por
    // título+módulo para no llenar la tabla con filas idénticas.
    const seen = new Set<string>();
    return [...ncTasks, ...planTasks]
      .filter((task) => {
        const key = `${task.moduleKey}|${task.title}`;
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      })
      .sort((a, b) => {
        const order = { ALTA: 0, MEDIA: 1, BAJA: 2 };
        return order[a.priority] - order[b.priority];
      })
      .slice(0, 5);
  }, [ncsQuery.data, plansQuery.data, membersQuery.data, t, locale]);

  const activity = useMemo<HomeActivity[]>(() => {
    const audit = auditQuery.data?.items;
    if (audit?.length) {
      return audit.map((e) => {
        const entity = entityLabel(e.entity);
        const fallback = t.home.auditLogFallback;
        return {
          id: e.id,
          title: actionLabel(e.action, locale),
          sub: entity
            ? `${entity}${e.entityId ? ` · ${e.entityId.slice(0, 8)}` : ''}`
            : fallback,
          when: timeAgo(e.createdAt, locale),
          target: actionTarget(e.action),
          tone: e.action.includes('delete') ? ('warn' as const) : ('info' as const),
        };
      });
    }
    return (notifQuery.data?.items ?? []).slice(0, 5).map((n) => ({
      id: n.id,
      title: n.title,
      sub: n.body ?? '',
      when: timeAgo(n.createdAt, locale),
      target: 'notifications' as ViewKey,
      tone: n.readAt ? ('ok' as const) : ('warn' as const),
    }));
  }, [auditQuery.data, notifQuery.data, locale, t]);

  const activeStandards = standardsQuery.data?.active ?? [];
  const branches = branchesQuery.data ?? [];
  const places = branches
    .map((b) => b.city ?? b.state ?? b.name)
    .filter((v): v is string => !!v);
  const placesLabel = places.length ? [...new Set(places)].join(' + ') : null;

  // Progreso del stepper a partir de datos reales. Cada etapa se considera
  // cumplida solo si existe evidencia de que se hizo, no por tener el módulo
  // abierto (p. ej. una auditoría *programada* no cierra la etapa de auditoría).
  const compliancePct = summary?.compliance.pct ?? 0;
  const implementedCount = summary?.compliance.implemented ?? 0;
  const closedAudits = (auditsQuery.data ?? []).filter(
    (a) => a.status === 'CLOSED' || a.status === 'COMPLETED',
  ).length;
  const stepDone = [
    implementedCount > 0,
    (plansQuery.data?.length ?? 0) > 0,
    compliancePct >= 80,
    closedAudits > 0,
  ];
  const firstPending = stepDone.indexOf(false);
  const activeStep = firstPending === -1 ? STEPS.length - 1 : firstPending;

  const firstName = user.name.split(' ')[0];
  const hour = new Date().getHours();
  const greeting =
    hour < 12
      ? t.home.greeting(firstName)
      : hour < 19
        ? t.home.greetingAfternoon(firstName)
        : t.home.greetingEvening(firstName);

  if (summaryQuery.isLoading && plansQuery.isLoading) {
    return (
      <div className="bg-[#f3f6fb] min-h-full p-8">
        <LoadingState label={t.common.loading} />
      </div>
    );
  }

  if (summaryQuery.isError) {
    return (
      <div className="bg-[#f3f6fb] min-h-full p-8">
        <ErrorState
          message={(summaryQuery.error as Error).message}
          onRetry={() => summaryQuery.refetch()}
          retryLabel={t.common.retry}
        />
      </div>
    );
  }

  const pct = summary?.compliance.pct ?? 0;

  return (
    <div className="bg-[#f3f6fb] min-h-full">
      <div className="max-w-screen-2xl mx-auto px-6 py-6 grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-6">
        {/* ===== Columna izquierda ===== */}
        <div className="min-w-0 space-y-5">
          {/* Encabezado */}
          <div>
            <h1 className="text-[22px] font-extrabold text-navy">{greeting}</h1>
            <p className="text-[13px] text-ink-soft mt-0.5">{t.home.state}</p>
            <div className="flex flex-wrap gap-2 mt-3">
              {activeStandards.map((s) => (
                <button
                  key={s.id}
                  onClick={() => onNavigate('standards')}
                  className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1 text-[12.5px] font-semibold text-primary hover:border-primary/40 transition-colors"
                >
                  <svg className="size-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  </svg>
                  {s.standard.code}:{s.standard.year}
                </button>
              ))}
              {/* El chip lleva a la configuración de la organización, que solo
                  administran los admin: para el resto es solo informativo. */}
              {perms.isAdmin ? (
                <button
                  onClick={() => onNavigate('org-admin')}
                  className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1 text-[12.5px] font-semibold text-ink-soft hover:border-primary/40 hover:text-ink transition-colors"
                >
                  <svg className="size-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <rect x="3" y="3" width="18" height="18" rx="3" />
                    <path d="M3 9h18M9 21V9" />
                  </svg>
                  {org?.name ?? '—'}
                </button>
              ) : (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1 text-[12.5px] font-semibold text-ink-soft">
                  <svg className="size-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <rect x="3" y="3" width="18" height="18" rx="3" />
                    <path d="M3 9h18M9 21V9" />
                  </svg>
                  {org?.name ?? '—'}
                </span>
              )}
              {placesLabel && (
                <span className="inline-flex items-center gap-1.5 rounded-full border border-line bg-white px-3 py-1 text-[12.5px] font-semibold text-ink-soft">
                  <svg className="size-3.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0 1 18 0z" />
                    <circle cx="12" cy="10" r="3" />
                  </svg>
                  {placesLabel}
                </span>
              )}
            </div>
          </div>

          {/* Ruta a la certificación */}
          <div className="relative overflow-hidden bg-white border border-line rounded-card shadow-card p-6">
            <svg className="absolute right-0 bottom-0 w-[55%] pointer-events-none opacity-60" viewBox="0 0 640 80" fill="none" aria-hidden="true">
              <path d="M 0 76 C 100 76 140 44 260 44 C 380 44 430 44 640 44" stroke="#DDE7F4" strokeWidth="32" strokeLinecap="round" />
              <path d="M 0 76 C 100 76 140 44 260 44 C 380 44 430 44 640 44" stroke="#EEF3FA" strokeWidth="22" strokeLinecap="round" />
              <path d="M 0 76 C 100 76 140 44 260 44 C 380 44 430 44 640 44" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeDasharray="10 12" />
            </svg>
            <div className="relative z-10">
              <h2 className="text-[16px] font-bold text-navy mb-4">{t.home.routeToCert}</h2>
              <div className="flex items-center gap-8 flex-wrap">
                <button
                  onClick={() => onNavigate('standards')}
                  className="relative size-[110px] shrink-0 cursor-pointer group"
                  aria-label={`${t.dashboard.compliance}: ${pct}%`}
                >
                  <svg className="size-full -rotate-90 transition-transform duration-300 group-hover:scale-105" viewBox="0 0 110 110">
                    <circle cx="55" cy="55" r="47" fill="none" stroke="#E8EDF5" strokeWidth="10" />
                    <circle
                      cx="55"
                      cy="55"
                      r="47"
                      fill="none"
                      stroke="#2563EB"
                      strokeWidth="10"
                      strokeLinecap="round"
                      strokeDasharray="295.3"
                      strokeDashoffset={295.3 - (295.3 * pct) / 100}
                    />
                  </svg>
                  <span className="absolute inset-0 flex items-center justify-center">
                    <span className="text-[30px] font-extrabold text-navy">{pct}%</span>
                  </span>
                </button>
                <div className="flex flex-col gap-1">
                  <div className="text-[15px] font-semibold text-navy">
                    {t.home.pendingRequirements(summary?.compliance.pending ?? 0)}
                  </div>
                  <div className="text-[12.5px] text-ink-soft mb-3">
                    {activeStandards.length
                      ? t.home.activeStandards(activeStandards.length)
                      : t.standards.noActive}
                  </div>
                  <Button className="h-[36px] text-[13px]" onClick={() => onNavigate('diagnosis')}>
                    {t.home.continue}
                  </Button>
                </div>
                <ol className="flex flex-1 min-w-[280px] relative justify-between">
                  <div className="absolute top-[19px] left-[6%] right-[6%] border-t-2 border-dashed border-[#D6DFEC]" aria-hidden="true" />
                  {STEPS.map((step, i) => {
                    const done = stepDone[i];
                    const isActive = !done && i === activeStep;
                    const label = t.home[
                      `step${step.key[0].toUpperCase()}${step.key.slice(1)}` as keyof typeof t.home
                    ] as unknown as string;
                    const state = done ? t.home.done : isActive ? t.home.inProgress : t.home.pending;
                    return (
                      <li key={step.key} className="flex flex-col items-center gap-1 flex-1 relative z-10">
                        <button
                          onClick={() => onNavigate(step.target)}
                          className={[
                            'size-[38px] rounded-full flex items-center justify-center text-white text-sm font-bold transition-transform hover:scale-105',
                            done
                              ? 'bg-[#0BAA70] shadow-[0_0_0_6px_#E7F8F1]'
                              : isActive
                                ? 'bg-[#3167F4] shadow-[0_0_0_7px_rgba(49,103,244,0.16)]'
                                : 'bg-white border-2 border-[#C9D6E8] text-[#8CA3C4]',
                          ].join(' ')}
                        >
                          {done ? (
                            <svg className="size-4" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
                              <polyline points="20 6 9 17 4 12" />
                            </svg>
                          ) : isActive ? (
                            <svg className="size-4" fill="currentColor" viewBox="0 0 24 24">
                              <polygon points="3 11 22 2 13 21 11 13 3 11" />
                            </svg>
                          ) : (
                            <svg className="size-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                              <circle cx="12" cy="12" r="10" />
                              <circle cx="12" cy="12" r="3" />
                            </svg>
                          )}
                        </button>
                        <span className={['text-[12px] mt-1.5 font-semibold text-center', isActive ? 'text-primary' : 'text-navy'].join(' ')}>
                          {label}
                        </span>
                        <span className={['text-[11px]', done ? 'text-[#087E55]' : isActive ? 'text-primary' : 'text-ink-muted'].join(' ')}>
                          {state}
                        </span>
                      </li>
                    );
                  })}
                </ol>
              </div>
            </div>
          </div>

          {/* KPIs */}
          <div className="grid grid-cols-3 gap-4">
            {[
              {
                target: 'nc' as ViewKey,
                iconBg: 'bg-danger-bg',
                icon: 'alert',
                value: String(summary?.nc.open ?? 0),
                label: t.dashboard.openNC,
                sub: `${summary?.nc.critical ?? 0} ${t.dashboard.critical}`,
                valueTone: 'text-danger',
                subTone: 'text-danger',
              },
              {
                target: 'audits' as ViewKey,
                iconBg: 'bg-warning-bg',
                icon: 'cal',
                value: String(summary?.audits.upcoming ?? 0),
                label: t.dashboard.nextAudits,
                sub: '',
                valueTone: 'text-navy',
                subTone: '',
              },
              {
                target: 'planning' as ViewKey,
                iconBg: 'bg-[#e8f5ee]',
                icon: 'clock',
                value: String(summary?.plans.active ?? 0),
                label: t.dashboard.planProgress,
                sub: `${summary?.plans.pendingTasks ?? 0} ${t.dashboards.pendingTasks}`,
                valueTone: 'text-navy',
                subTone: '',
              },
            ].map((kpi) => (
              <button
                key={kpi.label}
                onClick={() => onNavigate(kpi.target)}
                className="bg-white border border-line rounded-card shadow-card p-4 flex items-center gap-3.5 cursor-pointer hover:shadow-md hover:border-primary/40 transition-all text-left group"
              >
                <div className={`size-10 rounded-xl ${kpi.iconBg} flex items-center justify-center shrink-0`}>
                  {kpi.icon === 'alert' ? (
                    <svg className="size-5 text-danger" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" />
                      <line x1="12" y1="9" x2="12" y2="13" />
                      <line x1="12" y1="17" x2="12.01" y2="17" />
                    </svg>
                  ) : kpi.icon === 'cal' ? (
                    <svg className="size-5 text-warning" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <rect x="3" y="4" width="18" height="18" rx="2" />
                      <line x1="16" y1="2" x2="16" y2="6" />
                      <line x1="8" y1="2" x2="8" y2="6" />
                      <line x1="3" y1="10" x2="21" y2="10" />
                    </svg>
                  ) : (
                    <svg className="size-5 text-[#16a34a]" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <circle cx="12" cy="12" r="10" />
                      <polyline points="12 6 12 12 16 14" />
                    </svg>
                  )}
                </div>
                <div className="min-w-0">
                  <div className={`text-[26px] font-extrabold leading-none ${kpi.valueTone}`}>{kpi.value}</div>
                  <div className="text-[12px] text-ink-soft leading-tight mt-0.5">{kpi.label}</div>
                  {kpi.sub && <div className={`text-[11px] font-semibold ${kpi.subTone}`}>{kpi.sub}</div>}
                </div>
                <svg className="size-4 text-ink-muted ml-auto shrink-0 hidden sm:block group-hover:text-primary transition-colors" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <path d="m9 18 6-6-6-6" />
                </svg>
              </button>
            ))}
          </div>

          {/* Cumplimiento por cláusula */}
          <div className="bg-white border border-line rounded-card shadow-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[15px] font-bold text-navy">{t.home.compliance}</h3>
              {complianceQuery.isFetching && <span className="text-[11px] text-ink-muted">{t.common.loading}</span>}
            </div>
            {complianceQuery.isError ? (
              <ErrorState
                message={(complianceQuery.error as Error).message}
                onRetry={() => complianceQuery.refetch()}
                retryLabel={t.common.retry}
              />
            ) : clauses.length === 0 ? (
              <EmptyState title={t.common.noData} hint={t.standards.noActive} />
            ) : (
              <ul className="space-y-3">
                {clauses.map((c) => (
                  <li key={c.code} className="flex items-center gap-3 text-[13px]">
                    <span className="w-[140px] font-medium text-ink shrink-0">{c.code}</span>
                    <div className="flex-1 h-[7px] rounded-full bg-[#eef1f6] overflow-hidden cursor-pointer" onClick={() => onNavigate('standards')}>
                      <div className="h-full rounded-full transition-all duration-500" style={{ width: c.pct + '%', background: barColor(c.pct) }} />
                    </div>
                    <span className="w-9 text-right text-ink-soft font-semibold tabular-nums">{c.pct}%</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          {/* Mis tareas */}
          <div className="bg-white border border-line rounded-card shadow-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[15px] font-bold text-navy">{t.home.myTasks}</h3>
              <button className="text-[12px] font-semibold text-primary hover:underline" onClick={() => onNavigate('planning')}>
                {t.home.viewAll}
              </button>
            </div>
            {ncsQuery.isError || plansQuery.isError ? (
              <ErrorState
                message={((ncsQuery.error ?? plansQuery.error) as Error).message}
                onRetry={() => {
                  ncsQuery.refetch();
                  plansQuery.refetch();
                }}
                retryLabel={t.common.retry}
              />
            ) : tasks.length === 0 ? (
              <EmptyState title={t.home.noTasks} hint={t.common.noData} />
            ) : (
              <table className="w-full text-[13px]">
                <thead>
                  <tr className="text-[10.5px] uppercase tracking-wider text-ink-muted text-left border-b border-line">
                    <th className="pb-2 font-semibold pr-3 w-7" />
                    <th className="pb-2 font-semibold pr-3">{t.home.tablePriority}</th>
                    <th className="pb-2 font-semibold pr-3">{t.home.tableTask}</th>
                    <th className="pb-2 font-semibold pr-3">{t.home.tableModule}</th>
                    <th className="pb-2 font-semibold pr-3">{t.home.tableOwner}</th>
                    <th className="pb-2 pr-3" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-line">
                  {tasks.map((task) => (
                    <tr key={task.id}>
                      <td className="py-3 pr-3">
                        <button
                          onClick={() => {
                            // Una tarea de plan se cierra aquí; una NC se cierra en
                            // su módulo (tiene flujo de verificación de eficacia).
                            if (task.kind === 'task' && perms.canWrite) {
                              completeTaskMutation.mutate(task.id);
                            } else {
                              setExpandedTask(task.id);
                              onNavigate(task.moduleKey);
                            }
                          }}
                          disabled={completeTaskMutation.isPending}
                          className="size-5 rounded-full flex items-center justify-center shrink-0 transition-colors border-2 border-[#C9D6E8] hover:border-primary hover:bg-[#E7F8F1] disabled:opacity-50"
                          aria-label={task.kind === 'task' ? t.home.completeTask : t.home.openTask}
                          title={task.kind === 'task' ? t.home.completeTask : t.home.openTask}
                        />
                      </td>
                      <td className="py-3 pr-3">
                        <span className={`font-bold text-[12px] ${priorityTone(task.priority)}`}>{priorityLabel(task.priority, t)}</span>
                      </td>
                      <td className="py-3 pr-3">
                        <span className={expandedTask === task.id ? 'text-primary' : 'text-ink'}>{task.title}</span>
                      </td>
                      <td className="py-3 pr-3 text-ink-soft">{task.module}</td>
                      <td className="py-3 pr-3 text-ink-soft">{task.owner}</td>
                      <td className="py-3">
                        <button
                          onClick={() => onNavigate(task.moduleKey)}
                          className="h-7 px-3 rounded-btn bg-primary text-white text-[12px] font-semibold hover:bg-primary-strong transition-colors"
                        >
                          {t.home.view}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <div className="mt-3 text-[12px] text-ink-muted">
              {tasks.length} {t.home.pendingLabel}
              {!perms.canWrite && ` · ${t.common.readOnlyHint}`}
            </div>
          </div>
        </div>

        {/* ===== Columna derecha ===== */}
        <div className="space-y-5">
          {/* Prioridades de hoy */}
          <div className="bg-white border border-line rounded-card shadow-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[15px] font-bold text-navy">{t.home.priorities}</h3>
              <button className="text-[12.5px] font-semibold text-primary hover:underline" onClick={() => onNavigate('planning')}>
                {t.home.viewAll}
              </button>
            </div>
            {tasks.length === 0 ? (
              <p className="text-[12.5px] text-ink-soft">{t.home.noTasks}</p>
            ) : (
              <>
                <div className="grid grid-cols-[1fr_auto_auto_auto] gap-2 text-[10.5px] uppercase tracking-wider text-ink-muted font-semibold pb-2 border-b border-line">
                  <span>{t.home.tableTask}</span>
                  <span>{t.home.tableOwner}</span>
                  <span />
                  <span />
                </div>
                <ul className="divide-y divide-line">
                  {tasks.slice(0, 3).map((task) => {
                    const unassigned = task.owner === t.home.unassigned;
                    const initials = unassigned
                      ? null
                      : task.owner
                          .split(' ')
                          .map((w) => w[0])
                          .slice(0, 2)
                          .join('')
                          .toUpperCase();
                    return (
                    <li key={task.id} className="grid grid-cols-[1fr_auto_auto_auto] gap-2 items-center py-3">
                      <button
                        onClick={() => onNavigate(task.moduleKey)}
                        className="text-[13px] truncate text-left hover:underline text-ink"
                      >
                        {task.title}
                      </button>
                      <div
                        className={[
                          'size-6 rounded-full flex items-center justify-center text-[10px] font-bold shrink-0',
                          initials ? 'text-white' : 'bg-page text-ink-muted border border-line',
                        ].join(' ')}
                        style={initials ? { background: avatarBg(initials) } : undefined}
                        title={task.owner}
                      >
                        {initials ?? '–'}
                      </div>
                      <span className="text-[12px] text-ink-soft tabular-nums whitespace-nowrap">{task.due ?? '—'}</span>
                      <button
                        onClick={() => onNavigate(task.moduleKey)}
                        className="h-7 px-2.5 rounded-btn text-[12px] font-semibold transition-colors whitespace-nowrap bg-primary text-white hover:bg-primary-strong"
                      >
                        {t.home.view}
                      </button>
                    </li>
                    );
                  })}
                </ul>
              </>
            )}
          </div>

          {/* Actividad reciente */}
          <div className="bg-white border border-line rounded-card shadow-card p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[15px] font-bold text-navy">{t.home.recentActivity}</h3>
              <button className="text-[12.5px] font-semibold text-primary hover:underline" onClick={() => onNavigate('dashboards')}>
                {t.home.viewHistory}
              </button>
            </div>
            {activity.length === 0 ? (
              <p className="text-[12.5px] text-ink-soft">{t.common.noData}</p>
            ) : (
              <ul className="space-y-4">
                {activity.map((a) => (
                  <li key={a.id}>
                    <button onClick={() => onNavigate(a.target)} className="flex gap-3 w-full text-left group">
                      <ActivityIcon tone={a.tone} />
                      <span className="min-w-0 flex-1">
                        <span className="text-[13px] font-semibold text-ink leading-tight block group-hover:text-primary transition-colors">
                          {a.title}
                        </span>
                        {a.sub && <span className="text-[11.5px] text-ink-muted mt-0.5 block">{a.sub}</span>}
                      </span>
                      <span className="text-[11px] text-ink-muted whitespace-nowrap ml-auto pt-0.5">{a.when}</span>
                    </button>
                  </li>
                ))}
              </ul>
            )}
            <button
              onClick={() => onNavigate('dashboards')}
              className="mt-4 w-full text-center text-[12.5px] font-semibold text-primary hover:underline pt-3 border-t border-line block"
            >
              {t.home.fullHistory}
            </button>
          </div>

          {/* Organizaciones */}
          <div className="bg-white border border-line rounded-card shadow-card p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-[15px] font-bold text-navy">{t.home.orgs}</h3>
              {/* La suscripción solo la ven admin y alta dirección (la API
                  devuelve 403 al resto): para los demás el enlace no existe. */}
              {canSeeSubscription && (
                <button className="text-[12.5px] font-semibold text-primary hover:underline" onClick={() => onNavigate('subscription')}>
                  {t.home.viewAll}
                </button>
              )}
            </div>
            {org ? (
              <div
                className={`w-full flex items-center gap-3 border border-line rounded-btn px-3 py-2.5 text-left ${
                  canSeeSubscription
                    ? 'hover:border-primary/40 hover:shadow-sm transition-all group cursor-pointer'
                    : ''
                }`}
                role={canSeeSubscription ? 'button' : undefined}
                tabIndex={canSeeSubscription ? 0 : undefined}
                onClick={canSeeSubscription ? () => onNavigate('subscription') : undefined}
                onKeyDown={
                  canSeeSubscription
                    ? (e) => {
                        if (e.key === 'Enter' || e.key === ' ') {
                          e.preventDefault();
                          onNavigate('subscription');
                        }
                      }
                    : undefined
                }
              >
                <span className="size-8 rounded-lg bg-info-bg flex items-center justify-center shrink-0">
                  <svg className="size-4 text-info" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  </svg>
                </span>
                <span className="min-w-0 flex-1">
                  <span className="text-[13px] font-semibold text-ink truncate block group-hover:text-primary transition-colors">
                    {org.name}
                  </span>
                  <span className="text-[11px] text-ink-muted">
                    {org.plan} · {org.users}/{org.quotaUsers} {t.billing.users.toLowerCase()}
                  </span>
                </span>
                {canSeeSubscription && (
                  <svg className="size-4 text-ink-muted shrink-0 group-hover:text-primary transition-colors" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path d="m9 18 6-6-6-6" />
                  </svg>
                )}
              </div>
            ) : (
              <p className="text-[12.5px] text-ink-soft">{t.common.loading}</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
