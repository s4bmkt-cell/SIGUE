'use client';

import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '@/lib/api/client';
import { useI18n } from '@/components/providers/i18n-provider';
import { type MessageSchema } from '@/lib/i18n';
import { useActiveOrg } from '@/lib/hooks/use-active-org';
import { useToast } from '@/components/providers/toast-provider';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

// Acciones IA contextuales por módulo (equivalente a los casos de uso del gateway).
// La etiqueta visible sale del diccionario por caso de uso, así el copiloto habla
// el mismo idioma que el resto de la pantalla.
const SUGGESTIONS: Record<string, { useCase: keyof MessageSchema['copilot']['suggestions']; context: Record<string, unknown> }[]> = {
  documents: [
    { useCase: 'draft_document', context: { query: 'procedimiento' } },
    { useCase: 'detect_inconsistencies', context: { query: 'documentos' } },
  ],
  planning: [
    { useCase: 'suggest_risks', context: { query: 'riesgos' } },
  ],
  nc: [
    { useCase: 'root_cause', context: { query: 'causa raiz' } },
    { useCase: 'detect_inconsistencies', context: { query: 'nc' } },
  ],
  evidences: [
    { useCase: 'classify_evidence', context: { query: 'clasificacion' } },
  ],
  audits: [
    { useCase: 'detect_inconsistencies', context: { query: 'auditoria' } },
    { useCase: 'summarize', context: { query: 'auditorias' } },
  ],
  review: [
    { useCase: 'summarize', context: { query: 'revision direccion' } },
  ],
  isms: [
    { useCase: 'suggest_risks', context: { query: 'seguridad informacion' } },
    { useCase: 'detect_inconsistencies', context: { query: 'soa controles' } },
  ],
  bcms: [
    { useCase: 'suggest_risks', context: { query: 'continuidad negocio' } },
  ],
  'ai-systems': [
    { useCase: 'summarize', context: { query: 'sistemas ia' } },
  ],
  'ai-governance': [
    { useCase: 'summarize', context: { query: 'gobernanza ia' } },
  ],
  dashboards: [
    { useCase: 'summarize', context: { query: 'resumen' } },
  ],
  home: [
    { useCase: 'summarize', context: { query: 'resumen' } },
  ],
};

/** Caso de uso por defecto cuando el usuario escribe una pregunta libre. */
const DEFAULT_USE_CASE: Record<string, string> = {
  documents: 'draft_document',
  planning: 'suggest_risks',
  nc: 'root_cause',
  evidences: 'classify_evidence',
  audits: 'detect_inconsistencies',
  review: 'summarize',
  isms: 'suggest_risks',
  bcms: 'suggest_risks',
  'ai-systems': 'summarize',
  'ai-governance': 'summarize',
  dashboards: 'summarize',
  home: 'summarize',
};

export function CopilotFab({ currentView }: { currentView: string }) {
  const { t } = useI18n();
  const { orgId } = useActiveOrg();
  const toast = useToast();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [result, setResult] = useState<{ output: string; sources: { ref: string }[] } | null>(null);
  // La decisión se toma contra esta interacción; guardarla en estado (y no en
  // localStorage) mantiene el flujo dentro de la sesión y sin fugas entre orgs.
  const [interactionId, setInteractionId] = useState<string | null>(null);
  const [decision, setDecision] = useState<string | null>(null);
  const [disclosure, setDisclosure] = useState<string | null>(null);
  const [pendingAction, setPendingAction] = useState<{ useCase: string; entity: string; context: Record<string, unknown> } | null>(null);
  const [input, setInput] = useState('');
  const [editing, setEditing] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // El borrador se descarta al cambiar de pantalla u organización: `page.tsx`
  // monta el copiloto con `key` por vista, así que el estado nace limpio sin
  // necesidad de sincronizarlo con un efecto.

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ['ai-interactions', orgId] });
    qc.invalidateQueries({ queryKey: ['ai-use-cases', orgId] });
    qc.invalidateQueries({ queryKey: ['ai-incidents', orgId] });
  };

  const invokeMutation = useMutation({
    mutationFn: (data: { useCase: string; entity: string; context: Record<string, unknown> }) =>
      api.aiInvoke(orgId!, { useCase: data.useCase, module: currentView, entity: data.entity, context: data.context }),
    onSuccess: (data) => {
      setResult({ output: data.output, sources: data.sources });
      setInteractionId(data.interactionId);
      setDecision(data.decision);
      setEditing(null);
      setError(null);
      setDisclosure(null);
      setPendingAction(null);
      refresh();
    },
    onError: (err) => setError(err instanceof Error ? err.message : t.copilot.invokeError),
  });

  const decideMutation = useMutation({
    mutationFn: ({ decision: d, note, modifiedOutput }: { decision: string; note?: string; modifiedOutput?: string }) => {
      if (!interactionId) throw new Error(t.copilot.noInteraction);
      return api.aiDecide(orgId!, interactionId, d, { note, modifiedOutput });
    },
    onSuccess: (data, vars) => {
      // El servidor devuelve la interacción actualizada; si el revisor editó,
      // la salida mostrada debe ser la versión aprobada, no el borrador original.
      const updated = data as { decision?: string; output?: string } | undefined;
      setDecision(String(updated?.decision ?? vars.decision));
      if (updated?.output) {
        setResult((prev) => (prev ? { ...prev, output: updated.output! } : prev));
      }
      setEditing(null);
      setError(null);
      toast.success(t.copilot.decisionSaved);
      refresh();
    },
    onError: (err) => setError(err instanceof Error ? err.message : t.common.saveError),
  });

  const suggestions = SUGGESTIONS[currentView] ?? SUGGESTIONS.home;
  const viewName =
    (t.copilot.viewNames as Record<string, string>)[currentView] ?? currentView;

  /** Pregunta libre: se envía con el caso de uso propio de la pantalla. */
  const submitInput = () => {
    const text = input.trim();
    if (!text || invokeMutation.isPending) return;
    setDisclosure(text);
    setPendingAction({
      useCase: DEFAULT_USE_CASE[currentView] ?? 'summarize',
      entity: currentView,
      context: { query: text },
    });
    setInput('');
  };

  return (
    <>
      {/* FAB */}
      <button
        onClick={() => setOpen(!open)}
        className="fixed right-6 bottom-6 z-40 flex items-center gap-2 bg-navy text-white rounded-full px-5 py-3 text-sm font-bold shadow-lg hover:bg-navy-light transition-colors"
        aria-expanded={open}
      >
        <span className="text-emerald-400">✦</span> {t.copilot.title}
      </button>

      {/* Panel */}
      {open && (
        <aside className="fixed right-0 top-0 bottom-0 w-[min(420px,96vw)] z-40 bg-white border-l border-line shadow-2xl flex flex-col">
          {/* Header */}
          <div className="bg-navy text-white p-5 flex items-center gap-3">
            <div className="size-10 rounded-xl bg-white/10 flex items-center justify-center text-xl">✦</div>
            <div>
              <div className="font-bold">{t.copilot.title}</div>
              <div className="text-[11px] text-emerald-400">● {t.copilot.online}</div>
              <div className="text-[11px] text-white/60">{t.copilot.context}: {viewName}</div>
            </div>
            <button onClick={() => setOpen(false)} className="ml-auto text-white/70 hover:text-white" aria-label={t.common.close}>✕</button>
          </div>

          {/* Body */}
          <div className="flex-1 overflow-y-auto p-5">
            <p className="text-sm text-ink-soft mb-4">
              {t.copilot.ask} <b className="text-ink">{viewName}</b>.
            </p>

            <div className="text-[10.5px] font-bold uppercase tracking-wider text-ink-muted mb-2">
              {t.copilot.suggestionsFor}
            </div>
            <div className="grid grid-cols-2 gap-2 mb-5">
              {suggestions.map((s) => {
                const label = t.copilot.suggestions[s.useCase];
                return (
                  <button
                    key={s.useCase}
                    onClick={() => {
                      setDisclosure(label);
                      setPendingAction({ useCase: s.useCase, entity: currentView, context: s.context });
                    }}
                    className="border border-line rounded-lg px-3 py-2.5 text-xs font-semibold text-left hover:border-primary hover:text-primary transition-colors"
                  >
                    {label}
                  </button>
                );
              })}
            </div>

            {disclosure && pendingAction && (
              <div className="bg-info-bg border border-info/30 rounded-lg p-3 text-xs mb-4">
                <b className="text-info">🔎 {t.copilot.disclosure}</b>
                <p className="mt-1">{disclosure}</p>
                <p className="text-[11px] text-ink-muted mt-1">{t.copilot.sensitiveNotice}</p>
                <div className="flex gap-2 mt-2">
                  <Button size="sm" onClick={() => invokeMutation.mutate(pendingAction)} disabled={invokeMutation.isPending}>
                    {invokeMutation.isPending ? t.copilot.generating : t.copilot.continue}
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => { setDisclosure(null); setPendingAction(null); }}>
                    {t.copilot.cancel}
                  </Button>
                </div>
              </div>
            )}

            {error && (
              <div role="alert" className="bg-danger-bg border border-danger/30 rounded-lg p-3 text-xs text-danger mb-4">
                {error}
              </div>
            )}

            {result && (
              <div className="border border-line rounded-lg p-4">
                <div className="flex gap-2 items-center mb-2">
                  <Badge tone="ok">{t.copilot.draftBadge}</Badge>
                  <Badge tone={decision && decision !== 'PENDING' ? 'ok' : 'warn'} dot={false}>
                    {decision && decision !== 'PENDING' ? t.copilot.decisionSaved : t.copilot.requiresReview}
                  </Badge>
                </div>

                {editing === null ? (
                  <p className="text-sm whitespace-pre-line mb-3">{result.output}</p>
                ) : (
                  <div className="mb-3">
                    <textarea
                      aria-label={t.copilot.editedOutput}
                      value={editing}
                      onChange={(e) => setEditing(e.target.value)}
                      rows={8}
                      className="w-full rounded-btn border border-line px-3 py-2 text-sm outline-none focus:border-primary"
                    />
                    <div className="mt-2 flex gap-2">
                      <Button
                        size="sm"
                        onClick={() => decideMutation.mutate({ decision: 'MODIFIED', modifiedOutput: editing })}
                        disabled={decideMutation.isPending || !editing.trim()}
                      >
                        {t.common.save}
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setEditing(null)}>
                        {t.common.cancel}
                      </Button>
                    </div>
                  </div>
                )}

                <div className="text-xs text-ink-muted mb-3">
                  <b className="text-ink-soft">{t.copilot.sources}:</b>{' '}
                  {result.sources.length ? result.sources.map((s) => s.ref).join(' · ') : t.copilot.noEvidence}
                </div>

                {editing === null && (
                  <div className="flex gap-2 flex-wrap">
                    <Button
                      size="sm"
                      onClick={() => decideMutation.mutate({ decision: 'ACCEPTED' })}
                      disabled={decideMutation.isPending}
                    >
                      {t.copilot.accept}
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => setEditing(result.output)}>
                      {t.copilot.edit}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => decideMutation.mutate({ decision: 'REJECTED' })}
                      disabled={decideMutation.isPending}
                    >
                      {t.copilot.reject}
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => decideMutation.mutate({ decision: 'REPORTED', note: t.copilot.reportedNote })}
                      disabled={decideMutation.isPending}
                    >
                      {t.copilot.report}
                    </Button>
                  </div>
                )}
                <p className="text-[11px] text-warning mt-3">{t.copilot.humanReview}</p>
              </div>
            )}
          </div>

          {/* Footer */}
          <div className="border-t border-line p-4">
            <form
              className="flex items-center gap-2 bg-page border border-line rounded-lg px-3 py-2.5"
              onSubmit={(e) => {
                e.preventDefault();
                submitInput();
              }}
            >
              <input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="flex-1 bg-transparent text-sm outline-none"
                placeholder={`${t.copilot.inputPlaceholder} ${viewName}…`}
                aria-label={t.copilot.inputPlaceholder}
                disabled={invokeMutation.isPending}
              />
              <button
                type="submit"
                className="size-8 rounded-full bg-primary text-white text-sm disabled:opacity-40"
                aria-label={t.copilot.send}
                disabled={!input.trim() || invokeMutation.isPending}
              >
                ↑
              </button>
            </form>
            <p className="text-[10.5px] text-ink-muted mt-2 text-center">{t.copilot.enterToSend} · {t.copilot.disclaimer}</p>
          </div>
        </aside>
      )}
    </>
  );
}
